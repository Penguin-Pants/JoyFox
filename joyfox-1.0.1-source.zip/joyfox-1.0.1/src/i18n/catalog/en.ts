/**
 * The English catalog. It is the source of truth for the message keys: the
 * German catalog is typed against it, so a missing key or a wrong parameter
 * shape fails `npm run typecheck` (docs/i18n-spec.md, Section 3.4).
 *
 * Keys are flat and dotted, grouped by the surface that shows them. A value
 * is a string, or a function of typed params. A function prints every
 * number through `f.number()`, never with a plain `${p.value}`.
 */

/** Locale-aware helpers that t() passes to every catalog function. */
export interface Format {
  /** de: 1.234,5 en: 1,234.5 */
  number(value: number): string;
  plural(value: number, forms: { one: string; other: string }): string;
}

/** A param that the translator fills with an already translated string. */
export type Translated = string & { readonly __translated: true };

type T = Translated;

export const en = {
  // Shared labels
  "placement.qualified": "Qualified",
  "placement.needs-review": "Needs Review",
  "placement.quarantined": "Junk",
  "condition.verified": "Verified by JoyClub",
  "condition.personallyKnown": "Personally known",
  "condition.minimumPhotos": "Minimum photos",
  "condition.minimumProfileWords": "Minimum profile words",
  "condition.minimumAccountAgeDays": "Minimum account age in days",
  "condition.notTemplateSpam": "Not flagged as template spam",
  "condition.minimumTrustScore": "Minimum local trust score",
  "condition.firstMessageContains": "First message contains",
  "field.accountAgeDays": "Account age in days",
  "field.photoCount": "Photo count",
  "field.profileWordCount": "Profile word count",
  "outcome.qualified": "Qualified",
  "outcome.partial-information": "Partial information",
  "outcome.does-not-meet-rule": "Does not meet rule",
  "common.close": "Close",
  "common.openOptions": "Open JoyFox options",
  "common.saveFailed":
    "JoyFox could not save that change. Nothing was changed. Try again. If it keeps failing, reload the page.",
  "legacy.text": (p: { text: string }) => p.text,
  // Shown in place of a damaged or unknown text reference, never its key.
  "common.textUnavailable": "(This text cannot be shown.)",

  // Triage reasons (qualification engine, contact rule, triage service)
  "triage.reason.unknownValue": (p: { field: T }) =>
    `${p.field} is unknown, so it was not counted for or against.`,
  "triage.reason.atOrAbove": (
    p: { field: T; value: number; minimum: number },
    f: Format,
  ) =>
    `${p.field} is ${f.number(p.value)}, at or above the required ${f.number(p.minimum)}.`,
  "triage.reason.belowMinimum": (
    p: { field: T; value: number; minimum: number },
    f: Format,
  ) =>
    `${p.field} is ${f.number(p.value)}, below the required ${f.number(p.minimum)}.`,
  "triage.reason.accountAgeRangeAbove": (
    p: { min: number; max: number; minimum: number },
    f: Format,
  ) =>
    `Account age is between ${f.number(p.min)} and ${f.number(p.max)} days, at or above the required ${f.number(p.minimum)}.`,
  "triage.reason.accountAgeRangeBelow": (
    p: { min: number; max: number; minimum: number },
    f: Format,
  ) =>
    `Account age is between ${f.number(p.min)} and ${f.number(p.max)} days, below the required ${f.number(p.minimum)}.`,
  "triage.reason.accountAgeRangeCoarse": (
    p: { min: number; max: number; minimum: number },
    f: Format,
  ) =>
    `Account age is between ${f.number(p.min)} and ${f.number(p.max)} days, which is too coarse to compare with the required ${f.number(p.minimum)}, so it was not counted for or against.`,
  "triage.reason.verificationUnknown":
    "Verification status is unknown, so it was not counted for or against.",
  "triage.reason.verified": "The profile is verified, as the rule requires.",
  "triage.reason.notVerified":
    "The profile is not verified, which the rule requires.",
  "triage.reason.personallyKnownUnknown":
    "Whether you know this member personally is unknown, so it was not counted for or against.",
  "triage.reason.personallyKnown":
    "You marked this member as personally known, as the rule requires.",
  "triage.reason.notPersonallyKnown":
    "You have not marked this member as personally known, which the rule requires.",
  "triage.reason.noCriteria":
    "No qualification criteria are configured, so every sender qualifies.",
  "triage.reason.spamFlagged":
    "A message from this sender looks like a copied template.",
  "triage.reason.spamNotFlagged":
    "No message from this sender looks like a copied template.",
  "triage.reason.spamOverridden": "You marked this sender as not spam.",
  "triage.reason.spamUnknown":
    "JoyFox has not checked this sender's messages for templates, so spam status is unknown.",
  "triage.reason.phraseSeenNow": (p: { text: string }) =>
    `The latest message from this sender contains "${p.text}".`,
  "triage.reason.phraseSeenBefore": (p: { text: string }) =>
    `An earlier message from this sender, seen in your inbox, contains "${p.text}".`,
  "triage.reason.phraseNotInLatest": (p: { text: string }) =>
    `The latest message from this sender does not contain "${p.text}". The inbox shows only the latest message, so JoyFox cannot see if the first message contained it.`,
  "triage.reason.phraseNotSeen": (p: { text: string }) =>
    `JoyFox has not seen a message from this sender that contains "${p.text}". Only the inbox shows messages to JoyFox.`,
  "triage.reason.trustUnknown":
    "You have logged nothing about this member, so the local trust score is unknown.",
  "triage.reason.trustAtOrAbove": (
    p: { score: number; minimum: number },
    f: Format,
  ) =>
    `Your local trust score is ${f.number(p.score)}, at or above the required ${f.number(p.minimum)}.`,
  "triage.reason.trustBelow": (
    p: { score: number; minimum: number },
    f: Format,
  ) =>
    `Your local trust score is ${f.number(p.score)}, below the required ${f.number(p.minimum)}.`,
  "triage.reason.negatedMet": (p: { reason: T; condition: T }) =>
    `${p.reason} Your rule says "not ${p.condition}", so this counts as met.`,
  "triage.reason.negatedNotMet": (p: { reason: T; condition: T }) =>
    `${p.reason} Your rule says "not ${p.condition}", so this counts as not met.`,
  "triage.reason.unknownNeedsReview": (p: { reason: T }) =>
    `${p.reason} Your rule sends unknown values to Needs Review.`,
  "triage.reason.unknownMet": (p: { reason: T }) =>
    `${p.reason} Your rule counts an unknown value as met.`,
  "triage.reason.unknownNotMet": (p: { reason: T }) =>
    `${p.reason} Your rule counts an unknown value as not met.`,
  "triage.reason.numbered": (p: { number: number; reason: T }, f: Format) =>
    `Group ${f.number(p.number)}: ${p.reason}`,
  "triage.reason.userMoved": (p: { placement: T }) =>
    `You moved this sender to ${p.placement}.`,
  "triage.headline.noConditions":
    "Your contact rule has no required conditions, so every sender qualifies.",
  "triage.headline.meets": "This sender meets your contact rule.",
  "triage.headline.undecided":
    "JoyFox could not decide, because some information is unknown.",
  "triage.headline.doesNotMeet": (p: { placement: T }) =>
    `This sender does not meet your contact rule, so JoyFox places them in ${p.placement}.`,

  // Trust score
  "trust.reason.positive": (p: { count: number }, f: Format) =>
    `You logged ${f.plural(p.count, {
      one: "1 positive outcome",
      other: `${f.number(p.count)} positive outcomes`,
    })}.`,
  "trust.reason.negative": (p: { count: number }, f: Format) =>
    `You logged ${f.plural(p.count, {
      one: "1 negative outcome",
      other: `${f.number(p.count)} negative outcomes`,
    })}.`,
  "trust.reason.neutral": (p: { count: number }, f: Format) =>
    `You logged ${f.plural(p.count, {
      one: "1 neutral outcome",
      other: `${f.number(p.count)} neutral outcomes`,
    })}, which count 0.`,
  "trust.reason.personallyKnown": "You marked this member as personally known.",
  "trust.reason.spamFlagged":
    "A message from this member looks like a copied template.",
  "trust.scopeNote":
    "Based only on what you logged and saw in this browser. It is not a JoyClub or community rating.",

  // Template spam detector
  "spam.detail.override":
    "You marked this sender as not spam, so their messages are never flagged.",
  "spam.detail.belowMinimum": (
    p: { words: number; minimum: number },
    f: Format,
  ) =>
    `The message has ${f.plural(p.words, {
      one: "1 word",
      other: `${f.number(p.words)} words`,
    })}, below the ${f.number(p.minimum)} needed before template matching runs.`,
  "spam.detail.duplicate": (p: { percent: number }, f: Format) =>
    `This message closely matches an earlier message you received (${f.number(p.percent)}% similar).`,
  "spam.detail.knownPhrase":
    "The message contains a phrase from your known-template list.",
  "spam.detail.phraseSimilar": (p: { percent: number }, f: Format) =>
    `The message closely matches a phrase from your known-template list (${f.number(p.percent)}% similar).`,
  "spam.detail.noMatch":
    "The message matched no earlier message and no known template phrase.",

  // Quick Ignore and Delete (M9): the report built from ActionLog steps
  "action.step.ignore": "Ignore",
  "action.step.delete": "Delete",
  "action.where.before": (p: { step: T }) => `before ${p.step}`,
  "action.where.during": (p: { step: T }) => `during ${p.step}`,
  "action.failure.control-missing": (p: { step: T }) =>
    `JoyFox could not find JoyClub's ${p.step} option on this page.`,
  "action.failure.confirmation-missing": (p: { step: T }) =>
    `JoyClub's confirmation for ${p.step} did not appear.`,
  "action.failure.not-verified": (p: { step: T }) =>
    `JoyClub did not show that ${p.step} succeeded.`,
  "action.failure.unverifiable": (p: { step: T; where: T }) =>
    `JoyFox cannot see JoyClub's result for ${p.step} on this page, so it stopped ${p.where}.`,
  "action.failure.member-mismatch": (p: { where: T }) =>
    `The page showed another member, so JoyFox stopped ${p.where}.`,
  "action.failure.conversation-mismatch": (p: { where: T }) =>
    `The page showed another conversation, so JoyFox stopped ${p.where}.`,
  "action.failure.identity-unavailable": (p: { where: T }) =>
    `JoyFox could not confirm which member or conversation the page shows, so it stopped ${p.where}.`,
  "action.failure.account-changed": (p: { where: T }) =>
    `The active JoyFox account changed, so JoyFox stopped ${p.where}.`,
  "action.failure.turned-off": (p: { where: T }) =>
    `Ignore and Delete was turned off, so JoyFox stopped ${p.where}.`,
  "action.failure.superseded": (p: { where: T }) =>
    `A newer JoyFox run for this member started, so JoyFox stopped ${p.where}.`,
  "action.failure.log-unavailable": (p: { where: T }) =>
    `JoyFox could not write to its action log, so it stopped ${p.where}.`,
  "action.failure.handoff-failed": (p: { where: T }) =>
    `JoyFox could not move on to the member's profile, so it stopped ${p.where}.`,
  "action.failure.timeout": (p: { step: T }) =>
    `JoyClub did not respond in time during ${p.step}.`,
  "action.failure.step-error": (p: { where: T }) =>
    `An unexpected error stopped JoyFox ${p.where}.`,
  "action.stepText.ignore.done": "Ignore: done. JoyClub ignores this member.",
  "action.stepText.ignore.not-done": "Ignore: not done.",
  "action.stepText.ignore.unknown":
    "Ignore: not confirmed. JoyFox started it but did not see JoyClub confirm it.",
  "action.stepText.delete.done":
    "Delete: done. JoyClub moved the conversation to the trash.",
  "action.stepText.delete.not-done": "Delete: not done.",
  "action.stepText.delete.unknown":
    "Delete: not confirmed. JoyFox started it but did not see JoyClub confirm it.",
  "action.next.ignore":
    "Next: open the member's profile and check whether they are ignored. If not, ignore them there yourself.",
  "action.next.delete":
    "Next: open the conversation and check whether it is in the trash. If not, move it there yourself with JoyClub's trash button.",
  "action.next.showList":
    "Delete works only while this conversation shows in the ClubMail list beside it. Widen the window, or scroll the list until the conversation shows, then try again.",
  "action.self.ignore":
    "You can do it yourself: open the member's profile and ignore them there.",
  "action.self.delete":
    "You can do it yourself: move the conversation to the trash with JoyClub's trash button.",
  "action.report.finished": "Ignore and Delete finished.",
  "action.report.undo":
    "To undo, restore the conversation from JoyClub's trash. Then open the member's profile and choose \"Profil nicht mehr ignorieren\" in its menu.",
  "action.report.running": "Ignore and Delete is running.",
  "action.report.stopped": "Ignore and Delete stopped.",
  "action.report.interrupted":
    "Ignore and Delete was interrupted, for example because the tab closed.",
  "action.report.nothingChanged": "Nothing was changed on JoyClub.",
  "action.report.notUndone": "JoyFox did not undo anything.",
  "action.deleteReport.finished": "Delete finished.",
  "action.deleteReport.undo":
    "To undo, restore the conversation from JoyClub's trash.",
  "action.deleteReport.running": "Delete is running.",
  "action.deleteReport.stopped": "Delete stopped.",
  "action.deleteReport.interrupted":
    "Delete was interrupted, for example because the tab closed.",

  // Content script: the Delete and Ignore and Delete buttons and notice
  "quick.progress.Started": "Ignore and Delete is running. Checking the page.",
  "quick.delete.progress.Started": "Delete is running. Checking the page.",
  "quick.progress.DeleteRequested": "Moving the conversation to the trash.",
  "quick.progress.DeleteConfirmed":
    "Delete done. Opening the member's profile to ignore them there.",
  "quick.progress.IgnoreRequested": "Ignoring the member on JoyClub.",
  "quick.button": "Ignore and Delete",
  "quick.region": "JoyFox conversation actions",
  "quick.delete.button": "Delete",
  "quick.delete.scope":
    "One click moves this conversation to JoyClub's trash, then returns to the ClubMail list. The member is not ignored. JoyFox stops at the first problem and tells you what was done. It never sends a message.",
  "quick.scope":
    "Experimental. One click moves this conversation to JoyClub's trash, then opens the member's profile and ignores them there. JoyFox stops at the first problem and tells you what was done. It never sends a message.",
  "quick.needsList":
    "Works only while this conversation shows in the ClubMail list beside it. Widen the window, or scroll the list until the conversation shows.",
  "quick.noProfile":
    "JoyFox cannot find the link to this member's profile, where Ignore is, so it did nothing. You can do it yourself: move the conversation to the trash with JoyClub's trash button, then open the member's profile and ignore them there.",
  "quick.resumed": "Ignore and Delete, continued from the conversation:",
  "quick.waitingMenu": "Waiting for JoyClub's profile menu…",
  "quick.previous": "Your last Ignore and Delete for this member:",
  "quick.previousOther":
    "Your last Ignore and Delete for this member, in another conversation:",
  "quick.otherResult": "Your last Ignore and Delete, for another conversation:",
  "quick.delete.previous": "Your last Delete for this member:",
  "quick.delete.previousOther":
    "Your last Delete for this member, in another conversation:",
  "quick.delete.otherResult": "Your last Delete, for another conversation:",
  "quick.otherRunning":
    "A JoyFox run is still going for another conversation. Wait until it ends.",
  "quick.busy":
    "Another JoyFox run for this member is still going, for example in another tab. Nothing was done here.",
  "quick.junk.done":
    "Mark as junk: the sender is in Junk, and a Negative outcome is logged.",
  "quick.junk.busy":
    "Another JoyFox run for this member is still going, so JoyFox did not start the trash step.",
  "quick.junk.notTrashed": "The conversation was not moved to the trash.",
  "quick.delete.unexpected":
    "Delete stopped because of an unexpected error. JoyFox may have moved the conversation to the trash: check JoyClub's trash yourself.",
  "quick.unexpected":
    "Ignore and Delete stopped because of an unexpected error. JoyFox may have completed a step: check the member's profile and the conversation yourself.",

  // Content script: triage explanation, member bar and trust controls
  "triage.outcome.met": "Met",
  "triage.outcome.not-met": "Not met",
  "triage.outcome.needs-review": "Needs Review",
  "triage.conditions.summary": (p: { count: number }, f: Format) =>
    `All checked conditions (${f.number(p.count)})`,
  "triage.condition.line": (p: { outcome: T; condition: T }) =>
    `${p.outcome}: ${p.condition}. `,
  "triage.condition.lineNegated": (p: { outcome: T; condition: T }) =>
    `${p.outcome}: not ${p.condition}. `,
  "triage.placementLine": (p: { placement: T; source: T }) =>
    `Placement: ${p.placement} (${p.source}).`,
  "triage.source.override": "your manual choice",
  "triage.source.rule": "your contact rule",
  "triage.source.sharedEvent": "the shared-event exception",
  "triage.sharedEvent.attending": (p: { event: string; when: string }) =>
    `On the guest list of "${p.event}"${p.when ? ` (${p.when})` : ""}, which you marked Attending.`,
  "triage.sharedEvent.attended": (p: { event: string; when: string }) =>
    `On the guest list of "${p.event}"${p.when ? ` (${p.when})` : ""}, which you marked Attended.`,
  "triage.sharedEvent.optOut": "Don't use the shared event for this sender",
  "triage.movedOn": (p: { date: string; placement: T }) =>
    `You moved this sender on ${p.date}. Your rule alone would place them in ${p.placement}.`,
  "triage.place.group": "Place this sender",
  "triage.useRule": "Use my rule again",
  "mark.group": "Mark this sender",
  "mark.qualified": "Mark qualified",
  "mark.junk": "Mark as junk",
  "mark.trustFailed": (p: { placement: T }) =>
    `JoyFox placed this sender in ${p.placement} but could not log the trust outcome, so it stopped there. You can log it on the member's conversation or profile page.`,
  "mark.junk.noTrash":
    "The sender is in Junk, and a Negative outcome is logged. JoyFox could not move this conversation to the trash here. Move it there yourself with JoyClub's trash button.",
  "triage.profileFact.minimumPhotos": "photo count",
  "triage.profileFact.minimumProfileWords": "profile word count",
  "triage.profileFact.minimumAccountAgeDays": "account age",
  "triage.unknownFacts.one": (p: { fact: T }) =>
    `The ${p.fact} is unknown. Open the profile and JoyFox reads it.`,
  "triage.unknownFacts.two": (p: { first: T; second: T }) =>
    `The ${p.first} and ${p.second} are unknown. Open the profile and JoyFox reads them.`,
  "triage.unknownFacts.three": (p: { first: T; second: T; third: T }) =>
    `The ${p.first}, ${p.second} and ${p.third} are unknown. Open the profile and JoyFox reads them.`,
  "trust.score.none": "Local trust score: no history yet.",
  "trust.score.value": (p: { score: number }, f: Format) =>
    `Local trust score: ${f.number(p.score)}.`,
  "trust.details.summary": "How the score adds up",
  "trust.contribution": (p: { points: number; reason: T }, f: Format) =>
    `${p.points > 0 ? "+" : ""}${f.number(p.points)}: ${p.reason}`,
  "trust.log.group": "Log how it went with this member",
  "trust.log.positive": "Log positive",
  "trust.log.neutral": "Log neutral",
  "trust.log.negative": "Log negative",
  "trust.log.undo": "Undo last outcome",
  "bar.placementPrefix": "Placement: ",
  "bar.yourChoice": "(your choice)",
  "bar.sharedEvent": "(shared event)",
  "bar.openProfile": "Open profile",
  "bar.log": "Log:",
  "bar.positive": "Positive",
  "bar.neutral": "Neutral",
  "bar.negative": "Negative",
  "bar.undo": "Undo",
  "bar.details": "Details",
  "strip.collapse": "Collapse JoyFox",
  "strip.expand": "Expand JoyFox",
  "bar.scoreDetails": "Score details",
  "panel.ruleOff.no-rule":
    "No contact rule is set, so JoyFox does not place this sender.",
  "panel.ruleOff.rule-disabled":
    "Your contact rule is turned off, so JoyFox does not place this sender.",
  "panel.ruleOff.other":
    "JoyFox cannot place this sender right now. Reload the page to try again.",
  "panel.ruleOff.no-account":
    "No JoyFox account is active, so JoyFox shows nothing for this member.",

  // Content script: inbox triage
  "inbox.region": "JoyFox triage",
  "inbox.views": "Show messages",
  "inbox.view.default": "Inbox",
  "inbox.view.all": "Show all",
  "inbox.viewCount": (p: { view: T; count: number }, f: Format) =>
    `${p.view} (${f.number(p.count)})`,
  "inbox.about": "About these views",
  "inbox.aboutText":
    "Inbox hides Junk rows from this view only. Nothing is deleted, and JoyFox changes nothing on JoyClub.",
  "inbox.checking": "Checking",
  "inbox.badge": (p: { text: T }) => `JoyFox: ${p.text}. Details.`,
  "inbox.why": "Details",
  "inbox.whyNamed": (p: { name: string }) => `Details: ${p.name}`,
  "inbox.rowGone": "This row is no longer shown.",
  "inbox.unidentified":
    "JoyFox could not read this sender's profile number, so it could not check your rule. The row stays visible.",
  "inbox.stillChecking": "JoyFox is still checking this sender.",
  "inbox.setup.no-account":
    "JoyFox has no active account, so it does not sort this inbox.",
  "inbox.setup.no-rule":
    "No contact rule is saved, so JoyFox does not sort this inbox.",

  // Content script: notes and tags
  "notes.region": "JoyFox notes and tags",
  "notes.scope":
    "Private to JoyFox: stored only in this browser, under the active JoyFox account. JoyFox never sends it anywhere.",
  "notes.saved": "Note saved.",
  "notes.removed": "Note removed.",
  "notes.conflict":
    "This note changed in another tab or in the JoyFox data inspector, so JoyFox did not save your text. It is still in the box. Save again to replace the stored note, or discard your changes to see it.",
  "notes.refused":
    "The active JoyFox account changed, so nothing was stored. Text typed for the previous account was dropped.",
  "notes.emptyTag": "Type a tag first. Nothing was added.",
  "notes.emptyNote": "Type a note first. Nothing was saved.",
  "notes.tagAdded": "Tag added.",
  "notes.tagExists": "Already tagged.",
  "notes.tagRemoved": "Tag removed.",
  "notes.privateNote": "Private note",
  // Shown under a note box once the text is near its limit.
  "notes.length": (p: { count: number; maximum: number }, f: Format) =>
    `${f.number(p.count)} of ${f.number(p.maximum)} characters`,
  "notes.pasteCut":
    "Only part of the pasted text fit. The rest was not pasted.",
  "notes.discard": "Discard my changes",
  "notes.save": "Save note",
  "notes.tags": "Tags",
  "notes.noTags": "No tags yet.",
  "notes.remove": "Remove",
  "notes.removeTag": (p: { label: string }) => `Remove tag ${p.label}`,
  "notes.addTagLabel": "Add a tag",
  "notes.addTag": "Add tag",
  "notes.summary.none": "Your notes and tags (none yet)",
  "notes.summary.note": "Your notes and tags (a note)",
  "notes.summary.tags": (p: { count: number }, f: Format) =>
    `Your notes and tags (${f.plural(p.count, {
      one: "1 tag",
      other: `${f.number(p.count)} tags`,
    })})`,
  "notes.summary.noteAndTags": (p: { count: number }, f: Format) =>
    `Your notes and tags (a note and ${f.plural(p.count, {
      one: "1 tag",
      other: `${f.number(p.count)} tags`,
    })})`,

  // Content script: event and venue notes (V1-5)
  "listing.heading.event": "JoyFox: your notes on this event",
  "listing.heading.venue": "JoyFox: your notes on this venue",
  // The box's summary: what is stored, for example "Attending, 2 tags, a note".
  "listing.summary.event": (p: { state: string }) =>
    `JoyFox: your notes on this event (${p.state})`,
  "listing.summary.venue": (p: { state: string }) =>
    `JoyFox: your notes on this venue (${p.state})`,
  "listing.summary.none": "none yet",
  "listing.summary.note": "a note",
  "listing.loading": "Loading your notes…",
  "listing.readFailed":
    "JoyFox could not read your notes on this page. Reload the page to try again.",
  "listing.noAccount":
    "Select or add an account in the JoyFox options to keep notes on events.",
  "listing.attendanceLabel": "Your attendance",
  "listing.attendance.unknown": "No status",
  "listing.attendance.interested": "Interested",
  "listing.attendance.attending": "Attending",
  "listing.attendance.not-attending": "Not attending",
  "listing.attendance.attended": "Attended",
  "listing.noteLabel": "Your note",
  "listing.saveNote": "Save note",
  "listing.tagsLabel": "Your tags",
  "listing.tagLabel": "New tag",
  "listing.addTag": "Add tag",
  "listing.removeTag": (p: { tag: string }) => `Remove tag ${p.tag}`,
  "listing.emptyTag": "Type a tag first. Nothing was added.",
  "listing.tooManyTags.event": (p: { maximum: number }, f: Format) =>
    `You can add at most ${f.number(p.maximum)} tags to an event. Remove one first.`,
  "listing.tooManyTags.venue": (p: { maximum: number }, f: Format) =>
    `You can add at most ${f.number(p.maximum)} tags to a venue. Remove one first.`,
  "listing.privacy":
    "Private: stored only in this browser. JoyClub sees nothing, and your sign-up on JoyClub does not change.",
  "listing.saved": "Saved.",
  // The first save of an event or venue.
  "listing.tracked.event": "Saved. JoyFox now tracks this event.",
  "listing.tracked.venue": "Saved. JoyFox now tracks this venue.",
  "listing.removed.event":
    "No note, tag or attendance is left, so JoyFox no longer tracks this event.",
  "listing.removed.venue":
    "No note or tag is left, so JoyFox no longer tracks this venue.",
  "listing.conflict":
    "These notes changed in another tab, so JoyFox did not save. The stored notes are shown now; your typed note is still in the box.",
  "listing.refused": "The active JoyFox account changed, so nothing was saved.",

  // Options page: personal event calendar (V1-5)
  "events.heading": "Your events",
  "events.hint":
    "Every event and venue you added a note, tag or attendance to on JoyClub, in date order. JoyFox keeps them after JoyClub removes an event. To change one, open it on JoyClub.",
  "events.readFailed":
    "JoyFox could not read your events. Reload the page to try again.",
  "events.noAccount":
    "Select or add an account first. Each account has its own events.",
  "events.empty":
    "No tracked events yet. Open an event on JoyClub and add a note, a tag or your attendance.",
  "events.count": (p: { shown: number; total: number }, f: Format) =>
    `${f.number(p.shown)} of ${f.number(p.total)} tracked events shown.`,
  "events.filterLabel": "Show",
  "events.filter.all": "All tracked events",
  "events.searchLabel": "Search my notes, tags and titles",
  "events.noDate": "No date",
  "events.untitled": (p: { id: string }) => `Event ${p.id}`,
  "events.past": (p: { when: string }) => `${p.when} (past)`,
  "events.venue": (p: { venue: string }) => `Venue: ${p.venue}`,
  "events.venuesHeading": "Your venues",
  "events.guests": (p: { count: number }, f: Format) =>
    f.plural(p.count, {
      one: "1 guest stored",
      other: `${f.number(p.count)} guests stored`,
    }),
  "events.exception.label":
    "Shared-event exception: place a sender in Qualified when they are on the guest list of an event I marked Attending or Attended",
  "events.exception.hint":
    'Off by default. JoyFox stores a tracked event\'s guest list when you open the event page, as far as JoyClub has loaded it, and deletes it when you stop tracking the event. A sender you marked yourself keeps your choice, and the "Details" panel can turn the exception off for one sender.',
  "events.exception.saved": "Saved.",
  "events.exception.saveFailed":
    "JoyFox could not save this setting. Try again.",
  // Options page: the switch for the experimental Ignore and Delete (M9)
  "quickSetting.heading": "Ignore and Delete",
  "quickSetting.label":
    'Show the "Ignore and Delete" button on ClubMail conversations',
  "quickSetting.hint":
    'Experimental and on by default. One click moves the conversation to JoyClub\'s trash, opens the member\'s profile in the same tab and ignores the member there. It works only while the ClubMail list shows beside the conversation. JoyFox acts only when you click. The "Action log" in "Your data" records every step. This setting controls only "Ignore and Delete": the "Delete" button and "Mark as junk" move a conversation to JoyClub\'s trash also when it is off.',
  "quickSetting.risk":
    "If JoyClub finds a tool that clicks for you, it can restrict or close your account. Of all JoyFox features, this one has the highest risk.",
  "quickSetting.undo":
    "To undo, restore the conversation from JoyClub's trash. Then open the member's profile and choose \"Profil nicht mehr ignorieren\" in its menu.",
  "quickSetting.saved": "Saved. Open ClubMail tabs follow at once.",
  "quickSetting.saveFailed": "JoyFox could not save this setting. Try again.",
  "sharedEvents.heading": "Shared events",
  "sharedEvents.intro":
    "This member is on the stored guest list of these events you track:",

  // Content script: event list filter (V1-5)
  "eventFilter.label": "JoyFox: show",
  "eventFilter.all": "All loaded events and dates",
  "eventFilter.tracked": "Only events JoyFox tracks",
  "eventFilter.note": "Only events with your note",
  "eventFilter.attending": "Only events you attend",
  "eventFilter.interested": "Only events you are interested in",
  "eventFilter.tag": (p: { tag: string }) =>
    `Only events with your tag: ${p.tag}`,
  "eventFilter.count": (p: { shown: number; loaded: number }, f: Format) =>
    `${f.number(p.shown)} of ${f.number(p.loaded)} loaded events shown. Events loaded later are checked too.`,
  "eventFilter.readFailed":
    "JoyFox could not read your event notes. Reload the page to try again.",
  "eventFilter.noAccount":
    "Select or add an account in the JoyFox options to filter by your notes.",
  "eventFilter.badge": "JoyFox",
  "eventFilter.hasNote": "note",

  // Content script: profile type filter on the "My JOY" lists (V1-14)
  "typeFilter.legend": "Profile type",
  "typeFilter.man": "Man",
  "typeFilter.woman": "Woman",
  "typeFilter.couple": "Couple",
  "typeFilter.unknown": "Unknown",
  "typeFilter.count": (p: { shown: number; loaded: number }, f: Format) =>
    `Showing ${f.number(p.shown)} of ${f.number(p.loaded)} loaded`,
  "typeFilter.unknownHidden": (p: { count: number }, f: Format) =>
    `${f.number(p.count)} with unknown type hidden`,
  "typeFilter.scrollHint": "Scroll down to load more.",
  "typeFilter.unknownMark": "Type unknown",

  // Options page: message search (V1-4)
  "messages.heading": "Message search",
  "messages.hint":
    "JoyFox stores the ClubMail messages you open, sent and received, so you can search them here. It stores only what a conversation shows on screen and never loads older messages. The text stays in this browser, and an export file holds it too. If you allow JoyFox in private windows, it stores the messages you open there in the same way.",
  "messages.caching": "Store the messages I open in ClubMail",
  "messages.cachingOn": "Message storing is on.",
  "messages.cachingOff":
    'Message storing is off. Messages stored before stay until they are older than the time set here, or until you delete them under "Your data".',
  "messages.offHint":
    "Storing is off: JoyFox stores no new messages. Search still covers the messages stored before.",
  "messages.retentionLabel": "Keep messages for (months)",
  "messages.retentionSave": "Save",
  "messages.retentionHint": (p: { default: number }, f: Format) =>
    `Messages older than this are deleted automatically. Lowering the number deletes older messages at once. The default is ${f.number(p.default)}. Click "Save" to apply.`,
  // Save asks for a second click when the number goes down, as deletes do.
  "messages.retentionConfirm": "Save and delete",
  "messages.retentionConfirmPrompt": (p: { months: number }, f: Format) =>
    `Lowering the number deletes the stored messages older than ${f.plural(
      p.months,
      { one: "1 month", other: `${f.number(p.months)} months` },
    )} at once. Click "Save and delete" to confirm.`,
  "messages.retentionSaved": (p: { deleted: number }, f: Format) =>
    p.deleted === 0
      ? "Saved. No older message needed deleting."
      : `Saved. ${f.plural(p.deleted, {
          one: "1 older message was",
          other: `${f.number(p.deleted)} older messages were`,
        })} deleted.`,
  "messages.retentionInvalid": (
    p: { minimum: number; maximum: number },
    f: Format,
  ) =>
    `Enter a whole number from ${f.number(p.minimum)} to ${f.number(p.maximum)}. Nothing was changed.`,
  "messages.noAccount": "Select or add an account first.",
  "messages.readFailed":
    "JoyFox could not read your stored messages. Reload the page to try again.",
  "messages.searchLabel": "Search my messages",
  "messages.count": (p: { count: number }, f: Format) =>
    p.count === 0
      ? "No stored message contains this."
      : `${f.plural(p.count, {
          one: "1 message",
          other: `${f.number(p.count)} messages`,
        })} found.`,
  "messages.countLimited": (p: { count: number; shown: number }, f: Format) =>
    `${f.number(p.count)} messages found. The newest ${f.number(p.shown)} are shown.`,
  // `member` is the member's nickname, or `member.number` when JoyFox has
  // never seen it.
  "messages.sentTo": (p: { member: string; when: string }) =>
    `You to ${p.member} · ${p.when}`,
  "messages.receivedFrom": (p: { member: string; when: string }) =>
    `${p.member} to you · ${p.when}`,
  "messages.storedAt": (p: { when: string }) => `stored ${p.when}`,

  // Content script: profile signals on cards (V1-10)
  "signals.state.complete": "Complete",
  "signals.state.incomplete": "Incomplete",
  "signals.state.unknown": "Completeness unknown",
  // The inbox row's compact line: the full text is in the tooltip.
  "signals.state.unknownShort": "Unknown",
  "signals.photos": (p: { count: number }, f: Format) =>
    f.plural(p.count, {
      one: "1 photo",
      other: `${f.number(p.count)} photos`,
    }),
  "signals.photosUnknown": "photos unknown",
  "signals.words": (p: { count: number }, f: Format) =>
    f.plural(p.count, {
      one: "1 word",
      other: `${f.number(p.count)} words`,
    }),
  "signals.wordsUnknown": "words unknown",
  "signals.verified": "verified",
  "signals.notVerified": "not verified",
  "signals.verificationUnknown": "verification unknown",
  "signals.heading": "Profile completeness",
  "signals.trust": (p: { score: number }, f: Format) =>
    `Trust ${p.score > 0 ? "+" : ""}${f.number(p.score)}`,
  "signals.trustNoneShort": "Trust –",
  "signals.noteAdd": "Add note",
  "signals.noteEdit": "Note",
  "signals.tagsLabel": "Your tags",
  "signals.tagCount": (p: { count: number }, f: Format) =>
    f.plural(p.count, {
      one: "1 tag",
      other: `${f.number(p.count)} tags`,
    }),
  "signals.editor.label": (p: { member: string }) =>
    `JoyFox: note and tags for ${p.member}`,
  // A member whose nickname JoyFox has never seen.
  "member.number": (p: { id: string }) => `Member ${p.id}`,
  "signals.editor.loading": "Loading…",
  "signals.editor.close": "Close",
  "signals.editor.noAccount":
    "Select or add an account in the JoyFox options to keep notes.",
  "signals.editor.readFailed":
    "JoyFox could not read this member's notes. Close and try again.",
  "signals.filter.label": "JoyFox: hide incomplete profiles",
  "signals.filter.count": (p: { hidden: number; loaded: number }, f: Format) =>
    `${f.number(p.hidden)} of ${f.number(p.loaded)} loaded profiles hidden. Profiles JoyFox knows nothing about stay visible.`,

  // Content script: compatibility overlay (V1-2)
  "compat.heading": "Shared preferences",
  "compat.shared": (p: { count: number }, f: Format) =>
    `You share ${f.plural(p.count, {
      one: "1 preference",
      other: `${f.number(p.count)} preferences`,
    })} with this member:`,
  "compat.none": "You share no preferences with this member.",
  "compat.listToggle": "Show the shared preferences",
  "compat.own": (p: { count: number }, f: Format) =>
    `This is your profile. JoyFox compares other profiles with your ${f.plural(
      p.count,
      {
        one: "1 positive preference",
        other: `${f.number(p.count)} positive preferences`,
      },
    )}.`,
  "compat.ownUnknown":
    "Open your own JoyClub profile once, so JoyFox knows your preferences.",
  "compat.unreadable": "JoyFox could not read this profile's preferences yet.",
  "compat.missing": "This profile shows no preferences to compare.",
  "compat.readFailed":
    "JoyFox could not load your preferences. Reload the page to try again.",
  "compat.noAccount":
    "Select or add an account in the JoyFox options to compare preferences.",
  "compat.badge": (p: { count: number }, f: Format) =>
    `${f.number(p.count)} shared`,
  "compat.badgeLabel": (p: { count: number }, f: Format) =>
    `JoyFox: ${f.plural(p.count, {
      one: "1 shared preference",
      other: `${f.number(p.count)} shared preferences`,
    })}`,
  "compat.sort.button": "Sort by shared preferences",
  "compat.sort.on":
    "Sorted by shared preferences. Members whose profile you have not opened come last.",
  "compat.sort.unavailable":
    "JoyFox cannot sort the results as JoyClub shows them now. Their order has not changed.",

  // Content script: saved searches (V1-3)
  "searches.heading": "JoyFox saved searches",
  "searches.loading": "Loading saved searches…",
  "searches.readFailed":
    "JoyFox could not read your saved searches. Reload the page to try again.",
  "searches.empty": "No saved searches yet.",
  "searches.noAccount":
    "Select or add an account in the JoyFox options to save searches.",
  "searches.save": "Save this search",
  "searches.nameLabel": "Name for this search",
  "searches.confirmSave": "Save",
  "searches.cancel": "Cancel",
  "searches.noName": "Type a name first. Nothing was saved.",
  "searches.nameTooLong": (p: { maximum: number }, f: Format) =>
    `A name can have at most ${f.number(p.maximum)} characters. Nothing was saved.`,
  "searches.notSearchAddress":
    "This page's address is not a search JoyFox can save. Nothing was saved.",
  "searches.full": (p: { maximum: number }, f: Format) =>
    `You have ${f.number(p.maximum)} saved searches, the most JoyFox keeps. Delete one first.`,
  "searches.refused":
    "The active JoyFox account changed, so nothing was changed.",
  "searches.saved": (p: { name: string }) => `Saved "${p.name}".`,
  "searches.noMatch": (p: { name: string }) =>
    `"${p.name}" no longer matches JoyClub's search address, so JoyFox did not open it. Run the search again and save it again.`,
  "searches.running": (p: { name: string }) => `Running "${p.name}"…`,
  "searches.runningUnnamed": "Running the saved search…",
  "searches.shown": (p: { name: string }) => `Showing "${p.name}".`,
  "searches.shownUnnamed": "Showing the saved search.",
  "searches.runFailed":
    'JoyFox could not run the saved search. Open JoyClub\'s filter and click "Anwenden".',
  "searches.deleteLabel": (p: { name: string }) =>
    `Delete saved search ${p.name}`,
  "searches.confirmDelete": (p: { name: string }) =>
    `Click ✕ again to delete "${p.name}".`,
  "searches.deleted": (p: { name: string }) => `Deleted "${p.name}".`,

  // Content script: template picker
  "picker.toggle": "JoyFox templates",
  "picker.loading": "Loading templates…",
  "picker.readFailed":
    'JoyFox could not load your templates. Nothing was inserted. Click "JoyFox templates" again to try again.',
  "picker.empty": "No templates yet. Add them on the JoyFox options page.",
  "picker.noAccount":
    "No JoyFox account is active. Choose one on the JoyFox options page.",
  "picker.result.inserted":
    "Template inserted. Check the text, then click JoyClub's Send button yourself.",
  "picker.result.not-editable":
    "The message field cannot be edited right now. Nothing was inserted. Wait until you can type in the message field, then try again.",
  "picker.result.too-long": (p: { over: number; limit: number }, f: Format) =>
    `With the template, the message would be ${f.plural(p.over, {
      one: "1 character",
      other: `${f.number(p.over)} characters`,
    })} too long. The message field takes at most ${f.number(p.limit)} characters. Nothing was inserted. Shorten your text or the template.`,
  "picker.result.altered":
    "JoyClub changed the text after insertion. Check the message field before you send.",
  "templates.folder.general": "General",
  "templates.folder.eventConfirmation": "Event confirmation",
  "templates.folder.eventCancellation": "Event cancellation",

  // Options page: shell and tabs
  "options.title": "JoyFox options",
  "options.intro":
    "JoyFox stores everything locally in this browser profile. Inbox sorting stays off until you save a contact rule.",
  "options.tabs.start": "Get started",
  "options.tabs.accounts": "Accounts",
  "options.tabs.rule": "Contact rule",
  "options.tabs.templates": "Templates",
  "options.tabs.events": "Events",
  "options.tabs.messages": "Messages",
  "options.tabs.data": "Your data",
  "options.importRegion": "Import JoyFox data",
  "options.languageSaveFailed":
    "JoyFox could not save the language. Try again.",

  // Options page: Get started
  "start.state.done": "Done",
  "start.state.off": "Saved, but turned off",
  "start.state.todo": "Not done yet",
  "start.state.doneOpen": "Done: no conditions, so every sender qualifies",
  "start.ready": "JoyFox is set up. Open your JoyClub inbox to see it sorted.",
  "start.intro":
    "Three steps, a few minutes. Everything stays in this browser.",
  "start.introAccess":
    "Four steps, a few minutes. Everything stays in this browser.",
  "start.readFailed":
    "JoyFox could not read its setup. Reload the page to try again.",
  "start.step.access":
    "Allow JoyFox to access joyclub.de. Access is off now, so JoyFox cannot work on JoyClub.",
  "start.step.account":
    "Add your JoyClub account under [Accounts](#accounts). JoyFox makes the first one active.",
  "start.step.chooseAccount":
    "Choose the active account under [Accounts](#accounts).",
  "start.step.rule":
    "Save a contact rule under [Contact rule](#rule). Inbox sorting stays off until a rule is saved and turned on.",
  "start.step.inbox":
    "Open your JoyClub inbox (www.joyclub.de, ClubMail). JoyFox adds its tabs above the list.",

  // Options page: site access (Get started)
  "access.allow": "Allow access to joyclub.de",
  "access.granted":
    "Access to joyclub.de is on. Reload any JoyClub tab that is open, so JoyFox can work there.",
  "access.refused":
    "Access to joyclub.de is still off. JoyFox cannot work on JoyClub until you allow access here or in about:addons.",

  // Options page: accounts
  "accounts.readFailed":
    "JoyFox could not read its stored accounts. No account was changed. Reload the page to try again.",
  "accounts.hint":
    "JoyFox cannot read which JoyClub login a tab uses. The active account is the one selected here. JoyFox stores your notes, tags, rules, templates and other data under it.",
  "accounts.activeLabel": "Active account:",
  "accounts.noneSelected": "None selected",
  "accounts.empty": "No accounts yet. Add one below to use JoyFox.",
  "accounts.list": "Stored accounts",
  // An account's label with its JoyClub identifier, so two accounts with
  // similar labels can be told apart.
  "accounts.nameWithIdentifier": (p: { label: string; identifier: string }) =>
    `${p.label} (${p.identifier})`,
  "accounts.active": "Active",
  "accounts.inactive": "Not active",
  "accounts.use": "Use this account",
  "accounts.useLabel": (p: { name: string }) => `Use this account: ${p.name}`,
  "accounts.nowActive": (p: { name: string }) =>
    `Active account is now ${p.name}.`,
  "accounts.rename": "Rename",
  "accounts.renameLabel": (p: { name: string }) => `Rename account ${p.name}`,
  "accounts.renameField": (p: { identifier: string }) =>
    `New display label for ${p.identifier}`,
  "accounts.renameSave": "Save",
  "accounts.renameCancel": "Cancel",
  "accounts.renamed": (p: { name: string }) =>
    `Label saved. JoyFox now shows this account as ${p.name}.`,
  "accounts.remove": "Remove",
  "accounts.confirmRemove": "Confirm removal",
  "accounts.removeLabel": (p: { name: string }) => `Remove account ${p.name}`,
  "accounts.confirmRemoveLabel": (p: { name: string }) =>
    `Confirm removal of account ${p.name} and all of its data`,
  "accounts.removePrompt": (p: { name: string }) =>
    `Removing ${p.name} deletes everything JoyFox stored for this account, for example notes, tags, rules, templates, messages, event notes and saved searches. Click again to confirm.`,
  "accounts.removed": (p: { name: string }) =>
    `Removed ${p.name} and its stored data.`,
  "accounts.removedNoneActive": (p: { name: string }) =>
    `Removed ${p.name} and its stored data. No account is active now. Choose one with "Use this account".`,
  "accounts.removedNoneLeft": (p: { name: string }) =>
    `Removed ${p.name} and its stored data. No accounts are left. Add one to use JoyFox.`,
  "accounts.addForm": "Add an account",
  "accounts.identifier": "JoyClub account identifier",
  "accounts.identifierHint":
    "Your JoyClub nickname works well. JoyFox uses it only to tell your accounts apart and to match imports. JoyFox does not check it. You cannot change it later.",
  "accounts.label": "Display label (optional)",
  "accounts.labelHint":
    "Only JoyFox shows this label. If you leave it empty, JoyFox shows the identifier.",
  "accounts.add": "Add account",
  "accounts.added": (p: { name: string }) => `Added ${p.name}.`,

  // Options page: contact rule
  "rule.readFailed":
    "JoyFox could not read the contact rule. No rule was changed. Reload the page to try again.",
  "rule.hint":
    "The rule only changes how JoyFox groups your own inbox into Qualified, Needs Review and Junk. It never stops a message, never deletes anything, and the sender sees nothing.",
  "rule.noAccount":
    "Select or add an account first. Each account has its own rule.",
  "rule.newer":
    "This rule was made in a newer version of JoyFox and cannot be edited here. Delete it to start a new one.",
  "rule.note.saved": "A rule is saved for the active account.",
  "rule.note.none":
    "No rule is saved for the active account, so JoyFox does not sort the inbox.",
  "rule.enabled": "Sort my JoyClub inbox with this rule",
  "rule.placementLabel": "A sender who does not meet the rule goes to",
  "rule.spamHint":
    'Spam status is unknown for now: JoyFox does not check messages for templates yet. Only your own "not spam" corrections count. The inbox shows only the verification shield; photos, profile words and account age come from profiles you opened before.',
  "rule.autosaveHint":
    "Changes are saved automatically: a box or choice at once, a number or text when you leave its field.",
  "rule.firstMessageHint":
    '"First message contains" reads the message preview in your inbox, ignoring upper and lower case. The inbox shows only the latest message, so when a sender sent more than one, the preview may not be the first. If the preview does not contain your text, the condition counts as your "If JoyFox cannot see this" choice. Once JoyFox sees your text, it stays met.',
  "rule.preset.label": "Start from a preset",
  "rule.preset.choose": "Choose a preset…",
  "rule.preset.apply": "Apply preset",
  "rule.preset.confirm": "Replace conditions",
  "rule.preset.confirmPrompt":
    'The preset replaces every condition below. Click "Replace conditions" to confirm.',
  "rule.preset.hint":
    "A preset fills in the conditions below and saves them. You can then change them like any other rule.",
  "rule.preset.open": "Open",
  "rule.preset.complete": "Complete profiles only",
  "rule.preset.verified": "Verified members",
  "rule.preset.highTrust": "High-trust members",
  "rule.preset.custom": "Custom",
  "rule.preset.describe.open": "No conditions: every sender qualifies.",
  "rule.preset.describe.complete": (
    p: { photos: number; words: number },
    f: Format,
  ) =>
    `A sender needs at least ${f.number(p.photos)} photos and at least ${f.number(p.words)} words of profile text.`,
  "rule.preset.describe.verified": "A sender needs to be verified by JoyClub.",
  "rule.preset.describe.highTrust": (
    p: { photos: number; words: number; days: number },
    f: Format,
  ) =>
    `A sender needs to be verified by JoyClub, with at least ${f.number(p.photos)} photos, at least ${f.number(p.words)} words of profile text and an account at least ${f.number(p.days)} days old.`,
  "rule.preset.describe.custom":
    "Clears all conditions, so you can tick the ones you want.",
  "rule.preset.applied": (p: { preset: T }) =>
    `Preset "${p.preset}" applied and saved. You can change its conditions below.`,
  "rule.preset.appliedOpen":
    'Preset "Open" applied and saved. The rule has no conditions, so every sender qualifies.',
  "rule.preset.appliedCustom":
    "All conditions cleared and saved. Tick the conditions you want. Until you do, every sender qualifies.",
  "rule.editor": "Editor:",
  "rule.simple": "Simple",
  "rule.advanced": "Advanced",
  "rule.match.all": "ALL",
  "rule.match.any": "ANY",
  "rule.box.all": "A sender qualifies when ALL of these are met",
  "rule.box.any": "Or a sender qualifies when ANY of these is met",
  "rule.unknown.needs-review": "Send to Needs Review",
  "rule.unknown.met": "Count as met",
  "rule.unknown.not-met": "Count as not met",
  "rule.unknownPrompt": "If JoyFox cannot see this:",
  "rule.unknownLabel": (p: { condition: T }) =>
    `${p.condition}: if JoyFox cannot see this`,
  "rule.valueLabel": (p: { condition: T }) => `${p.condition} value`,
  "rule.numberProblem": (
    p: { minimum: number; maximum: number; condition: T },
    f: Format,
  ) =>
    `Enter a whole number from ${f.number(p.minimum)} to ${f.number(p.maximum)} for "${p.condition}".`,
  "rule.textPlaceholder": "Word, phrase or emoji",
  "rule.textLabel": (p: { condition: T }) =>
    `${p.condition}: word, phrase or emoji`,
  "rule.textProblem": (p: { maximum: number; condition: T }, f: Format) =>
    `Enter a word, phrase or emoji of up to ${f.number(p.maximum)} characters for "${p.condition}".`,
  "rule.fieldNumberProblem": (
    p: { minimum: number; maximum: number },
    f: Format,
  ) =>
    `Enter a whole number from ${f.number(p.minimum)} to ${f.number(p.maximum)}.`,
  "rule.fieldTextProblem": (p: { maximum: number }, f: Format) =>
    `Enter a word, phrase or emoji of up to ${f.number(p.maximum)} characters.`,
  "rule.textHint": "Type a word, phrase or emoji to use this condition.",
  "rule.spamNote": "(not checked yet: always unknown)",
  "rule.combine.label": "How the groups combine",
  "rule.combine.prefix": "A sender is qualified if ",
  "rule.combine.suffix": " of these groups match.",
  "rule.advancedHint":
    'Each group is met when ALL or ANY of its conditions are met, as you choose. Tick "not" to turn a condition around: "not Minimum photos 3" means fewer than 3 photos. A group without conditions is not saved.',
  "rule.addRule": "+ Add group",
  "rule.removeRule": "Remove group",
  "rule.confirmRemoveGroup": "Confirm removal",
  "rule.confirmRemoveGroupLabel": (p: { number: number }, f: Format) =>
    `Confirm removal of group ${f.number(p.number)}`,
  "rule.removeGroupPrompt": (p: { number: number }, f: Format) =>
    `Click again to remove group ${f.number(p.number)} and its conditions.`,
  "rule.ruleSuffix": " of these are met",
  "rule.noConditions": "No conditions yet. Add one below.",
  "rule.removeCondition": "Remove condition",
  "rule.removeConditionLabel": (p: { condition: T }) => `Remove ${p.condition}`,
  "rule.not": "not",
  "rule.notTitle": "Turn this condition around",
  "rule.notLabel": (p: { condition: T }) => `not: turn "${p.condition}" around`,
  "rule.joiner.all": "AND",
  "rule.joiner.any": "OR",
  "rule.ruleTitle": (p: { number: number }, f: Format) =>
    `Group ${f.number(p.number)}: met if `,
  "rule.ruleMatchLabel": (p: { number: number }, f: Format) =>
    `How group ${f.number(p.number)} combines its conditions`,
  "rule.removeRuleLabel": (p: { number: number }, f: Format) =>
    `Remove group ${f.number(p.number)}`,
  "rule.addConditionLabel": (p: { number: number }, f: Format) =>
    `Add a condition to group ${f.number(p.number)}`,
  "rule.addCondition": "+ Add condition…",
  "rule.ruleCount": (p: { count: number; maximum: number }, f: Format) =>
    `${f.number(p.count)} of ${f.number(p.maximum)} groups`,
  "rule.simpleUnavailable.all":
    "Simple view is not available: the groups combine with ALL.",
  "rule.simpleUnavailable.not":
    'Simple view is not available: the rule uses "not".',
  "rule.simpleUnavailable.severalAll":
    "Simple view is not available: more than one group needs ALL of several conditions.",
  "rule.simpleUnavailable.duplicate":
    "Simple view is not available: a condition appears in more than one group.",
  "rule.savedNoConditions":
    "Rule saved. It has no conditions yet, so every sender qualifies.",
  "rule.savedVacuous":
    "Rule saved. With nothing in the ALL box, every sender qualifies, so the ANY box has no effect.",
  "rule.saved": "Rule saved. Open JoyClub tabs update at once.",
  "rule.notSaved": (p: { problem: T }) =>
    `${p.problem} The rule was not saved.`,
  "rule.saveFailed":
    "JoyFox could not save the rule. Nothing was changed. Change the field again, or reload the page to see the saved rule.",
  "rule.deleteAll": "Delete whole contact rule",
  "rule.confirmDeleteAll": "Confirm delete",
  "rule.deletePrompt":
    "Click again to delete the whole contact rule. JoyFox then stops sorting the inbox for this account.",
  "rule.removed":
    "Contact rule deleted. JoyFox no longer sorts the inbox for this account.",
  "rule.removeFailed":
    "JoyFox could not delete the rule. Nothing was changed. Try again. If it keeps failing, reload the page.",
  "rule.stale.account.saved":
    "The active account changed, so the rule was not saved. Check the active account on the Accounts tab before you change the rule again.",
  "rule.stale.account.removed":
    "The active account changed, so the rule was not deleted. Check the active account on the Accounts tab before you delete a rule again.",
  "rule.stale.rule.saved":
    "The rule was changed in another tab. It was not saved. The form now shows the saved rule.",
  "rule.stale.rule.removed":
    "The rule was changed in another tab. It was not deleted. The form now shows the saved rule.",
  "rule.changedElsewhere":
    "The rule was changed in another tab. The form now shows the saved rule.",

  // Options page: templates
  "templates.readFailed":
    "JoyFox could not read your templates. No template was changed. Reload the page to try again.",
  "templates.heading": "Message templates",
  "templates.hint":
    'On a JoyClub conversation, the "JoyFox templates" button below the message field inserts a template at the cursor. You can still edit the text, and you always click JoyClub\'s Send button yourself. JoyFox never sends a message.',
  // `[Accounts](#accounts)` is drawn as a link to the Accounts tab.
  "templates.noAccount":
    "Choose an active account on the [Accounts](#accounts) tab to store templates.",
  "templates.empty": "No templates yet. Add one below.",
  "templates.inFolder": (p: { folder: string }) => `Templates in ${p.folder}`,
  "templates.edit": "Edit",
  "templates.editLabel": (p: { name: string }) => `Edit template ${p.name}`,
  "templates.editing": (p: { name: string }) => `Editing ${p.name}.`,
  "templates.delete": "Delete",
  "templates.confirmDelete": "Confirm delete",
  "templates.deleteLabel": (p: { name: string }) => `Delete template ${p.name}`,
  "templates.confirmDeleteLabel": (p: { name: string }) =>
    `Confirm delete: template ${p.name}`,
  "templates.deletePrompt": (p: { name: string }) =>
    `Click "Confirm delete" to delete ${p.name}.`,
  "templates.deleted": (p: { name: string }) => `Deleted ${p.name}.`,
  "templates.addForm": "Add a template",
  "templates.name": "Name",
  "templates.folder": "Folder (optional, General if empty)",
  "templates.text": "Text",
  "templates.saveChanges": "Save changes",
  "templates.add": "Add template",
  "templates.cancel": "Cancel editing",
  "templates.saved": (p: { name: string }) => `Saved ${p.name}.`,
  "templates.added": (p: { name: string }) => `Added ${p.name}.`,
  "templates.accountChanged":
    "The active account changed, so nothing was changed. Check the active account on the Accounts tab before you try again.",

  // Options page: your data
  "entity.extensionAccounts": "Account record",
  "entity.joyClubMembers": "Members",
  "entity.profileSnapshots": "Profile snapshots",
  "entity.userNotes": "Notes",
  "entity.userTags": "Tags",
  "entity.trustSignals": "Trust outcomes",
  "entity.contactRules": "Contact rules",
  "entity.conversationClassifications": "Manual placements",
  "entity.savedSearches": "Saved searches",
  "entity.eventMetadata": "Event notes",
  "entity.spendLogEntries": "Spending log",
  "entity.syncConfigs": "Sync settings",
  "entity.extensionPreferences": "Preferences",
  "entity.messageTemplates": "Message templates",
  "entity.spamPhrases": "Spam phrases",
  "entity.messageObservations": "Cached message text (normalized)",
  "entity.senderSpamOverrides": "Not-spam corrections",
  "entity.actionLogs": "Action log",
  "entity.messagePhraseMatches": "Message phrase matches",
  "entity.cachedMessages": "Stored messages (for search)",
  "data.readFailed":
    "JoyFox could not read its stored data. Nothing was changed. Reload the page to try again.",
  "data.hint":
    "Everything JoyFox stores stays in this browser profile. You can inspect it, save it as a JSON file and delete it here. Deleting here never changes anything on JoyClub.",
  // Import is on the Accounts tab (owner decision); this line points there.
  "data.importPointer": "To import a file, go to [Accounts](#accounts).",
  "data.noAccounts": "No accounts yet.",
  "data.accountPicker":
    "Account to inspect (does not change the active account)",
  "data.caption": "Stored records for this account",
  "data.col.type": "Data type",
  "data.col.records": "Records",
  "data.col.actions": "Actions",
  "data.show": "Show",
  "data.hide": "Hide",
  "data.showLabel": (p: { label: T }) => `Show ${p.label}`,
  "data.hideLabel": (p: { label: T }) => `Hide ${p.label}`,
  "data.deleteAll": "Delete all",
  "data.deleteAllLabel": (p: { label: T }) => `Delete all ${p.label}`,
  "data.deleteAllPrompt": (p: { count: number; label: T }, f: Format) =>
    `Click "Confirm" to delete all ${f.number(p.count)} ${p.label} records of this account.`,
  "data.deletedAll": (p: { label: T }) =>
    `Deleted all ${p.label} of this account.`,
  "data.recordsTitle": (p: { label: T; count: number }, f: Format) =>
    `${p.label} (${f.number(p.count)})`,
  "data.accountRecordHint":
    "The account record is removed only with the whole account, on the [Accounts](#accounts) tab.",
  "data.recordSummary": (p: { id: string; updated: string }) =>
    `${p.id} (updated ${p.updated})`,
  // A record with a name a person knows: a member's nickname, a template's
  // or saved search's name, an event's title or an account's label.
  "data.recordSummaryNamed": (p: {
    name: string;
    id: string;
    updated: string;
  }) => `${p.name}: ${p.id} (updated ${p.updated})`,
  // A record with a name a person reads, in delete labels and messages.
  "data.recordNamed": (p: { name: string; id: string }) =>
    `${p.name} (${p.id})`,
  "data.valueYes": "yes",
  "data.valueNo": "no",
  "data.valueEmpty": "(empty)",
  "data.rawJson": "Stored JSON",
  "data.moreCharacters": (p: { count: number }, f: Format) =>
    `…and ${f.number(p.count)} more characters (see "Stored JSON")`,
  "data.moreValues": (p: { count: number }, f: Format) =>
    `…and ${f.number(p.count)} more (see "Stored JSON")`,
  "data.delete": "Delete",
  "data.deleteRecordLabel": (p: { record: string }) =>
    `Delete record ${p.record}`,
  "data.deleteRecordPrompt": (p: { record: string }) =>
    `Click "Confirm" to delete record ${p.record}.`,
  "data.deletedRecord": (p: { record: string }) =>
    `Deleted record ${p.record}.`,
  "data.showMore": (p: { count: number }, f: Format) =>
    `Show ${f.number(p.count)} more`,
  "data.exportAccount": "Export this account (JSON)",
  "data.exportedAccount": "Export of this account created.",
  "data.deleteAccountData": "Delete this account's data",
  "data.deleteAccountDataLabel": "Delete this account's data (every record)",
  "data.deleteAccountDataPrompt":
    'Click "Confirm" to delete every record of this account. The account itself stays in Accounts.',
  "data.deletedAccountData":
    "Deleted all data of this account. The account itself is kept.",
  "data.allAccounts": "All accounts",
  "data.retentionLabel": "Profile snapshots kept per member",
  "data.retentionHint": (
    p: { minimum: number; maximum: number; default: number },
    f: Format,
  ) =>
    `JoyFox keeps the newest snapshots of each member's profile facts, always at least the latest one. Lowering the number deletes older snapshots at once, in every account. From ${f.number(p.minimum)} to ${f.number(p.maximum)}; the default is ${f.number(p.default)}. Click "Save" to apply.`,
  "data.retentionSave": "Save",
  "data.retentionConfirm": "Save and delete",
  "data.retentionConfirmPrompt": (p: { keep: number }, f: Format) =>
    `Lowering the number deletes older snapshots at once, in every account: each member keeps only ${f.plural(
      p.keep,
      {
        one: "the newest snapshot",
        other: `the newest ${f.number(p.keep)} snapshots`,
      },
    )}. Click "Save and delete" to confirm.`,
  "data.retentionSaved": (p: { deleted: number }, f: Format) =>
    p.deleted === 0
      ? "Saved. No snapshot needed deleting."
      : `Saved. ${f.plural(p.deleted, {
          one: "1 older snapshot was",
          other: `${f.number(p.deleted)} older snapshots were`,
        })} deleted.`,
  "data.retentionInvalid": (
    p: { minimum: number; maximum: number },
    f: Format,
  ) =>
    `Enter a whole number from ${f.number(p.minimum)} to ${f.number(p.maximum)}. Nothing was changed.`,
  "data.retentionFailed":
    "JoyFox could not save the setting. The field shows the number in use now. Try again.",
  "data.reminderLabel": "Remind me to export all data after (days)",
  "data.reminderHint": (
    p: { minimum: number; maximum: number; default: number },
    f: Format,
  ) =>
    `JoyFox data stays in this browser profile, also when you close the browser. If you remove JoyFox or lose the profile, the data is gone, so a full export is your backup. This page asks for one when the last full export is older than this number of days. 0 turns the reminder off. From ${f.number(p.minimum)} to ${f.number(p.maximum)}; the default is ${f.number(p.default)}. Click "Save" to apply.`,
  "data.reminderSave": "Save",
  "data.reminderSaved": (p: { days: number }, f: Format) =>
    p.days === 0
      ? "Saved. The export reminder is off."
      : `Saved. JoyFox reminds you ${f.plural(p.days, {
          one: "1 day",
          other: `${f.number(p.days)} days`,
        })} after the last full export.`,
  "data.reminderInvalid": (
    p: { minimum: number; maximum: number },
    f: Format,
  ) =>
    `Enter a whole number from ${f.number(p.minimum)} to ${f.number(p.maximum)}. Nothing was changed.`,
  "data.reminderNever":
    'You have not exported all JoyFox data yet. If you remove JoyFox or lose this browser profile, the data is gone. Click "Export all JoyFox data (JSON)" to save a backup.',
  "data.reminderDue": (p: { days: number }, f: Format) =>
    `Your last full export was ${f.plural(p.days, {
      one: "1 day ago",
      other: `${f.number(p.days)} days ago`,
    })}. If you remove JoyFox or lose this browser profile, newer data is gone. Click "Export all JoyFox data (JSON)" to save a backup.`,
  "data.lastExport": (p: { days: number }, f: Format) =>
    p.days === 0
      ? "Last full export: today."
      : `Last full export: ${f.plural(p.days, {
          one: "1 day ago",
          other: `${f.number(p.days)} days ago`,
        })}.`,
  "data.exportAll": "Export all JoyFox data (JSON)",
  "data.exportedAll": "Export of all JoyFox data created.",
  "data.deleteEverything": "Delete all JoyFox data",
  "data.deleteEverythingLabel": "Delete all JoyFox data in this browser",
  "data.deleteEverythingPrompt":
    'Click "Confirm" to delete every account, every record and every JoyFox setting in this browser. This cannot be undone.',
  "data.deletedEverything": "Deleted all JoyFox data in this browser.",
  "data.confirm": "Confirm",
  "data.confirmLabel": (p: { label: T }) => `Confirm: ${p.label}`,
  "data.actionFailed":
    "JoyFox could not finish the delete. Some records may be deleted already: the counts shown now are what is still stored. Try again.",
  "data.exportFailed":
    "JoyFox could not create the export. Nothing was exported. Try again.",
  "data.import.title": "Import",
  "data.import.hint":
    "Import a JoyFox export file: everything, or one account. It is merged into what is stored here. An account with the same JoyClub identifier is merged into the existing one. For the same note, rule or placement the newer version wins; existing tags and corrections are kept. The import starts when you choose the file, and you then see what changed.",
  "data.import.fileLabel": "JoyFox export file (JSON)",
  "data.import.summary.all": (
    p: { matched: number; added: number; total: number },
    f: Format,
  ) =>
    `This full export holds ${f.number(p.total)} account(s): ${f.number(p.matched)} merged into an existing account, ${f.number(p.added)} added as new.`,
  "data.import.summary.account": (
    p: { matched: number; added: number; total: number },
    f: Format,
  ) =>
    `This single-account export holds ${f.number(p.total)} account(s): ${f.number(p.matched)} merged into an existing account, ${f.number(p.added)} added as new.`,
  "data.import.caption": "What the import changed",
  "data.import.col.added": "Added",
  "data.import.col.replaced": "Replaced (newer)",
  "data.import.col.kept": "Kept",
  "data.import.col.duplicates": "Skipped duplicates",
  "data.import.noRecords": "The file holds no records.",
  // Setting names in the import result. A setting JoyFox does not name is
  // shown by its stored key.
  "data.setting.activeAccount": "active account",
  "data.setting.language": "language",
  "data.setting.messageCaching": "store messages",
  "data.setting.messageRetention": "keep messages for",
  "data.setting.quickIgnoreDelete": "Ignore and Delete button",
  "data.setting.stripCollapsed": "JoyFox bar collapsed",
  "data.setting.templatePicker": "template picker",
  "data.setting.sharedEventException": "shared-event exception",
  "data.setting.snapshotRetention": "snapshots kept per member",
  "data.setting.exportReminder": "export reminder",
  "data.setting.diagnostics": "diagnostics",
  "data.import.settingsUnknown":
    "The file also holds settings that this version of JoyFox does not know. They were not imported.",
  "data.import.settingsSkipped": (p: { keys: string }) =>
    `Settings in the file that are never imported (they switch features on): ${p.keys}.`,
  "data.import.settingsNotSaved": (p: { keys: string }) =>
    `Settings that could not be saved: ${p.keys}.`,
  "data.import.settingsAdded": (p: { keys: string }) =>
    `Settings added (only those not set here): ${p.keys}.`,
  "data.import.running": "Importing the file.",
  "data.import.nothing":
    "Everything in this file is already stored. Nothing was changed.",
  "data.import.complete": (p: { added: number; replaced: number }, f: Format) =>
    `Import complete: ${f.number(p.added)} record(s) added, ${f.number(p.replaced)} replaced by a newer version.`,
  "data.import.completeSettingsFailed": (
    p: { added: number; replaced: number },
    f: Format,
  ) =>
    `Import complete: ${f.number(p.added)} record(s) added, ${f.number(p.replaced)} replaced by a newer version. Some settings could not be saved (listed above). Set them again yourself.`,
  "data.import.incomplete":
    "JoyFox could not finish the import. Choose the file again to try again: records already stored are not added twice.",
  "data.import.unreadable":
    "JoyFox could not check that file. Nothing was imported. Choose the file again. If it still fails, reload the page, or export the file from JoyFox again.",

  // Errors the UI shows (ExtensionError.display). No final full stop: the
  // panels add a suffix such as "Nothing was changed." An error without a
  // display message gets the panel's own failure text instead, which says
  // what to do next.
  "error.withSuffix.nothingChanged": (p: { error: T }) =>
    `${p.error}. Nothing was changed.`,
  "error.withSuffix.nothingImported": (p: { error: T }) =>
    `${p.error}. Nothing was imported.`,
  "error.withSuffix.nothingDeleted": (p: { error: T }) =>
    `${p.error}. Nothing was deleted.`,
  "error.withSuffix.nothingExported": (p: { error: T }) =>
    `${p.error}. Nothing was exported. Try again.`,
  "error.withSuffix.settingNotChanged": (p: { error: T }) =>
    `${p.error}. The setting was not changed. Try again.`,
  "error.account.emptyIdentifier":
    "Enter your JoyClub account identifier first",
  "error.account.duplicate":
    "An account with this identifier is already in the list. Use that account, or enter another identifier",
  "error.account.notRegistered":
    "That account is no longer in the list, for example because it was removed in another tab",
  "error.account.gone": "That account no longer exists",
  "error.account.changed": "The active account changed",
  "error.template.noName": "A template needs a name",
  "error.template.nameTooLong": (p: { maximum: number }, f: Format) =>
    `A template name can have at most ${f.number(p.maximum)} characters`,
  "error.template.folderTooLong": (p: { maximum: number }, f: Format) =>
    `A folder name can have at most ${f.number(p.maximum)} characters`,
  "error.template.noText": "A template needs some text",
  "error.template.tooLong": (p: { maximum: number }, f: Format) =>
    `A template can have at most ${f.number(p.maximum)} characters`,
  "error.template.deleted": "That template was deleted meanwhile",
  "error.data.changedDuringCheck":
    "Stored data changed while the file was checked. Choose the file again",
  "error.data.unknownType": "Unknown data type",
  "error.data.accountRecord":
    "The account record is removed only with the whole account",
  // The next step ends each refusal that a correct export file fixes.
  "error.import.tooLarge":
    "The file is too large to be a JoyFox export. Choose a file exported by JoyFox",
  "error.import.notJson":
    "The file is not a JoyFox export. Choose a file exported by JoyFox",
  "error.import.notExport":
    "The file is not a JoyFox export. Choose a file exported by JoyFox",
  "error.import.noVersion":
    "The file does not say which JoyFox version made it. Choose a file exported by JoyFox",
  "error.import.newerVersion":
    "The file comes from a newer JoyFox version. Update JoyFox first",
  "error.import.noScope":
    "The file does not say if it holds one account or all data. Choose a file exported by JoyFox",
  "error.import.noAccountNamed":
    "The file is an export of one account, but it does not name the account. Choose a file exported by JoyFox",
  "error.import.unknownType":
    "The file holds a type of data that JoyFox does not know. Choose a file exported by JoyFox",
  "error.import.notList": (p: { entity: T }) =>
    `The ${p.entity} part of the file is damaged. Choose a file exported by JoyFox`,
  "error.import.notRecord": (p: { index: number; entity: T }, f: Format) =>
    `Record ${f.number(p.index)} in ${p.entity} is damaged. Choose a file exported by JoyFox`,
  "error.import.forbiddenKey": (p: { index: number; entity: T }, f: Format) =>
    `Record ${f.number(p.index)} in ${p.entity} holds a field name that JoyFox does not allow. Choose a file exported by JoyFox`,
  "error.import.unknownField": (p: { index: number; entity: T }, f: Format) =>
    `Record ${f.number(p.index)} in ${p.entity} holds a field that JoyFox does not know. Choose a file exported by JoyFox`,
  "error.import.tooLong": (
    p: { index: number; entity: T; maximum: number },
    f: Format,
  ) =>
    `Record ${f.number(p.index)} in ${p.entity} holds a text longer than ${f.number(p.maximum)} characters. Choose a file exported by JoyFox`,
  "error.import.invalid": (p: { index: number; entity: T }, f: Format) =>
    `Record ${f.number(p.index)} in ${p.entity} is damaged. Choose a file exported by JoyFox`,
  "error.import.future": (p: { index: number; entity: T }, f: Format) =>
    `Record ${f.number(p.index)} in ${p.entity} has a date in the future. Check the clock of the computer that made the file`,
  "error.import.otherAccount": (p: { index: number; entity: T }, f: Format) =>
    `Record ${f.number(p.index)} in ${p.entity} belongs to another account. Choose a file exported by JoyFox`,
  "error.import.notOwnScope": (p: { index: number }, f: Format) =>
    `Account record ${f.number(p.index)} is damaged. Choose a file exported by JoyFox`,
  "error.import.twice": (p: { index: number; entity: T }, f: Format) =>
    `Record ${f.number(p.index)} in ${p.entity} is in the file twice. Choose a file exported by JoyFox`,
  "error.import.sameIdentifier":
    "Two accounts in the file have the same identifier. Choose a file exported by JoyFox",
  "error.import.noAccountRecord":
    "The file is an export of one account, but it does not hold that account. Choose a file exported by JoyFox",
  "error.import.settingsInvalid":
    "The settings in the file are damaged. Choose a file exported by JoyFox",
  "error.import.settingsForbidden":
    "The settings in the file hold a name that JoyFox does not allow. Choose a file exported by JoyFox",
  "error.import.unknownSetting":
    "The file holds a setting that JoyFox does not use. Choose a file exported by JoyFox",
  "error.import.orphans":
    "Some records in the file belong to an account that the file does not hold. Choose a file exported by JoyFox",
  "error.import.sameRecordTwice":
    "Two records in the file would become the same record here. Choose a file exported by JoyFox",
} as const;

export type MessageKey = keyof typeof en;

/**
 * The params a key's function takes, or undefined for a plain string.
 * Distributive, so a union of keys never loses a key's params.
 */
export type ArgsOf<K extends MessageKey> = K extends MessageKey
  ? (typeof en)[K] extends (p: infer A, f: Format) => string
    ? A
    : undefined
  : never;

/** Keys whose value is a plain string. */
export type PlainKey = {
  [K in MessageKey]: ArgsOf<K> extends undefined ? K : never;
}[MessageKey];

/** Keys whose value is a function of params. */
export type ParamKey = Exclude<MessageKey, PlainKey>;

/** The shape every other catalog has: the same keys and param types. */
export type Catalog = {
  [K in MessageKey]: (typeof en)[K] extends string ? string : (typeof en)[K];
};
