import type {
  CachedMessage,
  EntityMap,
  EntityName,
  ExtensionAccount,
  MessageObservation,
  ProfileSnapshot,
} from "../domain/types";
import { newestCaptureFirst } from "../domain/snapshot-order";
import {
  commitAll,
  DATABASE_VERSION,
  ENTITY_NAMES,
  openDatabase,
  requestResult,
} from "./database";
import {
  IndexedDbRepository,
  storageKeyFor,
  withoutStorageKey,
  type Stored,
} from "./repository";
import { messageTime } from "../messages/message-settings";
import { DEFAULT_SNAPSHOT_RETENTION } from "./snapshot-retention";
import { validateEntity, ValidationError } from "./validation";

/**
 * Profile snapshots are time-series personal data, so the store keeps only the
 * newest snapshots per member. Without a bound, ordinary revisits grow storage
 * indefinitely and retain obsolete profile facts. The user can change the
 * number (`snapshot-retention.ts`); this is the default.
 */
export const PROFILE_SNAPSHOT_RETENTION = DEFAULT_SNAPSHOT_RETENTION;

/** The snapshots past `keep` for each member, newest kept first. */
function snapshotsBeyond(
  snapshots: ReadonlyArray<Stored<ProfileSnapshot>>,
  keep: number,
): Array<Stored<ProfileSnapshot>> {
  const byMember = new Map<string, Array<Stored<ProfileSnapshot>>>();
  for (const snapshot of snapshots) {
    const member = `${snapshot.accountId}\u0000${snapshot.memberId}`;
    const list = byMember.get(member) ?? [];
    list.push(snapshot);
    byMember.set(member, list);
  }
  // Instants, not strings: offsets and precision can differ.
  return [...byMember.values()].flatMap((list) =>
    list.sort(newestCaptureFirst).slice(Math.max(keep, 1)),
  );
}

export class ExtensionAccountRepository extends IndexedDbRepository<"extensionAccounts"> {
  constructor() {
    super("extensionAccounts");
  }
  /**
   * The account directory is the one store that must be readable without an
   * account scope, because the scope itself is chosen from its contents. Every
   * account record is self-scoped (`accountId === id`), so this reads the
   * directory and never another account's data.
   */
  async listAllAccounts(): Promise<ExtensionAccount[]> {
    const db = await openDatabase();
    const stored = await requestResult(
      db
        .transaction("extensionAccounts")
        .objectStore("extensionAccounts")
        .getAll() as IDBRequest<Array<Stored<ExtensionAccount>>>,
    );
    return stored.map(withoutStorageKey);
  }
  /**
   * Stores a new account only if no stored account has its JoyClub
   * identifier. The check and the write share one readwrite transaction, and
   * IndexedDB runs such transactions on this store one at a time, in every
   * extension context, so two creates can never both pass the check.
   * Returns `false`, writing nothing, for a duplicate.
   */
  async addIfIdentifierFree(account: ExtensionAccount): Promise<boolean> {
    validateEntity("extensionAccounts", account);
    if (account.accountId !== account.id)
      throw new ValidationError("An account must be its own scope");
    const db = await openDatabase();
    const transaction = db.transaction("extensionAccounts", "readwrite");
    const store = transaction.objectStore("extensionAccounts");
    let added = false;
    await commitAll(transaction, async () => {
      const stored = await requestResult(
        store.getAll() as IDBRequest<Array<Stored<ExtensionAccount>>>,
      );
      if (
        stored.some(
          (existing) => existing.joyClubAccountId === account.joyClubAccountId,
        )
      )
        return;
      store.put({
        ...account,
        storageKey: storageKeyFor(account.id, account.id),
      });
      added = true;
    });
    return added;
  }
}
export class JoyClubMemberRepository extends IndexedDbRepository<"joyClubMembers"> {
  constructor() {
    super("joyClubMembers");
  }
}
export class ProfileSnapshotRepository extends IndexedDbRepository<"profileSnapshots"> {
  constructor() {
    super("profileSnapshots");
  }
  protected override async applyRetention(
    store: IDBObjectStore,
    accountId: string,
    entity: ProfileSnapshot,
    retention = PROFILE_SNAPSHOT_RETENTION,
  ): Promise<void> {
    const stored = await requestResult(
      store.index("accountId").getAll(accountId) as IDBRequest<
        Array<Stored<ProfileSnapshot>>
      >,
    );
    const member = stored.filter(
      (snapshot) => snapshot.memberId === entity.memberId,
    );
    for (const obsolete of snapshotsBeyond(member, retention))
      store.delete(obsolete.storageKey);
  }
  /**
   * Keeps only the newest `keep` snapshots of every member in every account,
   * in one transaction: after the user lowers the setting, the snapshots
   * already stored follow it too. Returns how many were deleted.
   */
  async pruneAll(keep: number): Promise<number> {
    const db = await openDatabase();
    const transaction = db.transaction("profileSnapshots", "readwrite");
    const store = transaction.objectStore("profileSnapshots");
    let deleted = 0;
    await commitAll(transaction, async () => {
      const all = await requestResult(
        store.getAll() as IDBRequest<Array<Stored<ProfileSnapshot>>>,
      );
      for (const obsolete of snapshotsBeyond(all, keep)) {
        store.delete(obsolete.storageKey);
        deleted += 1;
      }
    });
    return deleted;
  }
}
export class UserNoteRepository extends IndexedDbRepository<"userNotes"> {
  constructor() {
    super("userNotes");
  }
}
export class UserTagRepository extends IndexedDbRepository<"userTags"> {
  constructor() {
    super("userTags");
  }
}
export class TrustSignalRepository extends IndexedDbRepository<"trustSignals"> {
  constructor() {
    super("trustSignals");
  }
}
export class ContactRuleRepository extends IndexedDbRepository<"contactRules"> {
  constructor() {
    super("contactRules");
  }
}
export class ConversationClassificationRepository extends IndexedDbRepository<"conversationClassifications"> {
  constructor() {
    super("conversationClassifications");
  }
}
export class SavedSearchRepository extends IndexedDbRepository<"savedSearches"> {
  constructor() {
    super("savedSearches");
  }
}
export class EventMetadataRepository extends IndexedDbRepository<"eventMetadata"> {
  constructor() {
    super("eventMetadata");
  }
}
export class SpendLogEntryRepository extends IndexedDbRepository<"spendLogEntries"> {
  constructor() {
    super("spendLogEntries");
  }
}
export class SyncConfigRepository extends IndexedDbRepository<"syncConfigs"> {
  constructor() {
    super("syncConfigs");
  }
}
export class ExtensionPreferenceRepository extends IndexedDbRepository<"extensionPreferences"> {
  constructor() {
    super("extensionPreferences");
  }
}
export class MessageTemplateRepository extends IndexedDbRepository<"messageTemplates"> {
  constructor() {
    super("messageTemplates");
  }
}
export class SpamPhraseRepository extends IndexedDbRepository<"spamPhrases"> {
  constructor() {
    super("spamPhrases");
  }
}
/**
 * PRD Section 13.3 sets a default auto-purge window of 12 months for cached
 * message text. Observations older than this are dropped on the next write, so
 * the cache cannot grow without bound or keep message content indefinitely.
 */
export const MESSAGE_OBSERVATION_RETENTION_DAYS = 365;

export class MessageObservationRepository extends IndexedDbRepository<"messageObservations"> {
  constructor() {
    super("messageObservations");
  }
  /**
   * The window is measured from this write, using `updatedAt`, which the
   * writer always sets to now. Measuring from the record's own `observedAt`
   * would let a caller backdate one message and drag the cutoff back with it,
   * keeping everything expired alive.
   *
   * The record being written is never purged here, so `put` cannot report
   * storing something this pass deleted in the same transaction.
   */
  protected override async applyRetention(
    store: IDBObjectStore,
    accountId: string,
    entity: MessageObservation,
  ): Promise<void> {
    const cutoff =
      Date.parse(entity.updatedAt) -
      MESSAGE_OBSERVATION_RETENTION_DAYS * 24 * 60 * 60 * 1000;
    const stored = await requestResult(
      store.index("accountId").getAll(accountId) as IDBRequest<
        Array<Stored<MessageObservation>>
      >,
    );
    for (const observation of stored)
      if (
        observation.id !== entity.id &&
        Date.parse(observation.observedAt) < cutoff
      )
        store.delete(observation.storageKey);
  }
}
export class SenderSpamOverrideRepository extends IndexedDbRepository<"senderSpamOverrides"> {
  constructor() {
    super("senderSpamOverrides");
  }
}
export class ActionLogRepository extends IndexedDbRepository<"actionLogs"> {
  constructor() {
    super("actionLogs");
  }
}
export class MessagePhraseMatchRepository extends IndexedDbRepository<"messagePhraseMatches"> {
  constructor() {
    super("messagePhraseMatches");
  }
}
export class CachedMessageRepository extends IndexedDbRepository<"cachedMessages"> {
  constructor() {
    super("cachedMessages");
  }
  /**
   * Deletes every cached message, in every account, older than `cutoff`
   * (an ISO date), in one transaction. A message's age counts from when it
   * was sent, or from when it was stored when the page showed no time.
   * Returns how many were deleted.
   */
  async pruneOlderThan(cutoff: string): Promise<number> {
    const db = await openDatabase();
    const transaction = db.transaction("cachedMessages", "readwrite");
    const store = transaction.objectStore("cachedMessages");
    let deleted = 0;
    await commitAll(transaction, async () => {
      const all = await requestResult(
        store.getAll() as IDBRequest<Array<Stored<CachedMessage>>>,
      );
      for (const message of all)
        if (Date.parse(messageTime(message)) < Date.parse(cutoff)) {
          store.delete(message.storageKey);
          deleted += 1;
        }
    });
    return deleted;
  }
}

export const repositories = {
  extensionAccounts: new ExtensionAccountRepository(),
  joyClubMembers: new JoyClubMemberRepository(),
  profileSnapshots: new ProfileSnapshotRepository(),
  userNotes: new UserNoteRepository(),
  userTags: new UserTagRepository(),
  trustSignals: new TrustSignalRepository(),
  contactRules: new ContactRuleRepository(),
  conversationClassifications: new ConversationClassificationRepository(),
  savedSearches: new SavedSearchRepository(),
  eventMetadata: new EventMetadataRepository(),
  spendLogEntries: new SpendLogEntryRepository(),
  syncConfigs: new SyncConfigRepository(),
  extensionPreferences: new ExtensionPreferenceRepository(),
  messageTemplates: new MessageTemplateRepository(),
  spamPhrases: new SpamPhraseRepository(),
  messageObservations: new MessageObservationRepository(),
  senderSpamOverrides: new SenderSpamOverrideRepository(),
  actionLogs: new ActionLogRepository(),
  messagePhraseMatches: new MessagePhraseMatchRepository(),
  cachedMessages: new CachedMessageRepository(),
};

export interface DataExport {
  schemaVersion: typeof DATABASE_VERSION;
  exportedAt: string;
  scope: "account";
  accountId: string;
  entities: { [N in EntityName]: EntityMap[N][] };
}

/**
 * Every record in every store, whatever its scope. It also carries records
 * whose scope is not a registered account (for example the diagnostic wake
 * counter), so "everything" is literally everything the database holds.
 */
export interface FullDataExport {
  schemaVersion: typeof DATABASE_VERSION;
  exportedAt: string;
  scope: "all";
  entities: { [N in EntityName]: EntityMap[N][] };
}

export type EntityCounts = { [N in EntityName]: number };

/** Reads every store in one transaction, so the export is one consistent view. */
export async function exportAccount(accountId: string): Promise<DataExport> {
  const db = await openDatabase();
  const transaction = db.transaction([...ENTITY_NAMES]);
  const entries = await Promise.all(
    ENTITY_NAMES.map(
      async (name) =>
        [
          name,
          (
            await requestResult(
              transaction
                .objectStore(name)
                .index("accountId")
                .getAll(accountId) as IDBRequest<
                Array<Stored<EntityMap[typeof name]>>
              >,
            )
          ).map(withoutStorageKey),
        ] as const,
    ),
  );
  return {
    schemaVersion: DATABASE_VERSION,
    exportedAt: new Date().toISOString(),
    scope: "account",
    accountId,
    entities: Object.fromEntries(entries) as DataExport["entities"],
  };
}

/** Reads every store in one transaction, so the export is one consistent view. */
export async function exportAllData(): Promise<FullDataExport> {
  const db = await openDatabase();
  const transaction = db.transaction([...ENTITY_NAMES]);
  const entries = await Promise.all(
    ENTITY_NAMES.map(
      async (name) =>
        [
          name,
          (
            await requestResult(
              transaction.objectStore(name).getAll() as IDBRequest<
                Array<Stored<EntityMap[typeof name]>>
              >,
            )
          ).map(withoutStorageKey),
        ] as const,
    ),
  );
  return {
    schemaVersion: DATABASE_VERSION,
    exportedAt: new Date().toISOString(),
    scope: "all",
    entities: Object.fromEntries(entries) as FullDataExport["entities"],
  };
}

/** Record counts per entity for one account, read in one transaction. */
export async function countAccountRecords(
  accountId: string,
): Promise<EntityCounts> {
  const db = await openDatabase();
  const transaction = db.transaction([...ENTITY_NAMES]);
  const entries = await Promise.all(
    ENTITY_NAMES.map(
      async (name) =>
        [
          name,
          await requestResult(
            transaction.objectStore(name).index("accountId").count(accountId),
          ),
        ] as const,
    ),
  );
  return Object.fromEntries(entries) as EntityCounts;
}

/**
 * Deletes every record of the given entities in one account, in one
 * transaction, so a failure leaves all of them in place rather than some.
 */
export async function deleteAccountEntities(
  accountId: string,
  names: readonly EntityName[],
): Promise<void> {
  if (names.length === 0) return;
  const db = await openDatabase();
  const transaction = db.transaction([...names], "readwrite");
  await commitAll(transaction, async () => {
    for (const name of names) {
      const store = transaction.objectStore(name);
      const keys = await requestResult(
        store.index("accountId").getAllKeys(accountId),
      );
      for (const recordKey of keys) store.delete(recordKey);
    }
  });
}

export async function deleteAccountData(accountId: string): Promise<void> {
  await deleteAccountEntities(accountId, ENTITY_NAMES);
}

/**
 * Empties every store, including records whose scope is not a registered
 * account. The stores themselves stay, so no schema upgrade is needed later.
 */
export async function clearAllData(): Promise<void> {
  const db = await openDatabase();
  const transaction = db.transaction([...ENTITY_NAMES], "readwrite");
  await commitAll(transaction, () => {
    for (const name of ENTITY_NAMES) transaction.objectStore(name).clear();
  });
}

/** The total record count over every store and scope. */
export async function countAllRecords(): Promise<number> {
  const db = await openDatabase();
  const transaction = db.transaction([...ENTITY_NAMES]);
  const counts = await Promise.all(
    ENTITY_NAMES.map((name) =>
      requestResult(transaction.objectStore(name).count()),
    ),
  );
  return counts.reduce((sum, count) => sum + count, 0);
}

export interface RecordWrite<N extends EntityName = EntityName> {
  name: N;
  entity: EntityMap[N];
}

/**
 * Writes many records, in any stores and scopes, in one transaction: all of
 * them commit or none do. Every record is validated before the transaction
 * opens. Used by import only. Retention (snapshot count, message age) is not
 * applied here; it applies on the next ordinary write to that store.
 */
export async function putRecords(
  writes: readonly RecordWrite[],
): Promise<void> {
  if (writes.length === 0) return;
  for (const { name, entity } of writes) validateEntity(name, entity);
  const names = [...new Set(writes.map((write) => write.name))];
  const db = await openDatabase();
  const transaction = db.transaction(names, "readwrite");
  await commitAll(transaction, () => {
    for (const { name, entity } of writes)
      transaction.objectStore(name).put({
        ...entity,
        storageKey: storageKeyFor(entity.accountId, entity.id),
      });
  });
}
