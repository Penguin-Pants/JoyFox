# Known limitations

- Only the inbox, conversation, profile, member search, event, event list and
  venue pages on `www.joyclub.de` are verified (`docs/selector-map.md`). Inbox
  triage and the conversation and profile panel render there, saved searches on
  the member search and event notes on the event pages. JOYCE stays disabled.
- The member ID is the number in the profile URL. Whether JoyClub ever reuses
  such a number is unconfirmed. Account, event and message identity sources are
  still unknown. Features must not use display names as identifiers.
- The note and tag editor (M5) shows on the profile page and on a conversation
  page, after the JoyFox panel. The inbox, search and event pages do not show
  notes or tags yet (build plan Section 12: "reusable later").
- Text typed in the note box and not saved is dropped when the active account
  changes or the page moves to another member, so it can never be saved under
  the wrong account or member. It is kept while the page briefly hides the
  header for the same member.
- While the editor is on a JoyClub page, the note and tag text is part of that
  page's document, which JoyClub's own scripts could read. JoyFox never sends it
  anywhere. Isolating the editor (for example in a closed shadow root) is a
  recorded follow-up; it would not stop a page script that records keystrokes.
- Account age comes only from the profile badge "Angemeldet seit <n> <unit>",
  which is a rounded duration, not a date. It becomes a join window widened one
  unit either side, because JoyClub's rounding is not confirmed. An age minimum
  passes or fails only when the whole window is on one side of it; otherwise the
  criterion is unknown. Only the German text is parsed, and only "11 Monaten"
  has been observed; the other unit forms follow German grammar. The inbox and
  conversation show no account age.
- Shield codes: `1` (grey) is verified and `0` (grey) is not verified. Code `3`
  ("persönlich bekannt", green) is the user's own mark of having met the member;
  the shield then hides JoyClub's verification. On a profile page the sidebar
  badge ("Verifiziertes Mitglied" or "Mitglied noch nicht verifiziert") says it
  in words and wins over the shield. On an inbox row, a conversation or a card
  with a green shield, verification comes from the last profile reading, or
  stays unknown if the profile was never opened. A missing shield and any other
  code read as unknown.
- "Personally known" is its own criterion (`requirePersonallyKnown`), higher
  trust than verification. Code `3` is "yes"; codes `0` and `1` are "no" (the
  owner confirmed that green replaces grey). A missing shield and other codes
  read as unknown. It is read live on each page and never cached, as the user
  can change the mark.
- Conversation header data is used only when its member ID matches a number in
  the conversation URL. If those URL numbers turn out not to be member IDs,
  header data will always read as missing.
- In the live check, a read state was extracted from only 9 of 25 rows. That
  count does not show how many rows carry the read-status icon: a row with the
  icon but no recognized `--<state>` modifier also counts as missing. The DOM
  has not been inspected for this, and the read state's meaning is unconfirmed.
  No feature uses it.
- The inbox is detected as soon as its list container renders, which can be
  before the rows arrive, so zero rows is ambiguous: still loading, or a truly
  empty inbox. No loading-complete or empty-state signal is verified yet. An
  inbox feature must not wait indefinitely on zero rows; it needs such a signal,
  or a bounded wait, before it treats the inbox as empty.
- The photo count, the profile word count and the account age come only from the
  profile page. JoyFox never opens a profile by itself (build plan Section 12),
  so they are unknown until the user opens it. On a conversation, a rule that
  needs one of them shows an "Open profile" link; the facts are captured when
  the user opens the profile and used from then on.
- The profile word count counts only the main text
  (`.profile-description-maintext__text`). The motto and all other page text are
  not counted. A profile with no main text block reads as unknown, not zero. The
  conversation header's short description is counted separately and is not used
  for M1.
- The extension cannot detect which JoyClub login a tab uses. The active account
  is whichever one the user selected on the options page, and the identifier
  recorded for it is user-declared, not verified. Switching JoyClub logins in
  the browser does not switch the active JoyFox account.
- Tags for one member are read by listing the account's tags and filtering.
  There is no member index yet, so this cost grows with the number of stored
  tags per account.
- The note and tag size limits (4000 and 64 characters) are storage guards
  chosen by this implementation, not values observed from JoyClub.
- The spam detector's thresholds are provisional. No document sets a similarity
  threshold or a minimum message length, and the build plan Section 30 keeps the
  acceptable triage false-positive threshold an open decision. The current
  values, 8 words minimum, 0.85 duplicate similarity, 0.9 phrase similarity and
  a 200-message comparison window, are starting points to tune against a real
  inbox. They are configurable for that reason.
- In scripts written without spaces, each character counts as one word for the
  minimum length, which is coarser than dictionary word segmentation.
  `Intl.Segmenter` would be finer but needs Firefox 125, above the 121 floor.
- Nothing writes a message observation yet. The detector is wired to storage but
  not to any page, because reading a message needs verified selectors. The
  user-facing toggle ADR 0004 requires for message caching must exist before the
  first live caller is added. The owner deferred it to that caller (ADR 0015).
- A very short known phrase matches almost every message, because phrase
  matching includes substring containment. The phrase list is user-authored and
  no minimum length is documented, so none is enforced.
- No default rule is shipped, because the PRD states the thresholds as
  user-configured values. Until the user saves a rule, JoyFox does not sort the
  inbox. The PRD Section 11.3 presets fill in the rule for the user, who applies
  one (V1-11, ADR 0016).
- Inbox triage groups rows by hiding them in place (ADR 0006). Within a group
  the rows keep JoyClub's order. Live acceptance passed on 2026-09-23
  (`manual-acceptance.md`, items 19 to 26). Triage also runs on a conversation
  page while JoyClub shows the list beside it.
- The inbox shows only the verification shield. Photos, profile words and
  account age come from snapshots of profiles the user opened before, so a
  sender whose profile was never opened reads those facts as unknown.
- Spam status is unknown on every page, because no page checks messages for
  templates yet. Only the user's own "not spam" correction counts.
- "First message contains" (ADR 0013) reads the inbox row's message preview,
  which is the sender's latest message, not necessarily the first. A preview
  without the phrase counts as the condition's "If JoyFox cannot see this"
  choice, never as a plain failure. The condition is met when any message JoyFox
  saw from the sender held the phrase, even a later one, and it stays met. A
  preview JoyClub cut short, or a preview of the user's own reply, can hide the
  phrase. On conversation and profile pages, only a stored match counts.
- An existing conversation does not bypass triage (PRD Section 7.4), because
  JoyFox cannot yet tell whether the user replied. The per-sender manual
  placement is the workaround.
- If the background does not answer, the inbox stays untriaged until the rule,
  account, a placement or a trust outcome changes, or the page reloads.
- The local trust score counts only what the user logged and saw in this
  browser. It is not a community reputation.
- Per-member message and tag reads list the account's records and filter in
  memory. There is no member or timestamp index yet, so both the retention purge
  and each classification cost grows with the stored record count.
- Background persistence is proven by an automated database-backed wake-counter
  test and by the manual forced event-page restart (passed 2026-09-23).
- Encryption is an isolated proof of concept. There is no sync transport: the
  owner deferred sync (V1-6) to the future roadmap (ADR 0016). Local export and
  import move data between browsers.
- Firefox signing and AMO distribution have not been implemented or claimed.
- Onboarding is minimal: the options page opens once on a fresh install, and
  "Get started" tracks access to joyclub.de, the account and the rule. JoyFox
  cannot see whether the inbox was opened, so the last step has no state. A
  temporary install from `about:debugging` counts as a fresh install each time
  it is loaded. The JoyFox toolbar button opens the options page at any time.
- "Get started" checks and requests access only for joyclub.de. JOYCE access is
  neither checked nor requested, as JOYCE stays inactive.
- Without an active account or a saved contact rule, the inbox and the member
  panel show one line with "Open JoyFox options". A rule that is turned off
  still shows nothing in the inbox (ADR 0006); the member panel says it is
  turned off. A background that does not answer shows nothing in either place.
- If the user allows JoyFox in private windows (the default is off), it stores
  what it reads there like in a normal window: messages while message storing is
  on, profile facts, nicknames and guest lists. These records stay after the
  private window closes (owner decision, UX audit 2026-09-28; privacy model).
- An account's JoyClub identifier cannot be changed after the account is added,
  because an import matches accounts by it. "Rename" changes only the display
  label. After the active account is removed, no account is active: JoyFox does
  not choose another one, and says so.
- "Not flagged as template spam" is always unknown, because JoyFox does not
  check messages for templates yet. The contact rule editor says so on the
  condition.
- The inbox view (Inbox, Qualified, Needs Review, Junk, Show all) and the event
  list filter are kept for the tab's session in the page's `sessionStorage`, so
  a new tab starts with the default. A tag filter is not kept, because JoyClub's
  own scripts can read that storage.
- Lowering either retention number ("Keep messages for" on "Messages", "Profile
  snapshots kept per member" on "Your data") deletes older records at once, so
  it takes a second click ("Save and delete"). A higher or equal number saves on
  the first click.
- On the user's own profile, the member panel and the note editor show nothing;
  the shared-preferences section stays. The note editor recognizes the own
  profile by the "Account" headline only.
- Quick Ignore and Delete (M9) has a live driver (ADR 0011) and was accepted
  live on 2026-09-25 (`manual-acceptance.md`, items 43 to 54). It is on by
  default since 2026-09-29 (`joyfox.quickIgnoreDelete`, a switch on the options
  page's "Contact rule" tab since 2026-09-27, ADR 0017). The switch controls
  only Ignore and Delete: "Delete" and "Mark as junk" click JoyClub's trash on a
  conversation page also while it is off. Items 44, 45, 47 and 50 could not be
  caused by hand and rest on synthetic tests. A member who is already ignored is
  not reported as such (item 46); the owner decided on 2026-09-25 to keep this
  as is. It deletes first, on the conversation page, then opens the member's
  profile in the same tab to ignore them there.
- Delete (alone, in Ignore and Delete and in "Mark as junk") is checked by the
  conversation's row leaving the list, so it runs only in the split view with
  the member's row loaded. Otherwise "Delete" and "Ignore and Delete" are greyed
  out, and a line under them says why (owner decision, 2026-09-29): the list is
  hidden, or it has not loaded that row yet. "Mark as junk" then keeps the Junk
  placement and the Negative outcome and says the conversation was not moved to
  the trash. It is checked again when the page changes, so a resize alone that
  shows the list leaves the buttons greyed out until the next change.
- After a finished Delete, JoyFox returns to the ClubMail list after 2 seconds,
  only while the page still shows that conversation. JoyClub's own Undo notice
  for the trash goes with the page; the conversation can still be restored from
  JoyClub's trash. JoyFox cannot undo a trash.
- "Mark qualified" and "Mark as junk" stop at the first step that fails or is
  refused (for example after an account switch). A step already done stays: a
  placement stays when its outcome could not be logged, and the notice says so.
  "Use my rule again" clears only the placement; a logged outcome stays until
  "Undo" in the bar removes it.
- JoyClub's own Undo notice for Delete disappears when JoyFox moves to the
  profile. The conversation can still be restored from JoyClub's trash.
- The M9 step timeout (15 seconds), the interrupted threshold (2 minutes; 30
  seconds for a run still at its start) and the profile page's wait for its menu
  (10 seconds) are provisional; no document sets them. The conversation page
  also waits 15 seconds (the step timeout) for the move to the profile; if it is
  still there, it withdraws the hand-off and the run stops before Ignore (ADR
  0011, review follow-ups).
- A cancelled move to the profile leaves a gap of up to 15 seconds: opening the
  same member's profile in the same tab within it still continues the run. Going
  to any other JoyClub page ends the hand-off at once (ADR 0011, "Stale hand-off
  on page load"). A move that takes longer than 15 seconds stops before Ignore,
  and the profile page then shows no JoyFox notice.
- Delete counts the member's rows in the list, not the conversation's own row,
  so a member with two conversations in the list can mislead it. Matching the
  own row needs evidence that an inbox row names its conversation.
- The PRD's guided alternative for M9 (navigate and stage, the user clicks) is
  not built. The owner dropped it on 2026-09-25 (ADR 0015); Mode A (the click is
  the confirmation) is the only mode, for Delete too.
- A sender is "trusted" (PRD Section 7.4) by a manual Qualified placement, not
  by a tag (ADR 0015).
- The database is at version 4. Versions 1 to 3 upgrade in place and keep their
  records.
- Cached profile facts do not expire (ADR 0005). A fact that changed on JoyClub
  since the member's profile was last seen stays in use until the profile is
  seen again.
- The M10 composer picker runs only on the standard conversation composer. It is
  on by default and turned off by setting `joyfox.templatePicker` to `false`
  (ADR 0007). The event ClubMail composer has no evidence and is not supported,
  so M10's "every compose context" acceptance is still open. The owner accepted
  this for the release on 2026-09-27 and logged it for later (ADR 0016,
  `Task Backlog.md`, "Deferred: event ClubMail composer").
- A template that does not fit the composer's `maxlength` is refused, never
  shortened. The template limits (name 80, folder 40, text 4000 characters) are
  storage guards chosen by this implementation.
- Template variables (for example the recipient's first name) are not built.
  Build plan Section 17 defers them until plain insertion is stable.
- Deleting one member record in the data inspector does not delete the notes,
  tags or other records that refer to that member. Each data type is deleted on
  its own.
- The data inspector lists 50 records at a time. An opened record shows its
  fields, with the stored JSON one click away (V1-7). It draws at most 200
  values and 1,000 characters per text; the stored JSON always has the rest.
- The contact rule saves on every change: at once for a box or choice, and when
  a number field loses focus or on Enter. An invalid number is not saved; the
  error names the field, and the last valid rule stays in force.
- Import merges; it never deletes. A newer note replaces an older one rather
  than combining them, and retention is not applied until the next ordinary
  write (ADR 0009). An import reads all stored data to plan, so a very large
  store makes the preview slower.
- The member strip's place depends on JoyClub's layout: it follows the header's
  parent when that parent is a horizontal flex row (ADR 0010). At narrow widths
  the bar wraps onto a second line. JoyClub's profile page holds a mobile and a
  desktop header and hides one by screen width; the strip follows the one the
  page displays. If the window is resized so that the other header shows, the
  strip moves on the next change to the page, not at once.
- JoyFox learns a member's nickname only from a card: an inbox row, a search
  result or a guest-list entry. A member met only on their profile page, or in a
  conversation whose inbox row was never shown, is named by number until a card
  shows them. A nickname changed on JoyClub updates when a card shows the new
  one.
- On a ClubMail row, a search result and a guest-list entry, JoyFox's card line
  has room for one line of 18 px. It shows short texts (the full text is in each
  chip's tooltip) and clips the last chips when the card is too narrow. The tags
  show as a count; the tooltip names them. On a guest-list entry the line uses
  the space JoyClub leaves under the card's text; a JoyClub change to the
  entry's fixed height could clip it.
- Saved searches (V1-3) appear only while JoyClub's result list
  (`div.member_search_list`) is on the page. Whether it is there for a search
  with no results is not known. JoyClub fills its filter panel from a saved
  address but lists the results of the filters stored on the account (live check
  109). So, after the user clicks a saved search, JoyFox opens JoyClub's filter
  panel and clicks JoyClub's "Anwenden" once. This also stores the saved filters
  on the account, as a click by the user would.
- If JoyClub's filter button or "Anwenden" does not appear within about 8
  seconds, JoyFox clicks nothing more. It shows a notice that asks the user to
  open the filter and click "Anwenden". While it waits and clicks, the bar says
  "Running …", then "Showing …"; it does not check that the results changed. The
  saved search whose address the page shows is marked as current; the same
  filters in another order in the address are not recognized.
- Event notes (V1-5) keep an event's title, start, venue and path from the page
  when the user saves. An event saved before its details loaded keeps what the
  page showed. The start is JoyClub's local time as shown ("Ortszeit"), with no
  time zone. The calendar on the options page has no links to JoyClub: a link
  would put a remote address in the extension's code, which the network
  isolation check forbids. The list filter works only on the events JoyClub has
  already loaded; it never loads more. The attendee list is not stored (V1-13).
  The event and venue box stays closed until something is stored for the page.
- The Compatibility Overlay (V1-2) needs the viewer's own profile opened once in
  the active account; it is recognized by the "Account" headline only it shows,
  so if JoyClub removes that headline, JoyFox asks to open the own profile and
  shows no counts. A card shows a count only for a member whose profile was
  opened before, and the count is the one from the last visit. A profile without
  a "Vorlieben" list shows no count. While its tag labels are still drawing,
  JoyFox reads the page again every half second, up to 10 times; a profile whose
  labels take longer shows no count until the page changes. Tags are matched by
  their German label only (`13-preferences.md`). The sort orders only the
  results JoyClub has loaded, and works only if JoyClub lays the list out as a
  flex or grid container.
- Profile signals on cards (V1-10) know a member's photo count and word count
  only from a snapshot, so only for a member whose profile was opened before;
  the card itself shows neither (`11-search.md`). Such a member shows
  "Completeness unknown" and is never hidden by "hide incomplete profiles". A
  guest-list entry shows no shield code (`14-events.md`), so on it the
  verification comes from the snapshot and the "met in person" mark from the
  profile page's last reading (owner, 2026-09-26). If you change the mark on
  JoyClub, a guest entry shows the old trust score until you open that profile
  again. The note and tag editor opens as a panel at the bottom right of the
  window, because a card is a link. The filter hides only results JoyClub has
  loaded.
- The shared-event exception (V1-13) knows only the guests JoyClub had loaded
  when the event page was open; the event page shows a first batch (37 of
  several hundred in `14-events.md`), and JoyFox never loads more, so a real
  co-attendee can be missed. It applies only while a contact rule is on, as an
  exception to that rule, and never over the user's own move. Turning it off for
  one sender is undone by deleting that record under "Your data".
- Conversation History Search (V1-4) finds only messages JoyFox stored: the ones
  a conversation showed on screen while message caching was on. It never loads
  older messages, so a message never scrolled into view is not searchable. A
  photo without text is not stored. A message edited or deleted on JoyClub keeps
  its stored text until the conversation is opened again (an edit) or the purge
  window passes (a deletion). Results name the other member by the nickname a
  card last showed, or by number when JoyFox never saw it, and have no link to
  JoyClub (the network isolation check forbids remote addresses in the
  extension's code). The search matches the query's words in order, ignoring
  case and spacing; it has no fuzzy matching.
- Mozilla's reviewers get no JoyClub test account (owner, 2026-09-28, kept for
  the AMO listing on 2026-10-12, ADR 0016). If AMO picks a version for manual
  review, the review can be delayed or rejected, or the add-on blocked.
