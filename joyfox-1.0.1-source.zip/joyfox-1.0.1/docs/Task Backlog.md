# Task Backlog

Work items derived from the Feature Inventory and Technical Design tabs, sequenced against the Release Roadmap. Every task traces back to a PRD section.

## Foundation Phase

Nothing in MVP starts until F1 through F6 are done. Every task cites the PRD or Technical Design section it traces back to.

| ID | Task | Depends on | Acceptance criteria | Size |
| --- | --- | --- | --- | --- |
| F1 | Verify JoyClub DOM structure: inbox, conversation, profile, search, event pages (PRD 16.1) | None | A selector map is documented per page type; each field's fallback behavior is confirmed | L |
| F2 | POC 1, inbox detection and one-field extraction (PRD 24.4) | F1, partial | Content script reliably extracts the sender name across 10 real inbox loads | S |
| F3 | POC 2, background event-page persistence (PRD 24.4) | None | A counter survives a forced background restart, confirmed in devtools | S |
| F4 | POC 3, WebCrypto encrypt and decrypt round trip against a mock endpoint (PRD 24.4) | None | Ciphertext decrypts back to the original plaintext; the mock server never receives plaintext | S |
| F5 | Build manifest and background scaffolding, the message envelope from Technical Design | F2 | A message sent from a content script reaches the background and gets a reply matched by requestId | M |
| F6 | Implement the Section 12 data model as one repository module per entity | F5 | Get, list, put, delete round-trip tested for every entity | M |
| F7 | Check whether JoyClub's conversation view exposes Ignore in-page, the fastest path for Quick Ignore and Delete | F1 | Documented yes or no, with the same-tab fallback plan confirmed either way | S |
| F8 | Verify Mozilla's current signing requirements for a self-distributed, unlisted build (PRD 18.2, 23) | None | Documented steps to produce a signed, installable build outside AMO | S |

## MVP Phase

Matches the PRD's Section 19.1 scope exactly. Nothing here is not in that list, and nothing in that list is missing here.

| ID | Task | Depends on | Acceptance criteria | Size |
| --- | --- | --- | --- | --- |
| M1 | Sender Qualification Score | F1, F6 | Matches a manual check at least 95 percent of the time across 50 messages (PRD 21.1) | M |
| M2 | Inbox Triage and Quarantine | M1 | A quarantined item never appears in the default view and is fully retrievable (PRD 21.1) | M |
| M3 | Copy-Paste and Template Spam Detector, rule-based | F6 | A near-identical message is flagged automatically; an override persists for that sender (PRD 6.1) | M |
| M4 | One global Contact Rule, simplified rule builder | M1, F6 | A sender failing the rule is quarantined by default, with the reason visible | M |
| M5 | Profile Notes and Tags | F6 | A note survives a restart and a markup change that keeps the same profile ID | S |
| M6 | Local Trust and Compatibility Score, basic version | M1, M5 | Updates immediately after a new interaction outcome is logged | M |
| M7 | Multi-account data scoping | F6 | Switching the active account never shows one account's data under another (PRD 21.3) | M |
| M8 | Data inspector, export, delete | F6 | A full export is complete against every entity, verified item by item (PRD 21.4) | M |
| M9 | Quick Ignore and Delete, Mode A | F7, F5 | Correct sender ignored and correct message deleted in 100 percent of test cases; a partial failure always shows which step failed (PRD 21.2) | L |
| M10 | Message Templates and Composition Assistance | F6 | A saved template inserts with no corruption in every compose context, including event ClubMail (PRD 21.2) | M |

## Status

| ID | Status | Notes |
| --- | --- | --- |
| F0, F2, F4 to F6 | Done | See `foundation-audit.md`. F2's live acceptance passed on 2026-09-23 (10 of 10 inbox loads). |
| F3 | Done | Automated wake-counter test passes, and the forced event-page restart in devtools passed on 2026-09-23 (`wakeCount` rose by one). |
| F1 | Partial | Inbox, conversation, profile, search and events verified from `docs/live-evidence/`. The event ClubMail composer remains; the owner accepted it as a known limitation on 2026-09-27 and logged it for later (ADR 0016). |
| F9 | Partial | Matrix in `08-attribute-matrix.md`. Verification appears on all three pages, photo count only on the profile, profile text on the conversation and the profile. Account age comes from the profile's "Angemeldet seit" badge. Profile type comes from the gender codes (`1` man, `2` woman, `3` couple). Still Unclear: photo count on the inbox row, and account age on the inbox and conversation. |
| F7 | Done | Answer: Path B. Ignore is only on the profile page ("Profil ignorieren" in `profile-context-menu`, then a `j-modal` confirmation); afterwards the item reads "Profil nicht mehr ignorieren". Delete asks for no confirmation; from the inbox row, the row goes and a 5-second Undo notice appears (`live-evidence/10-ignore.md`, 2026-09-24). The conversation page's Delete also asks for no confirmation; the row leaves the list and the conversation stays open at first (2026-09-24). |
| F8 | Done | `docs/distribution.md`: steps for a signed, unlisted build with automatic updates (channel chosen by the owner, 2026-09-26, ADR 0016; ID `joyfox@drclaw`). Checklist items 2 to 4 verified on 2026-09-26 with Mozilla's own tools (`web-ext` 10.7.0, `addons-linter` 10.13.0); the manifest declares `data_collection_permissions` as `{"required": ["none"]}`, `web-ext` is pinned, and CI runs `npm run lint:amo`. Items 1, 5 and 6 verified on 2026-09-28 from the Mozilla pages ("Checklist results, 2026-09-28"). Handed to V1-9: the reviewer's source README, and a live test that Firefox follows the GitHub redirect from an `update_link` ("Open for V1-9"). |
| M1 | Partial | Engine, fact merge and extraction are complete. Milestone C added the page badge, the explanation panel and profile snapshot capture. The 95 percent manual trial over 50 messages remains. |
| M2 | Partial | Tab bar, per-row badges, in-place filtering, per-sender manual placement and dynamic rows are complete and tested (`milestone-c-audit.md`). A manual Qualified placement is the PRD 7.4 trusted exception (ADR 0015). Live acceptance passed on 2026-09-23, including the split-view re-check. The existing-conversation exception is blocked on reply detection. |
| M4 | Partial | One global rule in the V1-compatible schema, a pure evaluator with explicit unknown handling, and the two-box options builder are complete and tested. The advanced editor (rule groups with AND/OR and "not", ADR 0012) is built and tested; its live acceptance (items 75 to 80) passed on 2026-09-25. The "First message contains" condition (ADR 0013) is built and tested; its live acceptance (items 86 to 90) passed on 2026-09-27. Presets are deferred. Live acceptance of the two-box builder passed on 2026-09-23. |
| M6 | Partial | Point-count trust score with a full explanation, outcome logging and undo on conversation and profile pages are complete and tested. Live acceptance passed on 2026-09-23. The spam point stays unknown until M3 reads messages from a page (blocked on the message-bubble evidence). |
| M3 | Partial | Normalization, the pluggable similarity engine, duplicate and known-phrase matching, explanations, and the persisted per-sender override are complete. Nothing reads a message from a page yet, which waits on F1. |
| M5 | Partial | Notes and tags persist, keyed to account plus a verified member ID. The note and tag editor is complete and tested on the profile and conversation pages, including the acceptance "survives a restart and a markup change that keeps the same profile ID" (`milestone-b-audit.md`, M5 editor). Live acceptance (`manual-acceptance.md`, items 36 to 42) passed on 2026-09-27. Inbox, search and event surfaces are "later" in build plan Section 12. |
| M7 | Partial | Explicit active account, account-scoped repositories, options switcher, and the Section 14 isolation test. Automatic account detection waits on F1 and F9. |
| M8 | Done | Account selector, counts, per-entity inspection, delete record, data type, account data and everything, account and full JSON export with the schema version. Export completeness is tested item by item against every entity (`milestone-d-audit.md`). Live acceptance passed on 2026-09-23 (`manual-acceptance.md`, items 27 to 30 and 35). |
| M10 | Partial | Create, edit, delete, folders and exact insertion at the cursor are complete, tested and accepted live on the standard composer (items 31 to 34, 2026-09-23). The picker is on by default (ADR 0007). The event ClubMail composer is unverified, so "every compose context" stays open. The owner accepted this as a known limitation for the release on 2026-09-27 (ADR 0016). |
| M9 | Partial | Live driver built (ADR 0011, owner choice "conversation first", 2026-09-24): Delete through the conversation's three-dot menu, a tab-bound hand-off in `storage.session`, then Ignore on the profile page. Off by default. Item 43 (both steps succeed) passed live on 2026-09-24. Items 44 to 54 were accepted on 2026-09-25: 48, 49 and 51 to 54 passed live; 44, 45, 47 and 50 cannot be caused by hand and are covered by synthetic tests; 46 ends in the correct state but does not say the member was already ignored; the owner keeps it as is. The guided mode is dropped (ADR 0015). Review follow-ups built on 2026-09-25 (ADR 0011): the hand-off is refused from any page but the run's conversation, and a cancelled move to the profile withdraws the marker. Items 98 and 100 were accepted on 2026-09-25 as not reproducible by hand (synthetic tests cover them); item 99, a normal run, passed on 2026-09-27 after three fixes found live (the hand-off matched the whole profile path, then the check of the sending page read the address the page started on; the driver took a hidden copy of the profile menu). The button is turned on and off with a switch on the options page's "Contact rule" tab. |

### MVP release gate (build plan Section 28)

| Gate item | Status |
| --- | --- |
| Cold installation works | Met: build, load, no errors (`manual-acceptance.md`, items 1 to 3) |
| Onboarding gets the extension into a usable state | Met: the options page opens on install and "Get started" tracks the steps. Timed live check passed (item 55, 2026-09-27) |
| Triage operates without hidden network access | Met: automated network-isolation test on every build |
| Missing sender information is shown as Unknown | Met (M1, M2) |
| Every triage decision can be explained | Met (M2, M4) |
| Classification overrides persist | Met (M2) |
| Profile notes survive restart | Met in automated tests (M5); live check passed (items 36 to 42, 2026-09-27) |
| Accounts remain isolated | Met: automated isolation tests (M7, M5 editor) |
| Data export covers all stored entities | Met (M8) |
| Complete data deletion works | Met (M8, item 35) |
| No automated Send action exists | Met: tests prove the picker never sends; M9 never sends |
| Synthetic-fixture tests pass | Met |
| Live manual selector acceptance passes | Met with one known limitation: inbox, conversation and profile pass; search (`11-search.md`) and events (`14-events.md`) are verified and passed their live checks on 2026-09-27 (items 108 to 132). The ClubMail composer on event pages is unverified; the owner accepted it as a known limitation for the release on 2026-09-27 (ADR 0016), logged for later under "Deferred: event ClubMail composer" |
| Unsupported markup causes graceful degradation | Met: features stay off without a verified selector |
| Permissions match documentation | Met: permission check in lint |

M9 is judged separately, under its own matrix (items 43 to 54), which was
accepted by hand on 2026-09-25 (ADR 0011, `manual-acceptance.md`).

### Follow-up work recorded during Milestone B

- Confirm what an unverified member shows (no shield, code `2`, or another
  code), so verification can fail as well as pass. Code `1` is mapped as
  verified, code `0` not verified (2026-09-27). Code `3` is the separate
  "personally known" signal; under it, the profile's sidebar badge gives the
  verification (ADR 0016 amendment).
- "Personally known" (code `3`) is available as the `requirePersonallyKnown`
  criterion. Offer it in the M4 rule builder, and use it in M6 trust and the
  PRD 7.4 triage exception for previously met senders. Done: it is the
  "Personally known" rule condition and a trust point (ADR 0015).
- Observe more "Angemeldet seit" forms (days, weeks, years, singular) to
  confirm the parser, and whether JoyClub rounds the duration down.
- Done in Milestone C: the qualification badge on inbox rows and in the
  conversation header, and snapshot capture on the profile page.

- Add a member index for user tags and message observations, so per-member
  reads and the retention purge do not scan the account. This changes the
  database schema and belongs with M8.
- Add the user-facing toggle for message caching that ADR 0004 requires,
  before anything writes a message observation from a live page.
  Deferred by the owner (2026-09-25, ADR 0015): built with the first feature
  that stores message text.
- Tune the spam thresholds against a real inbox and record the outcome, since
  build plan Section 30 keeps the acceptable false-positive threshold open.
- Done (2026-09-25): account creation is atomic. The duplicate check and the
  write share one IndexedDB transaction, so two creates at once cannot both
  register an identifier (`milestone-b-audit.md`, hardening).
- Replace the user-declared account identifier with a verified one once F1 and
  F9 establish where the JoyClub account identity appears.

### Follow-up work recorded during Milestone C

- Add the existing-conversation exception (PRD Section 7.4) once the
  read-status icon's meaning is confirmed.
- Done (2026-09-26): rule presets (PRD Section 11.3), as V1-11 (ADR 0016).
- Decide whether the inbox retries on its own after a failed background answer.
- Wire the spam detector to pages, so the "not template spam" condition and the
  trust score's spam point can become known.

### Owner requests (2026-09-24)

- Done: the contact rule autosaves on each change, with no Save button
  (`manual-acceptance.md`, items 56 to 58). Triggered by a lost rule: the
  owner expected a ticked box to be kept.
- Done: import of JSON exports (full and single-account), merged into what is
  stored by the owner-approved rules (ADR 0009), with a preview and a confirm
  step (`manual-acceptance.md`, items 59 to 62). PRD Section 13.3 names export
  only; this extends M8. Live acceptance passed on 2026-09-24 (items 59 to 62).

- Done: the JoyFox panel, note editor and Ignore and Delete panel share one
  full-width strip under the header row, with details on demand, and all
  injected UI takes its colors from the page (ADR 0010,
  `manual-acceptance.md` items 63 to 67). Triggered by the owner's screenshot
  of narrow white columns in the dark ClubMail header. Live acceptance passed
  on 2026-09-24 (items 63 to 67).
- Done: inbox views hide each row's wrappers too, so the rows of a view sit
  together at the top with no gaps (`manual-acceptance.md` items 68 and 69).
  Triggered by the owner's screenshot of gaps in the "Needs Review" view.
  Live acceptance passed on 2026-09-24.
- Done: the options page shows one section per tab, and the data table's
  Actions column, the rule condition columns and dark mode are fixed
  (`manual-acceptance.md` items 70 to 72). Triggered by the owner's report of
  a misaligned table and too much scrolling. Live acceptance passed on
  2026-09-24.
- Done: Import (text, file chooser, preview and confirm) moved to the Accounts
  tab, under the account list; the data panel still runs it
  (`manual-acceptance.md` items 73 and 74). Live acceptance passed on
  2026-09-24.
- Done: choosing a file imports it at once, with no "Confirm import" step; a
  table then shows what changed (`manual-acceptance.md` items 83 to 85).
  Triggered by the owner: the confirm button needed extra scrolling and a
  second click. Live acceptance passed on 2026-09-25.

### Owner requests (2026-09-25)

- German and English UI with a toggle in the options header, live switching in
  open tabs, and German as the default when Firefox runs in German. Build after
  the M9 manual matrix (items 43 to 54) passes; it was accepted on 2026-09-25,
  so this can start. Spec: `docs/i18n-spec.md`.
  Triggered by the owner: most JoyClub members are native German speakers.

### Follow-up work recorded during Milestone D

- Capture evidence for the event ClubMail composer (`manual-verification-needed.md`
  item 6), then add it as a second picker context.
- The member index for user tags and message observations (recorded during
  Milestone B for M8) is deferred: no M8 acceptance criterion needs it, and it
  needs a database version change best made with its first real caller.
- Done (commit 7caf140): the double-click guard (`src/options/confirm.ts`) on
  the Accounts panel's "Remove".
- Done (2026-09-25): failure-injection tests for account-wide deletes. They
  found a real gap: a store that threw between requests left the deletes
  already queued for other stores to commit. Every multi-step write now aborts
  its transaction on a throw (`commitAll`, `milestone-d-audit.md`, hardening).
- Template variables, once plain insertion is accepted live (build plan
  Section 17).

### Follow-up work recorded during the M5 editor

- Show notes and tags on the inbox, search and event surfaces (build plan
  Section 12, "reusable later"), once search and events are verified. Now
  V1-10.
- Decide whether to isolate the note editor from JoyClub's scripts, for example
  in a closed shadow root. It would not stop a page script that records
  keystrokes, so it needs a design decision first.

### Follow-up work recorded during the M9 core

- Done (ADR 0011): the live `QuickActionDriver`, the `storage.session`
  hand-off and the resume on the profile page. The manual matrix (items 43 to
  54) was accepted on 2026-09-25.
- M9 review follow-ups (ADR 0011, "Deferred from the review"):
  - Done (2026-09-25): check the sender page in `action.ignoreDelete.handOff`
    too.
  - Done (2026-09-25): drop the marker when the navigation is cancelled. The
    conversation page withdraws it when it is still there 15 seconds after the
    hand-off. Item 98 accepted as not reproducible by hand; synthetic tests
    cover it.
  - Blocked: match the deleted conversation's own row. `01-inbox.md` shows no
    conversation link or ID on an inbox row. Needs that evidence first.
  - Done (2026-09-25): a cancel followed by another page within the
    15-second wait no longer leaves the marker. Every JoyClub page that loads
    in the tab drops a marker meant for another page and closes its run (ADR
    0011, "Stale hand-off on page load"). Item 100 accepted as not
    reproducible by hand; synthetic tests cover it.
- Dropped (owner, 2026-09-25, ADR 0015): the PRD's settings toggle for the
  guided alternative (navigate and stage, the user clicks).
- Done (2026-09-25): a start stored after its tab stopped waiting no longer
  reads as running for 2 minutes. The background refuses a start past the
  tab's deadline, and a run still at `Started` reads as interrupted after 30
  seconds (`milestone-e-audit.md`, "Late start").
- Confirm or tune the step timeout (15 seconds) and the interrupted thresholds
  (2 minutes; 30 seconds at `Started`) against the live site.

M9 is the largest and riskiest MVP task, both in size and in its need to resume across a page navigation, since F7 answered the in-page-versus-navigation question with navigation (Path B). If F1 through F7 push MVP's timeline out meaningfully, M9 is the one task worth reconsidering for a fast-follow release rather than the rest of MVP slipping with it. That is a scope call, not a technical one, and stays with the person running this project.

### Deferred: event ClubMail composer (owner, 2026-09-27)

The owner accepted the unverified event ClubMail composer as a known
limitation for the release and logged it for later (ADR 0016). The template
picker stays off there. To close F1 and M10's "every compose context":

1. Capture sanitized evidence of the composer on an event page: its root, its
   text field, its `maxlength` and how it opens (`live-evidence/`).
2. Add its selectors to the registry and `selector-map.md`, then run the picker
   there behind the same verified-selector check.
3. Add a live check to `manual-acceptance.md` and run it.

## V1 Phase

Broken into tasks on 2026-09-25, now that the MVP is close to done. The scope is
PRD Section 20, "V1". The PRD's "Later" list (AMO submission, AI-assisted
classification, weekly digest, context-menu actions, the incognito-off reminder,
the local spend tracker) and its "Experimental" list (a Chromium build) are not
V1.

An acceptance criterion marked **proposed** is not in the PRD. It needs the
owner's approval before the task starts. The others quote the PRD.

| ID | Task | Depends on | Acceptance criteria | Size |
| --- | --- | --- | --- | --- |
| V1-1 | ~~Per-audience contact rules (PRD 6.1, 11.4)~~ **Dropped** by the owner (2026-09-26, ADR 0016): JoyClub's own contact settings already limit who can write, including by profile type; JoyFox adds its own conditions on top with one rule for all senders | None | None | None |
| V1-2 | Compatibility Overlay: highlight the viewed profile's preferences that match the user's own on the profile page (PRD 6.2), a compatibility badge on every surface where a profile card shows (search results, the inbox, event attendee lists; PRD 8.3) and a sort-by-compatibility toggle on search results (PRD 10.1). **Built (2026-09-26):** the viewer's own preferences are read on their own profile; a "Shared preferences" section and a frame on each shared tag on other profiles; "N shared" on search cards, inbox rows and event guest lists; "Sort by shared preferences" on search (`src/extraction/preferences.ts`, `src/compatibility/`, `src/content/compatibility.ts`); live check: `manual-acceptance.md`, items 116 to 120 | E1; E3; E4 (attendee lists); D5 (answered, ADR 0016) | Every tag marked as matching is independently verifiable by reading both checklists manually (PRD 6.2). **Approved (owner, 2026-09-26):** for two profiles that share preferences, every shared preference is highlighted and no other; two loaded results with different overlaps show different results and sort in overlap order; each profile card on search results, the inbox and event attendee lists shows the same compatibility result as that member's profile page (PRD 8.3), and the sort orders the loaded search results by it. | M |
| V1-3 | Saved Searches: store a search's URL and filter state, replay it in one click (PRD 6.2, 8.2). **Built (2026-09-26), accepted (live checks 108 to 110 passed, 2026-09-27):** a "JoyFox saved searches" bar above the member search results saves the page's address under a name and opens it again in one click (`src/content/saved-searches.ts`, `src/search/`); live check: `manual-acceptance.md`, items 108 to 110. **Live check 109 failed (2026-09-27):** the address filled JoyClub's filter panel, but the results followed the filters stored on the account. The owner chose the fix: after the user clicks a saved search, JoyFox opens JoyClub's filter panel and clicks "Anwenden" once. If a control does not appear, JoyFox asks the user to click "Anwenden" | E1 (captured) | **Approved (owner, 2026-09-26, ADR 0016):** a saved search opens the same URL with the same filters. If JoyClub's search address no longer matches, JoyFox says so and opens nothing. | S |
| V1-4 | Conversation History Search: full-text search over the user's own cached messages (PRD 6.2, 13.3). **Built (2026-09-26):** a conversation page stores the messages it shows while message caching is on; the options page's "Messages" tab has the switch, the purge window and the search (`src/messages/`, `src/extraction/messages.ts`, `src/content/message-cache.ts`, `src/options/messages-panel.ts`); live check: `manual-acceptance.md`, items 121 to 124 | E2; the message-caching toggle (ADR 0004, deferred to this caller by ADR 0015) | Cached message text is on by default, has a configurable auto-purge window, default 12 months, and is always manually deletable (PRD 13.3). **Approved (owner, 2026-09-26, ADR 0016):** with caching on, every message shown in an opened conversation is cached; then every cached message that contains the query is found, and no cached message without it is shown; with caching off, nothing is stored. The original message text is stored, so results are readable, and caching is on by default, as PRD 13.3 says. | M |
| V1-5 | Personal Event Tracker: private notes, attendance and tags on event and venue listings, and a personal calendar of tracked events (PRD 6.3, 9.1, 9.2). **Built (2026-09-26):** a notes box on event and venue pages, a filter and badges on "Dates & Events", and an "Events" tab on the options page (`src/events/`, `src/content/listing-panel.ts`, `src/content/event-list-filter.ts`, `src/options/events-panel.ts`); live check: `manual-acceptance.md`, items 111 to 115 | E4; D6 (answered, ADR 0016) | Event notes persist after the listing is removed from JoyClub's own calendar post-event (PRD 6.3). **Approved (owner, 2026-09-26):** notes, attendance and tags save and show again on event and venue listings; a filter by the user's own tags or notes shows only the matching events in JoyClub's already-loaded event list, with no new request to JoyClub (PRD 9.1, 10.1); the personal calendar lists every tracked event and filters the same way (PRD 9.1). | M |
| V1-6 | Self-hosted sync: encrypted client-side (ADR 0002) to the user's own endpoint (PRD 13.4, 14.2, 15). **Deferred** by the owner (2026-09-26, ADR 0016) to the future roadmap: local export and import are enough for now. The row stays as the plan for later | F4 (done); D2 (deferred) | No network request goes anywhere but joyclub.de or joyce.app until the user has explicitly completed sync setup (PRD 21.1). The encrypted payload is pushed only with an explicit on-screen confirmation; nothing syncs silently (PRD 10.2). The key is derived from a user-held passphrase before anything leaves the device (PRD 13.4); neither the passphrase nor the derived key is stored (ADR 0002). Host access covers only the configured endpoint, is requested at runtime as an optional permission once the user configures sync, and is never in the static manifest; no `<all_urls>` or broad host wildcard (PRD 15, 15.1). When sync is enabled, every other entity also exists, encrypted, on the endpoint (PRD 12.3). **Proposed:** the endpoint receives only ciphertext, and a second browser restores the same data from it with the same passphrase, verified item by item against every entity except `SyncConfig` (as the M8 export test does); a restore with a wrong passphrase fails and changes no data; neither the passphrase nor the derived key appears in storage or in any upload. | L |
| V1-7 | Data-inspector polish (PRD 13.5, 20). **Done (2026-09-26):** each record shows as fields, with the stored JSON one click away (`src/options/record-fields.ts`); live check: `manual-acceptance.md`, items 101 and 102 | M8 (done) | **Approved (owner, 2026-09-26, ADR 0016):** each record shows as readable fields, not raw JSON only; a full export stays complete against every entity, verified item by item (PRD 21.4). | S |
| V1-8 | Repository cleanup and documentation (PRD 20). **Done (2026-09-26):** extension ID `joyfox@drclaw` (ADR 0016), two unused source files removed, debug output only through the diagnostics flag (enforced by lint), the Section 33 docs and the README brought up to date, with build, install and verify steps | None; it can run beside the MVP gate items | **Approved (owner, 2026-09-26, ADR 0016):** cleanup: no placeholder values (such as the extension ID `joyfox@example.invalid`), no unused source files or fixtures, and no debug output outside the diagnostics flag remain, and every check passes; docs: every document in build plan Section 33 is current, and the README states how to build, install and verify a release; a license file exists (D3: `GPL-3.0-or-later`; the file is added, ADR 0016). | S |
| V1-10 | Cross-surface profile signals: the completeness badge, trust score, note icon and profile tags on every surface where a profile card shows (search results, the inbox, event attendee lists; PRD 8.3, 8.4), notes and tags editable inline there (PRD 6.2, 9.3), and a filter that hides incomplete profiles in the loaded search results (PRD 8.1). V1-2 covers the compatibility overlay. **Built (2026-09-26):** a JoyFox signals group on each card and a completeness line on the profile page; the note button opens an editor for the member's note and tags; "JoyFox: hide incomplete profiles" on search (`src/signals/`, `src/content/card-signals.ts`, `src/content/card-note-editor.ts`, `src/content/member-cards.ts`); live check: `manual-acceptance.md`, items 125 to 128 | E1; E4 (attendee lists); D8 (answered: fewer than 3 photos or fewer than 50 words is incomplete) | The signals render the same way on every surface where a profile card shows up (PRD 8.3). A note or tag attached to a profile ID follows that profile everywhere, not just where it was created (PRD 8.4). The note icon is editable inline wherever it appears (PRD 6.2). **Approved (owner, 2026-09-26, ADR 0016):** for one member, each signal on a search-result card, an inbox row and an attendee-list entry matches the same signal on that member's profile page; a tag added from a search result shows on that member's attendee-list entry; a tag and a note, each created and then edited from an attendee-list entry, save to that member's profile ID and show on the profile page; for a member whose photo count, word count and verification are known, the completeness badge shows those values (PRD 6.2); with one loaded result below the D8 completeness level (3 photos and 50 words) and one at or above it, the badge marks only the first as incomplete, and the incomplete-profile filter hides only that one, with no new request to JoyClub. A member whose completeness JoyFox does not know stays visible, marked unknown. | M |
| V1-11 | Rule presets: Open, Complete profiles only, Verified members, High-trust members and Custom (PRD 11.3). **Done (2026-09-26):** "Start from a preset" on the contact rule fills the Simple editor and saves (`src/rules/presets.ts`); live check: `manual-acceptance.md`, items 105 to 107 | M4's rule builder (built); D8 (answered, ADR 0016) | The presets mirror the standalone spec's presets (PRD 11.3). **Approved (owner, 2026-09-26, ADR 0016):** each preset fills the builder with the conditions ADR 0016 lists (from PRD 11.3 and the D8 values); the user can then edit the result like any other rule; Custom opens the builder with no conditions set. | S |
| V1-12 | Configurable `ProfileSnapshot` retention (PRD 13.3). **Done (2026-09-26):** "Profile snapshots kept per member" on "Your data" (`joyfox.snapshotRetention`, 1 to 100, default 20); saving a lower number prunes every member at once (`src/storage/snapshot-retention.ts`); live check: `manual-acceptance.md`, items 103 and 104 | None | The default keeps the latest snapshot plus a short history window, configurable, to bound how much sensitive data sits at rest (PRD 13.3). **Approved (owner, 2026-09-26, ADR 0016):** a setting controls how many snapshots are kept per member, default 20 (the current value); after the user lowers it, each member keeps only that many of the newest snapshots, including the ones already stored; the latest snapshot is always kept. | S |
| V1-13 | Shared-event exception: store the attendees that a tracked event's page shows, and a configurable triage exception for senders who share a tracked event with the user (PRD 7.4, 9.3). "Previously met" is already the "Personally known" rule condition (ADR 0015). **Built (2026-09-26):** a tracked event's page stores its guest list (`EventMetadata.attendees`); a profile page lists the shared tracked events; the exception is a switch on the options page's "Events" tab, off by default, and the "Why" panel names the event and turns it off for one sender (`src/triage/shared-event.ts`, `src/content/shared-events.ts`); live check: `manual-acceptance.md`, items 129 to 132 | V1-5; E4 | The extension reads and locally caches whatever attendee information JoyClub's own event page already renders to the logged-in viewer (PRD 9.3). A shared event co-attendee gets a configurable, but not automatic, exception; every exception is per-sender and reversible (PRD 7.4). **Approved (owner, 2026-09-26, ADR 0016):** opening a tracked event's page stores the shown attendees' profile IDs with that event, and that member's profile page lists the event; the exception is off by default; with it on, a sender who appears on a tracked event that the user marked as Attending or Attended is placed Qualified, the "Why" panel names the event, and the user can undo it for that sender. An event's attendee list is kept while the event is tracked and deleted when it is no longer tracked. | M |
| V1-14 | Profile type filter on the five "My JOY" lists (Profilbesuche, Matches, Mögen mich, Mag ich, Besuchte Profile): Man, Woman, Couple and Unknown checkboxes, nothing ticked shows all, kept for the tab across the lists (owner request, 2026-09-29; `visitor-type-filter-spec.md`). **Built and accepted (2026-09-29; live checks 167 to 171 passed):** `src/content/profile-type-filter.ts`, `cardProfileType` in `src/extraction/joyclub.ts`; live check: `manual-acceptance.md`, items 167 to 171 | E5 (captured 2026-09-29) | **Approved (owner, 2026-09-29):** the spec's acceptance criteria AC-01 to AC-23. JoyFox filters only loaded cards, never loads more, sends nothing and stores no member data; the only stored value is the ticked types in the tab's session storage. | S |
| V1-9 | Self-distributed public release on GitHub (PRD 18.2, 20). **Built (2026-09-28), release pending:** version 1.0.0, the `update_url` and an empty `updates.json`; `npm run lint` checks the release files and that the release notes repeat the README disclaimer; `npm run package:source`; the manual Release workflow signs as unlisted, checks the signed files against the build and drafts the GitHub release; the README tells Mozilla's reviewers how to rebuild (Node.js 24.14.0 and npm 11.9.0 gave identical files). No reviewer account (owner, 2026-09-28, ADR 0016). Still to do, by the owner: the one-time setup and a release run (`release.md`), then items 135 to 138 of `manual-acceptance.md`; the redirect check waits for the first update | V1-2 to V1-5, V1-7, V1-8 and V1-10 to V1-13 (V1-1 is dropped; V1-6 is deferred); D7 (answered: no fixed testing period, ADR 0016); MVP release gate (build plan Section 28); F8 (done 2026-09-28: unlisted, automatic updates; `distribution.md`, "Open for V1-9"); D3 (answered); D4 (answered: disclaimer, ADR 0016) | **Approved (owner, 2026-09-26):** the GitHub repository and its release are public and hold the source under the chosen license (D3); the release page repeats the README's disclaimer (D4); the signed build attached to the release installs on release Firefox and passes the MVP release gate; an installed release updates itself to a newer version through the GitHub-hosted `update_url` (F8); building the release tag's public source with the documented command gives files identical to the ones in the signed `.xpi`, apart from the signature files (reproducible builds, PRD 13.2). The `update_url` is `https://raw.githubusercontent.com/Penguin-Pants/JoyFox/main/updates.json` (owner, 2026-09-26); each release PR updates that file. | M |

### Blocked on site evidence

- **E1:** captured 2026-09-26 (`live-evidence/11-search.md`). The results URL
  holds every filter, and opening it in a new tab gave the same results. Still
  open: whether the URL or filters stored on the account drove that replay,
  whether a result card shows profile text (V1-10's 50-word rule), and search →
  profile navigation. V1-3 can be built from it, but its acceptance needs a
  URL-only replay check: open a saved address after the account's filters
  changed, and see the saved filters come back. That check failed on
  2026-09-27: the stored filters drove the results. Unblocks the search parts of
  V1-2 and V1-10.
- **E2:** captured 2026-09-26 (`live-evidence/12-messages.md`). Each message
  has `data-message-id` (`cm-message-` plus a UUID); sent and received bubbles
  carry `data-e2e="sent-message"` and `"received-message"`; the conversation
  URL is the owner's member ID, then the other member's. The owner confirmed on
  2026-09-26 that a message's `data-message-id` stays the same after a reload,
  so E2 is complete. V1-4 is built from it, with the message-caching switch
  (ADR 0004, ADR 0016).
- **E3:** structure captured 2026-09-26 (`live-evidence/13-preferences.md`):
  a profile shows only its selected tags, grouped in six levels from "Unbedingt"
  to "Geht gar nicht", and a tag's German label is its only key. Still open:
  the full tag vocabulary. It is not needed: tags are matched by label, and D5
  says which levels count as shared. V1-2 is built from it.
- **E4:** captured 2026-09-26 (`live-evidence/14-events.md`,
  `15-venues.md`): the event list (event ID in `data-element-id`), the event
  page, the attendee list (visible to the owner; each entry links to a
  profile) and the venue page (a venue is a member account). Still open: the
  venue's own events page. Unblocks V1-5, V1-13 and the attendee-list parts of
  V1-2 and V1-10.
- **E5:** captured 2026-09-29 (`live-evidence/17-my-joy-lists.md`, prompt
  `live-evidence/capture-prompt-e5.md`). The five "My JOY" lists share one
  component: a grid of `j-member-card`s whose `universal-gender` code gives the
  type (a couple is one code, `3`), filled by infinite scroll, and moved between
  client-side. Still open: an empty list's markup. Unblocks V1-14.

### Owner decisions needed

- **D1:** closed as moot (owner, 2026-09-26, ADR 0016): it only decided which
  audiences V1-1 needed, and V1-1 is dropped.
- **D2:** deferred with V1-6 (owner, 2026-09-26, ADR 0016). When sync is
  built: a simple REST endpoint, WebDAV, or something like remoteStorage (PRD
  Section 23). The encryption is decided (ADR 0002).
- **D3:** answered (owner, 2026-09-26, ADR 0016): GNU GPL version 3 or later
  (`GPL-3.0-or-later`), repository name `JoyFox`. The `LICENSE` file is added.
- **D4:** answered (owner, 2026-09-26, ADR 0016): no ToS review and no GDPR
  consult; the release carries a disclaimer instead (README, "Disclaimer"),
  against the recommended review. The owner can still choose a review before
  V1-9 ships.
- **D5:** answered (owner, 2026-09-26, ADR 0016): every preference section the
  checklist shows (exact list confirmed from E3); shared tags highlighted on
  the profile page, and an "N shared" count on cards and for the sort; no
  percentage. A tag is shared when both profiles have it at a positive level
  (Unbedingt, Steh ich drauf, Situationsabhängig or Möchte ich gerne
  ausprobieren).
- **D6:** answered (owner, 2026-09-26, ADR 0016): Interested, Attending, Not
  attending, Attended and no status. `EventMetadata.attendance` accepts
  `attended` (`src/domain/types.ts`).
- **D7:** answered (owner, 2026-09-26, ADR 0016): no fixed personal testing
  period. The release follows when V1 is done and the MVP release gate passes,
  against the recommended 4 weeks plus exit criteria.
- **D8:** answered (owner, 2026-09-26, ADR 0016). "Complete profiles only": at
  least 3 photos and 50 words of profile text. "High-trust members": verified,
  at least 3 photos, 50 words and an account at least 180 days old, with no
  trust-score condition. V1-10's incomplete-profile filter uses the same
  completeness level.
- The proposed acceptance criteria above: all approved (V1-2 to V1-5, V1-7 to
  V1-13; V1-9's on 2026-09-26).

### Order

A task with **proposed** criteria starts only after the owner approves them (see
"Owner decisions needed"); each step below assumes that approval.

1. Done: V1-7, V1-8, V1-11, V1-12 and V1-3. Their live checks passed on
   2026-09-27: items 101 and 102 (V1-7), 103 and 104 (V1-12), 105 to 107
   (V1-11) and 108 to 110 (V1-3; item 109 after PR #70).
2. Deferred to the future roadmap: V1-6 (and D2).
3. Evidence captured (E1 to E4, 2026-09-26). Live checks on 2026-09-27:
   V1-5 (items 111 to 115), V1-2 (116 to 120) and V1-4 (121 to 124) passed.
   V1-10 (125 to 128, item 126 after PR #77) passed. V1-13 (129 to 132) passed.
4. Last: V1-9, after V1-2 to V1-5, V1-7, V1-8 and V1-10 to V1-13, the MVP
   release gate and F8's verification checklist (both done: the gate on
   2026-09-27 with one known limitation, F8 on 2026-09-28).
