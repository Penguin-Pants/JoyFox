# 0016: V1 scope decisions: no per-audience rules, license, presets, no sync yet, overlay, attendance, disclaimer, release channel, preference levels

## Status

Accepted (project owner, 2026-09-26).

## Context

The V1 task plan (`Task Backlog.md`, "V1 Phase") left owner decisions open and
marked some acceptance criteria as proposed. On 2026-09-26 the owner answered
these:

1. V1-1, per-audience contact rules: one JoyFox rule set per sender profile type
   (single man, single woman, couple). PRD Sections 6.1, 11.4 and 20 list it as
   V1 scope. D1 asked whether a distinct couple audience was needed (PRD Section
   23).
2. D3: the open-source license and the repository name.
3. D8: the thresholds for the PRD 11.3 presets "Complete profiles only" and
   "High-trust members".
4. The proposed criteria of V1-7, V1-8 and V1-12.

## Decision

1. **V1-1 is dropped.** JoyClub's own contact settings already let the user
   accept messages only from profiles that meet their criteria, including by
   profile type. JoyFox adds its own conditions on top of that with one rule for
   all senders. No profile-type condition is added to that rule either. This
   overrides PRD Sections 6.1 and 11.4 and the per-audience item in PRD
   Section 20. **D1 is closed as moot**: it only decided which audiences V1-1
   needed.
2. **License: GNU GPL, version 3 or later (`GPL-3.0-or-later`).** The repository
   name stays `JoyFox`.
3. **Preset values (D8):**

   | Preset                 | Conditions                                                                                          |
   | ---------------------- | --------------------------------------------------------------------------------------------------- |
   | Open                   | None                                                                                                |
   | Complete profiles only | At least 3 photos and at least 50 words of profile text                                             |
   | Verified members       | Verified                                                                                            |
   | High-trust members     | Verified, at least 3 photos, at least 50 words of profile text and an account at least 180 days old |
   | Custom                 | None set; the user picks conditions                                                                 |

   "High-trust members" has no trust-score condition. The local trust score
   counts only the user's own history with a member (M6,
   `src/trust/trust-score.ts`), so a first sender almost always has no score,
   and the condition would quarantine nearly every first message. The user can
   still add the condition by hand. The same completeness level (3 photos, 50
   words) is the "incomplete" limit for V1-10's badge and filter.

4. **Criteria approved:** the proposed criteria of V1-7, V1-8 and V1-12 are
   accepted as written.

## Consequences

- JoyFox cannot require a condition from one profile type only, for example
  verification from single men only. The user sets that part in JoyClub's own
  contact settings.
- `ProfileSnapshot` still has no profile-type field, and `profileTypeFromCode`
  (`src/extraction/joyclub.ts`) still has no caller. Nothing in V1 needs them
  now.
- The repository gets a `LICENSE` file with the GPL version 3 text, and
  `package.json` states `GPL-3.0-or-later`. The rest of V1-8 stays open.
- V1-9 no longer depends on V1-1 or D1, and D3 is answered. It still depends on
  D4 (the ToS review and the GDPR consult) and the other items in its row.

## Amendment: extension ID (project owner, 2026-09-26)

The permanent Firefox extension ID (`browser_specific_settings.gecko.id` in
`manifests/firefox.json`) is `joyfox@drclaw`. It replaces the placeholder
`joyfox@example.invalid`, as V1-8's cleanup criterion requires. The ID cannot
change after the first signed release, since Firefox keys an extension's storage
to it. A build loaded with the placeholder ID keeps its data under that ID:
export it under "Your data" before the switch and import it after.

## Amendment: V1-11 criteria and V1-6 deferral (project owner, 2026-09-26)

1. **V1-11 criteria approved.** The proposed criteria are accepted as written:
   each preset fills the builder with the conditions in the preset table above;
   the user can then edit the result like any other rule; Custom opens the
   builder with no conditions set. In the build, a preset sets only the
   conditions, all in the ALL box, each sending the sender to Needs Review when
   JoyFox cannot see the fact. The on switch and the placement of a sender who
   does not meet the rule stay as the user set them. A preset saves at once,
   like every other rule change, so it asks for a second click before it
   replaces conditions already shown.
2. **V1-6 (self-hosted sync) is deferred** to the future roadmap. Local export
   and import (M8) are enough for now. This overrides the sync item in PRD
   Section 20's V1 list. D2 (the sync protocol) is deferred with it. V1-9 no
   longer depends on V1-6. The encryption decision (ADR 0002) and its proof of
   concept stay as they are, for when sync is built.

## Amendment: D5 and D6 (project owner, 2026-09-26)

1. **D5, the Compatibility Overlay (V1-2).** It compares every preference
   section that JoyClub's preference checklist shows the viewer. The exact list
   of sections and tags is confirmed from evidence E3, before V1-2 starts. On
   the profile page, the shared tags are highlighted inside JoyClub's own
   checklist. On search-result cards, inbox rows and attendee-list entries, a
   badge shows the number of shared tags ("N shared"), and the compatibility
   sort orders the loaded search results by that number. JoyFox shows no
   percentage, so the result does not read as a match score (PRD Section 8.5). A
   card shows a count only for a member whose profile the user opened before, as
   for the other cached facts. Preference fields are special-category data (PRD
   Section 13.1); they stay local and are covered by the snapshot history limit
   (V1-12).
2. **D6, the attendance values (V1-5).** Interested, Attending, Not attending,
   Attended and no status (`unknown`). "Attended" records an event the user went
   to, so past events keep a history. `EventMetadata.attendance` and its import
   validation accept the new value now; no screen writes it until V1-5. V1-13's
   shared-event exception uses Attending, as its criteria say, and the V1-13
   task decides whether Attended also counts.

## Amendment: D4 (project owner, 2026-09-26)

**D4: no ToS review and no GDPR consult before the public release; the release
carries a disclaimer instead.** This overrides the recommendations in PRD
Sections 18.3, 18.5 and 23. The owner chose it against the recommended option (a
self-review of JoyClub's terms plus one short GDPR consult), with the risks
stated:

- Nobody knows whether JoyClub's terms forbid tools like JoyFox. If they do,
  users can lose their accounts (PRD 18.4). Quick Ignore and Delete (M9) carries
  the highest risk and stays off by default.
- The household exemption (GDPR Article 2(2)(c)) very likely covers one user's
  private use, but it is not confirmed for a public open-source release. Sync is
  deferred (V1-6), so no data leaves the device.

The README states the disclaimer ("Disclaimer"): no connection to JoyClub, the
unchecked terms and the account risk, local storage of data about other members
and the user's responsibility for it, and no warranty. V1-9's release page
repeats it. The owner can still choose a review before V1-9 ships.

## Amendment: D7 and F8 (project owner, 2026-09-26)

1. **D7: no fixed personal testing period.** The public release (V1-9) follows
   when V1 is done and the MVP release gate passes. The owner chose this against
   the recommended option (at least 4 weeks of daily use plus exit criteria).
   This overrides the separate "personal dogfooding period" step in PRD Section
   24.7; the owner's own use while V1 is built takes its place. The risk: the
   last V1 features can reach users with little or no real use first.
2. **F8: an unlisted build with automatic updates.** Mozilla signs the build, it
   is not listed on addons.mozilla.org, and the GitHub release carries the
   signed `.xpi` (PRD Section 20). Firefox updates it through
   `browser_specific_settings.gecko.update_url`, which points to an
   `updates.json` served over HTTPS from GitHub; V1-9 sets the exact address.
   The steps in `docs/distribution.md` stay a draft until someone with access to
   the Mozilla pages completes its verification checklist; this environment
   cannot reach them. `data_collection_permissions` is added in V1-9, once its
   format is verified.

## Amendment: D5 levels and V1-3 criteria (project owner, 2026-09-26)

1. **D5, which levels count as shared.** Evidence E3
   (`docs/live-evidence/13-preferences.md`) shows that a profile lists only its
   selected tags, each in one of six levels: Unbedingt, Steh ich drauf,
   Situationsabhängig, Mag ich nicht so, Geht gar nicht and Möchte ich gerne
   ausprobieren. A tag counts as shared when both profiles have it at a positive
   level: Unbedingt, Steh ich drauf, Situationsabhängig or Möchte ich gerne
   ausprobieren. A tag that one profile likes and the other rejects is never
   shared. The German label is the only key, so tags are matched by label.
2. **V1-3 criteria approved** as written: a saved search opens the same URL with
   the same filters; if JoyClub's search address no longer matches, JoyFox says
   so and opens nothing. In the build, "matches" means that the saved address
   passes the verified search address in the selector registry (`11-search.md`)
   and still holds the filters stored with it.

## Amendment: V1-2 build decisions (project owner, 2026-09-26)

1. **The viewer's own preferences.** JoyFox reads them automatically each time
   the viewer opens their own profile, so they stay current. The own profile is
   recognized by the "Account" headline that JoyClub shows only there
   (`13-preferences.md`). If JoyClub removes it, JoyFox asks the viewer to open
   their own profile and shows no counts; it never guesses. The owner chose this
   over a button on the own profile and over a button on every profile.
2. **Couple profiles.** A tag counts as positive for a profile when any partner
   lists it at a positive level ("either partner"). The owner chose this over
   "every partner", with the risk stated: a tag one partner likes and the other
   rejects still counts for the couple. On the profile page, only the partner's
   positive entry is framed.
3. **Storage.** The positive labels are stored with the profile snapshot
   (`positivePreferences`), and the viewer's own snapshot is marked
   (`ownProfile`), as the D5 amendment requires: they stay local and follow the
   snapshot history limit (V1-12). Tags at a negative level are not stored.
4. **Sort.** The compatibility sort sets a CSS `order` on JoyClub's loaded
   result items and never moves or loads them. It works only when the result
   list is a flex or grid container, which the evidence does not record; JoyFox
   says so otherwise (live check, `manual-acceptance.md` item 119).

## Amendment: V1-4, V1-10 and V1-13 criteria (project owner, 2026-09-26)

The proposed criteria of V1-4, V1-10 and V1-13 are approved as written in the
task backlog, with these decisions:

1. **V1-4, message caching.** The original text of each message shown in an
   opened conversation is stored, so search results are readable, and caching is
   on by default, as PRD Section 13.3 says. This is the toggle ADR 0004 and ADR
   0015 require: with it off, nothing is stored. The text is special-category
   data kept unencrypted in the extension's database and in export files; the
   owner accepted this with the risk stated. It keeps PRD 13.3's 12-month
   default purge window, configurable, and manual delete.
2. **V1-10, unknown completeness.** The incomplete-profile filter hides only a
   member known to be below the D8 level. A member whose facts JoyFox does not
   know stays visible, marked unknown: JoyFox never guesses a profile is
   incomplete.
3. **V1-13, attendance and retention.** The shared-event exception counts events
   the user marked Attending or Attended (this settles the question the D6
   amendment left to V1-13). A tracked event's stored attendee list is kept
   while the event is tracked and deleted when it is no longer tracked, or with
   the user's data.

## Amendment: the green shield counts as verified (project owner, 2026-09-27; superseded the same day)

JoyClub's shield shows one state. The green "persönlich bekannt" shield (code
`3`) replaces the grey "geprüft" shield (code `1`), so a page never shows
JoyClub's verification for a member the user marked. Until now JoyFox read code
`3` as "verification unknown" (Milestone B audit). After the live checks of
2026-09-27, where a verified member with a green shield showed "verification
unknown", the owner decided that a green shield counts as verified ("Count green
as verified"). The owner accepted that a member can be personally known without
being verified by JoyClub, so a rule that requires verification now passes for
such a member.

"Personally known" stays its own signal: code `3` still passes the "Personally
known" condition and adds the trust point, and code `1` still means "not
personally known".

## Amendment: verification from the profile badge, then the shield code (project owner, 2026-09-27)

This replaces the amendment above. The owner corrected the facts it rested on:
the shield is green only for "persönlich bekannt", and grey both for a verified
member and for one who is not. Live profiles showed code `1` on a verified
member and code `0` on one who is not. The profile's sidebar badge list says it
in words: "Verifiziertes Mitglied" or "Mitglied noch nicht verifiziert", also
under a green shield.

The owner chose "Badge, then codes":

1. On a profile page, the sidebar badge gives the verification.
2. Elsewhere, code `1` is verified and code `0` is not verified.
3. Code `3` leaves verification unknown on that page. A cached reading from the
   member's profile fills it in; without one it stays unknown.

A green shield no longer counts as verified. "Personally known" is unchanged:
code `3` is "yes", and codes `0` and `1` are "no".

## Amendment: member nicknames in JoyFox's own texts (project owner, 2026-09-27)

JoyFox named other members by member number in its own texts ("Member 9999999 to
you", "note and tags for member 9999999"), which means nothing to the user. The
owner decided that JoyFox stores each member's JoyClub nickname, as a card shows
it, and uses it in every such text ("Store nicknames"). This changes the privacy
model, which said the sender name is never stored.

1. Sources: the inbox row's sender name, a search result's `user-name` attribute
   and a guest-list entry's name. The member ID stays the only identity.
2. The nickname is kept on the account's `JoyClubMember` record, updated when a
   card shows a new one, exported and deleted with the other records, and never
   logged.
3. Where JoyFox never saw a member's nickname, its texts show "Member" and the
   number.

## Amendment: event ClubMail composer as a known limitation (project owner, 2026-09-27)

The ClubMail composer on event pages has no evidence, so the M10 template picker
does not run there. It was the last open part of the MVP release gate's "Live
manual selector acceptance". The owner accepted it as a known limitation for the
release and logged it for later.

1. The gate item counts as met, with this limitation named.
2. F1 and M10 stay "Partial" until the composer is captured and checked live.
3. The steps to close it are in `Task Backlog.md`, "Deferred: event ClubMail
   composer".

## Amendment: first release version and reviewer account (project owner, 2026-09-28)

1. **Version.** The first public release is 1.0.0. Every later release has a
   higher version (`release.md`, "Rules").
2. **Reviewer account.** Mozilla's Add-on Policies require test credentials when
   any part of an add-on needs an account, and every JoyFox feature needs a
   JoyClub account. The owner chose not to give Mozilla's reviewers an account
   for now, and accepts the risk: if AMO picks a version for manual review, the
   review can be delayed or rejected, or the add-on blocked. The README tells
   reviewers that no account is provided. The owner can add one to any later
   submission.
3. **Release workflow.** A manual GitHub Actions workflow builds, checks, signs
   and drafts each release (`.github/workflows/release.yml`). The AMO keys are
   repository secrets. It builds on Ubuntu 24.04 with Node.js 22, the
   environment the README names for reviewers.

## Amendment: AMO listing replaces the unlisted channel (project owner, 2026-10-12)

This overrides F8 in "Amendment: D7 and F8" and the "Updates" decision in
`distribution.md`. The owner chose to list JoyFox publicly on addons.mozilla.org
(AMO) instead of the unlisted build with a self-hosted update file. Version
1.0.0 was signed as unlisted on AMO but never published on GitHub, so no public
copy depends on the old update address. A copy of 1.0.0 installed from that file
gets no update: remove it and install from AMO. The extension ID stays, so its
stored data stays.

1. **Channel: listed only.** AMO signs, hosts and updates JoyFox. The owner
   chose this over keeping a second, unlisted build on GitHub, which would need
   two manifests and two signed files per version.
2. **No `update_url`.** AMO's validator refuses `update_url` for a listed add-on
   (`MANIFEST_UPDATE_URL`, `distribution.md`). The manifest drops it,
   `updates.json` is deleted, and `npm run lint:amo` now checks the build as a
   listed add-on. The manifest names no remote address.
3. **First listed version 1.0.1,** because AMO keeps 1.0.0 (unlisted) and
   refuses a version number twice. It is submitted by hand through the AMO web
   form, which creates the listing (`release.md`, `amo-listing.md`). Later
   versions go through the Release workflow with `--channel=listed`.
4. **Reviewer account: still none.** The owner keeps the 2026-09-28 decision for
   the listed channel and accepts the higher risk: a listed version can be
   reviewed by hand, and without a JoyClub account the review can be delayed or
   rejected. The reviewer notes say so and explain what works without one.
5. **Privacy:** Firefox now checks AMO, not GitHub, for updates. JoyFox's own
   code still sends no request, and `data_collection_permissions` stays
   `["none"]`.
