import "../setup-indexeddb";
import { beforeEach, describe, expect, it } from "vitest";
import {
  AccountService,
  ACTIVE_ACCOUNT_SETTING_KEY,
} from "../../src/accounts/account-service";
import { ExtensionError } from "../../src/errors";
import { withAccountLock } from "../../src/storage/account-lock";
import { repositories } from "../../src/storage/repositories";
import { freshDatabase } from "../setup-indexeddb";
import { MemorySettingsArea } from "../memory-settings";

let settings: MemorySettingsArea;
let service: AccountService;

beforeEach(async () => {
  await freshDatabase();
  settings = new MemorySettingsArea();
  service = new AccountService(repositories.extensionAccounts, settings);
});

describe("M7 explicit active account", () => {
  it("activates the first account and keeps later ones inactive", async () => {
    const first = await service.createAccount({
      joyClubAccountId: "synthetic-a",
      label: "Account A",
    });
    const second = await service.createAccount({
      joyClubAccountId: "synthetic-b",
    });
    expect((await service.getActiveAccount())?.id).toBe(first.id);
    expect(settings.items.get(ACTIVE_ACCOUNT_SETTING_KEY)).toBe(first.id);
    await service.setActiveAccount(second.id);
    expect((await service.getActiveAccount())?.id).toBe(second.id);
  });

  it("switches only after a write to the account being left ends", async () => {
    const first = await service.createAccount({ joyClubAccountId: "a" });
    const second = await service.createAccount({ joyClubAccountId: "b" });
    let release!: () => void;
    const writing = withAccountLock(
      first.id,
      () => new Promise<void>((resolve) => (release = resolve)),
    );
    const switching = service.setActiveAccount(second.id);
    await new Promise((resolve) => setTimeout(resolve, 10));
    expect((await service.getActiveAccount())?.id).toBe(first.id);
    release();
    await Promise.all([writing, switching]);
    expect((await service.getActiveAccount())?.id).toBe(second.id);
  });

  it("stores an account as its own scope", async () => {
    const account = await service.createAccount({
      joyClubAccountId: "synthetic-a",
    });
    expect(account.accountId).toBe(account.id);
    expect(
      await repositories.extensionAccounts.get(account.id, account.id),
    ).toEqual(account);
  });

  it("drops an empty optional label rather than storing an empty string", async () => {
    const account = await service.createAccount({
      joyClubAccountId: "synthetic-a",
      label: "   ",
    });
    expect("label" in account).toBe(false);
  });

  it("rejects an empty or duplicate account identifier", async () => {
    await expect(
      service.createAccount({ joyClubAccountId: "  " }),
    ).rejects.toThrow(ExtensionError);
    await service.createAccount({ joyClubAccountId: "synthetic-a" });
    await expect(
      service.createAccount({ joyClubAccountId: " synthetic-a " }),
    ).rejects.toThrow(/already registered/);
  });

  it("registers an identifier once when two creates run at once", async () => {
    const results = await Promise.allSettled([
      service.createAccount({ joyClubAccountId: "synthetic-a" }),
      // A second options tab: its own service, the same database.
      new AccountService(
        repositories.extensionAccounts,
        settings,
      ).createAccount({ joyClubAccountId: " synthetic-a " }),
    ]);
    expect(results.map((result) => result.status).sort()).toEqual([
      "fulfilled",
      "rejected",
    ]);
    const rejected = results.find((result) => result.status === "rejected");
    expect(String(rejected?.reason)).toMatch(/already registered/);
    const stored = await service.listAccounts();
    expect(stored).toHaveLength(1);
    // The one stored account is the one that was reported as created, and
    // it is the active one.
    const created = results.find((result) => result.status === "fulfilled");
    expect(created?.status === "fulfilled" && created.value.id).toBe(
      stored[0]!.id,
    );
    expect(settings.items.get(ACTIVE_ACCOUNT_SETTING_KEY)).toBe(stored[0]!.id);
  });

  it("stores nothing and activates nothing for a duplicate", async () => {
    const first = await service.createAccount({
      joyClubAccountId: "synthetic-a",
    });
    await service.clearActiveAccount();
    await expect(
      service.createAccount({ joyClubAccountId: "synthetic-a" }),
    ).rejects.toThrow(/already registered/);
    expect((await service.listAccounts()).map((a) => a.id)).toEqual([first.id]);
    expect(settings.items.has(ACTIVE_ACCOUNT_SETTING_KEY)).toBe(false);
  });

  it("refuses to activate an unregistered account", async () => {
    await expect(
      service.setActiveAccount("not-a-real-account"),
    ).rejects.toThrow(/not registered/);
    expect(settings.items.has(ACTIVE_ACCOUNT_SETTING_KEY)).toBe(false);
  });

  it("reports no active account when the pointer dangles", async () => {
    await settings.set({ [ACTIVE_ACCOUNT_SETTING_KEY]: "removed-account" });
    expect(await service.getActiveAccount()).toBeUndefined();
  });

  it("clears the pointer and the data when an account is removed", async () => {
    const account = await service.createAccount({
      joyClubAccountId: "synthetic-a",
    });
    await repositories.userNotes.put(account.id, {
      id: "note:member-1",
      accountId: account.id,
      memberId: "member-1",
      body: "Synthetic note",
      createdAt: "2026-09-22T00:00:00.000Z",
      updatedAt: "2026-09-22T00:00:00.000Z",
    });
    await service.deleteAccount(account.id);
    expect(settings.items.has(ACTIVE_ACCOUNT_SETTING_KEY)).toBe(false);
    expect(await service.listAccounts()).toEqual([]);
    expect(await repositories.userNotes.list(account.id)).toEqual([]);
  });

  it("keeps the pointer when a different account is removed", async () => {
    const active = await service.createAccount({
      joyClubAccountId: "synthetic-a",
    });
    const other = await service.createAccount({
      joyClubAccountId: "synthetic-b",
    });
    await service.deleteAccount(other.id);
    expect((await service.getActiveAccount())?.id).toBe(active.id);
  });

  it("says whether the removed account was the active one", async () => {
    const active = await service.createAccount({ joyClubAccountId: "a" });
    const other = await service.createAccount({ joyClubAccountId: "b" });
    expect(await service.deleteAccount(other.id)).toBe(false);
    expect(await service.deleteAccount(active.id)).toBe(true);
    // No other account is made active on its own.
    expect(settings.items.has(ACTIVE_ACCOUNT_SETTING_KEY)).toBe(false);
  });

  it("lists accounts oldest first", async () => {
    let tick = 0;
    const ordered = new AccountService(
      repositories.extensionAccounts,
      settings,
      () => new Date(Date.UTC(2026, 8, 22, 0, 0, ++tick)).toISOString(),
    );
    await ordered.createAccount({ joyClubAccountId: "synthetic-a" });
    await ordered.createAccount({ joyClubAccountId: "synthetic-b" });
    expect(
      (await ordered.listAccounts()).map((a) => a.joyClubAccountId),
    ).toEqual(["synthetic-a", "synthetic-b"]);
  });
});

describe("renaming an account", () => {
  it("changes only the label, trimmed, and never the identifier", async () => {
    let tick = 0;
    const timed = new AccountService(
      repositories.extensionAccounts,
      settings,
      () => new Date(Date.UTC(2026, 8, 22, 0, 0, ++tick)).toISOString(),
    );
    const account = await timed.createAccount({
      joyClubAccountId: "drclaw",
      label: "Old",
    });
    const renamed = await timed.renameAccount(account.id, "  Me  ");
    expect(renamed).toMatchObject({
      id: account.id,
      accountId: account.id,
      joyClubAccountId: "drclaw",
      label: "Me",
      createdAt: account.createdAt,
    });
    expect(renamed.updatedAt > account.updatedAt).toBe(true);
    expect(
      await repositories.extensionAccounts.get(account.id, account.id),
    ).toEqual(renamed);
  });

  it("drops an empty label, as on create, so the identifier shows", async () => {
    const account = await service.createAccount({
      joyClubAccountId: "drclaw",
      label: "Me",
    });
    const renamed = await service.renameAccount(account.id, "   ");
    expect("label" in renamed).toBe(false);
    expect(
      await repositories.extensionAccounts.get(account.id, account.id),
    ).not.toHaveProperty("label");
  });

  it("refuses an account that is not stored, and writes nothing", async () => {
    await expect(service.renameAccount("gone", "Me")).rejects.toThrow(
      /no longer exists/,
    );
    expect(await service.listAccounts()).toEqual([]);
  });

  it("can never bring back an account removed at the same time", async () => {
    const account = await service.createAccount({ joyClubAccountId: "a" });
    const [removed, renamed] = await Promise.allSettled([
      service.deleteAccount(account.id),
      service.renameAccount(account.id, "Late"),
    ]);
    expect(removed.status).toBe("fulfilled");
    expect(renamed.status).toBe("rejected");
    expect(await service.listAccounts()).toEqual([]);
  });

  it("waits for a write to the account that holds its lock", async () => {
    const account = await service.createAccount({ joyClubAccountId: "a" });
    let release!: () => void;
    const writing = withAccountLock(
      account.id,
      () => new Promise<void>((resolve) => (release = resolve)),
    );
    const renaming = service.renameAccount(account.id, "New");
    await new Promise((resolve) => setTimeout(resolve, 10));
    expect((await service.listAccounts())[0]).not.toHaveProperty("label");
    release();
    await Promise.all([writing, renaming]);
    expect((await service.listAccounts())[0]?.label).toBe("New");
  });
});
