import { describe, expect, it } from "vitest";
import { texts } from "../i18n-text";
import { setLocale } from "../../src/i18n/translator";
import {
  ACTION_STATES,
  canTransition,
  checkTarget,
  isTerminal,
  QUICK_DELETE,
  reportOperation,
  STALE_AFTER_MS,
  STARTED_STALE_AFTER_MS,
  type ActionState,
} from "../../src/actions/ignore-delete";

const T0 = Date.parse("2026-09-23T10:00:00.000Z");
const at = (offset = 0) => new Date(T0 + offset).toISOString();
const steps = (...names: Array<ActionState | [ActionState, string]>) =>
  names.map((name) =>
    Array.isArray(name)
      ? { name: name[0], ok: false, at: at(), errorCode: name[1] }
      : { name, ok: name !== "Failed", at: at() },
  );
const report = (logged: ReturnType<typeof steps>, now = T0) =>
  reportOperation({ steps: logged, updatedAt: at() }, now);

const TARGET = { memberId: "1234567", conversationId: "personal-1234567-1" };

describe("M9 state machine", () => {
  it("allows only the next step, or Failed from a state that is not terminal", () => {
    const order: ActionState[] = [
      "Started",
      "DeleteRequested",
      "DeleteConfirmed",
      "IgnoreRequested",
      "IgnoreConfirmed",
      "Completed",
    ];
    for (const from of ACTION_STATES)
      for (const to of ACTION_STATES) {
        const next = order[order.indexOf(from) + 1];
        const expected =
          !isTerminal(from) &&
          (to === "Failed" || (next !== undefined && to === next));
        expect(canTransition(from, to), `${from} -> ${to}`).toBe(expected);
      }
  });

  it("never lets a step be skipped: Ignore needs a confirmed Delete", () => {
    expect(canTransition("Started", "IgnoreRequested")).toBe(false);
    expect(canTransition("DeleteRequested", "IgnoreRequested")).toBe(false);
    expect(canTransition("DeleteConfirmed", "Completed")).toBe(false);
  });
});

describe("M9 identity invariant", () => {
  it("passes only when member and conversation match", () => {
    expect(
      checkTarget(TARGET, { page: "conversation", ...TARGET }),
    ).toBeUndefined();
    expect(
      checkTarget(TARGET, { page: "profile", memberId: TARGET.memberId }),
    ).toBeUndefined();
  });

  it("fails on another member or conversation", () => {
    expect(
      checkTarget(TARGET, {
        page: "conversation",
        memberId: "7654321",
        conversationId: TARGET.conversationId,
      }),
    ).toBe("member-mismatch");
    expect(
      checkTarget(TARGET, {
        page: "conversation",
        memberId: TARGET.memberId,
        conversationId: "personal-1234567-2",
      }),
    ).toBe("conversation-mismatch");
  });

  it("requires the conversation page for Delete and the profile for Ignore", () => {
    const profile = { page: "profile" as const, memberId: TARGET.memberId };
    const conversation = { page: "conversation" as const, ...TARGET };
    expect(checkTarget(TARGET, profile, "ignore")).toBeUndefined();
    expect(checkTarget(TARGET, profile, "delete")).toBe("identity-unavailable");
    expect(checkTarget(TARGET, conversation, "delete")).toBeUndefined();
    expect(checkTarget(TARGET, conversation, "ignore")).toBe(
      "identity-unavailable",
    );
  });

  it("fails when identity cannot be proven, never passes by default", () => {
    expect(checkTarget(TARGET, { page: "other" })).toBe("identity-unavailable");
    expect(checkTarget(TARGET, { page: "conversation" })).toBe(
      "identity-unavailable",
    );
    expect(
      checkTarget(TARGET, { page: "conversation", memberId: TARGET.memberId }),
    ).toBe("identity-unavailable");
    expect(checkTarget(TARGET, { page: "profile" })).toBe(
      "identity-unavailable",
    );
  });
});

describe("M9 report", () => {
  it("reports a completed run", () => {
    const result = report(
      steps(
        "Started",
        "DeleteRequested",
        "DeleteConfirmed",
        "IgnoreRequested",
        "IgnoreConfirmed",
        "Completed",
      ),
    );
    expect(result).toMatchObject({
      status: "completed",
      ignore: "done",
      delete: "done",
    });
    expect(texts(result.lines)[0]).toBe("Ignore and Delete finished.");
  });

  it("says nothing changed when Delete's control was missing", () => {
    const result = report(steps("Started", ["Failed", "control-missing"]));
    expect(result).toMatchObject({
      status: "failed",
      ignore: "not-done",
      delete: "not-done",
      failure: "control-missing",
    });
    expect(texts(result.lines)).toEqual([
      "Ignore and Delete stopped.",
      "JoyFox could not find JoyClub's Delete option on this page.",
      "Delete: not done.",
      "Ignore: not done.",
      "Nothing was changed on JoyClub.",
      // Nothing was clicked, so there is nothing to check (M9 review).
      "You can do it yourself: move the conversation to the trash with JoyClub's trash button.",
      "You can do it yourself: open the member's profile and ignore them there.",
    ]);
  });

  it.each([
    [
      "conversation-mismatch",
      "The page showed another conversation, so JoyFox stopped before Delete.",
    ],
    [
      "identity-unavailable",
      "JoyFox could not confirm which member or conversation the page shows, so it stopped before Delete.",
    ],
    [
      "turned-off",
      "Ignore and Delete was turned off, so JoyFox stopped before Delete.",
    ],
    ["timeout", "JoyClub did not respond in time during Delete."],
    ["step-error", "An unexpected error stopped JoyFox before Delete."],
  ])(
    "names a %s stop in plain words, then how to do it by hand",
    (failure, line) => {
      const lines = texts(report(steps("Started", ["Failed", failure])).lines);
      expect(lines).toContain(line);
      // No state name or error code in the words.
      expect(lines.join(" ")).not.toContain(failure);
      expect(lines.at(-1)).toBe(
        "You can do it yourself: open the member's profile and ignore them there.",
      );
    },
  );

  it("says how to check an Ignore that JoyClub did not confirm", () => {
    const lines = texts(
      report(
        steps(
          "Started",
          "DeleteRequested",
          "DeleteConfirmed",
          "IgnoreRequested",
          ["Failed", "confirmation-missing"],
        ),
      ).lines,
    );
    expect(lines).toContain(
      "Ignore: not confirmed. JoyFox started it but did not see JoyClub confirm it.",
    );
    expect(lines).toContain(
      "Next: open the member's profile and check whether they are ignored. If not, ignore them there yourself.",
    );
  });

  it("keeps a done Delete and names Ignore as the failed step", () => {
    const result = report(
      steps("Started", "DeleteRequested", "DeleteConfirmed", [
        "Failed",
        "control-missing",
      ]),
    );
    expect(result).toMatchObject({ delete: "done", ignore: "not-done" });
    expect(texts(result.lines)).toContain(
      "JoyFox could not find JoyClub's Ignore option on this page.",
    );
    expect(texts(result.lines)).toContain("JoyFox did not undo anything.");
    expect(texts(result.lines).join(" ")).not.toMatch(/move it there yourself/);
    expect(texts(result.lines).join(" ")).toMatch(/member's profile/);
  });

  it("reports a requested but unconfirmed step as not confirmed, never as not done", () => {
    const result = report(
      steps("Started", "DeleteRequested", ["Failed", "confirmation-missing"]),
    );
    expect(result.delete).toBe("unknown");
    expect(texts(result.lines)).toContain(
      "Delete: not confirmed. JoyFox started it but did not see JoyClub confirm it.",
    );
    expect(texts(result.lines)).toContain("JoyFox did not undo anything.");
  });

  it("reads a stalled run as interrupted, and a recent one as running", () => {
    const logged = steps("Started", "DeleteRequested");
    expect(report(logged, T0 + 1000).status).toBe("running");
    const stale = report(logged, T0 + STALE_AFTER_MS + 1);
    expect(stale.status).toBe("interrupted");
    expect(stale.delete).toBe("unknown");
    expect(texts(stale.lines)[0]).toMatch(/interrupted/);
  });

  it("reads a run still at its start as interrupted after the shorter wait", () => {
    const started = steps("Started");
    expect(report(started, T0 + STARTED_STALE_AFTER_MS).status).toBe("running");
    const stale = report(started, T0 + STARTED_STALE_AFTER_MS + 1);
    expect(stale.status).toBe("interrupted");
    expect(stale.delete).toBe("not-done");
    expect(texts(stale.lines)).toContain("Nothing was changed on JoyClub.");
    // Past its start, a run keeps the longer wait.
    expect(
      report(
        steps("Started", "DeleteRequested"),
        T0 + STARTED_STALE_AFTER_MS + 1,
      ).status,
    ).toBe("running");
  });

  it("never says a started step was not attempted when the log fails", () => {
    const lost = report(
      steps("Started", "DeleteRequested", ["Failed", "log-unavailable"]),
    );
    expect(texts(lost.lines)).toContain(
      "JoyFox could not write to its action log, so it stopped during Delete.",
    );
    expect(texts(lost.lines).join(" ")).not.toMatch(/did not attempt/);
    const before = report(steps("Started", ["Failed", "log-unavailable"]));
    expect(texts(before.lines)).toContain(
      "JoyFox could not write to its action log, so it stopped before Delete.",
    );
  });

  it("never claims a rollback", () => {
    for (const failure of [
      "not-verified",
      "timeout",
      "account-changed",
      "member-mismatch",
    ])
      for (const lines of [
        texts(
          report(steps("Started", "DeleteRequested", ["Failed", failure]))
            .lines,
        ),
        texts(
          report(
            steps(
              "Started",
              "DeleteRequested",
              "DeleteConfirmed",
              "IgnoreRequested",
              ["Failed", failure],
            ),
          ).lines,
        ),
      ])
        expect(lines.join(" ")).not.toMatch(/rolled back|restored|reverted/i);
  });

  it("tells how to undo a finished run with JoyClub's own controls", () => {
    const logged = steps(
      "Started",
      "DeleteRequested",
      "DeleteConfirmed",
      "IgnoreRequested",
      "IgnoreConfirmed",
      "Completed",
    );
    expect(texts(report(logged).lines).at(-1)).toBe(
      "To undo, restore the conversation from JoyClub's trash. Then open the member's profile and choose \"Profil nicht mehr ignorieren\" in its menu.",
    );
    setLocale("de");
    try {
      // JoyClub's exact label (live-evidence/10-ignore.md).
      expect(texts(report(logged).lines).at(-1)).toContain(
        "„Profil nicht mehr ignorieren“",
      );
    } finally {
      setLocale("en");
    }
  });

  it("says how to show the list when Delete could not be checked", () => {
    const lines = texts(
      report(steps("Started", ["Failed", "unverifiable"])).lines,
    );
    expect(lines).toEqual([
      "Ignore and Delete stopped.",
      "JoyFox cannot see JoyClub's result for Delete on this page, so it stopped before Delete.",
      "Delete works only while this conversation shows in the ClubMail list beside it. Widen the window, or scroll the list until the conversation shows, then try again.",
      "Delete: not done.",
      "Ignore: not done.",
      "Nothing was changed on JoyClub.",
      "You can do it yourself: move the conversation to the trash with JoyClub's trash button.",
      "You can do it yourself: open the member's profile and ignore them there.",
    ]);
    // Only for Delete, whose result the list shows.
    expect(
      texts(
        report(
          steps("Started", "DeleteRequested", "DeleteConfirmed", [
            "Failed",
            "unverifiable",
          ]),
        ).lines,
      ).join(" "),
    ).not.toMatch(/Widen the window/);
  });

  it("asks to check a step only when JoyFox started it", () => {
    // Delete was clicked but not confirmed: the user checks it.
    const started = texts(
      report(steps("Started", "DeleteRequested", ["Failed", "timeout"])).lines,
    );
    expect(started).toContain(
      "Next: open the conversation and check whether it is in the trash. If not, move it there yourself with JoyClub's trash button.",
    );
    expect(started.join(" ")).not.toMatch(/You can do it yourself/);
    // Stopped before any click: nothing to check.
    const untouched = texts(
      report(steps("Started", ["Failed", "account-changed"])).lines,
    );
    expect(untouched.join(" ")).not.toMatch(/Next:|check whether/);
  });
});

describe("Delete alone: state machine and report (ADR 0017)", () => {
  const deleteReport = (logged: ReturnType<typeof steps>, now = T0) =>
    reportOperation(
      { action: QUICK_DELETE, steps: logged, updatedAt: at() },
      now,
    );

  it("runs Started, DeleteRequested, DeleteConfirmed, Completed, or Failed", () => {
    const order: ActionState[] = [
      "Started",
      "DeleteRequested",
      "DeleteConfirmed",
      "Completed",
    ];
    for (const from of ACTION_STATES)
      for (const to of ACTION_STATES) {
        const index = order.indexOf(from);
        const next = index < 0 ? undefined : order[index + 1];
        const expected =
          !isTerminal(from) &&
          (to === "Failed" || (next !== undefined && to === next));
        expect(canTransition(from, to, QUICK_DELETE), `${from} -> ${to}`).toBe(
          expected,
        );
      }
    // Ignore never follows Delete alone.
    expect(
      canTransition("DeleteConfirmed", "IgnoreRequested", QUICK_DELETE),
    ).toBe(false);
  });

  it("reports a finished Delete without naming Ignore", () => {
    const result = deleteReport(
      steps("Started", "DeleteRequested", "DeleteConfirmed", "Completed"),
    );
    expect(result.status).toBe("completed");
    expect(texts(result.lines)).toEqual([
      "Delete finished.",
      "Delete: done. JoyClub moved the conversation to the trash.",
      "To undo, restore the conversation from JoyClub's trash.",
    ]);
  });

  it("reports a stopped Delete with the reason and the next manual step", () => {
    const untouched = deleteReport(
      steps("Started", ["Failed", "unverifiable"]),
    );
    expect(texts(untouched.lines)).toEqual([
      "Delete stopped.",
      "JoyFox cannot see JoyClub's result for Delete on this page, so it stopped before Delete.",
      "Delete works only while this conversation shows in the ClubMail list beside it. Widen the window, or scroll the list until the conversation shows, then try again.",
      "Delete: not done.",
      "Nothing was changed on JoyClub.",
      "You can do it yourself: move the conversation to the trash with JoyClub's trash button.",
    ]);
    const started = deleteReport(
      steps("Started", "DeleteRequested", ["Failed", "not-verified"]),
    );
    expect(texts(started.lines)).toEqual([
      "Delete stopped.",
      "JoyClub did not show that Delete succeeded.",
      "Delete: not confirmed. JoyFox started it but did not see JoyClub confirm it.",
      "JoyFox did not undo anything.",
      "Next: open the conversation and check whether it is in the trash. If not, move it there yourself with JoyClub's trash button.",
    ]);
  });

  it("reads a stalled Delete as interrupted, and a recent one as running", () => {
    const logged = steps("Started", "DeleteRequested");
    expect(texts(deleteReport(logged, T0 + 1000).lines)).toEqual([
      "Delete is running.",
    ]);
    const stalled = deleteReport(logged, T0 + STALE_AFTER_MS + 1);
    expect(stalled.status).toBe("interrupted");
    expect(texts(stalled.lines)[0]).toBe(
      "Delete was interrupted, for example because the tab closed.",
    );
  });

  it("speaks German", () => {
    setLocale("de");
    try {
      expect(
        texts(
          deleteReport(
            steps("Started", "DeleteRequested", "DeleteConfirmed", "Completed"),
          ).lines,
        )[0],
      ).toBe("„Löschen“ ist fertig.");
    } finally {
      setLocale("en");
    }
  });
});
