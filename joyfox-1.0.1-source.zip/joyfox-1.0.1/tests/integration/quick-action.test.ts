// @vitest-environment jsdom
import "../setup-indexeddb";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { texts } from "../i18n-text";
import { t } from "../../src/i18n/translator";
import { ActionLogService } from "../../src/actions/action-log-service";
import {
  runQuickDelete,
  runQuickIgnoreDelete,
  type ActionRecorder,
  type QuickActionDriver,
} from "../../src/actions/executor";
import {
  STALE_AFTER_MS,
  STARTED_STALE_AFTER_MS,
  type ActionStep,
  type CurrentTarget,
} from "../../src/actions/ignore-delete";
import { registerActionHandlers } from "../../src/background/action-handlers";
import {
  HANDOFF_WAIT_MS,
  liveQuickActionDriver,
  messageQuickActionClient,
  profileUrl,
  QUICK_ACTION_TEXT,
  QuickIgnoreDelete,
  type QuickActionClient,
} from "../../src/content/quick-action";
import { JoyClubQuickActionDriver } from "../../src/content/quick-action-driver";
import { MemberPanel } from "../../src/content/member-panel";
import type { TriageClient } from "../../src/content/triage-client";
import type { TriagePlacement } from "../../src/domain/types";
import type { MemberTriage } from "../../src/triage/triage-service";
import type { MessageContract } from "../../src/messaging/protocol";
import { MessageRouter } from "../../src/messaging/router";
import { ACTION_REVISION_KEY } from "../../src/storage/action-revision";
import { repositories } from "../../src/storage/repositories";
import { MemorySettingsArea } from "../memory-settings";
import { freshDatabase } from "../setup-indexeddb";
import conversationHtml from "../fixtures/joyclub/conversation.html?raw";
import profileHtml from "../fixtures/joyclub/profile.html?raw";

const MEMBER = "1234567";
const CONVERSATION = "personal-1234567-7654321";
const TARGET = { memberId: MEMBER, conversationId: CONVERSATION };
const HERE: CurrentTarget = { page: "conversation", ...TARGET };
let active: string | undefined;
let clock: number;
let router: MessageRouter;
let client: QuickActionClient;
/** `storage.session`, shared by every background a test starts. */
let session: MemorySettingsArea;
/** The tab the test's content script runs in. */
const TAB = 7;

function backgroundRouter(): MessageRouter {
  const next = new MessageRouter();
  registerActionHandlers(next, {
    // One test clock for the background, so "later" can be simulated.
    actions: new ActionLogService(undefined, undefined, () =>
      new Date(clock).toISOString(),
    ),
    activeAccountId: () => Promise.resolve(active),
    now: () => clock,
    session,
  });
  return next;
}

/** A content script's client in one tab; the browser names the tab. */
const tabClient = (tabId = TAB, via = () => router) =>
  messageQuickActionClient((message) =>
    via().route(message, { tabId, url: window.location.href }),
  );

/** The run's conversation page, where a hand-off starts. */
const CONVERSATION_URL = `${window.location.origin}/clubmail/conversation/conversation-wrapper-${CONVERSATION}/`;

/** The same tab's client while it shows the run's conversation. */
const fromConversation = (tabId = TAB) =>
  messageQuickActionClient((message) =>
    router.route(message, { tabId, url: CONVERSATION_URL }),
  );

/** The run's member's profile, where a hand-off goes. */
const PROFILE_PATH = "/profile/1234567.synthetic_one.html";
const onProfilePage = () => window.history.replaceState(null, "", PROFILE_PATH);

beforeEach(async () => {
  await freshDatabase();
  active = "account-a";
  clock = Date.now();
  session = new MemorySettingsArea();
  router = backgroundRouter();
  client = tabClient();
});

afterEach(() => {
  document.body.innerHTML = "";
});

/** The sender's profile page, where Ignore is (F7, Path B). */
const PROFILE: CurrentTarget = { page: "profile", memberId: MEMBER };

/**
 * A scripted stand-in for JoyClub. It records every click it receives. It
 * starts on the conversation page and, once Delete is verified, shows the
 * sender's profile, as the live run does after its hand-off.
 */
class FakeDriver implements QuickActionDriver {
  clicks: string[] = [];
  page: "conversation" | "profile" = "conversation";
  current: () => CurrentTarget = () =>
    this.page === "conversation" ? HERE : PROFILE;
  controls: Partial<Record<ActionStep, boolean>> = {};
  confirmation: Partial<Record<ActionStep, "shown" | "missing" | "none">> = {};
  verified: Partial<Record<ActionStep, boolean>> = {};
  /** Whether the page can show Delete's result (the list beside it). */
  listShown = true;
  afterClick?: (click: string) => void | Promise<void>;
  currentTarget(): CurrentTarget {
    return this.current();
  }
  hasControl(step: ActionStep): boolean {
    return this.controls[step] ?? true;
  }
  canVerify(step: ActionStep): boolean {
    return step === "ignore" || this.listShown;
  }
  async request(step: ActionStep): Promise<void> {
    this.clicks.push(`request:${step}`);
    await this.afterClick?.(`request:${step}`);
  }
  async awaitConfirmation(step: ActionStep) {
    return this.confirmation[step] ?? "shown";
  }
  async confirm(step: ActionStep): Promise<void> {
    this.clicks.push(`confirm:${step}`);
    await this.afterClick?.(`confirm:${step}`);
  }
  async verify(step: ActionStep): Promise<boolean> {
    const ok = this.verified[step] ?? true;
    if (step === "delete" && ok) this.page = "profile";
    return ok;
  }
}

const run = (
  driver: QuickActionDriver,
  recorder: ActionRecorder = client.recorder("account-a"),
  extra: Partial<Parameters<typeof runQuickIgnoreDelete>[0]> = {},
) =>
  runQuickIgnoreDelete({
    target: TARGET,
    driver,
    recorder,
    timeoutMs: 200,
    ...extra,
  });

/** The stored ActionLog steps, as `name` or `name:errorCode`. */
async function logged(account = "account-a"): Promise<string[][]> {
  const logs = await repositories.actionLogs.list(account);
  return logs.map((log) =>
    log.steps.map((step) =>
      step.errorCode ? `${step.name}:${step.errorCode}` : step.name,
    ),
  );
}

const FULL = [
  "Started",
  "DeleteRequested",
  "DeleteConfirmed",
  "IgnoreRequested",
  "IgnoreConfirmed",
  "Completed",
];

const ALL_CLICKS = [
  "request:delete",
  "confirm:delete",
  "request:ignore",
  "confirm:ignore",
];

describe("M9 manual test matrix, synthetic (build plan Section 24)", () => {
  it("case 1: Delete and Ignore both succeed", async () => {
    const driver = new FakeDriver();
    const result = await run(driver);
    expect(driver.clicks).toEqual(ALL_CLICKS);
    expect(await logged()).toEqual([FULL]);
    expect(result.report).toMatchObject({
      status: "completed",
      ignore: "done",
      delete: "done",
    });
    expect(texts(result.report.lines)).toEqual([
      "Ignore and Delete finished.",
      "Delete: done. JoyClub moved the conversation to the trash.",
      "Ignore: done. JoyClub ignores this member.",
      "To undo, restore the conversation from JoyClub's trash. Then open the member's profile and choose \"Profil nicht mehr ignorieren\" in its menu.",
    ]);
    const [log] = await repositories.actionLogs.list("account-a");
    expect(log).toMatchObject({
      memberId: MEMBER,
      conversationId: CONVERSATION,
      action: "quick-ignore-delete",
    });
    // The member directory carries the member the log refers to.
    expect(
      (await repositories.joyClubMembers.list("account-a")).map((m) => m.id),
    ).toEqual([MEMBER]);
  });

  it("case 2: Delete control missing, nothing is clicked", async () => {
    const driver = new FakeDriver();
    driver.controls.delete = false;
    const result = await run(driver);
    expect(driver.clicks).toEqual([]);
    expect(await logged()).toEqual([["Started", "Failed:control-missing"]]);
    expect(texts(result.report.lines)).toContain(
      "Nothing was changed on JoyClub.",
    );
  });

  it("case 3: Delete confirmation missing stops before any Ignore", async () => {
    const driver = new FakeDriver();
    driver.confirmation.delete = "missing";
    const result = await run(driver);
    expect(driver.clicks).toEqual(["request:delete"]);
    expect(await logged()).toEqual([
      ["Started", "DeleteRequested", "Failed:confirmation-missing"],
    ]);
    expect(result.report).toMatchObject({
      delete: "unknown",
      ignore: "not-done",
    });
    expect(texts(result.report.lines)).toContain(
      "JoyClub's confirmation for Delete did not appear.",
    );
  });

  it("case 4: Delete succeeds, Ignore control missing: Delete is kept and reported", async () => {
    const driver = new FakeDriver();
    driver.controls.ignore = false;
    const result = await run(driver);
    expect(driver.clicks).toEqual(["request:delete", "confirm:delete"]);
    expect(await logged()).toEqual([
      [
        "Started",
        "DeleteRequested",
        "DeleteConfirmed",
        "Failed:control-missing",
      ],
    ]);
    expect(result.report).toMatchObject({ delete: "done", ignore: "not-done" });
    expect(texts(result.report.lines)).toEqual(
      expect.arrayContaining([
        "Delete: done. JoyClub moved the conversation to the trash.",
        "Ignore: not done.",
        "JoyFox could not find JoyClub's Ignore option on this page.",
        "JoyFox did not undo anything.",
      ]),
    );
  });

  it("case 5: Ignore confirmation fails, or JoyClub does not show success", async () => {
    const missing = new FakeDriver();
    missing.confirmation.ignore = "missing";
    expect(texts((await run(missing)).report.lines)).toContain(
      "JoyClub's confirmation for Ignore did not appear.",
    );
    const unverified = new FakeDriver();
    unverified.verified.ignore = false;
    const report = (await run(unverified)).report;
    expect(report).toMatchObject({ delete: "done", ignore: "unknown" });
    expect(texts(report.lines)).toContain(
      "JoyClub did not show that Ignore succeeded.",
    );
    expect(await logged()).toEqual(
      expect.arrayContaining([
        [
          "Started",
          "DeleteRequested",
          "DeleteConfirmed",
          "IgnoreRequested",
          "Failed:confirmation-missing",
        ],
        [
          "Started",
          "DeleteRequested",
          "DeleteConfirmed",
          "IgnoreRequested",
          "Failed:not-verified",
        ],
      ]),
    );
  });

  it("case 6: a step that never answers times out, and a page that goes away stops the run", async () => {
    const hanging = new FakeDriver();
    hanging.afterClick = (click) =>
      click === "request:delete" ? new Promise(() => undefined) : undefined;
    const result = await run(hanging);
    expect(result.report.failure).toBe("timeout");
    expect(result.report.delete).toBe("unknown");
    const gone = new FakeDriver();
    gone.afterClick = (click) => {
      if (click === "request:delete") gone.current = () => ({ page: "other" });
    };
    const stopped = await run(gone);
    expect(stopped.report.failure).toBe("identity-unavailable");
    expect(gone.clicks).toEqual(["request:delete"]);
  });

  it("case 7: a closed tab leaves an interrupted log with the exact step reached", async () => {
    const recorder = client.recorder("account-a");
    const begun = await recorder.begin(TARGET);
    if (begun.status !== "started") throw new Error("not started");
    await recorder.record(begun.operationId, "DeleteRequested");
    // The tab closes here. Later, the page asks for the member's last run.
    clock += STALE_AFTER_MS + 60_000;
    const answer = await client.latest(MEMBER);
    expect(answer).toMatchObject({
      status: "ok",
      report: { status: "interrupted", delete: "unknown", ignore: "not-done" },
    });
    // An interrupted run does not block a new one.
    const again = await client.recorder("account-a").begin(TARGET);
    expect(again.status).toBe("started");
  });

  it("case 8: member identity mismatch stops before the click", async () => {
    const driver = new FakeDriver();
    driver.current = () => ({ ...HERE, memberId: "5550001" });
    expect((await run(driver)).report.failure).toBe("member-mismatch");
    expect(driver.clicks).toEqual([]);
    // Also on the profile, before Ignore's confirmation.
    const mid = new FakeDriver();
    mid.afterClick = (click) => {
      if (click === "request:ignore")
        mid.current = () => ({ ...PROFILE, memberId: "5550001" });
    };
    expect((await run(mid)).report.failure).toBe("member-mismatch");
    expect(mid.clicks).toEqual([
      "request:delete",
      "confirm:delete",
      "request:ignore",
    ]);
  });

  it("case 9: conversation identity mismatch stops before Delete", async () => {
    const driver = new FakeDriver();
    driver.current = () => ({
      ...HERE,
      conversationId: "personal-1234567-1111111",
    });
    const result = await run(driver);
    expect(result.report.failure).toBe("conversation-mismatch");
    expect(result.report).toMatchObject({
      delete: "not-done",
      ignore: "not-done",
    });
    expect(driver.clicks).toEqual([]);
  });

  it("case 10: markup that changes between steps stops the run", async () => {
    const driver = new FakeDriver();
    driver.afterClick = (click) => {
      if (click === "confirm:delete")
        driver.current = () => ({ page: "profile" });
    };
    const result = await run(driver);
    expect(result.report.failure).toBe("identity-unavailable");
    expect(driver.clicks).not.toContain("request:ignore");
  });

  it("case 11: the run continues after the background restarts", async () => {
    const first = client.recorder("account-a");
    let recorder: ActionRecorder = first;
    const driver = new FakeDriver();
    driver.afterClick = (click) => {
      if (click !== "confirm:delete") return;
      // A new background: new services, no memory, the same database.
      const restarted = backgroundRouter();
      recorder = messageQuickActionClient((message) =>
        restarted.route(message),
      ).recorder("account-a");
    };
    const result = await run(driver, {
      begin: (target) => recorder.begin(target),
      record: (id, state, failure) => recorder.record(id, state, failure),
    });
    expect(result.report.status).toBe("completed");
    expect(await logged()).toEqual([FULL]);
  });

  it("case 12: another account activated mid-sequence stops before the next click", async () => {
    const driver = new FakeDriver();
    driver.afterClick = (click) => {
      if (click === "confirm:delete") active = "account-b";
    };
    const result = await run(driver);
    expect(driver.clicks).toEqual(["request:delete", "confirm:delete"]);
    expect(result.report).toMatchObject({
      failure: "account-changed",
      delete: "done",
      ignore: "not-done",
    });
    // Account A's log stops where it could still write; B has nothing.
    expect(await logged("account-a")).toEqual([["Started", "DeleteRequested"]]);
    expect(await logged("account-b")).toEqual([]);
  });

  it("stores no start the tab stopped waiting for", async () => {
    const recorder = client.recorder("account-a");
    // The deadline passed while the request waited for the account lock.
    expect(await recorder.begin(TARGET, clock - 1)).toEqual({
      status: "expired",
    });
    expect(await logged()).toEqual([]);
    // A start within its deadline is stored.
    expect(await recorder.begin(TARGET, clock + 1000)).toMatchObject({
      status: "started",
    });
    expect(await logged()).toEqual([["Started"]]);
  });

  it("reports an expired start like a log that did not answer", async () => {
    const driver = new FakeDriver();
    const deadlines: Array<number | undefined> = [];
    const result = await run(driver, {
      begin: async (_target, deadline) => {
        deadlines.push(deadline);
        return { status: "expired" };
      },
      record: async () => "recorded",
    });
    expect(result.status).toBe("finished");
    expect(result.report.failure).toBe("log-unavailable");
    expect(driver.clicks).toEqual([]);
    // The deadline is the step timeout from now (200 ms in these tests).
    expect(deadlines[0]).toBeGreaterThan(Date.now() - 1000);
    expect(deadlines[0]).toBeLessThanOrEqual(Date.now() + 200);
  });

  it("lets a retry start once a late stored start stops counting as running", async () => {
    const recorder = client.recorder("account-a");
    // A start stored after its tab gave up: nothing continues it.
    const late = await recorder.begin(TARGET);
    if (late.status !== "started") throw new Error("not started");
    expect(await recorder.begin(TARGET)).toMatchObject({ status: "busy" });
    clock += STARTED_STALE_AFTER_MS + 1;
    const retry = await recorder.begin(TARGET);
    expect(retry.status).toBe("started");
    // Should the first tab wake up after all, it may not go on.
    expect(await recorder.record(late.operationId, "DeleteRequested")).toBe(
      "superseded",
    );
  });

  it("never clicks when the step cannot be recorded first", async () => {
    const driver = new FakeDriver();
    const result = await run(driver, {
      begin: (target) => client.recorder("account-a").begin(target),
      record: () => Promise.reject(new Error("storage failed")),
    });
    expect(driver.clicks).toEqual([]);
    expect(result.report.failure).toBe("log-unavailable");
    expect(texts(result.report.lines)).toContain(
      "Nothing was changed on JoyClub.",
    );
  });

  it("checks identity again after storing, right before the click", async () => {
    const driver = new FakeDriver();
    const recorder = client.recorder("account-a");
    // The page switches member while DeleteRequested is being stored.
    const result = await run(driver, {
      begin: (target) => recorder.begin(target),
      record: async (id, state, failure) => {
        const answer = await recorder.record(id, state, failure);
        if (state === "DeleteRequested")
          driver.current = () => ({ ...HERE, memberId: "5550001" });
        return answer;
      },
    });
    expect(driver.clicks).toEqual([]);
    expect(result.report.failure).toBe("member-mismatch");
    // The log says the step was started, never less than happened.
    expect(await logged()).toEqual([
      ["Started", "DeleteRequested", "Failed:member-mismatch"],
    ]);
  });

  it("stops before the click when the account changes while storing", async () => {
    let stop: "account-changed" | undefined;
    const driver = new FakeDriver();
    const recorder = client.recorder("account-a");
    const result = await run(
      driver,
      {
        begin: (target) => recorder.begin(target),
        record: async (id, state, failure) => {
          const answer = await recorder.record(id, state, failure);
          if (state === "IgnoreRequested") stop = "account-changed";
          return answer;
        },
      },
      { stopReason: () => stop },
    );
    expect(driver.clicks).toEqual(["request:delete", "confirm:delete"]);
    expect(result.report.failure).toBe("account-changed");
  });

  it("contains a driver that throws, and closes the log", async () => {
    const driver = new FakeDriver();
    driver.afterClick = (click) => {
      if (click === "confirm:delete")
        driver.current = () => {
          throw new Error("markup changed");
        };
    };
    const result = await run(driver);
    expect(result.report).toMatchObject({
      failure: "step-error",
      delete: "done",
      ignore: "not-done",
    });
    expect(await logged()).toEqual([
      ["Started", "DeleteRequested", "DeleteConfirmed", "Failed:step-error"],
    ]);
    const states: string[] = [];
    const noisy = await run(new FakeDriver(), undefined, {
      onState: (state) => {
        states.push(state);
        throw new Error("display failed");
      },
    });
    expect(noisy.report.status).toBe("completed");
    expect(states).toContain("Completed");
  });

  it("keeps Delete as done on screen when its result cannot be stored", async () => {
    const recorder = client.recorder("account-a");
    let lost = true;
    const result = await run(new FakeDriver(), {
      begin: (target) => recorder.begin(target),
      record: (id, state, failure) => {
        if (state === "DeleteConfirmed" && lost) {
          lost = false;
          return Promise.reject(new Error("port closed"));
        }
        return recorder.record(id, state, failure);
      },
    });
    expect(result.report).toMatchObject({ delete: "done", ignore: "not-done" });
    expect(texts(result.report.lines)).toContain(
      "JoyFox could not write to its action log, so it stopped before Ignore.",
    );
    // The stored log reads "not confirmed", never "not done".
    const stored = await client.latest(MEMBER);
    expect(stored).toMatchObject({ report: { delete: "unknown" } });
    if (stored.status !== "ok") throw new Error("no report");
    expect(texts(stored.report.lines)).toContain(
      "JoyFox could not write to its action log, so it stopped during Delete.",
    );
  });

  it("never clicks Ignore on the conversation page, nor Delete on the profile", async () => {
    const stays = new FakeDriver();
    // The page does not move to the profile after Delete.
    stays.current = () => HERE;
    const result = await run(stays);
    expect(result.report.failure).toBe("identity-unavailable");
    expect(stays.clicks).not.toContain("request:ignore");
    const onProfile = new FakeDriver();
    onProfile.current = () => PROFILE;
    expect((await run(onProfile)).report.failure).toBe("identity-unavailable");
    expect(onProfile.clicks).toEqual([]);
  });

  it("refuses every step of a run that a newer run replaced", async () => {
    const driver = new FakeDriver();
    driver.afterClick = async (click) => {
      if (click !== "request:delete") return;
      // This tab stalls past the interrupted threshold; another tab starts
      // a new run for the same member, which is allowed.
      clock += STALE_AFTER_MS + 60_000;
      const newer = await client.recorder("account-a").begin(TARGET);
      expect(newer.status).toBe("started");
    };
    const result = await run(driver);
    // The stalled run finishes the click it was in, then may not go on.
    expect(driver.clicks).toEqual(["request:delete", "confirm:delete"]);
    expect(result.report.failure).toBe("superseded");
    expect(texts(result.report.lines)).toContain(
      "A newer JoyFox run for this member started, so JoyFox stopped before Ignore.",
    );
    const logs = await repositories.actionLogs.list("account-a");
    expect(logs.map((log) => log.steps.at(-1)?.name).sort()).toEqual([
      "DeleteRequested",
      "Started",
    ]);
  });

  it("refuses a second run for a member while one is running", async () => {
    const recorder = client.recorder("account-a");
    await recorder.begin(TARGET);
    const second = await run(new FakeDriver());
    expect(second.status).toBe("busy");
    expect(await logged()).toHaveLength(1);
  });
});

describe("M9 hand-off to the profile page (ADR 0011)", () => {
  it("hands off after Delete, and the profile page finishes the run", async () => {
    const driver = new FakeDriver();
    driver.current = () => HERE;
    const handed: string[] = [];
    const first = await run(driver, undefined, {
      handOff: async (operationId, next) => {
        handed.push(`${operationId}:${next}`);
      },
    });
    expect(first.status).toBe("handed-off");
    expect(driver.clicks).toEqual(["request:delete", "confirm:delete"]);
    expect(handed).toEqual([`${first.operationId}:ignore`]);
    expect(await logged()).toEqual([
      ["Started", "DeleteRequested", "DeleteConfirmed"],
    ]);
    // The new page: the profile, resuming from Ignore.
    const [log] = await repositories.actionLogs.list("account-a");
    const profile = new FakeDriver();
    profile.current = () => PROFILE;
    const second = await run(profile, undefined, {
      resume: {
        operationId: first.operationId!,
        from: "ignore",
        steps: log!.steps,
      },
    });
    expect(profile.clicks).toEqual(["request:ignore", "confirm:ignore"]);
    expect(second.report.status).toBe("completed");
    expect(await logged()).toEqual([FULL]);
  });

  it("stops when the hand-off cannot be stored, so no page continues it", async () => {
    const driver = new FakeDriver();
    driver.current = () => HERE;
    const result = await run(driver, undefined, {
      handOff: () => Promise.reject(new Error("session storage failed")),
    });
    expect(result.status).toBe("finished");
    expect(result.report).toMatchObject({
      failure: "handoff-failed",
      delete: "done",
      ignore: "not-done",
    });
    expect(texts(result.report.lines)).toContain(
      "JoyFox could not move on to the member's profile, so it stopped before Ignore.",
    );
    expect(await logged()).toEqual([
      [
        "Started",
        "DeleteRequested",
        "DeleteConfirmed",
        "Failed:handoff-failed",
      ],
    ]);
  });

  it("does not hand off once the flag is off or the account changed", async () => {
    let stop: "turned-off" | undefined;
    const driver = new FakeDriver();
    driver.current = () => HERE;
    driver.afterClick = (click) => {
      if (click === "confirm:delete") stop = "turned-off";
    };
    let handed = false;
    const result = await run(driver, undefined, {
      stopReason: () => stop,
      handOff: async () => {
        handed = true;
      },
    });
    expect(handed).toBe(false);
    expect(result.report.failure).toBe("turned-off");
  });

  it("does not move on when the flag is turned off while the hand-off is stored", async () => {
    let stop: "turned-off" | undefined;
    const driver = new FakeDriver();
    driver.current = () => HERE;
    const result = await run(driver, undefined, {
      stopReason: () => stop,
      handOff: async () => {
        stop = "turned-off";
      },
    });
    expect(result.status).toBe("finished");
    expect(result.report.failure).toBe("turned-off");
  });

  it("reports a hand-off that never answers as a timeout", async () => {
    const driver = new FakeDriver();
    driver.current = () => HERE;
    const result = await run(driver, undefined, {
      handOff: () => new Promise(() => undefined),
    });
    expect(result.status).toBe("finished");
    expect(result.report.failure).toBe("timeout");
  });

  it("does not hand off when the next step's page is already shown", async () => {
    const driver = new FakeDriver();
    let handed = false;
    const result = await run(driver, undefined, {
      handOff: async () => {
        handed = true;
      },
    });
    expect(handed).toBe(false);
    expect(result.report.status).toBe("completed");
  });

  it("refuses to resume on another member's profile", async () => {
    const driver = new FakeDriver();
    driver.current = () => HERE;
    const first = await run(driver, undefined, { handOff: async () => {} });
    const [log] = await repositories.actionLogs.list("account-a");
    const other = new FakeDriver();
    other.current = () => ({ page: "profile", memberId: "5550001" });
    const result = await run(other, undefined, {
      resume: {
        operationId: first.operationId!,
        from: "ignore",
        steps: log!.steps,
      },
    });
    expect(result.report.failure).toBe("member-mismatch");
    expect(other.clicks).toEqual([]);
  });
});

describe("M9 hand-off messages (ADR 0011)", () => {
  // The tab reads its marker from the profile the run went to.
  beforeEach(onProfilePage);

  /** A run stopped right after Delete, as the conversation page leaves it. */
  async function afterDelete(): Promise<string> {
    const recorder = client.recorder("account-a");
    const begun = await recorder.begin(TARGET);
    if (begun.status !== "started") throw new Error("not started");
    await recorder.record(begun.operationId, "DeleteRequested");
    await recorder.record(begun.operationId, "DeleteConfirmed");
    return begun.operationId;
  }

  it("gives the marker to the same tab once, with the stored steps", async () => {
    const id = await afterDelete();
    await fromConversation().handOff("account-a", id, "ignore", PROFILE_PATH);
    // Another tab gets nothing.
    expect(await tabClient(8).pending()).toEqual({ status: "none" });
    const answer = await client.pending();
    expect(answer).toMatchObject({
      status: "ok",
      accountId: "account-a",
      operationId: id,
      memberId: MEMBER,
      conversationId: CONVERSATION,
      next: "ignore",
    });
    if (answer.status !== "ok") throw new Error("no marker");
    expect(answer.steps.map((step) => step.name)).toEqual([
      "Started",
      "DeleteRequested",
      "DeleteConfirmed",
    ]);
    // One-shot: a reload does not continue the run again.
    expect(await client.pending()).toEqual({ status: "none" });
  });

  it("survives a background restart, since the marker is in storage.session", async () => {
    const id = await afterDelete();
    await fromConversation().handOff("account-a", id, "ignore", PROFILE_PATH);
    const restarted = backgroundRouter();
    expect(await tabClient(TAB, () => restarted).pending()).toMatchObject({
      status: "ok",
      operationId: id,
    });
  });

  it("keeps the marker when a read fails, so a retry still finds it", async () => {
    const id = await afterDelete();
    await fromConversation().handOff("account-a", id, "ignore", PROFILE_PATH);
    // A background whose database read fails once, as during a restart.
    let fail = true;
    const actions = new ActionLogService(undefined, undefined, () =>
      new Date(clock).toISOString(),
    );
    const find = actions.find.bind(actions);
    actions.find = (accountId, operationId) => {
      if (fail) {
        fail = false;
        return Promise.reject(new Error("database closing"));
      }
      return find(accountId, operationId);
    };
    const flaky = new MessageRouter();
    registerActionHandlers(flaky, {
      actions,
      activeAccountId: () => Promise.resolve(active),
      now: () => clock,
      session,
    });
    const page = tabClient(TAB, () => flaky);
    await expect(page.pending()).rejects.toThrow();
    expect(await page.pending()).toMatchObject({
      status: "ok",
      operationId: id,
    });
  });

  it("refuses a hand-off before Delete is confirmed, or for an old run", async () => {
    const recorder = client.recorder("account-a");
    const begun = await recorder.begin(TARGET);
    if (begun.status !== "started") throw new Error("not started");
    await recorder.record(begun.operationId, "DeleteRequested");
    await expect(
      fromConversation().handOff(
        "account-a",
        begun.operationId,
        "ignore",
        PROFILE_PATH,
      ),
    ).rejects.toThrow();
    await recorder.record(begun.operationId, "DeleteConfirmed");
    // A newer run for the member replaces this one.
    clock += STALE_AFTER_MS + 60_000;
    await recorder.begin(TARGET);
    await expect(
      fromConversation().handOff(
        "account-a",
        begun.operationId,
        "ignore",
        PROFILE_PATH,
      ),
    ).rejects.toThrow();
    expect(session.items.size).toBe(0);
  });

  it("drops a marker that is stale, moved, or from another account", async () => {
    const id = await afterDelete();
    await fromConversation().handOff("account-a", id, "ignore", PROFILE_PATH);
    clock += STALE_AFTER_MS + 1;
    expect(await client.pending()).toEqual({ status: "none" });

    clock = Date.now();
    await freshDatabase();
    const moved = await afterDelete();
    await fromConversation().handOff(
      "account-a",
      moved,
      "ignore",
      PROFILE_PATH,
    );
    await client.recorder("account-a").record(moved, "IgnoreRequested");
    expect(await client.pending()).toEqual({ status: "none" });

    await freshDatabase();
    const switched = await afterDelete();
    await fromConversation().handOff(
      "account-a",
      switched,
      "ignore",
      PROFILE_PATH,
    );
    active = "account-b";
    // Closed under account A, and said, never left as still going.
    const stopped = await client.pending();
    expect(stopped).toMatchObject({ status: "stopped" });
    if (stopped.status !== "stopped") throw new Error("not stopped");
    expect(texts(stopped.lines)).toContain(
      "The active JoyFox account changed, so JoyFox stopped before Ignore.",
    );
    expect(texts(stopped.lines)).toContain(
      "Delete: done. JoyClub moved the conversation to the trash.",
    );
    expect((await logged("account-a")).at(-1)?.at(-1)).toBe(
      "Failed:account-changed",
    );
    expect(await logged("account-b")).toEqual([]);
  });

  it("hands off only from the run's own conversation page", async () => {
    const id = await afterDelete();
    const at = (url: string) =>
      messageQuickActionClient((message) =>
        router.route(message, { tabId: TAB, url }),
      ).handOff("account-a", id, "ignore", PROFILE_PATH);
    const origin = window.location.origin;
    // The profile itself, the inbox, another conversation, no address.
    await expect(at(`${origin}${PROFILE_PATH}`)).rejects.toThrow();
    await expect(at(`${origin}/clubmail/`)).rejects.toThrow();
    await expect(
      at(
        `${origin}/clubmail/conversation/conversation-wrapper-personal-1234567-5550001/`,
      ),
    ).rejects.toThrow();
    await expect(
      messageQuickActionClient((message) =>
        router.route(message, { tabId: TAB }),
      ).handOff("account-a", id, "ignore", PROFILE_PATH),
    ).rejects.toThrow();
    expect(session.items.size).toBe(0);
    // The run's own conversation, with or without the closing slash.
    await at(
      `${origin}/clubmail/conversation/conversation-wrapper-${CONVERSATION}`,
    );
    expect(session.items.size).toBe(1);
  });

  it("reads the tab's current address, as a conversation opened from the inbox keeps the inbox as its sender address", async () => {
    // Owner's live check, item 99 (2026-09-27): JoyClub opens a conversation
    // from the inbox in place, so `sender.url` still named the inbox and
    // every normal hand-off was refused. The tab's current address decides.
    const id = await afterDelete();
    const origin = window.location.origin;
    let tabAt = `${origin}/clubmail/conversation/conversation-wrapper-personal-1234567-5550001/`;
    const withTabs = new MessageRouter();
    registerActionHandlers(withTabs, {
      actions: new ActionLogService(undefined, undefined, () =>
        new Date(clock).toISOString(),
      ),
      activeAccountId: () => Promise.resolve(active),
      now: () => clock,
      session,
      tabUrl: (tabId) =>
        tabId === TAB ? Promise.resolve(tabAt) : Promise.reject(new Error()),
    });
    const fromInbox = () =>
      messageQuickActionClient((message) =>
        withTabs.route(message, { tabId: TAB, url: `${origin}/clubmail/` }),
      ).handOff("account-a", id, "ignore", PROFILE_PATH);
    // The tab shows another conversation: refused, whatever the sender says.
    await expect(fromInbox()).rejects.toThrow();
    expect(session.items.size).toBe(0);
    // The tab shows the run's conversation: stored, though the sender's
    // address is still the inbox.
    tabAt = CONVERSATION_URL;
    await fromInbox();
    expect(session.items.size).toBe(1);
  });

  it("withdraws only this run's marker in this tab, and closes the run", async () => {
    const id = await afterDelete();
    await fromConversation().handOff("account-a", id, "ignore", PROFILE_PATH);
    // Another tab, or another run, withdraws nothing.
    expect(await fromConversation(8).withdraw("account-a", id)).toEqual({
      status: "none",
    });
    expect(
      await fromConversation().withdraw("account-a", "action:other"),
    ).toEqual({ status: "none" });
    expect(session.items.size).toBe(1);
    const answer = await fromConversation().withdraw("account-a", id);
    expect(answer.status).toBe("withdrawn");
    if (answer.status !== "withdrawn") throw new Error("not withdrawn");
    expect(texts(answer.lines)).toContain(
      "JoyFox could not move on to the member's profile, so it stopped before Ignore.",
    );
    expect(texts(answer.lines)).toContain(
      "Delete: done. JoyClub moved the conversation to the trash.",
    );
    expect(await logged()).toEqual([
      [
        "Started",
        "DeleteRequested",
        "DeleteConfirmed",
        "Failed:handoff-failed",
      ],
    ]);
    // The profile, visited later in the tab, continues nothing.
    expect(session.items.size).toBe(0);
    expect(await client.pending()).toEqual({ status: "none" });
  });

  it("withdraws nothing once the profile has read the marker", async () => {
    const id = await afterDelete();
    await fromConversation().handOff("account-a", id, "ignore", PROFILE_PATH);
    expect(await client.pending()).toMatchObject({ status: "ok" });
    expect(await fromConversation().withdraw("account-a", id)).toEqual({
      status: "none",
    });
    expect(await logged()).toEqual([
      ["Started", "DeleteRequested", "DeleteConfirmed"],
    ]);
  });

  it("leaves the marker to the profile after an account switch", async () => {
    const id = await afterDelete();
    await fromConversation().handOff("account-a", id, "ignore", PROFILE_PATH);
    active = "account-b";
    expect(await fromConversation().withdraw("account-a", id)).toEqual({
      status: "none",
    });
    // The profile closes the run as an account change, as before.
    expect(await client.pending()).toMatchObject({ status: "stopped" });
    expect((await logged("account-a")).at(-1)?.at(-1)).toBe(
      "Failed:account-changed",
    );
  });

  /** A page in the tab at `path`, as the browser reports it. */
  const pageAt = (path: string, tabId = TAB) =>
    messageQuickActionClient((message) =>
      router.route(message, {
        tabId,
        url: `${window.location.origin}${path}`,
      }),
    );

  it("keeps the marker for the profile it names when that page loads", async () => {
    const id = await afterDelete();
    await fromConversation().handOff("account-a", id, "ignore", PROFILE_PATH);
    expect(await pageAt(PROFILE_PATH).dropStale()).toEqual({ status: "none" });
    expect(await client.pending()).toMatchObject({
      status: "ok",
      operationId: id,
    });
  });

  it("resumes on the run's member's profile under another slug spelling", async () => {
    // Owner's live check, item 99 (2026-09-27): the header's link and the
    // loaded profile can spell the nickname slug differently. The member ID
    // decides; the run must not end as handoff-failed on its own profile.
    const id = await afterDelete();
    await fromConversation().handOff("account-a", id, "ignore", PROFILE_PATH);
    const respelled = "/profile/1234567.Synthetic_One.html";
    expect(await pageAt(respelled).dropStale()).toEqual({ status: "none" });
    expect(session.items.size).toBe(1);
    expect(await pageAt(respelled).pending()).toMatchObject({
      status: "ok",
      operationId: id,
    });
  });

  it("drops the marker when another page loads in the tab, and closes the run", async () => {
    const id = await afterDelete();
    await fromConversation().handOff("account-a", id, "ignore", PROFILE_PATH);
    // Another tab changes nothing.
    expect(await pageAt("/clubmail/", 8).dropStale()).toEqual({
      status: "none",
    });
    expect(session.items.size).toBe(1);
    expect(await pageAt("/clubmail/").dropStale()).toEqual({
      status: "dropped",
    });
    expect(session.items.size).toBe(0);
    expect(await logged()).toEqual([
      [
        "Started",
        "DeleteRequested",
        "DeleteConfirmed",
        "Failed:handoff-failed",
      ],
    ]);
    // The profile, visited later in the tab, continues nothing.
    expect(await client.pending()).toEqual({ status: "none" });
  });

  it("drops the marker on another member's profile too", async () => {
    const id = await afterDelete();
    await fromConversation().handOff("account-a", id, "ignore", PROFILE_PATH);
    expect(await pageAt("/profile/5550001.synthetic.html").dropStale()).toEqual(
      { status: "dropped" },
    );
    expect((await logged()).at(-1)?.at(-1)).toBe("Failed:handoff-failed");
  });

  it("closes the run under its own account after an account switch", async () => {
    const id = await afterDelete();
    await fromConversation().handOff("account-a", id, "ignore", PROFILE_PATH);
    active = "account-b";
    expect(await pageAt("/clubmail/").dropStale()).toEqual({
      status: "dropped",
    });
    expect((await logged("account-a")).at(-1)?.at(-1)).toBe(
      "Failed:handoff-failed",
    );
    expect(await logged("account-b")).toEqual([]);
  });

  it("keeps the marker when closing the run fails, so a later page retries", async () => {
    const id = await afterDelete();
    await fromConversation().handOff("account-a", id, "ignore", PROFILE_PATH);
    // A background whose log write fails once, as during a restart.
    let fail = true;
    const actions = new ActionLogService(undefined, undefined, () =>
      new Date(clock).toISOString(),
    );
    const record = actions.record.bind(actions);
    actions.record = (...args: Parameters<typeof record>) => {
      if (fail) {
        fail = false;
        return Promise.reject(new Error("database closing"));
      }
      return record(...args);
    };
    const flaky = new MessageRouter();
    registerActionHandlers(flaky, {
      actions,
      activeAccountId: () => Promise.resolve(active),
      now: () => clock,
      session,
    });
    const inbox = messageQuickActionClient((message) =>
      flaky.route(message, {
        tabId: TAB,
        url: `${window.location.origin}/clubmail/`,
      }),
    );
    await expect(inbox.dropStale()).rejects.toThrow();
    expect(session.items.size).toBe(1);
    expect(await inbox.dropStale()).toEqual({ status: "dropped" });
    expect(session.items.size).toBe(0);
    expect((await logged()).at(-1)?.at(-1)).toBe("Failed:handoff-failed");
  });

  it("removes a stale marker without writing to the log", async () => {
    const id = await afterDelete();
    await fromConversation().handOff("account-a", id, "ignore", PROFILE_PATH);
    clock += STALE_AFTER_MS + 1;
    expect(await pageAt("/clubmail/").dropStale()).toEqual({ status: "none" });
    expect(session.items.size).toBe(0);
    expect(await logged()).toEqual([
      ["Started", "DeleteRequested", "DeleteConfirmed"],
    ]);
  });

  it("answers none when no marker waits in the tab", async () => {
    expect(await pageAt("/clubmail/").dropStale()).toEqual({ status: "none" });
    await expect(
      messageQuickActionClient((message) => router.route(message)).dropStale(),
    ).rejects.toThrow();
  });

  it("refuses a message without a tab, and a first step as the next", async () => {
    const id = await afterDelete();
    const noTab = messageQuickActionClient((message) => router.route(message));
    await expect(
      noTab.handOff("account-a", id, "ignore", PROFILE_PATH),
    ).rejects.toThrow();
    await expect(noTab.pending()).rejects.toThrow();
    await expect(
      fromConversation().handOff("account-a", id, "delete", PROFILE_PATH),
    ).rejects.toThrow();
  });
});

describe("M9 ActionLog messages", () => {
  const send = <K extends keyof MessageContract>(
    type: K,
    payload: MessageContract[K]["request"],
  ) => router.route({ type, requestId: "r1", payload });

  it("refuses a transition the state machine does not allow", async () => {
    const begun = await client.recorder("account-a").begin(TARGET);
    if (begun.status !== "started") throw new Error("not started");
    const record = client.recorder("account-a").record;
    expect(await record(begun.operationId, "IgnoreRequested")).toBe("invalid");
    expect(await record(begun.operationId, "Failed")).toBe("invalid");
    expect(await record(begun.operationId, "DeleteRequested", "timeout")).toBe(
      "invalid",
    );
    expect(await record("action:unknown", "DeleteRequested")).toBe(
      "unknown-operation",
    );
    expect(await logged()).toEqual([["Started"]]);
  });

  it("rejects malformed payloads and stores nothing", async () => {
    const rejected = { ok: false, error: { code: "HANDLER_FAILED" } };
    expect(
      await send("action.ignoreDelete.start", {
        accountId: "account-a",
        memberId: "Synthetic Name",
        conversationId: CONVERSATION,
      }),
    ).toMatchObject(rejected);
    expect(
      await send("action.ignoreDelete.start", {
        accountId: "account-a",
        memberId: MEMBER,
        conversationId: CONVERSATION,
        deadline: "soon" as never,
      }),
    ).toMatchObject(rejected);
    expect(
      await send("action.ignoreDelete.start", {
        accountId: "account-a",
        memberId: MEMBER,
        conversationId: "conversation 1",
      }),
    ).toMatchObject(rejected);
    expect(
      await send("action.ignoreDelete.record", {
        accountId: "account-a",
        operationId: "x",
        state: "Deleted" as never,
      }),
    ).toMatchObject(rejected);
    expect(
      await send("action.ignoreDelete.record", {
        accountId: "account-a",
        operationId: "x",
        state: "Failed",
        failure: "oops" as never,
      }),
    ).toMatchObject(rejected);
    expect(await logged()).toEqual([]);
  });

  it("stores the conversation ID only as text", async () => {
    const log = {
      id: "action:synthetic",
      accountId: "account-a",
      action: "quick-ignore-delete",
      steps: [],
      createdAt: "2026-09-23T10:00:00.000Z",
      updatedAt: "2026-09-23T10:00:00.000Z",
    };
    await expect(
      repositories.actionLogs.put("account-a", {
        ...log,
        conversationId: 3 as never,
      }),
    ).rejects.toThrow(/conversationId/);
    await repositories.actionLogs.put("account-a", {
      ...log,
      conversationId: CONVERSATION,
    });
  });

  it("marks every stored transition, so other tabs refresh", async () => {
    const settings = new MemorySettingsArea();
    const marked = new MessageRouter();
    registerActionHandlers(marked, {
      actions: new ActionLogService(),
      activeAccountId: () => Promise.resolve(active),
      settings,
    });
    const recorder = messageQuickActionClient((message) =>
      marked.route(message),
    ).recorder("account-a");
    const revision = () => settings.items.get(ACTION_REVISION_KEY);
    const begun = await recorder.begin(TARGET);
    if (begun.status !== "started") throw new Error("not started");
    const afterStart = revision();
    expect(afterStart).toEqual(expect.any(String));
    await recorder.record(begun.operationId, "IgnoreRequested");
    expect(revision()).toBe(afterStart);
    await recorder.record(begun.operationId, "DeleteRequested");
    expect(revision()).not.toBe(afterStart);
  });

  it("returns the stored conversation and when the run last moved", async () => {
    const begun = await client.recorder("account-a").begin(TARGET);
    if (begun.status !== "started") throw new Error("not started");
    expect(await client.latest(MEMBER)).toMatchObject({
      status: "ok",
      conversationId: CONVERSATION,
      updatedAt: new Date(clock).toISOString(),
    });
  });

  it("answers no-account and none", async () => {
    expect(await client.latest(MEMBER)).toEqual({
      status: "none",
      accountId: "account-a",
    });
    active = undefined;
    expect(await client.latest(MEMBER)).toEqual({ status: "no-account" });
  });
});

describe("M9 button and notice", () => {
  const section = () =>
    document.querySelector<HTMLElement>('[data-joyfox-ui="quick-action"]');
  const runButton = () =>
    Array.from(section()?.querySelectorAll("button") ?? []).find(
      (node) => node.textContent === t(QUICK_ACTION_TEXT.button),
    );
  const deleteButton = () =>
    Array.from(section()?.querySelectorAll("button") ?? []).find(
      (node) => node.textContent === t(QUICK_ACTION_TEXT.deleteButton),
    );
  const notice = () => section()?.textContent ?? "";

  function openConversation(driver?: QuickActionDriver) {
    window.history.replaceState(
      null,
      "",
      `/clubmail/conversation/conversation-wrapper-${CONVERSATION}`,
    );
    document.body.innerHTML = conversationHtml;
    const quick = new QuickIgnoreDelete(document, client, () => driver);
    quick.update();
    return quick;
  }

  it("has a live driver now, and never appears without one", async () => {
    expect(liveQuickActionDriver()).toBeInstanceOf(JoyClubQuickActionDriver);
    openConversation(undefined);
    await new Promise((resolve) => setTimeout(resolve, 20));
    expect(section()).toBeNull();
  });

  it("hands off to the sender's profile after Delete, and the profile finishes", async () => {
    const driver = new FakeDriver();
    // The live page stays on the conversation until JoyFox navigates.
    driver.current = () => HERE;
    const visited: string[] = [];
    window.history.replaceState(
      null,
      "",
      `/clubmail/conversation/conversation-wrapper-${CONVERSATION}`,
    );
    document.body.innerHTML = conversationHtml;
    const quick = new QuickIgnoreDelete(
      document,
      client,
      () => driver,
      (url) => visited.push(url),
    );
    quick.update();
    await vi.waitFor(() => expect(runButton()).toBeDefined());
    runButton()!.click();
    // The page moves only once the run returns "handed-off".
    await vi.waitFor(() => expect(visited).toHaveLength(1));
    await vi.waitFor(() =>
      expect(notice()).toContain(t(QUICK_ACTION_TEXT.handedOff)),
    );
    expect(visited).toEqual([
      `${window.location.origin}/profile/1234567.synthetic_one.html`,
    ]);
    expect(driver.clicks).toEqual(["request:delete", "confirm:delete"]);

    // The tab loads the profile; the conversation page goes, and a new
    // content script starts there.
    window.dispatchEvent(new Event("pagehide"));
    window.history.replaceState(
      null,
      "",
      "/profile/1234567.synthetic_one.html",
    );
    document.body.innerHTML = profileHtml;
    const onProfile = new FakeDriver();
    onProfile.current = () => PROFILE;
    const resumed = new QuickIgnoreDelete(document, client, () => onProfile);
    resumed.updateProfile();
    await vi.waitFor(() =>
      expect(notice()).toContain("Ignore and Delete finished."),
    );
    expect(notice()).toContain(t(QUICK_ACTION_TEXT.resumed));
    expect(onProfile.clicks).toEqual(["request:ignore", "confirm:ignore"]);
    expect(await logged()).toEqual([FULL]);
    // No button on the profile, and a reload does not run it again.
    expect(runButton()).toBeUndefined();
    const again = new FakeDriver();
    again.current = () => PROFILE;
    new QuickIgnoreDelete(document, client, () => again).updateProfile();
    await new Promise((resolve) => setTimeout(resolve, 30));
    expect(again.clicks).toEqual([]);
  });

  /** A conversation page whose navigation to the profile is a stub. */
  function conversationPage(driver: QuickActionDriver, visited: string[]) {
    window.history.replaceState(
      null,
      "",
      `/clubmail/conversation/conversation-wrapper-${CONVERSATION}`,
    );
    document.body.innerHTML = conversationHtml;
    const quick = new QuickIgnoreDelete(
      document,
      client,
      () => driver,
      (url) => visited.push(url),
      () => Date.now(),
      60,
    );
    quick.update();
    return quick;
  }

  it("withdraws the hand-off when the page is not left for the profile", async () => {
    const driver = new FakeDriver();
    driver.current = () => HERE;
    const visited: string[] = [];
    conversationPage(driver, visited);
    await vi.waitFor(() => expect(runButton()).toBeDefined());
    runButton()!.click();
    await vi.waitFor(() => expect(visited).toHaveLength(1));
    // The navigation is cancelled: this page stays, and says what was done.
    await vi.waitFor(() =>
      expect(notice()).toContain(
        "JoyFox could not move on to the member's profile, so it stopped before Ignore.",
      ),
    );
    expect(notice()).toContain(
      "Delete: done. JoyClub moved the conversation to the trash.",
    );
    expect((await logged())[0]?.at(-1)).toBe("Failed:handoff-failed");
    expect(session.items.size).toBe(0);
    // A later visit to the profile in this tab continues nothing.
    onProfilePage();
    document.body.innerHTML = profileHtml;
    const later = new FakeDriver();
    later.current = () => PROFILE;
    new QuickIgnoreDelete(document, client, () => later).updateProfile();
    await new Promise((resolve) => setTimeout(resolve, 30));
    expect(later.clicks).toEqual([]);
  });

  it("keeps the hand-off once the page is left for the profile", async () => {
    const driver = new FakeDriver();
    driver.current = () => HERE;
    const visited: string[] = [];
    conversationPage(driver, visited);
    await vi.waitFor(() => expect(runButton()).toBeDefined());
    runButton()!.click();
    await vi.waitFor(() => expect(visited).toHaveLength(1));
    // The browser unloads the page on its way to the profile.
    window.dispatchEvent(new Event("pagehide"));
    await new Promise((resolve) => setTimeout(resolve, 120));
    expect(session.items.size).toBe(1);
    expect((await logged())[0]?.at(-1)).toBe("DeleteConfirmed");
    onProfilePage();
    document.body.innerHTML = profileHtml;
    const onProfile = new FakeDriver();
    onProfile.current = () => PROFILE;
    new QuickIgnoreDelete(document, client, () => onProfile).updateProfile();
    await vi.waitFor(async () =>
      expect((await logged())[0]?.at(-1)).toBe("Completed"),
    );
    expect(onProfile.clicks).toEqual(["request:ignore", "confirm:ignore"]);
  });

  it("drops a hand-off when another page loads in the tab first", async () => {
    const driver = new FakeDriver();
    driver.current = () => HERE;
    const visited: string[] = [];
    conversationPage(driver, visited);
    await vi.waitFor(() => expect(runButton()).toBeDefined());
    runButton()!.click();
    await vi.waitFor(() => expect(visited).toHaveLength(1));
    // The move is cancelled and the user opens the inbox instead: the old
    // page goes (so its own wait ends), and a new page loads.
    window.dispatchEvent(new Event("pagehide"));
    window.history.replaceState(null, "", "/clubmail/");
    document.body.innerHTML = "";
    const inbox = new QuickIgnoreDelete(
      document,
      client,
      () => new FakeDriver(),
    );
    inbox.pageSeen();
    inbox.pageSeen();
    await vi.waitFor(async () =>
      expect((await logged())[0]?.at(-1)).toBe("Failed:handoff-failed"),
    );
    // Later, the member's profile in the same tab continues nothing.
    onProfilePage();
    document.body.innerHTML = profileHtml;
    const later = new FakeDriver();
    later.current = () => PROFILE;
    const profile = new QuickIgnoreDelete(document, client, () => later);
    profile.pageSeen();
    profile.updateProfile();
    await new Promise((resolve) => setTimeout(resolve, 30));
    expect(later.clicks).toEqual([]);
  });

  it("still finishes on the profile when that page reports itself first", async () => {
    const driver = new FakeDriver();
    driver.current = () => HERE;
    const visited: string[] = [];
    conversationPage(driver, visited);
    await vi.waitFor(() => expect(runButton()).toBeDefined());
    runButton()!.click();
    await vi.waitFor(() => expect(visited).toHaveLength(1));
    window.dispatchEvent(new Event("pagehide"));
    onProfilePage();
    document.body.innerHTML = profileHtml;
    const onProfile = new FakeDriver();
    onProfile.current = () => PROFILE;
    const profile = new QuickIgnoreDelete(document, client, () => onProfile);
    // As in the content script: the page is reported, then updated.
    profile.pageSeen();
    profile.updateProfile();
    await vi.waitFor(async () =>
      expect((await logged())[0]?.at(-1)).toBe("Completed"),
    );
    expect(onProfile.clicks).toEqual(["request:ignore", "confirm:ignore"]);
  });

  it("asks to drop a hand-off once per page, and only with a driver", async () => {
    let asked = 0;
    const counting: QuickActionClient = {
      ...client,
      dropStale: () => {
        asked += 1;
        return Promise.resolve({ status: "none" });
      },
    };
    const none = new QuickIgnoreDelete(document, counting, () => undefined);
    none.pageSeen();
    expect(asked).toBe(0);
    const page = new QuickIgnoreDelete(
      document,
      counting,
      () => new FakeDriver(),
    );
    page.pageSeen();
    page.pageSeen();
    expect(asked).toBe(1);
  });

  it("starts nothing when the member's profile address is unknown", async () => {
    const driver = new FakeDriver();
    openConversation(driver);
    await vi.waitFor(() => expect(runButton()).toBeDefined());
    // The header's link no longer names the member's profile.
    document
      .querySelector(".cm-conversation-header")!
      .setAttribute("href", "https://example.invalid/profile/1234567.x.html");
    runButton()!.click();
    await vi.waitFor(() =>
      expect(notice()).toContain(t(QUICK_ACTION_TEXT.noProfile)),
    );
    // No technical term, and a way to do it by hand.
    expect(notice()).toContain(
      "JoyFox cannot find the link to this member's profile, where Ignore is, so it did nothing. You can do it yourself: move the conversation to the trash with JoyClub's trash button, then open the member's profile and ignore them there.",
    );
    expect(driver.clicks).toEqual([]);
    expect(await logged()).toEqual([]);
  });

  it("drops a waiting hand-off when the flag is off, so it never runs later", async () => {
    const recorder = client.recorder("account-a");
    const begun = await recorder.begin(TARGET);
    if (begun.status !== "started") throw new Error("not started");
    await recorder.record(begun.operationId, "DeleteRequested");
    await recorder.record(begun.operationId, "DeleteConfirmed");
    await fromConversation().handOff(
      "account-a",
      begun.operationId,
      "ignore",
      PROFILE_PATH,
    );
    onProfilePage();
    document.body.innerHTML = profileHtml;
    const driver = new FakeDriver();
    driver.current = () => PROFILE;
    // The profile loads with the flag off.
    const off = new QuickIgnoreDelete(document, client, () => driver);
    off.turnOff();
    await vi.waitFor(async () =>
      expect((await logged())[0]?.at(-1)).toBe("Failed:turned-off"),
    );
    // Turned on again: nothing is left to continue.
    const on = new QuickIgnoreDelete(document, client, () => driver);
    on.updateProfile();
    await new Promise((resolve) => setTimeout(resolve, 30));
    expect(driver.clicks).toEqual([]);
  });

  it("closes a hand-off already read when the flag is turned off", async () => {
    const recorder = client.recorder("account-a");
    const begun = await recorder.begin(TARGET);
    if (begun.status !== "started") throw new Error("not started");
    await recorder.record(begun.operationId, "DeleteRequested");
    await recorder.record(begun.operationId, "DeleteConfirmed");
    await fromConversation().handOff(
      "account-a",
      begun.operationId,
      "ignore",
      PROFILE_PATH,
    );
    onProfilePage();
    document.body.innerHTML = profileHtml;
    // The profile menu is not there yet, so the run waits after reading.
    const driver = new FakeDriver();
    driver.current = () => PROFILE;
    driver.controls.ignore = false;
    const quick = new QuickIgnoreDelete(document, client, () => driver);
    quick.updateProfile();
    // Let the page read (and so remove) its marker.
    await new Promise((resolve) => setTimeout(resolve, 50));
    expect(await client.pending()).toEqual({ status: "none" });
    quick.turnOff();
    await vi.waitFor(async () =>
      expect((await logged())[0]?.at(-1)).toBe("Failed:turned-off"),
    );
    expect(driver.clicks).toEqual([]);
  });

  it("asks again when reading the hand-off fails once", async () => {
    const recorder = client.recorder("account-a");
    const begun = await recorder.begin(TARGET);
    if (begun.status !== "started") throw new Error("not started");
    await recorder.record(begun.operationId, "DeleteRequested");
    await recorder.record(begun.operationId, "DeleteConfirmed");
    await fromConversation().handOff(
      "account-a",
      begun.operationId,
      "ignore",
      PROFILE_PATH,
    );
    onProfilePage();
    document.body.innerHTML = profileHtml;
    let failures = 1;
    const flaky: QuickActionClient = {
      ...client,
      pending: () =>
        failures-- > 0
          ? Promise.reject(new Error("background restarting"))
          : client.pending(),
    };
    const driver = new FakeDriver();
    driver.current = () => PROFILE;
    new QuickIgnoreDelete(document, flaky, () => driver).updateProfile();
    await vi.waitFor(
      () => expect(driver.clicks).toEqual(["request:ignore", "confirm:ignore"]),
      { timeout: 3000 },
    );
    // Let the run store its last steps before the next test starts.
    await vi.waitFor(async () =>
      expect((await logged())[0]?.at(-1)).toBe("Completed"),
    );
  });

  it("shows a hand-off stopped by an account switch on the profile", async () => {
    const recorder = client.recorder("account-a");
    const begun = await recorder.begin(TARGET);
    if (begun.status !== "started") throw new Error("not started");
    await recorder.record(begun.operationId, "DeleteRequested");
    await recorder.record(begun.operationId, "DeleteConfirmed");
    await fromConversation().handOff(
      "account-a",
      begun.operationId,
      "ignore",
      PROFILE_PATH,
    );
    active = "account-b";
    onProfilePage();
    document.body.innerHTML = profileHtml;
    const driver = new FakeDriver();
    driver.current = () => PROFILE;
    new QuickIgnoreDelete(document, client, () => driver).updateProfile();
    await vi.waitFor(() =>
      expect(notice()).toContain("The active JoyFox account changed"),
    );
    expect(driver.clicks).toEqual([]);
  });

  it("reads the hand-off only on the profile it named", async () => {
    const recorder = client.recorder("account-a");
    const begun = await recorder.begin(TARGET);
    if (begun.status !== "started") throw new Error("not started");
    await recorder.record(begun.operationId, "DeleteRequested");
    await recorder.record(begun.operationId, "DeleteConfirmed");
    await fromConversation().handOff(
      "account-a",
      begun.operationId,
      "ignore",
      PROFILE_PATH,
    );
    window.history.replaceState(null, "", "/clubmail/");
    expect(await client.pending()).toEqual({ status: "none" });
  });

  it("does not continue a hand-off on another member's profile", async () => {
    const recorder = client.recorder("account-a");
    const begun = await recorder.begin(TARGET);
    if (begun.status !== "started") throw new Error("not started");
    await recorder.record(begun.operationId, "DeleteRequested");
    await recorder.record(begun.operationId, "DeleteConfirmed");
    await fromConversation().handOff(
      "account-a",
      begun.operationId,
      "ignore",
      PROFILE_PATH,
    );
    window.history.replaceState(null, "", "/profile/5550001.synthetic.html");
    document.body.innerHTML = profileHtml;
    const other = new FakeDriver();
    other.current = () => ({ page: "profile", memberId: "5550001" });
    new QuickIgnoreDelete(document, client, () => other).updateProfile();
    await new Promise((resolve) => setTimeout(resolve, 30));
    expect(other.clicks).toEqual([]);
    expect(section()).toBeNull();
  });

  it("goes only to the run's member on this site", () => {
    const header = document.createElement("a");
    const at = (href: string) => {
      header.setAttribute("href", href);
      return profileUrl(header, MEMBER);
    };
    expect(at("/profile/1234567.synthetic_one.html")).toBe(
      `${window.location.origin}/profile/1234567.synthetic_one.html`,
    );
    expect(at("/profile/5550001.synthetic.html")).toBeUndefined();
    expect(
      at("https://example.invalid/profile/1234567.x.html"),
    ).toBeUndefined();
    expect(at("/clubmail/")).toBeUndefined();
  });

  it("runs on one click and shows what was done", async () => {
    const driver = new FakeDriver();
    openConversation(driver);
    await vi.waitFor(() => expect(runButton()).toBeDefined());
    const header = document.querySelector(".cm-conversation-header")!;
    expect(header.nextElementSibling).toBe(section()?.parentElement);
    expect(section()?.parentElement?.getAttribute("data-joyfox-ui")).toBe(
      "member-strip",
    );
    expect(notice()).toContain("It never sends a message.");
    runButton()!.click();
    await vi.waitFor(() =>
      expect(notice()).toContain("Ignore and Delete finished."),
    );
    expect(driver.clicks).toHaveLength(4);
    expect(await logged()).toEqual([FULL]);
  });

  it("names the failed step and the next manual action", async () => {
    const driver = new FakeDriver();
    driver.controls.ignore = false;
    openConversation(driver);
    await vi.waitFor(() => expect(runButton()).toBeDefined());
    runButton()!.click();
    await vi.waitFor(() =>
      expect(notice()).toContain(
        "JoyFox could not find JoyClub's Ignore option on this page.",
      ),
    );
    expect(notice()).toContain("Delete: done.");
    expect(notice()).toContain("ignore them there yourself");
    const status = section()?.querySelector('[role="status"]');
    expect(status?.getAttribute("aria-live")).toBe("polite");
  });

  it("shows an interrupted earlier run from the ActionLog", async () => {
    const begun = await client.recorder("account-a").begin(TARGET);
    if (begun.status !== "started") throw new Error("not started");
    await client
      .recorder("account-a")
      .record(begun.operationId, "DeleteRequested");
    clock += STALE_AFTER_MS + 60_000;
    openConversation(new FakeDriver());
    await vi.waitFor(() =>
      expect(notice()).toContain(t(QUICK_ACTION_TEXT.previous)),
    );
    expect(notice()).toContain("was interrupted");
    expect(notice()).toContain("Delete: not confirmed.");
  });

  it("ignores a second click while running", async () => {
    const driver = new FakeDriver();
    let release: () => void = () => undefined;
    driver.afterClick = (click) =>
      click === "request:delete"
        ? new Promise<void>((resolve) => {
            release = resolve;
          })
        : undefined;
    openConversation(driver);
    await vi.waitFor(() => expect(runButton()).toBeDefined());
    runButton()!.click();
    await vi.waitFor(() => expect(driver.clicks).toEqual(["request:delete"]));
    expect(runButton()?.getAttribute("aria-disabled")).toBe("true");
    runButton()!.click();
    release();
    await vi.waitFor(() =>
      expect(notice()).toContain("Ignore and Delete finished."),
    );
    expect(await logged()).toHaveLength(1);
  });

  it("stops before the next click when the account changes", async () => {
    const driver = new FakeDriver();
    let release: () => void = () => undefined;
    driver.afterClick = (click) =>
      click === "confirm:delete"
        ? new Promise<void>((resolve) => {
            release = resolve;
          })
        : undefined;
    const quick = openConversation(driver);
    await vi.waitFor(() => expect(runButton()).toBeDefined());
    runButton()!.click();
    await vi.waitFor(() => expect(driver.clicks).toContain("confirm:delete"));
    active = "account-b";
    quick.accountChanged();
    release();
    await vi.waitFor(() =>
      expect(notice()).toContain("The active JoyFox account changed"),
    );
    expect(driver.clicks).not.toContain("request:ignore");
  });

  it("keeps one live region while the run moves", async () => {
    const driver = new FakeDriver();
    openConversation(driver);
    await vi.waitFor(() => expect(runButton()).toBeDefined());
    const region = section()?.querySelector('[role="status"]');
    runButton()!.click();
    await vi.waitFor(() =>
      expect(notice()).toContain("Ignore and Delete finished."),
    );
    expect(section()?.querySelector('[role="status"]')).toBe(region);
  });

  it("ties a run to its conversation and shows its result on the next one", async () => {
    const driver = new FakeDriver();
    let release: () => void = () => undefined;
    driver.afterClick = (click) =>
      click === "request:delete"
        ? new Promise<void>((resolve) => {
            release = resolve;
          })
        : undefined;
    const quick = openConversation(driver);
    await vi.waitFor(() => expect(runButton()).toBeDefined());
    runButton()!.click();
    await vi.waitFor(() => expect(driver.clicks).toEqual(["request:delete"]));
    // JoyClub routes to another member's conversation in place.
    window.history.replaceState(
      null,
      "",
      "/clubmail/conversation/conversation-wrapper-personal-5550001-7654321",
    );
    document
      .querySelector(".cm-conversation-header")!
      .setAttribute("href", "/profile/5550001.synthetic_four.html");
    driver.current = () => ({
      page: "conversation",
      memberId: "5550001",
      conversationId: "personal-5550001-7654321",
    });
    quick.update();
    await vi.waitFor(() =>
      expect(notice()).toContain(t(QUICK_ACTION_TEXT.otherRunning)),
    );
    expect(runButton()?.getAttribute("aria-disabled")).toBe("true");
    release();
    await vi.waitFor(() =>
      expect(notice()).toContain(t(QUICK_ACTION_TEXT.otherResult)),
    );
    expect(notice()).toContain("The page showed another member");
    expect(notice()).toContain("Delete: not confirmed.");
    expect(driver.clicks).toEqual(["request:delete"]);
    expect(runButton()?.getAttribute("aria-disabled")).toBe("false");
  });

  it("stops a run and hides Ignore and Delete when the flag is turned off, keeping Delete", async () => {
    const driver = new FakeDriver();
    let release: () => void = () => undefined;
    driver.afterClick = (click) =>
      click === "request:delete"
        ? new Promise<void>((resolve) => {
            release = resolve;
          })
        : undefined;
    const quick = openConversation(driver);
    await vi.waitFor(() => expect(runButton()).toBeDefined());
    runButton()!.click();
    await vi.waitFor(() => expect(driver.clicks).toEqual(["request:delete"]));
    // The content script turns it off, then updates the page (D2).
    quick.turnOff();
    quick.update();
    expect(runButton()).toBeUndefined();
    expect(deleteButton()).toBeDefined();
    release();
    await vi.waitFor(async () =>
      expect((await logged())[0]?.at(-1)).toBe("Failed:turned-off"),
    );
    await new Promise((resolve) => setTimeout(resolve, 20));
    expect(runButton()).toBeUndefined();
    // The stored run still says how far it got, so a partial result is
    // never lost from view.
    await vi.waitFor(() =>
      expect(notice()).toContain(
        "Ignore and Delete was turned off, so JoyFox stopped during Delete.",
      ),
    );
    expect(driver.clicks).toEqual(["request:delete"]);
  });

  it("follows another tab's run, and says a busy click did nothing", async () => {
    const quick = openConversation(new FakeDriver());
    await vi.waitFor(() => expect(runButton()).toBeDefined());
    // Another tab starts a run for the same member.
    const other = client.recorder("account-a");
    const begun = await other.begin(TARGET);
    if (begun.status !== "started") throw new Error("not started");
    quick.invalidate();
    await vi.waitFor(() =>
      expect(runButton()?.getAttribute("aria-disabled")).toBe("true"),
    );
    // The other tab's run stops; the next revision event reloads the log.
    await other.record(begun.operationId, "Failed", "control-missing");
    quick.invalidate();
    await vi.waitFor(() =>
      expect(runButton()?.getAttribute("aria-disabled")).toBe("false"),
    );
    expect(notice()).toContain(t(QUICK_ACTION_TEXT.previous));
  });

  it("labels an earlier run from another conversation with the member", async () => {
    const begun = await client
      .recorder("account-a")
      .begin({ ...TARGET, conversationId: "personal-1234567-1111111" });
    if (begun.status !== "started") throw new Error("not started");
    await client
      .recorder("account-a")
      .record(begun.operationId, "Failed", "control-missing");
    openConversation(new FakeDriver());
    await vi.waitFor(() =>
      expect(notice()).toContain(t(QUICK_ACTION_TEXT.previousOther)),
    );
    expect(notice()).not.toContain(t(QUICK_ACTION_TEXT.previous));
  });

  it("sets the stale timer once, from when the other run last moved", async () => {
    const quick = openConversation(new FakeDriver());
    await vi.waitFor(() => expect(runButton()).toBeDefined());
    // Another tab's run last moved 110 seconds ago, past its start.
    clock = Date.now() - (STALE_AFTER_MS - 10_000);
    const begun = await client.recorder("account-a").begin(TARGET);
    if (begun.status !== "started") throw new Error("not started");
    await client
      .recorder("account-a")
      .record(begun.operationId, "DeleteRequested");
    const timer = vi.spyOn(globalThis, "setTimeout");
    const staleTimers = () =>
      timer.mock.calls.filter(([, delay]) => (delay ?? 0) >= 5_000);
    quick.invalidate();
    await vi.waitFor(() =>
      expect(runButton()?.getAttribute("aria-disabled")).toBe("true"),
    );
    expect(staleTimers()).toHaveLength(1);
    const delay = staleTimers()[0]![1]!;
    expect(delay).toBeGreaterThan(5_000);
    expect(delay).toBeLessThan(15_000);
    // Page mutations redraw often; none may postpone the timer.
    for (let index = 0; index < 5; index += 1) quick.update();
    expect(staleTimers()).toHaveLength(1);
    timer.mockRestore();
  });

  it("sets the stale timer from the shorter wait for a run still at its start", async () => {
    const quick = openConversation(new FakeDriver());
    await vi.waitFor(() => expect(runButton()).toBeDefined());
    // Another tab's run started 20 seconds ago and has not moved since.
    clock = Date.now() - (STARTED_STALE_AFTER_MS - 10_000);
    const begun = await client.recorder("account-a").begin(TARGET);
    if (begun.status !== "started") throw new Error("not started");
    const timer = vi.spyOn(globalThis, "setTimeout");
    const staleTimers = () =>
      timer.mock.calls.filter(([, delay]) => (delay ?? 0) >= 5_000);
    quick.invalidate();
    await vi.waitFor(() =>
      expect(runButton()?.getAttribute("aria-disabled")).toBe("true"),
    );
    const delay = staleTimers()[0]![1]!;
    expect(delay).toBeGreaterThan(5_000);
    expect(delay).toBeLessThan(15_000);
    timer.mockRestore();
  });

  it("shows nothing without an active account", async () => {
    active = undefined;
    openConversation(new FakeDriver());
    await new Promise((resolve) => setTimeout(resolve, 20));
    expect(section()).toBeNull();
  });

  it("names what the click does in the button's description, as a group", async () => {
    openConversation(new FakeDriver());
    await vi.waitFor(() => expect(runButton()).toBeDefined());
    // The click is the confirmation, so a screen reader reads the note too.
    const described = runButton()!.getAttribute("aria-describedby")!;
    expect(document.getElementById(described)?.textContent).toBe(
      t(QUICK_ACTION_TEXT.scope),
    );
    // A group inside the strip's one region, not a landmark of its own.
    expect(section()?.getAttribute("role")).toBe("group");
    expect(section()?.parentElement?.getAttribute("role")).toBe("region");
  });

  it("greys out both buttons and says why when the list that shows Delete's result is missing", async () => {
    const driver = new FakeDriver();
    driver.listShown = false;
    const quick = openConversation(driver);
    await vi.waitFor(() => expect(runButton()).toBeDefined());
    const hint = () =>
      Array.from(section()!.querySelectorAll<HTMLElement>("p")).find(
        (node) => node.textContent === t(QUICK_ACTION_TEXT.needsList),
      )!;
    expect(t(QUICK_ACTION_TEXT.needsList)).toBe(
      "Works only while this conversation shows in the ClubMail list beside it. Widen the window, or scroll the list until the conversation shows.",
    );
    expect(hint().hidden).toBe(false);
    // Right under the buttons, and part of each one's description.
    expect(runButton()!.parentElement!.nextElementSibling).toBe(hint());
    for (const node of [runButton()!, deleteButton()!]) {
      expect(node.getAttribute("aria-describedby")?.split(" ")).toContain(
        hint().id,
      );
      // Greyed out (owner decision, 2026-09-29): a click does nothing.
      expect(node.getAttribute("aria-disabled")).toBe("true");
    }
    runButton()!.click();
    deleteButton()!.click();
    await new Promise((resolve) => setTimeout(resolve, 20));
    expect(driver.clicks).toEqual([]);
    expect(await logged()).toEqual([]);
    // The window is widened: the next redraw hides it and frees the buttons.
    driver.listShown = true;
    quick.update();
    expect(hint().hidden).toBe(true);
    expect(runButton()!.getAttribute("aria-describedby")?.split(" ")).toEqual([
      expect.stringMatching(/^joyfox-quick-scope-/),
    ]);
    expect(runButton()!.getAttribute("aria-disabled")).toBe("false");
    expect(deleteButton()!.getAttribute("aria-disabled")).toBe("false");
  });

  it("hides the list hint while a run goes and once the conversation is in the trash", async () => {
    const driver = new FakeDriver();
    // The live page stays on the conversation; Delete removes the row.
    driver.current = () => HERE;
    let release: () => void = () => undefined;
    driver.afterClick = (click) => {
      if (click !== "confirm:delete") return undefined;
      driver.listShown = false;
      return new Promise<void>((resolve) => (release = resolve));
    };
    const visited: string[] = [];
    window.history.replaceState(
      null,
      "",
      `/clubmail/conversation/conversation-wrapper-${CONVERSATION}`,
    );
    document.body.innerHTML = conversationHtml;
    const quick = new QuickIgnoreDelete(
      document,
      client,
      () => driver,
      (url) => visited.push(url),
      () => Date.now(),
      60,
    );
    quick.update();
    await vi.waitFor(() => expect(runButton()).toBeDefined());
    const hint = () =>
      section()!.querySelector<HTMLElement>(".joyfox-quick-action__hint")!;
    runButton()!.click();
    await vi.waitFor(() => expect(driver.clicks).toContain("confirm:delete"));
    quick.update();
    expect(hint().hidden).toBe(true);
    release();
    // The move to the profile is cancelled: the page stays, Delete is done.
    await vi.waitFor(async () =>
      expect((await logged())[0]?.at(-1)).toBe("Failed:handoff-failed"),
    );
    await vi.waitFor(() => expect(notice()).toContain("Delete: done."));
    quick.update();
    expect(hint().hidden).toBe(true);
  });

  /**
   * A run handed off to the profile, whose menu is not there yet. Moves
   * the page would make are kept in `visited`.
   */
  async function handedOffToProfile(
    driver: FakeDriver,
    visited: string[] = [],
    returnWaitMs = 20,
  ) {
    const recorder = client.recorder("account-a");
    const begun = await recorder.begin(TARGET);
    if (begun.status !== "started") throw new Error("not started");
    await recorder.record(begun.operationId, "DeleteRequested");
    await recorder.record(begun.operationId, "DeleteConfirmed");
    await fromConversation().handOff(
      "account-a",
      begun.operationId,
      "ignore",
      PROFILE_PATH,
    );
    onProfilePage();
    document.body.innerHTML = profileHtml;
    driver.current = () => PROFILE;
    const quick = new QuickIgnoreDelete(
      document,
      client,
      () => driver,
      (url) => visited.push(url),
      () => Date.now(),
      HANDOFF_WAIT_MS,
      returnWaitMs,
    );
    quick.updateProfile();
    return quick;
  }

  const lines = () =>
    Array.from(section()?.querySelectorAll("li") ?? [], (item) =>
      item.textContent?.trim(),
    );

  it("says it waits for JoyClub's profile menu, then runs once it is there", async () => {
    const driver = new FakeDriver();
    driver.controls.ignore = false;
    const quick = await handedOffToProfile(driver);
    await vi.waitFor(() =>
      expect(lines()).toEqual([
        t(QUICK_ACTION_TEXT.resumed),
        "Waiting for JoyClub's profile menu…",
      ]),
    );
    // The menu renders; the next page event starts the run.
    driver.controls.ignore = true;
    quick.updateProfile();
    await vi.waitFor(() =>
      expect(notice()).toContain("Ignore and Delete finished."),
    );
    expect(notice()).not.toContain("Waiting for JoyClub's profile menu");
    expect(driver.clicks).toEqual(["request:ignore", "confirm:ignore"]);
  });

  const CLUBMAIL = `${window.location.origin}/clubmail/`;

  it("returns to the ClubMail list once the run is finished", async () => {
    const driver = new FakeDriver();
    const visited: string[] = [];
    await handedOffToProfile(driver, visited, 60);
    await vi.waitFor(() =>
      expect(notice()).toContain("Ignore and Delete finished."),
    );
    // The notice stays on screen for a moment first.
    expect(visited).toEqual([]);
    await vi.waitFor(() => expect(visited).toEqual([CLUBMAIL]));
    expect(driver.clicks).toEqual(["request:ignore", "confirm:ignore"]);
  });

  it("stays on the profile when the run stops before it is finished", async () => {
    const driver = new FakeDriver();
    driver.verified.ignore = false;
    const visited: string[] = [];
    await handedOffToProfile(driver, visited);
    await vi.waitFor(async () =>
      expect((await logged())[0]?.at(-1)).toBe("Failed:not-verified"),
    );
    await new Promise((resolve) => setTimeout(resolve, 60));
    expect(visited).toEqual([]);
    expect(notice()).toContain("Ignore and Delete stopped.");
  });

  it("does not return once the user moved on", async () => {
    const visited: string[] = [];
    await handedOffToProfile(new FakeDriver(), visited, 60);
    await vi.waitFor(() =>
      expect(notice()).toContain("Ignore and Delete finished."),
    );
    // JoyClub routes to a conversation in place during the pause.
    window.history.replaceState(
      null,
      "",
      `/clubmail/conversation/conversation-wrapper-${CONVERSATION}`,
    );
    document.body.innerHTML = conversationHtml;
    await new Promise((resolve) => setTimeout(resolve, 120));
    expect(visited).toEqual([]);
  });

  it("does not return once the flag is turned off", async () => {
    const visited: string[] = [];
    const quick = await handedOffToProfile(new FakeDriver(), visited, 60);
    await vi.waitFor(() =>
      expect(notice()).toContain("Ignore and Delete finished."),
    );
    quick.turnOff();
    await new Promise((resolve) => setTimeout(resolve, 120));
    expect(visited).toEqual([]);
  });

  it("does not return once the account changes", async () => {
    const visited: string[] = [];
    const quick = await handedOffToProfile(new FakeDriver(), visited, 60);
    await vi.waitFor(() =>
      expect(notice()).toContain("Ignore and Delete finished."),
    );
    quick.accountChanged();
    await new Promise((resolve) => setTimeout(resolve, 120));
    expect(visited).toEqual([]);
  });

  it("does not return when the flag is turned off while the end is stored", async () => {
    // Hold the last stored step, so the flag goes off before the run ends.
    let release: () => void = () => undefined;
    let held = false;
    const record = client.recorder;
    client = {
      ...client,
      recorder: (accountId) => {
        const inner = record(accountId);
        return {
          ...inner,
          record: async (operationId, state, failure) => {
            if (state === "Completed") {
              held = true;
              await new Promise<void>((resolve) => (release = resolve));
            }
            return inner.record(operationId, state, failure);
          },
        };
      },
    };
    const driver = new FakeDriver();
    const visited: string[] = [];
    const quick = await handedOffToProfile(driver, visited);
    await vi.waitFor(() => expect(held).toBe(true));
    quick.turnOff();
    release();
    await vi.waitFor(async () =>
      expect((await logged())[0]?.at(-1)).toBe("Completed"),
    );
    await new Promise((resolve) => setTimeout(resolve, 80));
    expect(visited).toEqual([]);
  });

  it("shows the continued line once while a resumed run starts", async () => {
    const driver = new FakeDriver();
    // Hold the first stored step, so the run's first line stays on screen.
    let release: () => void = () => undefined;
    const record = client.recorder;
    client = {
      ...client,
      recorder: (accountId) => {
        const inner = record(accountId);
        return {
          ...inner,
          record: async (operationId, state, failure) => {
            if (state === "IgnoreRequested")
              await new Promise<void>((resolve) => (release = resolve));
            return inner.record(operationId, state, failure);
          },
        };
      },
    };
    await handedOffToProfile(driver);
    await vi.waitFor(() =>
      expect(lines()).toEqual([
        t(QUICK_ACTION_TEXT.resumed),
        "Ignore and Delete is running. Checking the page.",
      ]),
    );
    release();
    await vi.waitFor(() =>
      expect(notice()).toContain("Ignore and Delete finished."),
    );
    expect(
      lines().filter((line) => line === t(QUICK_ACTION_TEXT.resumed)),
    ).toHaveLength(1);
  });
});

describe("Delete alone (ADR 0017)", () => {
  const section = () =>
    document.querySelector<HTMLElement>('[data-joyfox-ui="quick-action"]');
  const named = (text: string) =>
    Array.from(document.querySelectorAll("button")).find(
      (node) => node.textContent === text,
    );
  const deleteButton = () => named(t(QUICK_ACTION_TEXT.deleteButton));
  const ignoreButton = () => named(t(QUICK_ACTION_TEXT.button));
  const notice = () =>
    Array.from(
      section()?.querySelectorAll(".joyfox-quick-action__status li") ?? [],
      (item) => item.textContent,
    );

  /** A driver on the live conversation page: Delete asks no question. */
  function conversationDriver(): FakeDriver {
    const driver = new FakeDriver();
    driver.current = () => HERE;
    driver.confirmation.delete = "none";
    return driver;
  }

  function openConversation(
    driver: QuickActionDriver,
    visited: string[] = [],
    returnWaitMs = 40,
  ) {
    window.history.replaceState(
      null,
      "",
      `/clubmail/conversation/conversation-wrapper-${CONVERSATION}`,
    );
    document.body.innerHTML = conversationHtml;
    const quick = new QuickIgnoreDelete(
      document,
      client,
      () => driver,
      (url) => visited.push(url),
      () => Date.now(),
      HANDOFF_WAIT_MS,
      returnWaitMs,
    );
    return quick;
  }

  it("runs Started, DeleteRequested, DeleteConfirmed, Completed, and never names Ignore", async () => {
    const driver = conversationDriver();
    const result = await runQuickDelete({
      target: TARGET,
      driver,
      recorder: client.recorder("account-a"),
      timeoutMs: 200,
    });
    expect(driver.clicks).toEqual(["request:delete"]);
    expect(await logged()).toEqual([
      ["Started", "DeleteRequested", "DeleteConfirmed", "Completed"],
    ]);
    const [log] = await repositories.actionLogs.list("account-a");
    expect(log).toMatchObject({
      action: "quick-delete",
      memberId: MEMBER,
      conversationId: CONVERSATION,
    });
    expect(texts(result.report.lines)).toEqual([
      "Delete finished.",
      "Delete: done. JoyClub moved the conversation to the trash.",
      "To undo, restore the conversation from JoyClub's trash.",
    ]);
  });

  it("stops at the first failure with the Delete step's checks and codes", async () => {
    const missing = conversationDriver();
    missing.controls.delete = false;
    const stopped = await runQuickDelete({
      target: TARGET,
      driver: missing,
      recorder: client.recorder("account-a"),
      timeoutMs: 200,
    });
    expect(missing.clicks).toEqual([]);
    expect(texts(stopped.report.lines)).toEqual([
      "Delete stopped.",
      "JoyFox could not find JoyClub's Delete option on this page.",
      "Delete: not done.",
      "Nothing was changed on JoyClub.",
      "You can do it yourself: move the conversation to the trash with JoyClub's trash button.",
    ]);
    // Another conversation on the page: the identity check stops it.
    const other = conversationDriver();
    other.current = () => ({ ...HERE, conversationId: "personal-1-2" });
    const mismatch = await runQuickDelete({
      target: TARGET,
      driver: other,
      recorder: client.recorder("account-a"),
      timeoutMs: 200,
    });
    expect(mismatch.report.failure).toBe("conversation-mismatch");
    expect(other.clicks).toEqual([]);
    // JoyClub does not show the row leaving the list.
    const unverified = conversationDriver();
    unverified.verified.delete = false;
    const failed = await runQuickDelete({
      target: TARGET,
      driver: unverified,
      recorder: client.recorder("account-a"),
      timeoutMs: 200,
    });
    expect(failed.report.failure).toBe("not-verified");
    expect(texts(failed.report.lines)).toContain(
      "Next: open the conversation and check whether it is in the trash. If not, move it there yourself with JoyClub's trash button.",
    );
    for (const lines of await logged())
      expect(lines.join(" ")).not.toContain("Ignore");
  });

  it("refuses a hand-off for a Delete-only run", async () => {
    const recorder = client.recorder("account-a");
    const begun = await recorder.begin(TARGET, undefined, "quick-delete");
    if (begun.status !== "started") throw new Error("not started");
    await recorder.record(begun.operationId, "DeleteRequested");
    await recorder.record(begun.operationId, "DeleteConfirmed");
    // Ignore never follows Delete alone.
    expect(await recorder.record(begun.operationId, "IgnoreRequested")).toBe(
      "invalid",
    );
    await expect(
      fromConversation().handOff(
        "account-a",
        begun.operationId,
        "ignore",
        PROFILE_PATH,
      ),
    ).rejects.toThrow();
  });

  it("shows Delete with the flag off, and both buttons with it on", async () => {
    const quick = openConversation(conversationDriver());
    quick.turnOff();
    quick.update();
    await vi.waitFor(() => expect(deleteButton()).toBeDefined());
    expect(ignoreButton()).toBeUndefined();
    // Its description says what the click does.
    const described = deleteButton()!.getAttribute("aria-describedby")!;
    expect(document.getElementById(described)?.textContent).toBe(
      t(QUICK_ACTION_TEXT.deleteScope),
    );
    // Read by screen readers only: the labels say enough on screen.
    expect(document.getElementById(described)?.className).toBe(
      "joyfox-visually-hidden",
    );
    quick.turnOn();
    quick.update();
    expect(deleteButton()).toBeDefined();
    expect(ignoreButton()).toBeDefined();
    // Delete first, side by side (A2).
    expect(deleteButton()!.nextElementSibling).toBe(ignoreButton());
  });

  it("is disabled without the ClubMail list beside the conversation", async () => {
    const driver = conversationDriver();
    driver.listShown = false;
    const quick = openConversation(driver);
    quick.turnOff();
    quick.update();
    await vi.waitFor(() => expect(deleteButton()).toBeDefined());
    expect(deleteButton()!.getAttribute("aria-disabled")).toBe("true");
    const hint = section()!.querySelector<HTMLElement>(
      ".joyfox-quick-action__hint",
    )!;
    expect(hint.hidden).toBe(false);
    expect(hint.textContent).toBe(t(QUICK_ACTION_TEXT.needsList));
    deleteButton()!.click();
    await new Promise((resolve) => setTimeout(resolve, 20));
    expect(driver.clicks).toEqual([]);
    expect(await logged()).toEqual([]);
  });

  it("moves the conversation to the trash in one click and returns to the list after the wait", async () => {
    const driver = conversationDriver();
    const visited: string[] = [];
    const quick = openConversation(driver, visited, 60);
    quick.update();
    await vi.waitFor(() => expect(deleteButton()).toBeDefined());
    deleteButton()!.click();
    await vi.waitFor(() => expect(notice()).toContain("Delete finished."));
    // The notice shows first; nothing moved yet (D5).
    expect(visited).toEqual([]);
    await vi.waitFor(() =>
      expect(visited).toEqual([`${window.location.origin}/clubmail/`]),
    );
    expect(driver.clicks).toEqual(["request:delete"]);
    expect(await logged()).toEqual([
      ["Started", "DeleteRequested", "DeleteConfirmed", "Completed"],
    ]);
  });

  it("stays on the page after a failed Delete, and says what to do next", async () => {
    const driver = conversationDriver();
    driver.verified.delete = false;
    const visited: string[] = [];
    const quick = openConversation(driver, visited, 20);
    quick.update();
    await vi.waitFor(() => expect(deleteButton()).toBeDefined());
    deleteButton()!.click();
    await vi.waitFor(() => expect(notice()).toContain("Delete stopped."));
    expect(notice()).toContain(
      "Next: open the conversation and check whether it is in the trash. If not, move it there yourself with JoyClub's trash button.",
    );
    await new Promise((resolve) => setTimeout(resolve, 80));
    expect(visited).toEqual([]);
  });

  it("disables both buttons while one run goes, and a busy start does nothing", async () => {
    const driver = conversationDriver();
    let release: () => void = () => undefined;
    driver.afterClick = (click) =>
      click === "request:delete"
        ? new Promise<void>((resolve) => (release = resolve))
        : undefined;
    const quick = openConversation(driver);
    quick.update();
    await vi.waitFor(() => expect(ignoreButton()).toBeDefined());
    deleteButton()!.click();
    await vi.waitFor(() => expect(driver.clicks).toEqual(["request:delete"]));
    expect(deleteButton()!.getAttribute("aria-disabled")).toBe("true");
    expect(ignoreButton()!.getAttribute("aria-disabled")).toBe("true");
    expect(notice()).toEqual(["Moving the conversation to the trash."]);
    ignoreButton()!.click();
    deleteButton()!.click();
    release();
    await vi.waitFor(() => expect(notice()).toContain("Delete finished."));
    expect(driver.clicks).toEqual(["request:delete"]);
    expect(await logged()).toHaveLength(1);
    // Another tab's Ignore and Delete for the member: Delete waits too.
    const other = client.recorder("account-a");
    const begun = await other.begin(TARGET);
    if (begun.status !== "started") throw new Error("not started");
    quick.invalidate();
    await vi.waitFor(() =>
      expect(deleteButton()?.getAttribute("aria-disabled")).toBe("true"),
    );
    // A start that reaches the log anyway is refused as busy.
    const refused = await client
      .recorder("account-a")
      .begin(TARGET, undefined, "quick-delete");
    expect(refused.status).toBe("busy");
  });

  it("labels an earlier Delete-only run as a Delete", async () => {
    const recorder = client.recorder("account-a");
    const begun = await recorder.begin(TARGET, undefined, "quick-delete");
    if (begun.status !== "started") throw new Error("not started");
    await recorder.record(begun.operationId, "Failed", "control-missing");
    const quick = openConversation(conversationDriver());
    quick.update();
    await vi.waitFor(() =>
      expect(notice()[0]).toBe("Your last Delete for this member:"),
    );
    expect(notice()).toContain("Delete stopped.");
    expect(notice().join(" ")).not.toContain("Ignore");
  });
});

describe("Mark as junk on the conversation page (C5 to C7)", () => {
  const panel = () =>
    document.querySelector<HTMLElement>('[data-joyfox-ui="member-panel"]');
  const quickNotice = () =>
    document.querySelector('[data-joyfox-ui="quick-action"]')?.textContent ??
    "";
  const markButton = (text: string) =>
    Array.from(panel()?.querySelectorAll("button") ?? []).find(
      (node) => node.textContent === text,
    );

  /** A triage client that keeps the placement and the outcomes in memory. */
  function memoryTriage() {
    const state = {
      placement: "quarantined" as TriagePlacement,
      source: "rule" as MemberTriage["source"],
      calls: [] as string[],
      outcomes: [] as string[],
    };
    const result = (): MemberTriage => ({
      memberId: MEMBER,
      placement: state.placement,
      source: state.source,
      automatic: {
        placement: "quarantined",
        reasons: [],
        evaluatedConditions: [],
      },
      trust: {
        score: state.outcomes.length,
        contributions: [],
        logged: state.outcomes.length,
      },
    });
    const triage: TriageClient = {
      evaluate: async () => ({
        status: "ok",
        accountId: "account-a",
        results: [result()],
      }),
      setOverride: async (_account, _member, placement) => {
        state.calls.push(`override:${placement}`);
        if (placement) {
          state.placement = placement;
          state.source = "override";
        } else state.source = "rule";
      },
      getTrust: async () => ({ status: "no-account" }),
      logTrust: async (_account, _member, kind) => {
        state.calls.push(`log:${kind}`);
        state.outcomes.push(kind);
      },
      undoTrust: async () => undefined,
      captureSnapshot: async () => undefined,
      optOutSharedEvent: async () => undefined,
      openOptions: async () => undefined,
    };
    return { state, triage };
  }

  function openPage(driver: FakeDriver, visited: string[]) {
    window.history.replaceState(
      null,
      "",
      `/clubmail/conversation/conversation-wrapper-${CONVERSATION}`,
    );
    document.body.innerHTML = conversationHtml;
    const quick = new QuickIgnoreDelete(
      document,
      client,
      () => driver,
      (url) => visited.push(url),
      () => Date.now(),
      HANDOFF_WAIT_MS,
      40,
    );
    const { state, triage } = memoryTriage();
    const member = new MemberPanel(document, triage, quick);
    member.update("conversation");
    quick.update();
    return { quick, member, state };
  }

  function conversationDriver(): FakeDriver {
    const driver = new FakeDriver();
    driver.current = () => HERE;
    driver.confirmation.delete = "none";
    return driver;
  }

  it("places in Junk, logs Negative, trashes the conversation and returns to the list", async () => {
    const driver = conversationDriver();
    const visited: string[] = [];
    const { state } = openPage(driver, visited);
    await vi.waitFor(() => expect(markButton("Mark as junk")).toBeDefined());
    await vi.waitFor(() =>
      expect(
        document.querySelector('[data-joyfox-ui="quick-action"]'),
      ).not.toBeNull(),
    );
    markButton("Mark as junk")!.click();
    // Busy at once, for both Mark buttons (C9).
    expect(markButton("Mark as junk")!.getAttribute("aria-disabled")).toBe(
      "true",
    );
    expect(markButton("Mark qualified")!.getAttribute("aria-disabled")).toBe(
      "true",
    );
    markButton("Mark as junk")!.click();
    await vi.waitFor(() => expect(quickNotice()).toContain("Delete finished."));
    expect(quickNotice()).toContain(
      "Mark as junk: the sender is in Junk, and a Negative outcome is logged.",
    );
    // The placement, then the outcome, then the trash (C5), once.
    expect(state.calls).toEqual(["override:quarantined", "log:negative"]);
    expect(driver.clicks).toEqual(["request:delete"]);
    expect(await logged()).toEqual([
      ["Started", "DeleteRequested", "DeleteConfirmed", "Completed"],
    ]);
    // The Action log shows it as a Delete run (T3).
    const [log] = await repositories.actionLogs.list("account-a");
    expect(log?.action).toBe("quick-delete");
    await vi.waitFor(() =>
      expect(visited).toEqual([`${window.location.origin}/clubmail/`]),
    );
    // Now the user's own choice: Mark as junk is disabled (D12).
    await vi.waitFor(() =>
      expect(markButton("Mark as junk")?.disabled).toBe(true),
    );
    expect(markButton("Mark qualified")?.disabled).toBe(false);
  });

  it("waits for the Delete flow's first load before the trash step", async () => {
    const driver = conversationDriver();
    const visited: string[] = [];
    window.history.replaceState(
      null,
      "",
      `/clubmail/conversation/conversation-wrapper-${CONVERSATION}`,
    );
    document.body.innerHTML = conversationHtml;
    // The first ActionLog read answers only after the Mark click.
    let answer: () => void = () => undefined;
    let reads = 0;
    const slow: QuickActionClient = {
      ...client,
      latest: (memberId) =>
        (reads += 1) > 1
          ? client.latest(memberId)
          : new Promise((resolve) => {
              answer = () => resolve(client.latest(memberId));
            }),
    };
    const quick = new QuickIgnoreDelete(
      document,
      slow,
      () => driver,
      (url) => visited.push(url),
      () => Date.now(),
      HANDOFF_WAIT_MS,
      40,
    );
    const { state, triage } = memoryTriage();
    const member = new MemberPanel(document, triage, quick);
    member.update("conversation");
    quick.update();
    await vi.waitFor(() => expect(markButton("Mark as junk")).toBeDefined());
    expect(
      document.querySelector('[data-joyfox-ui="quick-action"]'),
    ).toBeNull();
    markButton("Mark as junk")!.click();
    await vi.waitFor(() =>
      expect(state.calls).toEqual(["override:quarantined", "log:negative"]),
    );
    answer();
    await vi.waitFor(() => expect(quickNotice()).toContain("Delete finished."));
    expect(driver.clicks).toEqual(["request:delete"]);
    expect(panel()?.textContent).not.toContain(
      "JoyFox could not move this conversation to the trash here.",
    );
  });

  it("keeps the placement and the Negative log when the trash cannot run", async () => {
    const driver = conversationDriver();
    driver.listShown = false;
    const visited: string[] = [];
    const { state } = openPage(driver, visited);
    await vi.waitFor(() => expect(markButton("Mark as junk")).toBeDefined());
    await vi.waitFor(() =>
      expect(
        document.querySelector('[data-joyfox-ui="quick-action"]'),
      ).not.toBeNull(),
    );
    markButton("Mark as junk")!.click();
    await vi.waitFor(() =>
      expect(quickNotice()).toContain(
        "The conversation was not moved to the trash.",
      ),
    );
    expect(quickNotice()).toContain(
      "You can do it yourself: move the conversation to the trash with JoyClub's trash button.",
    );
    expect(state.calls).toEqual(["override:quarantined", "log:negative"]);
    expect(state.placement).toBe("quarantined");
    expect(driver.clicks).toEqual([]);
    await new Promise((resolve) => setTimeout(resolve, 80));
    expect(visited).toEqual([]);
  });

  it("keeps the placement and the Negative log when the trash fails", async () => {
    const driver = conversationDriver();
    driver.verified.delete = false;
    const visited: string[] = [];
    const { state } = openPage(driver, visited);
    await vi.waitFor(() => expect(markButton("Mark as junk")).toBeDefined());
    await vi.waitFor(() =>
      expect(
        document.querySelector('[data-joyfox-ui="quick-action"]'),
      ).not.toBeNull(),
    );
    markButton("Mark as junk")!.click();
    await vi.waitFor(() => expect(quickNotice()).toContain("Delete stopped."));
    expect(quickNotice()).toContain(
      "Mark as junk: the sender is in Junk, and a Negative outcome is logged.",
    );
    expect(state.calls).toEqual(["override:quarantined", "log:negative"]);
    expect(state.outcomes).toEqual(["negative"]);
    await new Promise((resolve) => setTimeout(resolve, 80));
    expect(visited).toEqual([]);
  });

  it("says so in the bar when no Delete flow can take the trash step", async () => {
    window.history.replaceState(
      null,
      "",
      `/clubmail/conversation/conversation-wrapper-${CONVERSATION}`,
    );
    document.body.innerHTML = conversationHtml;
    const { state, triage } = memoryTriage();
    // No Delete flow on this page: the member panel alone.
    const member = new MemberPanel(document, triage, {
      junk: async () => "unavailable",
    });
    member.update("conversation");
    await vi.waitFor(() => expect(markButton("Mark as junk")).toBeDefined());
    markButton("Mark as junk")!.click();
    await vi.waitFor(() =>
      expect(panel()?.textContent).toContain(
        "The sender is in Junk, and a Negative outcome is logged. JoyFox could not move this conversation to the trash here. Move it there yourself with JoyClub's trash button.",
      ),
    );
    expect(state.calls).toEqual(["override:quarantined", "log:negative"]);
  });

  it("marks qualified with one Positive outcome and trashes nothing", async () => {
    const driver = conversationDriver();
    const visited: string[] = [];
    const { state } = openPage(driver, visited);
    await vi.waitFor(() => expect(markButton("Mark qualified")).toBeDefined());
    markButton("Mark qualified")!.click();
    await vi.waitFor(() =>
      expect(markButton("Mark qualified")?.disabled).toBe(true),
    );
    expect(state.calls).toEqual(["override:qualified", "log:positive"]);
    expect(driver.clicks).toEqual([]);
    expect(await logged()).toEqual([]);
  });

  it("stops before the outcome and the trash when the placement is not saved", async () => {
    const driver = conversationDriver();
    const visited: string[] = [];
    window.history.replaceState(
      null,
      "",
      `/clubmail/conversation/conversation-wrapper-${CONVERSATION}`,
    );
    document.body.innerHTML = conversationHtml;
    const quick = new QuickIgnoreDelete(
      document,
      client,
      () => driver,
      (url) => visited.push(url),
    );
    const { state, triage } = memoryTriage();
    const member = new MemberPanel(
      document,
      {
        ...triage,
        // The account changed: the background refused the write (C7).
        setOverride: () => Promise.reject(new Error("refused")),
      },
      quick,
    );
    member.update("conversation");
    quick.update();
    await vi.waitFor(() => expect(markButton("Mark as junk")).toBeDefined());
    markButton("Mark as junk")!.click();
    await vi.waitFor(() =>
      expect(panel()?.textContent).toContain(
        "JoyFox could not save that change. Nothing was changed.",
      ),
    );
    expect(state.calls).toEqual([]);
    expect(driver.clicks).toEqual([]);
    expect(await logged()).toEqual([]);
  });
});

describe("Mark as junk on the profile page (D10)", () => {
  it("places in Junk and logs Negative, with no trash", async () => {
    onProfilePage();
    document.body.innerHTML = profileHtml;
    const calls: string[] = [];
    let junkCalls = 0;
    const result: MemberTriage = {
      memberId: MEMBER,
      placement: "needs-review",
      source: "rule",
      automatic: {
        placement: "needs-review",
        reasons: [],
        evaluatedConditions: [],
      },
      trust: "unknown",
    };
    const member = new MemberPanel(
      document,
      {
        evaluate: async () => ({
          status: "ok",
          accountId: "account-a",
          results: [result],
        }),
        setOverride: async (_a, _m, placement) => {
          calls.push(`override:${placement}`);
        },
        getTrust: async () => ({ status: "no-account" }),
        logTrust: async (_a, _m, kind) => {
          calls.push(`log:${kind}`);
        },
        undoTrust: async () => undefined,
        captureSnapshot: async () => undefined,
        optOutSharedEvent: async () => undefined,
        openOptions: async () => undefined,
      },
      {
        junk: async () => {
          junkCalls += 1;
          return "shown";
        },
      },
    );
    member.update("profile");
    const button = () =>
      Array.from(document.querySelectorAll("button")).find(
        (node) => node.textContent === "Mark as junk",
      );
    await vi.waitFor(() => expect(button()).toBeDefined());
    button()!.click();
    await vi.waitFor(() =>
      expect(calls).toEqual(["override:quarantined", "log:negative"]),
    );
    await new Promise((resolve) => setTimeout(resolve, 20));
    expect(junkCalls).toBe(0);
  });
});
