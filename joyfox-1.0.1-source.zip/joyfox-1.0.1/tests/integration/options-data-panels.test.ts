// @vitest-environment jsdom
import "../setup-indexeddb";
import { beforeEach, describe, expect, it } from "vitest";
import { setLocale } from "../../src/i18n/translator";
import { AccountService } from "../../src/accounts/account-service";
import { DataService } from "../../src/data/data-service";
import { confirmTiming } from "../../src/options/confirm";
import { DataPanel, RECORD_PAGE_SIZE } from "../../src/options/data-panel";
import { TemplatePanel } from "../../src/options/template-panel";
import { ENTITY_NAMES } from "../../src/storage/database";
import { rememberNicknames } from "../../src/storage/member-directory";
import { repositories } from "../../src/storage/repositories";
import { TemplateService } from "../../src/templates/template-service";
import { MemorySettingsArea } from "../memory-settings";
import { freshDatabase } from "../setup-indexeddb";

let settings: MemorySettingsArea;
let accounts: AccountService;
let templates: TemplateService;
let root: HTMLElement;
let a: string;
let b: string;

beforeEach(async () => {
  await freshDatabase();
  // Tests confirm at once; the double-click test restores the grace period.
  confirmTiming.graceMs = 0;
  settings = new MemorySettingsArea();
  accounts = new AccountService(repositories.extensionAccounts, settings);
  templates = new TemplateService();
  a = (
    await accounts.createAccount({
      joyClubAccountId: "synthetic-a",
      label: "Alpha",
    })
  ).id;
  b = (
    await accounts.createAccount({
      joyClubAccountId: "synthetic-b",
      label: "Beta",
    })
  ).id;
  document.body.replaceChildren();
  root = document.createElement("section");
  document.body.append(root);
});

async function settle(until: () => boolean): Promise<void> {
  for (let attempt = 0; attempt < 500 && !until(); attempt += 1)
    await new Promise((resolve) => setTimeout(resolve, 0));
  if (!until())
    throw new Error(`Never reached the expected state: ${root.innerHTML}`);
}

const text = () => root.textContent ?? "";
const status = () => root.querySelector(".joyfox-panel__status");
const byLabel = (label: string) =>
  root.querySelector<HTMLButtonElement>(`button[aria-label="${label}"]`)!;
// Note: a status message is set before the redraw finishes, so waits key off
// the redrawn DOM, never off the status text alone.
// A file choice disables the chooser; only the redraw that ends the import
// draws it enabled again.
const importIdle = () =>
  root.querySelector<HTMLInputElement>("#joyfox-data-import")?.disabled ===
  false;
const count = (entity: string) =>
  root.querySelector(`tr[data-entity="${entity}"] .joyfox-data__count`)
    ?.textContent;

const data = () => new DataService(accounts, settings);

/**
 * Shows an entity's records and opens each one: a record's fields are drawn
 * only when it is opened.
 */
async function showRecords(label: string): Promise<void> {
  byLabel(label).click();
  await settle(() => root.querySelector(".joyfox-data__record") !== null);
  for (const details of Array.from(
    root.querySelectorAll<HTMLDetailsElement>(".joyfox-data__details"),
  ))
    details.open = true;
  await settle(() => root.querySelector(".joyfox-data__fields") !== null);
}

describe("M8 data panel", () => {
  let saved: Array<{ name: string; text: string }>;
  let panel: DataPanel;
  let changes: number;

  beforeEach(async () => {
    saved = [];
    changes = 0;
    await templates.save(a, { name: "Hi", body: "Hallo" });
    await templates.save(b, { name: "B only", body: "Beta text" });
    panel = new DataPanel(
      root,
      new DataService(accounts, settings),
      accounts,
      (name, content) => saved.push({ name, text: content }),
      () => (changes += 1),
    );
    await panel.render();
  });

  it("shows Delete-only and Ignore and Delete runs in the Action log, each with its own label (A9)", async () => {
    const run = (id: string, action: string, at: string) => ({
      id,
      accountId: a,
      memberId: "2222222",
      conversationId: "personal-1-2",
      action,
      steps: [
        { name: "Started", ok: true, at },
        { name: "DeleteRequested", ok: true, at },
        { name: "DeleteConfirmed", ok: true, at },
        { name: "Completed", ok: true, at },
      ],
      createdAt: at,
      updatedAt: at,
    });
    await repositories.actionLogs.put(
      a,
      run("action:1", "quick-delete", "2026-09-29T10:00:00.000Z"),
    );
    await repositories.actionLogs.put(a, {
      ...run("action:2", "quick-ignore-delete", "2026-09-29T11:00:00.000Z"),
      steps: [
        {
          name: "Started",
          ok: true,
          at: "2026-09-29T11:00:00.000Z",
        },
        {
          name: "Failed",
          ok: false,
          at: "2026-09-29T11:00:01.000Z",
          errorCode: "control-missing",
        },
      ],
    });
    await panel.render();
    await showRecords("Show Action log");
    await settle(
      () => root.querySelectorAll(".joyfox-data__report").length === 2,
    );
    const firstLines = Array.from(
      root.querySelectorAll(".joyfox-data__report"),
      (report) => report.querySelector("li")?.textContent,
    ).sort();
    expect(firstLines).toEqual([
      "Delete finished.",
      "Ignore and Delete stopped.",
    ]);
  });

  it("shows a count for every entity of the active account by default", () => {
    expect(root.querySelectorAll("tr[data-entity]")).toHaveLength(
      ENTITY_NAMES.length,
    );
    expect(count("messageTemplates")).toBe("1");
    expect(count("extensionAccounts")).toBe("1");
    // Every row has the same three table cells; the buttons sit in a box
    // inside the last one, so the cell stays a table cell and lines up.
    for (const row of Array.from(root.querySelectorAll("tr[data-entity]"))) {
      expect(Array.from(row.children, (cell) => cell.tagName)).toEqual([
        "TH",
        "TD",
        "TD",
      ]);
      expect(row.lastElementChild?.className).toBe("");
    }
    expect(
      root.querySelector(
        'tr[data-entity="messageTemplates"] td > .joyfox-data__actions button',
      ),
    ).not.toBeNull();
    const select = root.querySelector<HTMLSelectElement>(
      "#joyfox-data-account",
    )!;
    expect(select.value).toBe(a);
    expect(
      root.querySelector("label[for='joyfox-data-account']"),
    ).not.toBeNull();
  });

  it("names a record's member by the nickname a card showed", async () => {
    // Owner decision, 2026-09-27: the nickname, not only the number.
    await rememberNicknames(
      repositories.joyClubMembers,
      a,
      [{ memberId: "2222222", nickname: "Synthetic_Owl" }],
      "2026-09-27T10:00:00.000Z",
    );
    await panel.render();
    byLabel("Show Members").click();
    await settle(() => root.querySelector(".joyfox-data__record") !== null);
    expect(
      root.querySelector(".joyfox-data__record summary")?.textContent,
    ).toMatch(/^Synthetic_Owl: 2222222 \(updated /u);
  });

  it("shows a record as readable fields, with the stored JSON one click away", async () => {
    await showRecords("Show Message templates");
    const record = root.querySelector(".joyfox-data__record details")!;
    const [stored] = await data().records(a, "messageTemplates");
    const fields = record.querySelector<HTMLDListElement>(
      ":scope > .joyfox-data__fields",
    )!;
    const shown = new Map(
      Array.from(fields.querySelectorAll(":scope > dt"), (term) => [
        term.textContent,
        term.nextElementSibling?.textContent,
      ]),
    );
    // Every stored field is listed by its stored name.
    expect([...shown.keys()]).toEqual(Object.keys(stored!));
    expect(shown.get("name")).toBe("Hi");
    expect(shown.get("body")).toBe("Hallo");
    expect(fields.querySelector("time")?.dateTime).toBe(stored!.createdAt);
    // The raw JSON is still there, closed, and is exactly what is stored.
    const raw = record.querySelector<HTMLDetailsElement>(".joyfox-data__raw")!;
    expect(raw.open).toBe(false);
    expect(raw.querySelector("summary")?.textContent).toBe("Stored JSON");
    // The JSON text is made only when "Stored JSON" is opened.
    expect(raw.querySelector("pre")).toBeNull();
    raw.open = true;
    await settle(() => raw.querySelector("pre") !== null);
    expect(JSON.parse(raw.querySelector("pre")!.textContent!)).toEqual(stored);
  });

  it("draws a record's fields only when the record is opened", async () => {
    byLabel("Show Message templates").click();
    await settle(() => root.querySelector(".joyfox-data__record") !== null);
    const record = root.querySelector<HTMLDetailsElement>(
      ".joyfox-data__record details",
    )!;
    expect(record.querySelector(".joyfox-data__fields")).toBeNull();
    expect(record.querySelector(".joyfox-data__raw")).toBeNull();
    record.open = true;
    await settle(() => record.querySelector(".joyfox-data__fields") !== null);
    // Closing and opening again draws nothing twice.
    record.open = false;
    record.open = true;
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(record.querySelectorAll(".joyfox-data__fields")).toHaveLength(1);
    expect(record.querySelectorAll(".joyfox-data__raw")).toHaveLength(1);
  });

  it("sets how many profile snapshots are kept, and prunes at once (V1-12)", async () => {
    for (let index = 0; index < 4; index += 1)
      await repositories.profileSnapshots.put(a, {
        id: `snap-${index}`,
        accountId: a,
        memberId: "1234567",
        capturedAt: new Date(Date.UTC(2026, 0, 1, 0, 0, index)).toISOString(),
        verification: "unknown",
        photoCount: index,
        profileWordCount: "unknown",
        joinedAt: "unknown",
        createdAt: "2026-01-01T00:00:00.000Z",
        updatedAt: "2026-01-01T00:00:00.000Z",
      });
    await panel.render();
    const input = () =>
      root.querySelector<HTMLInputElement>("#joyfox-data-retention")!;
    expect(input().value).toBe("20");
    expect(
      root.querySelector("label[for='joyfox-data-retention']")?.textContent,
    ).toBe("Profile snapshots kept per member");
    expect(input().getAttribute("aria-describedby")).toBe(
      "joyfox-data-retention-hint",
    );
    const save = () =>
      root.querySelector<HTMLButtonElement>(".joyfox-data__retention-save")!;
    input().value = "0";
    save().click();
    await settle(
      () => status()?.textContent?.includes("whole number") ?? false,
    );
    expect(await repositories.profileSnapshots.list(a)).toHaveLength(4);
    input().value = "1";
    // A lower number deletes at once, so the first click only asks.
    save().click();
    await settle(() => save().textContent === "Save and delete");
    expect(status()?.textContent).toBe(
      'Lowering the number deletes older snapshots at once, in every account: each member keeps only the newest snapshot. Click "Save and delete" to confirm.',
    );
    expect(input().value).toBe("1");
    expect(await repositories.profileSnapshots.list(a)).toHaveLength(4);
    save().click();
    await settle(() => status()?.textContent?.includes("Saved.") ?? false);
    expect(status()?.textContent).toContain("3 older snapshots were deleted.");
    expect(input().value).toBe("1");
    expect(
      (await repositories.profileSnapshots.list(a)).map(({ id }) => id),
    ).toEqual(["snap-3"]);
    expect(changes).toBeGreaterThan(0);
  });

  it("disarms a lower snapshot number when another number is typed, and saves a higher one at once", async () => {
    await panel.render();
    const input = () =>
      root.querySelector<HTMLInputElement>("#joyfox-data-retention")!;
    const save = () =>
      root.querySelector<HTMLButtonElement>(".joyfox-data__retention-save")!;
    input().value = "5";
    save().click();
    await settle(() => save().textContent === "Save and delete");
    input().value = "6";
    input().dispatchEvent(new Event("input"));
    expect(save().textContent).toBe("Save");
    expect(status()?.textContent).toBe("");
    input().value = "30";
    save().click();
    await settle(() => status()?.textContent?.includes("Saved.") ?? false);
    expect(input().value).toBe("30");
  });

  it("asks again when the armed snapshot number is typed again after a change", async () => {
    for (let index = 0; index < 4; index += 1)
      await repositories.profileSnapshots.put(a, {
        id: `snap-${index}`,
        accountId: a,
        memberId: "1234567",
        capturedAt: new Date(Date.UTC(2026, 0, 1, 0, 0, index)).toISOString(),
        verification: "unknown",
        photoCount: index,
        profileWordCount: "unknown",
        joinedAt: "unknown",
        createdAt: "2026-01-01T00:00:00.000Z",
        updatedAt: "2026-01-01T00:00:00.000Z",
      });
    await panel.render();
    const input = () =>
      root.querySelector<HTMLInputElement>("#joyfox-data-retention")!;
    const save = () =>
      root.querySelector<HTMLButtonElement>(".joyfox-data__retention-save")!;
    const retype = (value: string) => {
      input().value = value;
      input().dispatchEvent(new Event("input"));
    };
    input().value = "1";
    save().click();
    await settle(() => save().textContent === "Save and delete");
    // Another number disarms it; the same number again must ask again.
    retype("2");
    retype("1");
    expect(save().textContent).toBe("Save");
    save().click();
    await settle(() => save().textContent === "Save and delete");
    expect(status()?.textContent).toContain('Click "Save and delete"');
    expect(await repositories.profileSnapshots.list(a)).toHaveLength(4);
  });

  it("keeps expanded records open when the panel redraws", async () => {
    await showRecords("Show Message templates");
    const record = () =>
      root.querySelector<HTMLDetailsElement>(".joyfox-data__record details")!;
    record().open = true;
    // A language change redraws the whole panel the same way.
    setLocale("de");
    await panel.render();
    setLocale("en");
    expect(root.querySelectorAll(".joyfox-data__record")).toHaveLength(1);
    expect(record().open).toBe(true);
    record().open = false;
    await panel.render();
    expect(record().open).toBe(false);
  });

  it("inspects another account without changing the active one", async () => {
    const select = root.querySelector<HTMLSelectElement>(
      "#joyfox-data-account",
    )!;
    select.value = b;
    select.dispatchEvent(new Event("change"));
    await settle(() => byLabel("Show Message templates") !== null);
    await showRecords("Show Message templates");
    expect(text()).toContain("Beta text");
    expect(text()).not.toContain("Hallo");
    expect((await accounts.getActiveAccount())?.id).toBe(a);
  });

  it("shows records as text, never as markup", async () => {
    await templates.save(a, {
      name: "<img src=x onerror=alert(1)>",
      body: "<b>x</b>",
    });
    await panel.render();
    await showRecords("Show Message templates");
    for (const raw of Array.from(
      root.querySelectorAll<HTMLDetailsElement>(".joyfox-data__raw"),
    ))
      raw.open = true;
    await settle(() => root.querySelector(".joyfox-data__json") !== null);
    expect(text()).toContain("<b>x</b>");
    expect(root.querySelector("img")).toBeNull();
    expect(root.querySelector("b")).toBeNull();
  });

  it("deletes a record only on the second click", async () => {
    byLabel("Show Message templates").click();
    await settle(() => root.querySelector(".joyfox-data__record") !== null);
    const id = root.querySelector<HTMLElement>(".joyfox-data__record")!.dataset
      .recordId!;
    // The template's name first, its ID beside it.
    byLabel(`Delete record Hi (${id})`).click();
    await settle(() => byLabel(`Confirm: Delete record Hi (${id})`) !== null);
    expect(status()?.textContent).toContain(`delete record Hi (${id})`);
    expect(await templates.list(a)).toHaveLength(1);
    byLabel(`Confirm: Delete record Hi (${id})`).click();
    await settle(() => count("messageTemplates") === "0");
    expect(await templates.list(a)).toEqual([]);
    expect(await templates.list(b)).toHaveLength(1);
    expect(changes).toBe(1);
  });

  it("any other action disarms a pending delete", async () => {
    byLabel("Delete all Message templates").click();
    await settle(
      () => byLabel("Confirm: Delete all Message templates") !== null,
    );
    byLabel("Show Message templates").click();
    await settle(() => byLabel("Delete all Message templates") !== null);
    expect(await templates.list(a)).toHaveLength(1);
  });

  it("an export disarms a pending delete", async () => {
    byLabel("Delete all JoyFox data in this browser").click();
    await settle(
      () => byLabel("Confirm: Delete all JoyFox data in this browser") !== null,
    );
    root.querySelector<HTMLButtonElement>(".joyfox-data__export-all")!.click();
    await settle(
      () =>
        saved.length === 1 &&
        byLabel("Delete all JoyFox data in this browser") !== null,
    );
    expect(await accounts.listAccounts()).toHaveLength(2);
  });

  it("offers no delete for the account record", async () => {
    byLabel("Show Account record").click();
    await settle(() => text().includes("removed only with the whole account"));
    expect(
      root.querySelector('button[aria-label^="Delete all Account"]'),
    ).toBeNull();
    expect(
      root.querySelector('button[aria-label^="Delete record"]'),
    ).toBeNull();
  });

  it("pages through a long record list", async () => {
    for (let i = 0; i < RECORD_PAGE_SIZE + 5; i += 1)
      await repositories.spamPhrases.put(a, {
        id: `phrase-${i}`,
        accountId: a,
        phrase: `invented ${i}`,
        enabled: true,
        createdAt: "2026-09-23T00:00:00.000Z",
        updatedAt: "2026-09-23T00:00:00.000Z",
      });
    await panel.render();
    byLabel("Show Spam phrases").click();
    await settle(() => root.querySelector(".joyfox-data__more") !== null);
    expect(root.querySelectorAll(".joyfox-data__record")).toHaveLength(
      RECORD_PAGE_SIZE,
    );
    root.querySelector<HTMLButtonElement>(".joyfox-data__more")!.click();
    await settle(
      () =>
        root.querySelectorAll(".joyfox-data__record").length ===
        RECORD_PAGE_SIZE + 5,
    );
  });

  it("reminds to export everything until a full export is made", async () => {
    const reminder = () => root.querySelector(".joyfox-data__reminder");
    expect(reminder()?.textContent).toBe(
      'You have not exported all JoyFox data yet. If you remove JoyFox or lose this browser profile, the data is gone. Click "Export all JoyFox data (JSON)" to save a backup.',
    );
    // An account export is not a backup of everything.
    root.querySelector<HTMLButtonElement>(".joyfox-data__export")!.click();
    await settle(() => saved.length === 1);
    await panel.render();
    expect(reminder()).not.toBeNull();
    root.querySelector<HTMLButtonElement>(".joyfox-data__export-all")!.click();
    await settle(() => saved.length === 2 && reminder() === null);
    expect(
      Date.parse(settings.items.get("joyfox.lastExportAt") as string),
    ).not.toBeNaN();
    expect(text()).toContain("Last full export: today.");
  });

  it("reminds again when the last full export is older than the set days", async () => {
    const daysAgo = (days: number) =>
      new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString();
    await settings.set({ "joyfox.lastExportAt": daysAgo(13) });
    await panel.render();
    expect(root.querySelector(".joyfox-data__reminder")).toBeNull();
    expect(text()).toContain("Last full export: 13 days ago.");
    await settings.set({ "joyfox.lastExportAt": daysAgo(20) });
    await panel.render();
    expect(root.querySelector(".joyfox-data__reminder")?.textContent).toBe(
      'Your last full export was 20 days ago. If you remove JoyFox or lose this browser profile, newer data is gone. Click "Export all JoyFox data (JSON)" to save a backup.',
    );
  });

  it("sets the export reminder days, and 0 turns the reminder off", async () => {
    const input = () =>
      root.querySelector<HTMLInputElement>("#joyfox-data-export-reminder")!;
    const save = () =>
      root.querySelector<HTMLButtonElement>(".joyfox-data__reminder-save")!;
    expect(input().value).toBe("14");
    expect(
      root.querySelector("label[for='joyfox-data-export-reminder']")
        ?.textContent,
    ).toBe("Remind me to export all data after (days)");
    expect(input().getAttribute("aria-describedby")).toBe(
      "joyfox-data-export-reminder-hint",
    );
    input().value = "400";
    save().click();
    await settle(
      () => status()?.textContent?.includes("whole number") ?? false,
    );
    expect(status()?.textContent).toBe(
      "Enter a whole number from 0 to 365. Nothing was changed.",
    );
    expect(settings.items.has("joyfox.exportReminderDays")).toBe(false);
    input().value = "0";
    save().click();
    await settle(() => root.querySelector(".joyfox-data__reminder") === null);
    expect(status()?.textContent).toBe("Saved. The export reminder is off.");
    expect(settings.items.get("joyfox.exportReminderDays")).toBe(0);
    expect(input().value).toBe("0");
    input().value = "30";
    save().click();
    await settle(() => root.querySelector(".joyfox-data__reminder") !== null);
    expect(status()?.textContent).toBe(
      "Saved. JoyFox reminds you 30 days after the last full export.",
    );
  });

  it("exports the inspected account and everything as JSON files", async () => {
    root.querySelector<HTMLButtonElement>(".joyfox-data__export")!.click();
    await settle(() => saved.length === 1);
    const account = JSON.parse(saved[0]!.text);
    expect(account.accountId).toBe(a);
    expect(account.entities.messageTemplates[0].body).toBe("Hallo");
    root.querySelector<HTMLButtonElement>(".joyfox-data__export-all")!.click();
    await settle(() => saved.length === 2);
    const all = JSON.parse(saved[1]!.text);
    expect(all.scope).toBe("all");
    expect(all.entities.messageTemplates).toHaveLength(2);
    expect(saved[1]!.name).toMatch(
      /^joyfox-export-all-\d{4}-\d{2}-\d{2}\.json$/,
    );
  });

  it("clears one account's data and keeps the account", async () => {
    byLabel("Delete this account's data (every record)").click();
    await settle(
      () =>
        byLabel("Confirm: Delete this account's data (every record)") !== null,
    );
    byLabel("Confirm: Delete this account's data (every record)").click();
    await settle(() => count("messageTemplates") === "0");
    expect(count("extensionAccounts")).toBe("1");
    expect(await templates.list(b)).toHaveLength(1);
  });

  it("a double-click never confirms a delete", async () => {
    confirmTiming.graceMs = 500;
    const target = () => byLabel("Delete all JoyFox data in this browser");
    target().dispatchEvent(new MouseEvent("click", { detail: 1 }));
    await settle(
      () => byLabel("Confirm: Delete all JoyFox data in this browser") !== null,
    );
    const confirm = byLabel("Confirm: Delete all JoyFox data in this browser");
    // The second click of a double-click, and a fast single click.
    confirm.dispatchEvent(new MouseEvent("click", { detail: 2 }));
    confirm.dispatchEvent(new MouseEvent("click", { detail: 1 }));
    await new Promise((resolve) => setTimeout(resolve, 20));
    expect(await accounts.listAccounts()).toHaveLength(2);
    // A double-click on the unarmed button does not arm it twice either.
    confirmTiming.graceMs = 0;
    confirm.dispatchEvent(new MouseEvent("click", { detail: 1 }));
    await settle(() => text().includes("No accounts yet."));
  });

  it("includes every JoyFox setting in the full export", async () => {
    await settings.set({ "joyfox.diagnostics": true });
    root.querySelector<HTMLButtonElement>(".joyfox-data__export-all")!.click();
    await settle(() => saved.length === 1);
    const all = JSON.parse(saved[0]!.text);
    expect(all.settings).toMatchObject({
      "joyfox.activeAccountId": a,
      "joyfox.diagnostics": true,
    });
  });

  it("imports a file as soon as it is chosen, and shows what changed", async () => {
    // Export account B, then change its template so the import has work.
    root.querySelector<HTMLButtonElement>(".joyfox-data__export-all")!.click();
    await settle(() => saved.length === 1);
    const file = new File([saved[0]!.text], "export.json", {
      type: "application/json",
    });
    await data().clearAccountData(b);
    await panel.render();

    const input = root.querySelector<HTMLInputElement>("#joyfox-data-import")!;
    Object.defineProperty(input, "files", { value: [file] });
    input.dispatchEvent(new Event("change"));
    // No second click: choosing the file is the whole import.
    await settle(() => importIdle() && text().includes("Import complete"));
    expect((await templates.list(b)).map((t) => t.body)).toEqual(["Beta text"]);
    const row = root.querySelector('tr[data-import-entity="messageTemplates"]');
    expect(row?.textContent).toContain("1");
    expect(root.querySelector(".joyfox-data__import-confirm")).toBeNull();

    // The same file again changes nothing. The old result goes at once.
    const again = root.querySelector<HTMLInputElement>("#joyfox-data-import")!;
    Object.defineProperty(again, "files", { value: [file] });
    again.dispatchEvent(new Event("change"));
    expect(text()).not.toContain("Import complete");
    await settle(() => importIdle() && text().includes("Nothing was changed"));
    expect((await templates.list(b)).map((t) => t.body)).toEqual(["Beta text"]);
  });

  it("ignores a second file choice while an import runs", async () => {
    root.querySelector<HTMLButtonElement>(".joyfox-data__export-all")!.click();
    await settle(() => saved.length === 1);
    await data().clearAccountData(b);
    await panel.render();
    let finishFirst!: (text: string) => void;
    const slow = {
      size: 10,
      text: () => new Promise<string>((resolve) => (finishFirst = resolve)),
    } as unknown as File;
    const other = {
      size: 10,
      text: () => Promise.resolve("not json"),
    } as unknown as File;
    const input = root.querySelector<HTMLInputElement>("#joyfox-data-import")!;
    let files: File[] = [slow];
    Object.defineProperty(input, "files", { get: () => files });
    input.dispatchEvent(new Event("change"));
    // The chooser is disabled until the import settles, and a second
    // choice cannot start a second import meanwhile.
    expect(input.disabled).toBe(true);
    files = [other];
    input.dispatchEvent(new Event("change"));
    await new Promise((resolve) => setTimeout(resolve, 20));
    expect(text()).not.toContain("Nothing was imported");
    finishFirst(saved[0]!.text);
    await settle(() => importIdle() && text().includes("Import complete"));
    expect((await templates.list(b)).map((t) => t.body)).toEqual(["Beta text"]);
  });

  it("does not call settings added when they could not be saved", async () => {
    root.querySelector<HTMLButtonElement>(".joyfox-data__export-all")!.click();
    await settle(() => saved.length === 1);
    await data().clearAccountData(b);
    // With no active account set, the import adds one.
    await settings.remove(["joyfox.activeAccountId"]);
    class FailingSettings extends DataService {
      override async applyImport(text: string, signature: string) {
        return {
          ...(await super.applyImport(text, signature)),
          settingsSaved: false,
        };
      }
    }
    const failing = new DataPanel(
      root,
      new FailingSettings(accounts, settings),
      accounts,
    );
    await failing.render();
    const input = root.querySelector<HTMLInputElement>("#joyfox-data-import")!;
    Object.defineProperty(input, "files", {
      value: [new File([saved[0]!.text], "export.json")],
    });
    input.dispatchEvent(new Event("change"));
    await settle(
      () => importIdle() && text().includes("Settings that could not be saved"),
    );
    expect(text()).not.toContain("Settings added");
    // The status points at the list above it and says what to do.
    expect(text()).toContain(
      "Some settings could not be saved (listed above). Set them again yourself.",
    );
    const result = root.querySelector(".joyfox-data__import-result")!;
    const line = Array.from(
      root.querySelectorAll(".joyfox-panel__status"),
    ).find((node) => node.textContent?.includes("Import complete"))!;
    expect(
      result.compareDocumentPosition(line) & Node.DOCUMENT_POSITION_FOLLOWING,
    ).toBeTruthy();
  });

  it("never shows the stored key of a setting JoyFox does not know", async () => {
    root.querySelector<HTMLButtonElement>(".joyfox-data__export-all")!.click();
    await settle(() => saved.length === 1);
    const file = JSON.parse(saved[0]!.text) as {
      settings: Record<string, unknown>;
    };
    // A later version's setting, and a feature switch that is never imported.
    file.settings["joyfox.fromLaterVersion"] = true;
    file.settings["joyfox.quickIgnoreDelete"] = true;
    const input = root.querySelector<HTMLInputElement>("#joyfox-data-import")!;
    Object.defineProperty(input, "files", {
      value: [new File([JSON.stringify(file)], "export.json")],
    });
    input.dispatchEvent(new Event("change"));
    await settle(
      () => importIdle() && text().includes("this version of JoyFox"),
    );
    expect(text()).toContain(
      "The file also holds settings that this version of JoyFox does not know. They were not imported.",
    );
    expect(text()).toContain(
      "Settings in the file that are never imported (they switch features on): Ignore and Delete button.",
    );
    expect(text()).not.toContain("joyfox.");
  });

  it("checks even a file that changes nothing under the data lock", async () => {
    root.querySelector<HTMLButtonElement>(".joyfox-data__export-all")!.click();
    await settle(() => saved.length === 1);
    let applied = 0;
    class Counting extends DataService {
      override applyImport(text: string, signature: string) {
        applied += 1;
        return super.applyImport(text, signature);
      }
    }
    const counting = new DataPanel(
      root,
      new Counting(accounts, settings),
      accounts,
    );
    await counting.render();
    const input = root.querySelector<HTMLInputElement>("#joyfox-data-import")!;
    Object.defineProperty(input, "files", {
      value: [new File([saved[0]!.text], "export.json")],
    });
    input.dispatchEvent(new Event("change"));
    await settle(() => importIdle() && text().includes("Nothing was changed"));
    expect(applied).toBe(1);
  });

  it("enables the chooser again when the redraw after an import fails", async () => {
    const importRoot = document.createElement("section");
    document.body.append(importRoot);
    let failReads = false;
    class Flaky extends AccountService {
      override listAccounts() {
        if (failReads) return Promise.reject(new Error("read failed"));
        return super.listAccounts();
      }
    }
    const placed = new DataPanel(
      root,
      new DataService(accounts, settings),
      new Flaky(repositories.extensionAccounts, settings),
      () => undefined,
      () => undefined,
      importRoot,
    );
    await placed.render();
    failReads = true;
    const input = importRoot.querySelector<HTMLInputElement>(
      "#joyfox-data-import",
    )!;
    Object.defineProperty(input, "files", {
      value: [new File(["not json"], "x.json")],
    });
    input.dispatchEvent(new Event("change"));
    expect(input.disabled).toBe(true);
    for (
      let attempt = 0;
      attempt < 500 &&
      importRoot.querySelector<HTMLInputElement>("#joyfox-data-import")
        ?.disabled !== false;
      attempt += 1
    )
      await new Promise((resolve) => setTimeout(resolve, 0));
    expect(
      importRoot.querySelector<HTMLInputElement>("#joyfox-data-import")
        ?.disabled,
    ).toBe(false);
    expect(importRoot.textContent).toContain("Nothing was imported");
  });

  it("reports a file that is not an export, and imports nothing", async () => {
    const input = root.querySelector<HTMLInputElement>("#joyfox-data-import")!;
    Object.defineProperty(input, "files", {
      value: [new File(["not json"], "x.json")],
    });
    input.dispatchEvent(new Event("change"));
    await settle(() => importIdle() && text().includes("Nothing was imported"));
    expect(root.querySelector(".joyfox-data__import-result")).toBeNull();
  });

  it("draws Import in its own place, with its own status line, when given one", async () => {
    // The options page puts it on the Accounts tab (owner request).
    const importRoot = document.createElement("section");
    document.body.append(importRoot);
    const placed = new DataPanel(
      root,
      new DataService(accounts, settings),
      accounts,
      (name, content) => saved.push({ name, text: content }),
      () => undefined,
      importRoot,
    );
    await placed.render();
    expect(root.querySelector("#joyfox-data-import")).toBeNull();
    const input = importRoot.querySelector<HTMLInputElement>(
      "#joyfox-data-import",
    )!;
    expect(importRoot.textContent).toContain("Import a JoyFox export file");
    Object.defineProperty(input, "files", {
      value: [new File(["not json"], "x.json")],
    });
    input.dispatchEvent(new Event("change"));
    for (
      let attempt = 0;
      attempt < 500 &&
      !importRoot.textContent?.includes("Nothing was imported");
      attempt += 1
    )
      await new Promise((resolve) => setTimeout(resolve, 0));
    expect(
      importRoot.querySelector(".joyfox-panel__status")?.textContent,
    ).toContain("Nothing was imported");
    expect(text()).not.toContain("Nothing was imported");
  });

  it("deletes all JoyFox data after confirmation", async () => {
    await settings.set({ "joyfox.diagnostics": true });
    byLabel("Delete all JoyFox data in this browser").click();
    await settle(
      () => byLabel("Confirm: Delete all JoyFox data in this browser") !== null,
    );
    byLabel("Confirm: Delete all JoyFox data in this browser").click();
    await settle(() => text().includes("No accounts yet."));
    expect(await accounts.listAccounts()).toEqual([]);
    expect(settings.items.size).toBe(0);
  });
});

describe("M10 template panel", () => {
  let panel: TemplatePanel;
  let changes: number;

  beforeEach(async () => {
    changes = 0;
    panel = new TemplatePanel(root, templates, accounts, () => (changes += 1));
    await panel.render();
  });

  const field = <T extends HTMLElement>(id: string) =>
    root.querySelector<T>(`#${id}`)!;

  async function submit(name: string, body: string, folder = "") {
    field<HTMLInputElement>("joyfox-template-name").value = name;
    field<HTMLInputElement>("joyfox-template-folder").value = folder;
    field<HTMLTextAreaElement>("joyfox-template-body").value = body;
    root.querySelector<HTMLFormElement>("form")!.requestSubmit();
  }

  it("adds a template into a folder under the active account", async () => {
    await submit("Confirm", "Du bist dabei!", "Event confirmation");
    await settle(() => byLabel("Edit template Confirm") !== null);
    expect(text()).toContain("Added Confirm.");
    expect(root.querySelector(".joyfox-templates__folder")?.textContent).toBe(
      "Event confirmation",
    );
    expect((await templates.list(a))[0]).toMatchObject({
      name: "Confirm",
      folder: "Event confirmation",
    });
    expect(await templates.list(b)).toEqual([]);
    expect(changes).toBe(1);
    expect(field<HTMLInputElement>("joyfox-template-name").value).toBe("");
    const suggestions = Array.from(
      root.querySelectorAll("#joyfox-template-folders option"),
    ).map((option) => (option as HTMLOptionElement).value);
    expect(suggestions).toContain("Event cancellation");
  });

  it("edits a template in place", async () => {
    await submit("Old", "Old text");
    await settle(() => byLabel("Edit template Old") !== null);
    byLabel("Edit template Old").click();
    await settle(
      () => field<HTMLInputElement>("joyfox-template-name").value === "Old",
    );
    expect(field<HTMLTextAreaElement>("joyfox-template-body").value).toBe(
      "Old text",
    );
    await submit("New", "New text");
    await settle(() => byLabel("Edit template New") !== null);
    expect(text()).toContain("Saved New.");
    const list = await templates.list(a);
    expect(list).toHaveLength(1);
    expect(list[0]).toMatchObject({ name: "New", body: "New text" });
  });

  it("keeps the typed text when saving fails", async () => {
    await submit("   ", "Text");
    await settle(() => status()?.getAttribute("data-kind") === "error");
    expect(status()?.textContent).toContain("Nothing was changed");
    expect(field<HTMLTextAreaElement>("joyfox-template-body").value).toBe(
      "Text",
    );
  });

  it("keeps a draft while a delete is armed, and deletes on the second click", async () => {
    await submit("One", "Text");
    await settle(() => byLabel("Delete template One") !== null);
    field<HTMLTextAreaElement>("joyfox-template-body").value = "Draft";
    byLabel("Delete template One").click();
    await settle(() => byLabel("Confirm delete: template One") !== null);
    expect(field<HTMLTextAreaElement>("joyfox-template-body").value).toBe(
      "Draft",
    );
    byLabel("Confirm delete: template One").click();
    await settle(() => text().includes("No templates yet."));
    expect(text()).toContain("Deleted One.");
    expect(await templates.list(a)).toEqual([]);
  });

  it("keeps the typed text as a new template when the edited one was deleted", async () => {
    await submit("Gone", "Old");
    await settle(() => byLabel("Edit template Gone") !== null);
    byLabel("Edit template Gone").click();
    await settle(
      () => field<HTMLInputElement>("joyfox-template-name").value === "Gone",
    );
    const [stored] = await templates.list(a);
    await templates.delete(a, stored!.id);
    await submit("Kept", "Typed text");
    await settle(() => status()?.getAttribute("data-kind") === "error");
    await settle(
      () =>
        root.querySelector("form")?.getAttribute("aria-label") ===
        "Add a template",
    );
    expect(field<HTMLTextAreaElement>("joyfox-template-body").value).toBe(
      "Typed text",
    );
    root.querySelector<HTMLFormElement>("form")!.requestSubmit();
    await settle(() => byLabel("Edit template Kept") !== null);
  });

  it("refuses to write after the active account changed", async () => {
    await accounts.setActiveAccount(b);
    await submit("Late", "Text");
    await settle(() => text().includes("The active account changed"));
    expect(text()).toContain(
      "The active account changed, so nothing was changed. Check the active account on the Accounts tab before you try again.",
    );
    expect(await templates.list(a)).toEqual([]);
    expect(await templates.list(b)).toEqual([]);
  });

  it("adds one template on a double submit", async () => {
    await submit("Once", "Text");
    root.querySelector<HTMLFormElement>("form")!.requestSubmit();
    await settle(() => byLabel("Edit template Once") !== null);
    await new Promise((resolve) => setTimeout(resolve, 20));
    expect(await templates.list(a)).toHaveLength(1);
  });

  it("clears the status when the active account changes", async () => {
    await submit("Secret name", "Text");
    await settle(() => byLabel("Edit template Secret name") !== null);
    expect(status()?.textContent).toContain("Secret name");
    await accounts.setActiveAccount(b);
    await panel.render();
    expect(text()).not.toContain("Secret name");
  });

  it("asks for an account when none is active", async () => {
    await accounts.clearActiveAccount();
    await panel.render();
    expect(text()).toContain("Choose an active account");
    expect(root.querySelector("form")).toBeNull();
  });
});
