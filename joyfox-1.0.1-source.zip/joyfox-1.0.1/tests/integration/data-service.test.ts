import "../setup-indexeddb";
import { beforeEach, describe, expect, it } from "vitest";
import {
  AccountService,
  ACTIVE_ACCOUNT_SETTING_KEY,
} from "../../src/accounts/account-service";
import {
  DataService,
  ENTITY_LABELS,
  exportFileName,
  serializeExport,
} from "../../src/data/data-service";
import type {
  AccountScopedEntity,
  EntityMap,
  EntityName,
} from "../../src/domain/types";
import { DATABASE_VERSION, ENTITY_NAMES } from "../../src/storage/database";
import { withAccountLock } from "../../src/storage/account-lock";
import { repositories } from "../../src/storage/repositories";
import { TRIAGE_REVISION_KEY } from "../../src/storage/triage-revision";
import { MemorySettingsArea } from "../memory-settings";
import { freshDatabase } from "../setup-indexeddb";

const now = "2026-09-23T10:00:00.000Z";

/** One synthetic record per entity. No real member data. */
/** A cached message's ID is derived from JoyClub's message ID (V1-4). */
const MESSAGE_ID = "cm-message-00000000-0000-4000-8000-000000000001";

const sample: {
  [N in EntityName]: Omit<EntityMap[N], keyof AccountScopedEntity>;
} = {
  extensionAccounts: { joyClubAccountId: "synthetic" },
  joyClubMembers: { joyClubMemberId: "1234567" },
  profileSnapshots: {
    memberId: "1234567",
    capturedAt: now,
    verification: true,
    photoCount: 3,
    profileWordCount: 42,
    joinedAt: "unknown",
    joinedEarliest: "2025-09-23",
    joinedLatest: "2025-11-23",
  },
  userNotes: { memberId: "1234567", body: "Invented note\nsecond line" },
  userTags: { memberId: "1234567", label: "Invented tag" },
  trustSignals: { memberId: "1234567", kind: "positive", occurredAt: now },
  contactRules: {
    name: "Synthetic rule",
    schemaVersion: 1,
    audience: "all",
    enabled: true,
    defaultPlacement: "needs-review",
    root: { type: "group", match: "all", children: [] },
  },
  conversationClassifications: {
    memberId: "1234567",
    placement: "quarantined",
    source: "user",
    decidedAt: now,
    reasons: [{ key: "legacy.text", params: { text: "Invented reason" } }],
  },
  savedSearches: {
    name: "Synthetic search",
    url: "https://example.invalid/search",
    filters: { nested: [1, 2] },
  },
  eventMetadata: {
    eventId: "event-1",
    note: "Invented",
    tags: ["a"],
    attendance: "attending",
  },
  spendLogEntries: {
    occurredAt: now,
    amountMinor: 499,
    currency: "EUR",
    category: "coins",
  },
  syncConfigs: {
    endpoint: "https://example.invalid/sync",
    keyDerivation: {
      algorithm: "PBKDF2",
      iterations: 600_000,
      hash: "SHA-256",
      salt: "synthetic-salt",
    },
  },
  extensionPreferences: { key: "synthetic.preference", value: { on: true } },
  messageTemplates: {
    name: "Synthetic template",
    body: "Hallo 😀\nBis bald",
    folder: "Event confirmation",
  },
  spamPhrases: { phrase: "Invented phrase", enabled: false },
  messageObservations: {
    memberId: "1234567",
    observedAt: now,
    normalizedText: "invented synthetic message text",
  },
  senderSpamOverrides: {
    memberId: "1234567",
    decision: "not-spam",
    decidedAt: now,
    reason: "Invented",
  },
  actionLogs: {
    memberId: "1234567",
    action: "synthetic.action",
    steps: [{ name: "started", ok: true, at: now }],
  },
  messagePhraseMatches: {
    memberId: "1234567",
    phrase: "blue heron",
    matchedAt: now,
  },
  cachedMessages: {
    messageId: MESSAGE_ID,
    conversationId: "personal-1111111-1234567",
    memberId: "1234567",
    direction: "received",
    sentAt: now,
    text: "Invented synthetic message",
  },
};

function record<N extends EntityName>(
  name: N,
  accountId: string,
  id: string,
): EntityMap[N] {
  return {
    id,
    accountId,
    createdAt: now,
    updatedAt: now,
    ...sample[name],
  } as EntityMap[N];
}

type AnyRepository = {
  put(accountId: string, entity: AccountScopedEntity): Promise<void>;
  list(accountId: string): Promise<AccountScopedEntity[]>;
};
const repo = (name: EntityName) => repositories[name] as never as AnyRepository;

/** Every entity filled for the account, the account record included. */
async function fill(accountId: string): Promise<void> {
  for (const name of ENTITY_NAMES)
    await repo(name).put(
      accountId,
      record(
        name,
        accountId,
        name === "extensionAccounts"
          ? accountId
          : name === "cachedMessages"
            ? `message:${MESSAGE_ID}`
            : `${name}-1`,
      ),
    );
}

let settings: MemorySettingsArea;
let accounts: AccountService;
let data: DataService;

beforeEach(async () => {
  await freshDatabase();
  settings = new MemorySettingsArea();
  accounts = new AccountService(repositories.extensionAccounts, settings);
  data = new DataService(accounts, settings);
  await fill("account-a");
  await fill("account-b");
  await settings.set({ [ACTIVE_ACCOUNT_SETTING_KEY]: "account-a" });
});

describe("M8 export", () => {
  it("saves the snapshot retention and prunes stored snapshots at once (V1-12)", async () => {
    for (let index = 0; index < 5; index += 1)
      await repositories.profileSnapshots.put("a", {
        id: `snap-${index}`,
        accountId: "a",
        memberId: "1234567",
        capturedAt: new Date(Date.UTC(2026, 0, 1, 0, 0, index)).toISOString(),
        verification: "unknown",
        photoCount: index,
        profileWordCount: "unknown",
        joinedAt: "unknown",
        createdAt: "2026-01-01T00:00:00.000Z",
        updatedAt: "2026-01-01T00:00:00.000Z",
      });
    expect(await data.snapshotRetention()).toBe(20);
    expect(await data.setSnapshotRetention(2)).toBe(3);
    expect(await data.snapshotRetention()).toBe(2);
    expect(settings.items.get("joyfox.snapshotRetention")).toBe(2);
    expect(
      (await repositories.profileSnapshots.list("a"))
        .map(({ id }) => id)
        .sort(),
    ).toEqual(["snap-3", "snap-4"]);
    // An invalid number changes nothing.
    await expect(data.setSnapshotRetention(0)).rejects.toThrow();
    await expect(data.setSnapshotRetention(2.5)).rejects.toThrow();
    expect(await data.snapshotRetention()).toBe(2);
    expect(await repositories.profileSnapshots.list("a")).toHaveLength(2);
  });

  it("covers every entity, item by item, with the schema version", async () => {
    const exported = await data.exportAccount("account-a");
    expect(exported.schemaVersion).toBe(DATABASE_VERSION);
    expect(exported.scope).toBe("account");
    expect(Object.keys(exported.entities).sort()).toEqual(
      [...ENTITY_NAMES].sort(),
    );
    // Round-trip through the file format, then compare each stored record.
    const file = JSON.parse(serializeExport(exported)) as typeof exported;
    for (const name of ENTITY_NAMES) {
      const stored = await repo(name).list("account-a");
      expect(stored).toHaveLength(1);
      expect(file.entities[name]).toEqual(stored);
      expect(JSON.stringify(file.entities[name])).not.toContain("account-b");
      expect(JSON.stringify(file.entities[name])).not.toContain("storageKey");
    }
  });

  it("exports everything, including records outside a registered account", async () => {
    // The diagnostic wake counter writes under a scope that is not an account.
    await repositories.extensionPreferences.put(
      "acceptance",
      record("extensionPreferences", "acceptance", "background-wake-count"),
    );
    const exported = await data.exportAll();
    expect(exported.scope).toBe("all");
    expect(exported.schemaVersion).toBe(DATABASE_VERSION);
    for (const name of ENTITY_NAMES) {
      const expected = [
        ...(await repo(name).list("account-a")),
        ...(await repo(name).list("account-b")),
        ...(await repo(name).list("acceptance")),
      ];
      expect(exported.entities[name]).toHaveLength(expected.length);
      expect(exported.entities[name]).toEqual(expect.arrayContaining(expected));
    }
  });

  it("is human-readable JSON and names no account in the file name", async () => {
    const exported = await data.exportAccount("account-a");
    const text = serializeExport(exported);
    expect(text).toContain('\n  "schemaVersion": ');
    expect(exportFileName(exported)).toBe(
      `joyfox-export-account-${exported.exportedAt.slice(0, 10)}.json`,
    );
    expect(exportFileName(exported)).not.toContain("account-a");
  });

  it("names every entity in plain language", () => {
    for (const name of ENTITY_NAMES) expect(ENTITY_LABELS[name]).toBeTruthy();
  });
});

describe("M8 inspection and delete", () => {
  it("counts records per entity for one account only", async () => {
    await repositories.userTags.put(
      "account-a",
      record("userTags", "account-a", "tag-2"),
    );
    const counts = await data.counts("account-a");
    for (const name of ENTITY_NAMES)
      expect(counts[name]).toBe(name === "userTags" ? 2 : 1);
  });

  it("lists one entity's records, newest first", async () => {
    await repositories.userTags.put("account-a", {
      ...record("userTags", "account-a", "tag-2"),
      updatedAt: "2026-09-24T00:00:00.000Z",
    });
    const ids = (await data.records("account-a", "userTags")).map((r) => r.id);
    expect(ids).toEqual(["tag-2", "userTags-1"]);
  });

  it("deletes one record and signals open pages", async () => {
    await data.deleteRecord("account-a", "userNotes", "userNotes-1");
    expect(await repositories.userNotes.list("account-a")).toEqual([]);
    expect(await repositories.userNotes.list("account-b")).toHaveLength(1);
    expect(settings.items.has(TRIAGE_REVISION_KEY)).toBe(true);
  });

  it("waits for a write that holds the account lock", async () => {
    let release!: () => void;
    const held = withAccountLock(
      "account-a",
      () => new Promise<void>((resolve) => (release = resolve)),
    );
    let deleted = false;
    const deleting = data
      .deleteEntity("account-a", "userNotes")
      .then(() => (deleted = true));
    await new Promise((resolve) => setTimeout(resolve, 10));
    expect(deleted).toBe(false);
    release();
    await Promise.all([held, deleting]);
    expect(await repositories.userNotes.list("account-a")).toEqual([]);
  });

  it("deletes one entity class in one account", async () => {
    await data.deleteEntity("account-a", "trustSignals");
    const counts = await data.counts("account-a");
    for (const name of ENTITY_NAMES)
      expect(counts[name]).toBe(name === "trustSignals" ? 0 : 1);
    expect((await data.counts("account-b")).trustSignals).toBe(1);
  });

  it("never deletes the account record on its own", async () => {
    await expect(
      data.deleteRecord("account-a", "extensionAccounts", "account-a"),
    ).rejects.toThrow("whole account");
    await expect(
      data.deleteEntity("account-a", "extensionAccounts"),
    ).rejects.toThrow("whole account");
    expect(await accounts.getActiveAccount()).toBeDefined();
  });

  it("refuses an unknown entity name from a caller", async () => {
    await expect(
      data.deleteEntity("account-a", "unknown" as EntityName),
    ).rejects.toThrow("Unknown data type");
  });

  it("clears an account's data but keeps the account", async () => {
    await data.clearAccountData("account-a");
    const counts = await data.counts("account-a");
    for (const name of ENTITY_NAMES)
      expect(counts[name]).toBe(name === "extensionAccounts" ? 1 : 0);
    expect((await accounts.getActiveAccount())?.id).toBe("account-a");
    for (const count of Object.values(await data.counts("account-b")))
      expect(count).toBe(1);
  });

  it("refuses to delete in an account that no longer exists", async () => {
    await accounts.deleteAccount("account-b");
    await expect(data.clearAccountData("account-b")).rejects.toThrow(
      "no longer exists",
    );
  });

  it("reports data written while everything was being deleted", async () => {
    // A writer to a scope that held no data runs after the stores are
    // cleared, while delete-all still holds its locks.
    const racingSettings = new MemorySettingsArea();
    racingSettings.clear = async () => {
      await repositories.extensionPreferences.put(
        "new-scope",
        record("extensionPreferences", "new-scope", "late"),
      );
    };
    const racing = new DataService(accounts, racingSettings);
    await expect(racing.deleteEverything()).rejects.toThrow("written");
  });

  it("locks scopes that hold data but are not accounts", async () => {
    await repositories.extensionPreferences.put(
      "acceptance",
      record("extensionPreferences", "acceptance", "background-wake-count"),
    );
    let release!: () => void;
    const held = withAccountLock(
      "acceptance",
      () => new Promise<void>((resolve) => (release = resolve)),
    );
    let done = false;
    const deleting = data.deleteEverything().then(() => (done = true));
    await new Promise((resolve) => setTimeout(resolve, 10));
    expect(done).toBe(false);
    release();
    await Promise.all([held, deleting]);
    expect(done).toBe(true);
  });

  it("holds back account creation and switches until it ends", async () => {
    let release!: () => void;
    const held = withAccountLock(
      "account-a",
      () => new Promise<void>((resolve) => (release = resolve)),
    );
    const deleting = data.deleteEverything();
    await new Promise((resolve) => setTimeout(resolve, 10));
    // Queued behind the exclusive lock: lands after the delete, not in it.
    const creating = accounts.createAccount({ joyClubAccountId: "late" });
    release();
    await Promise.all([held, deleting]);
    const created = await creating;
    expect((await accounts.listAccounts()).map((a) => a.id)).toEqual([
      created.id,
    ]);
    expect((await accounts.getActiveAccount())?.id).toBe(created.id);
  });

  it("deletes everything, in every scope, with every setting", async () => {
    await repositories.extensionPreferences.put(
      "acceptance",
      record("extensionPreferences", "acceptance", "background-wake-count"),
    );
    await settings.set({ "joyfox.diagnostics": true });
    await data.deleteEverything();
    const exported = await data.exportAll();
    for (const name of ENTITY_NAMES)
      expect(exported.entities[name]).toEqual([]);
    expect(settings.items.size).toBe(0);
    expect(await accounts.getActiveAccount()).toBeUndefined();
    expect(await accounts.listAccounts()).toEqual([]);
  });
});

describe("M8 account-wide delete under failure", () => {
  /**
   * Make one store's delete throw, as a storage error would, after every
   * store before it already queued its deletes in the same transaction.
   */
  function failDeletesIn(store: EntityName): () => void {
    const original = IDBObjectStore.prototype.delete;
    IDBObjectStore.prototype.delete = function (
      this: IDBObjectStore,
      key: IDBValidKey | IDBKeyRange,
    ) {
      if (this.name === store) throw new Error("injected storage failure");
      return original.call(this, key);
    };
    return () => {
      IDBObjectStore.prototype.delete = original;
    };
  }

  const allCounts = async (accountId: string) =>
    Object.values(await data.counts(accountId));

  it("rolls back every store when clearing an account's data fails", async () => {
    // The last store in the sweep, so every other store was already swept.
    const restore = failDeletesIn(ENTITY_NAMES.at(-1)!);
    try {
      await expect(data.clearAccountData("account-a")).rejects.toThrow(
        "injected storage failure",
      );
    } finally {
      restore();
    }
    for (const count of await allCounts("account-a")) expect(count).toBe(1);
    for (const count of await allCounts("account-b")) expect(count).toBe(1);
  });

  it("keeps the account and all its data when removing it fails", async () => {
    const restore = failDeletesIn(ENTITY_NAMES.at(-1)!);
    try {
      await expect(accounts.deleteAccount("account-a")).rejects.toThrow(
        "injected storage failure",
      );
    } finally {
      restore();
    }
    for (const count of await allCounts("account-a")) expect(count).toBe(1);
    expect((await accounts.listAccounts()).map((a) => a.id)).toContain(
      "account-a",
    );
    // The pointer went first, so no page acts on the account meanwhile;
    // the account can be activated again.
    expect(await accounts.getActiveAccount()).toBeUndefined();
    await accounts.setActiveAccount("account-a");
    expect((await accounts.getActiveAccount())?.id).toBe("account-a");
  });

  it("rolls back when one store's key read fails", async () => {
    const original = IDBIndex.prototype.getAllKeys;
    IDBIndex.prototype.getAllKeys = function (
      this: IDBIndex,
      ...args: Parameters<IDBIndex["getAllKeys"]>
    ) {
      if (this.objectStore.name === ENTITY_NAMES.at(-1))
        throw new Error("injected read failure");
      return original.apply(this, args);
    };
    try {
      await expect(data.clearAccountData("account-a")).rejects.toThrow(
        "injected read failure",
      );
    } finally {
      IDBIndex.prototype.getAllKeys = original;
    }
    for (const count of await allCounts("account-a")) expect(count).toBe(1);
  });
});
