"use strict";
(() => {
  // src/errors.ts
  var ExtensionError = class extends Error {
    constructor(code, message2, options) {
      super(message2, options);
      this.code = code;
      this.name = "ExtensionError";
      if (options?.display) this.display = options.display;
    }
    /**
     * What the UI shows, in the user's language. The English `message` stays
     * for logs; a panel never shows it (docs/i18n-spec.md, Section 3.10).
     */
    display;
  };
  function isExtensionError(value, code) {
    return value instanceof ExtensionError && (code === void 0 || value.code === code);
  }

  // src/i18n/catalog/en.ts
  var en = {
    // Shared labels
    "placement.qualified": "Qualified",
    "placement.needs-review": "Needs Review",
    "placement.quarantined": "Junk",
    "condition.verified": "Verified by JoyClub",
    "condition.personallyKnown": "Personally known",
    "condition.minimumPhotos": "Minimum photos",
    "condition.minimumProfileWords": "Minimum profile words",
    "condition.minimumAccountAgeDays": "Minimum account age in days",
    "condition.notTemplateSpam": "Not flagged as template spam",
    "condition.minimumTrustScore": "Minimum local trust score",
    "condition.firstMessageContains": "First message contains",
    "field.accountAgeDays": "Account age in days",
    "field.photoCount": "Photo count",
    "field.profileWordCount": "Profile word count",
    "outcome.qualified": "Qualified",
    "outcome.partial-information": "Partial information",
    "outcome.does-not-meet-rule": "Does not meet rule",
    "common.close": "Close",
    "common.openOptions": "Open JoyFox options",
    "common.saveFailed": "JoyFox could not save that change. Nothing was changed. Try again. If it keeps failing, reload the page.",
    "legacy.text": (p) => p.text,
    // Shown in place of a damaged or unknown text reference, never its key.
    "common.textUnavailable": "(This text cannot be shown.)",
    // Triage reasons (qualification engine, contact rule, triage service)
    "triage.reason.unknownValue": (p) => `${p.field} is unknown, so it was not counted for or against.`,
    "triage.reason.atOrAbove": (p, f) => `${p.field} is ${f.number(p.value)}, at or above the required ${f.number(p.minimum)}.`,
    "triage.reason.belowMinimum": (p, f) => `${p.field} is ${f.number(p.value)}, below the required ${f.number(p.minimum)}.`,
    "triage.reason.accountAgeRangeAbove": (p, f) => `Account age is between ${f.number(p.min)} and ${f.number(p.max)} days, at or above the required ${f.number(p.minimum)}.`,
    "triage.reason.accountAgeRangeBelow": (p, f) => `Account age is between ${f.number(p.min)} and ${f.number(p.max)} days, below the required ${f.number(p.minimum)}.`,
    "triage.reason.accountAgeRangeCoarse": (p, f) => `Account age is between ${f.number(p.min)} and ${f.number(p.max)} days, which is too coarse to compare with the required ${f.number(p.minimum)}, so it was not counted for or against.`,
    "triage.reason.verificationUnknown": "Verification status is unknown, so it was not counted for or against.",
    "triage.reason.verified": "The profile is verified, as the rule requires.",
    "triage.reason.notVerified": "The profile is not verified, which the rule requires.",
    "triage.reason.personallyKnownUnknown": "Whether you know this member personally is unknown, so it was not counted for or against.",
    "triage.reason.personallyKnown": "You marked this member as personally known, as the rule requires.",
    "triage.reason.notPersonallyKnown": "You have not marked this member as personally known, which the rule requires.",
    "triage.reason.noCriteria": "No qualification criteria are configured, so every sender qualifies.",
    "triage.reason.spamFlagged": "A message from this sender looks like a copied template.",
    "triage.reason.spamNotFlagged": "No message from this sender looks like a copied template.",
    "triage.reason.spamOverridden": "You marked this sender as not spam.",
    "triage.reason.spamUnknown": "JoyFox has not checked this sender's messages for templates, so spam status is unknown.",
    "triage.reason.phraseSeenNow": (p) => `The latest message from this sender contains "${p.text}".`,
    "triage.reason.phraseSeenBefore": (p) => `An earlier message from this sender, seen in your inbox, contains "${p.text}".`,
    "triage.reason.phraseNotInLatest": (p) => `The latest message from this sender does not contain "${p.text}". The inbox shows only the latest message, so JoyFox cannot see if the first message contained it.`,
    "triage.reason.phraseNotSeen": (p) => `JoyFox has not seen a message from this sender that contains "${p.text}". Only the inbox shows messages to JoyFox.`,
    "triage.reason.trustUnknown": "You have logged nothing about this member, so the local trust score is unknown.",
    "triage.reason.trustAtOrAbove": (p, f) => `Your local trust score is ${f.number(p.score)}, at or above the required ${f.number(p.minimum)}.`,
    "triage.reason.trustBelow": (p, f) => `Your local trust score is ${f.number(p.score)}, below the required ${f.number(p.minimum)}.`,
    "triage.reason.negatedMet": (p) => `${p.reason} Your rule says "not ${p.condition}", so this counts as met.`,
    "triage.reason.negatedNotMet": (p) => `${p.reason} Your rule says "not ${p.condition}", so this counts as not met.`,
    "triage.reason.unknownNeedsReview": (p) => `${p.reason} Your rule sends unknown values to Needs Review.`,
    "triage.reason.unknownMet": (p) => `${p.reason} Your rule counts an unknown value as met.`,
    "triage.reason.unknownNotMet": (p) => `${p.reason} Your rule counts an unknown value as not met.`,
    "triage.reason.numbered": (p, f) => `Group ${f.number(p.number)}: ${p.reason}`,
    "triage.reason.userMoved": (p) => `You moved this sender to ${p.placement}.`,
    "triage.headline.noConditions": "Your contact rule has no required conditions, so every sender qualifies.",
    "triage.headline.meets": "This sender meets your contact rule.",
    "triage.headline.undecided": "JoyFox could not decide, because some information is unknown.",
    "triage.headline.doesNotMeet": (p) => `This sender does not meet your contact rule, so JoyFox places them in ${p.placement}.`,
    // Trust score
    "trust.reason.positive": (p, f) => `You logged ${f.plural(p.count, {
      one: "1 positive outcome",
      other: `${f.number(p.count)} positive outcomes`
    })}.`,
    "trust.reason.negative": (p, f) => `You logged ${f.plural(p.count, {
      one: "1 negative outcome",
      other: `${f.number(p.count)} negative outcomes`
    })}.`,
    "trust.reason.neutral": (p, f) => `You logged ${f.plural(p.count, {
      one: "1 neutral outcome",
      other: `${f.number(p.count)} neutral outcomes`
    })}, which count 0.`,
    "trust.reason.personallyKnown": "You marked this member as personally known.",
    "trust.reason.spamFlagged": "A message from this member looks like a copied template.",
    "trust.scopeNote": "Based only on what you logged and saw in this browser. It is not a JoyClub or community rating.",
    // Template spam detector
    "spam.detail.override": "You marked this sender as not spam, so their messages are never flagged.",
    "spam.detail.belowMinimum": (p, f) => `The message has ${f.plural(p.words, {
      one: "1 word",
      other: `${f.number(p.words)} words`
    })}, below the ${f.number(p.minimum)} needed before template matching runs.`,
    "spam.detail.duplicate": (p, f) => `This message closely matches an earlier message you received (${f.number(p.percent)}% similar).`,
    "spam.detail.knownPhrase": "The message contains a phrase from your known-template list.",
    "spam.detail.phraseSimilar": (p, f) => `The message closely matches a phrase from your known-template list (${f.number(p.percent)}% similar).`,
    "spam.detail.noMatch": "The message matched no earlier message and no known template phrase.",
    // Quick Ignore and Delete (M9): the report built from ActionLog steps
    "action.step.ignore": "Ignore",
    "action.step.delete": "Delete",
    "action.where.before": (p) => `before ${p.step}`,
    "action.where.during": (p) => `during ${p.step}`,
    "action.failure.control-missing": (p) => `JoyFox could not find JoyClub's ${p.step} option on this page.`,
    "action.failure.confirmation-missing": (p) => `JoyClub's confirmation for ${p.step} did not appear.`,
    "action.failure.not-verified": (p) => `JoyClub did not show that ${p.step} succeeded.`,
    "action.failure.unverifiable": (p) => `JoyFox cannot see JoyClub's result for ${p.step} on this page, so it stopped ${p.where}.`,
    "action.failure.member-mismatch": (p) => `The page showed another member, so JoyFox stopped ${p.where}.`,
    "action.failure.conversation-mismatch": (p) => `The page showed another conversation, so JoyFox stopped ${p.where}.`,
    "action.failure.identity-unavailable": (p) => `JoyFox could not confirm which member or conversation the page shows, so it stopped ${p.where}.`,
    "action.failure.account-changed": (p) => `The active JoyFox account changed, so JoyFox stopped ${p.where}.`,
    "action.failure.turned-off": (p) => `Ignore and Delete was turned off, so JoyFox stopped ${p.where}.`,
    "action.failure.superseded": (p) => `A newer JoyFox run for this member started, so JoyFox stopped ${p.where}.`,
    "action.failure.log-unavailable": (p) => `JoyFox could not write to its action log, so it stopped ${p.where}.`,
    "action.failure.handoff-failed": (p) => `JoyFox could not move on to the member's profile, so it stopped ${p.where}.`,
    "action.failure.timeout": (p) => `JoyClub did not respond in time during ${p.step}.`,
    "action.failure.step-error": (p) => `An unexpected error stopped JoyFox ${p.where}.`,
    "action.stepText.ignore.done": "Ignore: done. JoyClub ignores this member.",
    "action.stepText.ignore.not-done": "Ignore: not done.",
    "action.stepText.ignore.unknown": "Ignore: not confirmed. JoyFox started it but did not see JoyClub confirm it.",
    "action.stepText.delete.done": "Delete: done. JoyClub moved the conversation to the trash.",
    "action.stepText.delete.not-done": "Delete: not done.",
    "action.stepText.delete.unknown": "Delete: not confirmed. JoyFox started it but did not see JoyClub confirm it.",
    "action.next.ignore": "Next: open the member's profile and check whether they are ignored. If not, ignore them there yourself.",
    "action.next.delete": "Next: open the conversation and check whether it is in the trash. If not, move it there yourself with JoyClub's trash button.",
    "action.next.showList": "Delete works only while this conversation shows in the ClubMail list beside it. Widen the window, or scroll the list until the conversation shows, then try again.",
    "action.self.ignore": "You can do it yourself: open the member's profile and ignore them there.",
    "action.self.delete": "You can do it yourself: move the conversation to the trash with JoyClub's trash button.",
    "action.report.finished": "Ignore and Delete finished.",
    "action.report.undo": `To undo, restore the conversation from JoyClub's trash. Then open the member's profile and choose "Profil nicht mehr ignorieren" in its menu.`,
    "action.report.running": "Ignore and Delete is running.",
    "action.report.stopped": "Ignore and Delete stopped.",
    "action.report.interrupted": "Ignore and Delete was interrupted, for example because the tab closed.",
    "action.report.nothingChanged": "Nothing was changed on JoyClub.",
    "action.report.notUndone": "JoyFox did not undo anything.",
    "action.deleteReport.finished": "Delete finished.",
    "action.deleteReport.undo": "To undo, restore the conversation from JoyClub's trash.",
    "action.deleteReport.running": "Delete is running.",
    "action.deleteReport.stopped": "Delete stopped.",
    "action.deleteReport.interrupted": "Delete was interrupted, for example because the tab closed.",
    // Content script: the Delete and Ignore and Delete buttons and notice
    "quick.progress.Started": "Ignore and Delete is running. Checking the page.",
    "quick.delete.progress.Started": "Delete is running. Checking the page.",
    "quick.progress.DeleteRequested": "Moving the conversation to the trash.",
    "quick.progress.DeleteConfirmed": "Delete done. Opening the member's profile to ignore them there.",
    "quick.progress.IgnoreRequested": "Ignoring the member on JoyClub.",
    "quick.button": "Ignore and Delete",
    "quick.region": "JoyFox conversation actions",
    "quick.delete.button": "Delete",
    "quick.delete.scope": "One click moves this conversation to JoyClub's trash, then returns to the ClubMail list. The member is not ignored. JoyFox stops at the first problem and tells you what was done. It never sends a message.",
    "quick.scope": "Experimental. One click moves this conversation to JoyClub's trash, then opens the member's profile and ignores them there. JoyFox stops at the first problem and tells you what was done. It never sends a message.",
    "quick.needsList": "Works only while this conversation shows in the ClubMail list beside it. Widen the window, or scroll the list until the conversation shows.",
    "quick.noProfile": "JoyFox cannot find the link to this member's profile, where Ignore is, so it did nothing. You can do it yourself: move the conversation to the trash with JoyClub's trash button, then open the member's profile and ignore them there.",
    "quick.resumed": "Ignore and Delete, continued from the conversation:",
    "quick.waitingMenu": "Waiting for JoyClub's profile menu\u2026",
    "quick.previous": "Your last Ignore and Delete for this member:",
    "quick.previousOther": "Your last Ignore and Delete for this member, in another conversation:",
    "quick.otherResult": "Your last Ignore and Delete, for another conversation:",
    "quick.delete.previous": "Your last Delete for this member:",
    "quick.delete.previousOther": "Your last Delete for this member, in another conversation:",
    "quick.delete.otherResult": "Your last Delete, for another conversation:",
    "quick.otherRunning": "A JoyFox run is still going for another conversation. Wait until it ends.",
    "quick.busy": "Another JoyFox run for this member is still going, for example in another tab. Nothing was done here.",
    "quick.junk.done": "Mark as junk: the sender is in Junk, and a Negative outcome is logged.",
    "quick.junk.busy": "Another JoyFox run for this member is still going, so JoyFox did not start the trash step.",
    "quick.junk.notTrashed": "The conversation was not moved to the trash.",
    "quick.delete.unexpected": "Delete stopped because of an unexpected error. JoyFox may have moved the conversation to the trash: check JoyClub's trash yourself.",
    "quick.unexpected": "Ignore and Delete stopped because of an unexpected error. JoyFox may have completed a step: check the member's profile and the conversation yourself.",
    // Content script: triage explanation, member bar and trust controls
    "triage.outcome.met": "Met",
    "triage.outcome.not-met": "Not met",
    "triage.outcome.needs-review": "Needs Review",
    "triage.conditions.summary": (p, f) => `All checked conditions (${f.number(p.count)})`,
    "triage.condition.line": (p) => `${p.outcome}: ${p.condition}. `,
    "triage.condition.lineNegated": (p) => `${p.outcome}: not ${p.condition}. `,
    "triage.placementLine": (p) => `Placement: ${p.placement} (${p.source}).`,
    "triage.source.override": "your manual choice",
    "triage.source.rule": "your contact rule",
    "triage.source.sharedEvent": "the shared-event exception",
    "triage.sharedEvent.attending": (p) => `On the guest list of "${p.event}"${p.when ? ` (${p.when})` : ""}, which you marked Attending.`,
    "triage.sharedEvent.attended": (p) => `On the guest list of "${p.event}"${p.when ? ` (${p.when})` : ""}, which you marked Attended.`,
    "triage.sharedEvent.optOut": "Don't use the shared event for this sender",
    "triage.movedOn": (p) => `You moved this sender on ${p.date}. Your rule alone would place them in ${p.placement}.`,
    "triage.place.group": "Place this sender",
    "triage.useRule": "Use my rule again",
    "mark.group": "Mark this sender",
    "mark.qualified": "Mark qualified",
    "mark.junk": "Mark as junk",
    "mark.trustFailed": (p) => `JoyFox placed this sender in ${p.placement} but could not log the trust outcome, so it stopped there. You can log it on the member's conversation or profile page.`,
    "mark.junk.noTrash": "The sender is in Junk, and a Negative outcome is logged. JoyFox could not move this conversation to the trash here. Move it there yourself with JoyClub's trash button.",
    "triage.profileFact.minimumPhotos": "photo count",
    "triage.profileFact.minimumProfileWords": "profile word count",
    "triage.profileFact.minimumAccountAgeDays": "account age",
    "triage.unknownFacts.one": (p) => `The ${p.fact} is unknown. Open the profile and JoyFox reads it.`,
    "triage.unknownFacts.two": (p) => `The ${p.first} and ${p.second} are unknown. Open the profile and JoyFox reads them.`,
    "triage.unknownFacts.three": (p) => `The ${p.first}, ${p.second} and ${p.third} are unknown. Open the profile and JoyFox reads them.`,
    "trust.score.none": "Local trust score: no history yet.",
    "trust.score.value": (p, f) => `Local trust score: ${f.number(p.score)}.`,
    "trust.details.summary": "How the score adds up",
    "trust.contribution": (p, f) => `${p.points > 0 ? "+" : ""}${f.number(p.points)}: ${p.reason}`,
    "trust.log.group": "Log how it went with this member",
    "trust.log.positive": "Log positive",
    "trust.log.neutral": "Log neutral",
    "trust.log.negative": "Log negative",
    "trust.log.undo": "Undo last outcome",
    "bar.placementPrefix": "Placement: ",
    "bar.yourChoice": "(your choice)",
    "bar.sharedEvent": "(shared event)",
    "bar.openProfile": "Open profile",
    "bar.log": "Log:",
    "bar.positive": "Positive",
    "bar.neutral": "Neutral",
    "bar.negative": "Negative",
    "bar.undo": "Undo",
    "bar.details": "Details",
    "strip.collapse": "Collapse JoyFox",
    "strip.expand": "Expand JoyFox",
    "bar.scoreDetails": "Score details",
    "panel.ruleOff.no-rule": "No contact rule is set, so JoyFox does not place this sender.",
    "panel.ruleOff.rule-disabled": "Your contact rule is turned off, so JoyFox does not place this sender.",
    "panel.ruleOff.other": "JoyFox cannot place this sender right now. Reload the page to try again.",
    "panel.ruleOff.no-account": "No JoyFox account is active, so JoyFox shows nothing for this member.",
    // Content script: inbox triage
    "inbox.region": "JoyFox triage",
    "inbox.views": "Show messages",
    "inbox.view.default": "Inbox",
    "inbox.view.all": "Show all",
    "inbox.viewCount": (p, f) => `${p.view} (${f.number(p.count)})`,
    "inbox.about": "About these views",
    "inbox.aboutText": "Inbox hides Junk rows from this view only. Nothing is deleted, and JoyFox changes nothing on JoyClub.",
    "inbox.checking": "Checking",
    "inbox.badge": (p) => `JoyFox: ${p.text}. Details.`,
    "inbox.why": "Details",
    "inbox.whyNamed": (p) => `Details: ${p.name}`,
    "inbox.rowGone": "This row is no longer shown.",
    "inbox.unidentified": "JoyFox could not read this sender's profile number, so it could not check your rule. The row stays visible.",
    "inbox.stillChecking": "JoyFox is still checking this sender.",
    "inbox.setup.no-account": "JoyFox has no active account, so it does not sort this inbox.",
    "inbox.setup.no-rule": "No contact rule is saved, so JoyFox does not sort this inbox.",
    // Content script: notes and tags
    "notes.region": "JoyFox notes and tags",
    "notes.scope": "Private to JoyFox: stored only in this browser, under the active JoyFox account. JoyFox never sends it anywhere.",
    "notes.saved": "Note saved.",
    "notes.removed": "Note removed.",
    "notes.conflict": "This note changed in another tab or in the JoyFox data inspector, so JoyFox did not save your text. It is still in the box. Save again to replace the stored note, or discard your changes to see it.",
    "notes.refused": "The active JoyFox account changed, so nothing was stored. Text typed for the previous account was dropped.",
    "notes.emptyTag": "Type a tag first. Nothing was added.",
    "notes.emptyNote": "Type a note first. Nothing was saved.",
    "notes.tagAdded": "Tag added.",
    "notes.tagExists": "Already tagged.",
    "notes.tagRemoved": "Tag removed.",
    "notes.privateNote": "Private note",
    // Shown under a note box once the text is near its limit.
    "notes.length": (p, f) => `${f.number(p.count)} of ${f.number(p.maximum)} characters`,
    "notes.pasteCut": "Only part of the pasted text fit. The rest was not pasted.",
    "notes.discard": "Discard my changes",
    "notes.save": "Save note",
    "notes.tags": "Tags",
    "notes.noTags": "No tags yet.",
    "notes.remove": "Remove",
    "notes.removeTag": (p) => `Remove tag ${p.label}`,
    "notes.addTagLabel": "Add a tag",
    "notes.addTag": "Add tag",
    "notes.summary.none": "Your notes and tags (none yet)",
    "notes.summary.note": "Your notes and tags (a note)",
    "notes.summary.tags": (p, f) => `Your notes and tags (${f.plural(p.count, {
      one: "1 tag",
      other: `${f.number(p.count)} tags`
    })})`,
    "notes.summary.noteAndTags": (p, f) => `Your notes and tags (a note and ${f.plural(p.count, {
      one: "1 tag",
      other: `${f.number(p.count)} tags`
    })})`,
    // Content script: event and venue notes (V1-5)
    "listing.heading.event": "JoyFox: your notes on this event",
    "listing.heading.venue": "JoyFox: your notes on this venue",
    // The box's summary: what is stored, for example "Attending, 2 tags, a note".
    "listing.summary.event": (p) => `JoyFox: your notes on this event (${p.state})`,
    "listing.summary.venue": (p) => `JoyFox: your notes on this venue (${p.state})`,
    "listing.summary.none": "none yet",
    "listing.summary.note": "a note",
    "listing.loading": "Loading your notes\u2026",
    "listing.readFailed": "JoyFox could not read your notes on this page. Reload the page to try again.",
    "listing.noAccount": "Select or add an account in the JoyFox options to keep notes on events.",
    "listing.attendanceLabel": "Your attendance",
    "listing.attendance.unknown": "No status",
    "listing.attendance.interested": "Interested",
    "listing.attendance.attending": "Attending",
    "listing.attendance.not-attending": "Not attending",
    "listing.attendance.attended": "Attended",
    "listing.noteLabel": "Your note",
    "listing.saveNote": "Save note",
    "listing.tagsLabel": "Your tags",
    "listing.tagLabel": "New tag",
    "listing.addTag": "Add tag",
    "listing.removeTag": (p) => `Remove tag ${p.tag}`,
    "listing.emptyTag": "Type a tag first. Nothing was added.",
    "listing.tooManyTags.event": (p, f) => `You can add at most ${f.number(p.maximum)} tags to an event. Remove one first.`,
    "listing.tooManyTags.venue": (p, f) => `You can add at most ${f.number(p.maximum)} tags to a venue. Remove one first.`,
    "listing.privacy": "Private: stored only in this browser. JoyClub sees nothing, and your sign-up on JoyClub does not change.",
    "listing.saved": "Saved.",
    // The first save of an event or venue.
    "listing.tracked.event": "Saved. JoyFox now tracks this event.",
    "listing.tracked.venue": "Saved. JoyFox now tracks this venue.",
    "listing.removed.event": "No note, tag or attendance is left, so JoyFox no longer tracks this event.",
    "listing.removed.venue": "No note or tag is left, so JoyFox no longer tracks this venue.",
    "listing.conflict": "These notes changed in another tab, so JoyFox did not save. The stored notes are shown now; your typed note is still in the box.",
    "listing.refused": "The active JoyFox account changed, so nothing was saved.",
    // Options page: personal event calendar (V1-5)
    "events.heading": "Your events",
    "events.hint": "Every event and venue you added a note, tag or attendance to on JoyClub, in date order. JoyFox keeps them after JoyClub removes an event. To change one, open it on JoyClub.",
    "events.readFailed": "JoyFox could not read your events. Reload the page to try again.",
    "events.noAccount": "Select or add an account first. Each account has its own events.",
    "events.empty": "No tracked events yet. Open an event on JoyClub and add a note, a tag or your attendance.",
    "events.count": (p, f) => `${f.number(p.shown)} of ${f.number(p.total)} tracked events shown.`,
    "events.filterLabel": "Show",
    "events.filter.all": "All tracked events",
    "events.searchLabel": "Search my notes, tags and titles",
    "events.noDate": "No date",
    "events.untitled": (p) => `Event ${p.id}`,
    "events.past": (p) => `${p.when} (past)`,
    "events.venue": (p) => `Venue: ${p.venue}`,
    "events.venuesHeading": "Your venues",
    "events.guests": (p, f) => f.plural(p.count, {
      one: "1 guest stored",
      other: `${f.number(p.count)} guests stored`
    }),
    "events.exception.label": "Shared-event exception: place a sender in Qualified when they are on the guest list of an event I marked Attending or Attended",
    "events.exception.hint": `Off by default. JoyFox stores a tracked event's guest list when you open the event page, as far as JoyClub has loaded it, and deletes it when you stop tracking the event. A sender you marked yourself keeps your choice, and the "Details" panel can turn the exception off for one sender.`,
    "events.exception.saved": "Saved.",
    "events.exception.saveFailed": "JoyFox could not save this setting. Try again.",
    // Options page: the switch for the experimental Ignore and Delete (M9)
    "quickSetting.heading": "Ignore and Delete",
    "quickSetting.label": 'Show the "Ignore and Delete" button on ClubMail conversations',
    "quickSetting.hint": `Experimental and on by default. One click moves the conversation to JoyClub's trash, opens the member's profile in the same tab and ignores the member there. It works only while the ClubMail list shows beside the conversation. JoyFox acts only when you click. The "Action log" in "Your data" records every step. This setting controls only "Ignore and Delete": the "Delete" button and "Mark as junk" move a conversation to JoyClub's trash also when it is off.`,
    "quickSetting.risk": "If JoyClub finds a tool that clicks for you, it can restrict or close your account. Of all JoyFox features, this one has the highest risk.",
    "quickSetting.undo": `To undo, restore the conversation from JoyClub's trash. Then open the member's profile and choose "Profil nicht mehr ignorieren" in its menu.`,
    "quickSetting.saved": "Saved. Open ClubMail tabs follow at once.",
    "quickSetting.saveFailed": "JoyFox could not save this setting. Try again.",
    "sharedEvents.heading": "Shared events",
    "sharedEvents.intro": "This member is on the stored guest list of these events you track:",
    // Content script: event list filter (V1-5)
    "eventFilter.label": "JoyFox: show",
    "eventFilter.all": "All loaded events and dates",
    "eventFilter.tracked": "Only events JoyFox tracks",
    "eventFilter.note": "Only events with your note",
    "eventFilter.attending": "Only events you attend",
    "eventFilter.interested": "Only events you are interested in",
    "eventFilter.tag": (p) => `Only events with your tag: ${p.tag}`,
    "eventFilter.count": (p, f) => `${f.number(p.shown)} of ${f.number(p.loaded)} loaded events shown. Events loaded later are checked too.`,
    "eventFilter.readFailed": "JoyFox could not read your event notes. Reload the page to try again.",
    "eventFilter.noAccount": "Select or add an account in the JoyFox options to filter by your notes.",
    "eventFilter.badge": "JoyFox",
    "eventFilter.hasNote": "note",
    // Content script: profile type filter on the "My JOY" lists (V1-14)
    "typeFilter.legend": "Profile type",
    "typeFilter.man": "Man",
    "typeFilter.woman": "Woman",
    "typeFilter.couple": "Couple",
    "typeFilter.unknown": "Unknown",
    "typeFilter.count": (p, f) => `Showing ${f.number(p.shown)} of ${f.number(p.loaded)} loaded`,
    "typeFilter.unknownHidden": (p, f) => `${f.number(p.count)} with unknown type hidden`,
    "typeFilter.scrollHint": "Scroll down to load more.",
    "typeFilter.unknownMark": "Type unknown",
    // Options page: message search (V1-4)
    "messages.heading": "Message search",
    "messages.hint": "JoyFox stores the ClubMail messages you open, sent and received, so you can search them here. It stores only what a conversation shows on screen and never loads older messages. The text stays in this browser, and an export file holds it too. If you allow JoyFox in private windows, it stores the messages you open there in the same way.",
    "messages.caching": "Store the messages I open in ClubMail",
    "messages.cachingOn": "Message storing is on.",
    "messages.cachingOff": 'Message storing is off. Messages stored before stay until they are older than the time set here, or until you delete them under "Your data".',
    "messages.offHint": "Storing is off: JoyFox stores no new messages. Search still covers the messages stored before.",
    "messages.retentionLabel": "Keep messages for (months)",
    "messages.retentionSave": "Save",
    "messages.retentionHint": (p, f) => `Messages older than this are deleted automatically. Lowering the number deletes older messages at once. The default is ${f.number(p.default)}. Click "Save" to apply.`,
    // Save asks for a second click when the number goes down, as deletes do.
    "messages.retentionConfirm": "Save and delete",
    "messages.retentionConfirmPrompt": (p, f) => `Lowering the number deletes the stored messages older than ${f.plural(
      p.months,
      { one: "1 month", other: `${f.number(p.months)} months` }
    )} at once. Click "Save and delete" to confirm.`,
    "messages.retentionSaved": (p, f) => p.deleted === 0 ? "Saved. No older message needed deleting." : `Saved. ${f.plural(p.deleted, {
      one: "1 older message was",
      other: `${f.number(p.deleted)} older messages were`
    })} deleted.`,
    "messages.retentionInvalid": (p, f) => `Enter a whole number from ${f.number(p.minimum)} to ${f.number(p.maximum)}. Nothing was changed.`,
    "messages.noAccount": "Select or add an account first.",
    "messages.readFailed": "JoyFox could not read your stored messages. Reload the page to try again.",
    "messages.searchLabel": "Search my messages",
    "messages.count": (p, f) => p.count === 0 ? "No stored message contains this." : `${f.plural(p.count, {
      one: "1 message",
      other: `${f.number(p.count)} messages`
    })} found.`,
    "messages.countLimited": (p, f) => `${f.number(p.count)} messages found. The newest ${f.number(p.shown)} are shown.`,
    // `member` is the member's nickname, or `member.number` when JoyFox has
    // never seen it.
    "messages.sentTo": (p) => `You to ${p.member} \xB7 ${p.when}`,
    "messages.receivedFrom": (p) => `${p.member} to you \xB7 ${p.when}`,
    "messages.storedAt": (p) => `stored ${p.when}`,
    // Content script: profile signals on cards (V1-10)
    "signals.state.complete": "Complete",
    "signals.state.incomplete": "Incomplete",
    "signals.state.unknown": "Completeness unknown",
    // The inbox row's compact line: the full text is in the tooltip.
    "signals.state.unknownShort": "Unknown",
    "signals.photos": (p, f) => f.plural(p.count, {
      one: "1 photo",
      other: `${f.number(p.count)} photos`
    }),
    "signals.photosUnknown": "photos unknown",
    "signals.words": (p, f) => f.plural(p.count, {
      one: "1 word",
      other: `${f.number(p.count)} words`
    }),
    "signals.wordsUnknown": "words unknown",
    "signals.verified": "verified",
    "signals.notVerified": "not verified",
    "signals.verificationUnknown": "verification unknown",
    "signals.heading": "Profile completeness",
    "signals.trust": (p, f) => `Trust ${p.score > 0 ? "+" : ""}${f.number(p.score)}`,
    "signals.trustNoneShort": "Trust \u2013",
    "signals.noteAdd": "Add note",
    "signals.noteEdit": "Note",
    "signals.tagsLabel": "Your tags",
    "signals.tagCount": (p, f) => f.plural(p.count, {
      one: "1 tag",
      other: `${f.number(p.count)} tags`
    }),
    "signals.editor.label": (p) => `JoyFox: note and tags for ${p.member}`,
    // A member whose nickname JoyFox has never seen.
    "member.number": (p) => `Member ${p.id}`,
    "signals.editor.loading": "Loading\u2026",
    "signals.editor.close": "Close",
    "signals.editor.noAccount": "Select or add an account in the JoyFox options to keep notes.",
    "signals.editor.readFailed": "JoyFox could not read this member's notes. Close and try again.",
    "signals.filter.label": "JoyFox: hide incomplete profiles",
    "signals.filter.count": (p, f) => `${f.number(p.hidden)} of ${f.number(p.loaded)} loaded profiles hidden. Profiles JoyFox knows nothing about stay visible.`,
    // Content script: compatibility overlay (V1-2)
    "compat.heading": "Shared preferences",
    "compat.shared": (p, f) => `You share ${f.plural(p.count, {
      one: "1 preference",
      other: `${f.number(p.count)} preferences`
    })} with this member:`,
    "compat.none": "You share no preferences with this member.",
    "compat.listToggle": "Show the shared preferences",
    "compat.own": (p, f) => `This is your profile. JoyFox compares other profiles with your ${f.plural(
      p.count,
      {
        one: "1 positive preference",
        other: `${f.number(p.count)} positive preferences`
      }
    )}.`,
    "compat.ownUnknown": "Open your own JoyClub profile once, so JoyFox knows your preferences.",
    "compat.unreadable": "JoyFox could not read this profile's preferences yet.",
    "compat.missing": "This profile shows no preferences to compare.",
    "compat.readFailed": "JoyFox could not load your preferences. Reload the page to try again.",
    "compat.noAccount": "Select or add an account in the JoyFox options to compare preferences.",
    "compat.badge": (p, f) => `${f.number(p.count)} shared`,
    "compat.badgeLabel": (p, f) => `JoyFox: ${f.plural(p.count, {
      one: "1 shared preference",
      other: `${f.number(p.count)} shared preferences`
    })}`,
    "compat.sort.button": "Sort by shared preferences",
    "compat.sort.on": "Sorted by shared preferences. Members whose profile you have not opened come last.",
    "compat.sort.unavailable": "JoyFox cannot sort the results as JoyClub shows them now. Their order has not changed.",
    // Content script: saved searches (V1-3)
    "searches.heading": "JoyFox saved searches",
    "searches.loading": "Loading saved searches\u2026",
    "searches.readFailed": "JoyFox could not read your saved searches. Reload the page to try again.",
    "searches.empty": "No saved searches yet.",
    "searches.noAccount": "Select or add an account in the JoyFox options to save searches.",
    "searches.save": "Save this search",
    "searches.nameLabel": "Name for this search",
    "searches.confirmSave": "Save",
    "searches.cancel": "Cancel",
    "searches.noName": "Type a name first. Nothing was saved.",
    "searches.nameTooLong": (p, f) => `A name can have at most ${f.number(p.maximum)} characters. Nothing was saved.`,
    "searches.notSearchAddress": "This page's address is not a search JoyFox can save. Nothing was saved.",
    "searches.full": (p, f) => `You have ${f.number(p.maximum)} saved searches, the most JoyFox keeps. Delete one first.`,
    "searches.refused": "The active JoyFox account changed, so nothing was changed.",
    "searches.saved": (p) => `Saved "${p.name}".`,
    "searches.noMatch": (p) => `"${p.name}" no longer matches JoyClub's search address, so JoyFox did not open it. Run the search again and save it again.`,
    "searches.running": (p) => `Running "${p.name}"\u2026`,
    "searches.runningUnnamed": "Running the saved search\u2026",
    "searches.shown": (p) => `Showing "${p.name}".`,
    "searches.shownUnnamed": "Showing the saved search.",
    "searches.runFailed": `JoyFox could not run the saved search. Open JoyClub's filter and click "Anwenden".`,
    "searches.deleteLabel": (p) => `Delete saved search ${p.name}`,
    "searches.confirmDelete": (p) => `Click \u2715 again to delete "${p.name}".`,
    "searches.deleted": (p) => `Deleted "${p.name}".`,
    // Content script: template picker
    "picker.toggle": "JoyFox templates",
    "picker.loading": "Loading templates\u2026",
    "picker.readFailed": 'JoyFox could not load your templates. Nothing was inserted. Click "JoyFox templates" again to try again.',
    "picker.empty": "No templates yet. Add them on the JoyFox options page.",
    "picker.noAccount": "No JoyFox account is active. Choose one on the JoyFox options page.",
    "picker.result.inserted": "Template inserted. Check the text, then click JoyClub's Send button yourself.",
    "picker.result.not-editable": "The message field cannot be edited right now. Nothing was inserted. Wait until you can type in the message field, then try again.",
    "picker.result.too-long": (p, f) => `With the template, the message would be ${f.plural(p.over, {
      one: "1 character",
      other: `${f.number(p.over)} characters`
    })} too long. The message field takes at most ${f.number(p.limit)} characters. Nothing was inserted. Shorten your text or the template.`,
    "picker.result.altered": "JoyClub changed the text after insertion. Check the message field before you send.",
    "templates.folder.general": "General",
    "templates.folder.eventConfirmation": "Event confirmation",
    "templates.folder.eventCancellation": "Event cancellation",
    // Options page: shell and tabs
    "options.title": "JoyFox options",
    "options.intro": "JoyFox stores everything locally in this browser profile. Inbox sorting stays off until you save a contact rule.",
    "options.tabs.start": "Get started",
    "options.tabs.accounts": "Accounts",
    "options.tabs.rule": "Contact rule",
    "options.tabs.templates": "Templates",
    "options.tabs.events": "Events",
    "options.tabs.messages": "Messages",
    "options.tabs.data": "Your data",
    "options.importRegion": "Import JoyFox data",
    "options.languageSaveFailed": "JoyFox could not save the language. Try again.",
    // Options page: Get started
    "start.state.done": "Done",
    "start.state.off": "Saved, but turned off",
    "start.state.todo": "Not done yet",
    "start.state.doneOpen": "Done: no conditions, so every sender qualifies",
    "start.ready": "JoyFox is set up. Open your JoyClub inbox to see it sorted.",
    "start.intro": "Three steps, a few minutes. Everything stays in this browser.",
    "start.introAccess": "Four steps, a few minutes. Everything stays in this browser.",
    "start.readFailed": "JoyFox could not read its setup. Reload the page to try again.",
    "start.step.access": "Allow JoyFox to access joyclub.de. Access is off now, so JoyFox cannot work on JoyClub.",
    "start.step.account": "Add your JoyClub account under [Accounts](#accounts). JoyFox makes the first one active.",
    "start.step.chooseAccount": "Choose the active account under [Accounts](#accounts).",
    "start.step.rule": "Save a contact rule under [Contact rule](#rule). Inbox sorting stays off until a rule is saved and turned on.",
    "start.step.inbox": "Open your JoyClub inbox (www.joyclub.de, ClubMail). JoyFox adds its tabs above the list.",
    // Options page: site access (Get started)
    "access.allow": "Allow access to joyclub.de",
    "access.granted": "Access to joyclub.de is on. Reload any JoyClub tab that is open, so JoyFox can work there.",
    "access.refused": "Access to joyclub.de is still off. JoyFox cannot work on JoyClub until you allow access here or in about:addons.",
    // Options page: accounts
    "accounts.readFailed": "JoyFox could not read its stored accounts. No account was changed. Reload the page to try again.",
    "accounts.hint": "JoyFox cannot read which JoyClub login a tab uses. The active account is the one selected here. JoyFox stores your notes, tags, rules, templates and other data under it.",
    "accounts.activeLabel": "Active account:",
    "accounts.noneSelected": "None selected",
    "accounts.empty": "No accounts yet. Add one below to use JoyFox.",
    "accounts.list": "Stored accounts",
    // An account's label with its JoyClub identifier, so two accounts with
    // similar labels can be told apart.
    "accounts.nameWithIdentifier": (p) => `${p.label} (${p.identifier})`,
    "accounts.active": "Active",
    "accounts.inactive": "Not active",
    "accounts.use": "Use this account",
    "accounts.useLabel": (p) => `Use this account: ${p.name}`,
    "accounts.nowActive": (p) => `Active account is now ${p.name}.`,
    "accounts.rename": "Rename",
    "accounts.renameLabel": (p) => `Rename account ${p.name}`,
    "accounts.renameField": (p) => `New display label for ${p.identifier}`,
    "accounts.renameSave": "Save",
    "accounts.renameCancel": "Cancel",
    "accounts.renamed": (p) => `Label saved. JoyFox now shows this account as ${p.name}.`,
    "accounts.remove": "Remove",
    "accounts.confirmRemove": "Confirm removal",
    "accounts.removeLabel": (p) => `Remove account ${p.name}`,
    "accounts.confirmRemoveLabel": (p) => `Confirm removal of account ${p.name} and all of its data`,
    "accounts.removePrompt": (p) => `Removing ${p.name} deletes everything JoyFox stored for this account, for example notes, tags, rules, templates, messages, event notes and saved searches. Click again to confirm.`,
    "accounts.removed": (p) => `Removed ${p.name} and its stored data.`,
    "accounts.removedNoneActive": (p) => `Removed ${p.name} and its stored data. No account is active now. Choose one with "Use this account".`,
    "accounts.removedNoneLeft": (p) => `Removed ${p.name} and its stored data. No accounts are left. Add one to use JoyFox.`,
    "accounts.addForm": "Add an account",
    "accounts.identifier": "JoyClub account identifier",
    "accounts.identifierHint": "Your JoyClub nickname works well. JoyFox uses it only to tell your accounts apart and to match imports. JoyFox does not check it. You cannot change it later.",
    "accounts.label": "Display label (optional)",
    "accounts.labelHint": "Only JoyFox shows this label. If you leave it empty, JoyFox shows the identifier.",
    "accounts.add": "Add account",
    "accounts.added": (p) => `Added ${p.name}.`,
    // Options page: contact rule
    "rule.readFailed": "JoyFox could not read the contact rule. No rule was changed. Reload the page to try again.",
    "rule.hint": "The rule only changes how JoyFox groups your own inbox into Qualified, Needs Review and Junk. It never stops a message, never deletes anything, and the sender sees nothing.",
    "rule.noAccount": "Select or add an account first. Each account has its own rule.",
    "rule.newer": "This rule was made in a newer version of JoyFox and cannot be edited here. Delete it to start a new one.",
    "rule.note.saved": "A rule is saved for the active account.",
    "rule.note.none": "No rule is saved for the active account, so JoyFox does not sort the inbox.",
    "rule.enabled": "Sort my JoyClub inbox with this rule",
    "rule.placementLabel": "A sender who does not meet the rule goes to",
    "rule.spamHint": 'Spam status is unknown for now: JoyFox does not check messages for templates yet. Only your own "not spam" corrections count. The inbox shows only the verification shield; photos, profile words and account age come from profiles you opened before.',
    "rule.autosaveHint": "Changes are saved automatically: a box or choice at once, a number or text when you leave its field.",
    "rule.firstMessageHint": '"First message contains" reads the message preview in your inbox, ignoring upper and lower case. The inbox shows only the latest message, so when a sender sent more than one, the preview may not be the first. If the preview does not contain your text, the condition counts as your "If JoyFox cannot see this" choice. Once JoyFox sees your text, it stays met.',
    "rule.preset.label": "Start from a preset",
    "rule.preset.choose": "Choose a preset\u2026",
    "rule.preset.apply": "Apply preset",
    "rule.preset.confirm": "Replace conditions",
    "rule.preset.confirmPrompt": 'The preset replaces every condition below. Click "Replace conditions" to confirm.',
    "rule.preset.hint": "A preset fills in the conditions below and saves them. You can then change them like any other rule.",
    "rule.preset.open": "Open",
    "rule.preset.complete": "Complete profiles only",
    "rule.preset.verified": "Verified members",
    "rule.preset.highTrust": "High-trust members",
    "rule.preset.custom": "Custom",
    "rule.preset.describe.open": "No conditions: every sender qualifies.",
    "rule.preset.describe.complete": (p, f) => `A sender needs at least ${f.number(p.photos)} photos and at least ${f.number(p.words)} words of profile text.`,
    "rule.preset.describe.verified": "A sender needs to be verified by JoyClub.",
    "rule.preset.describe.highTrust": (p, f) => `A sender needs to be verified by JoyClub, with at least ${f.number(p.photos)} photos, at least ${f.number(p.words)} words of profile text and an account at least ${f.number(p.days)} days old.`,
    "rule.preset.describe.custom": "Clears all conditions, so you can tick the ones you want.",
    "rule.preset.applied": (p) => `Preset "${p.preset}" applied and saved. You can change its conditions below.`,
    "rule.preset.appliedOpen": 'Preset "Open" applied and saved. The rule has no conditions, so every sender qualifies.',
    "rule.preset.appliedCustom": "All conditions cleared and saved. Tick the conditions you want. Until you do, every sender qualifies.",
    "rule.editor": "Editor:",
    "rule.simple": "Simple",
    "rule.advanced": "Advanced",
    "rule.match.all": "ALL",
    "rule.match.any": "ANY",
    "rule.box.all": "A sender qualifies when ALL of these are met",
    "rule.box.any": "Or a sender qualifies when ANY of these is met",
    "rule.unknown.needs-review": "Send to Needs Review",
    "rule.unknown.met": "Count as met",
    "rule.unknown.not-met": "Count as not met",
    "rule.unknownPrompt": "If JoyFox cannot see this:",
    "rule.unknownLabel": (p) => `${p.condition}: if JoyFox cannot see this`,
    "rule.valueLabel": (p) => `${p.condition} value`,
    "rule.numberProblem": (p, f) => `Enter a whole number from ${f.number(p.minimum)} to ${f.number(p.maximum)} for "${p.condition}".`,
    "rule.textPlaceholder": "Word, phrase or emoji",
    "rule.textLabel": (p) => `${p.condition}: word, phrase or emoji`,
    "rule.textProblem": (p, f) => `Enter a word, phrase or emoji of up to ${f.number(p.maximum)} characters for "${p.condition}".`,
    "rule.fieldNumberProblem": (p, f) => `Enter a whole number from ${f.number(p.minimum)} to ${f.number(p.maximum)}.`,
    "rule.fieldTextProblem": (p, f) => `Enter a word, phrase or emoji of up to ${f.number(p.maximum)} characters.`,
    "rule.textHint": "Type a word, phrase or emoji to use this condition.",
    "rule.spamNote": "(not checked yet: always unknown)",
    "rule.combine.label": "How the groups combine",
    "rule.combine.prefix": "A sender is qualified if ",
    "rule.combine.suffix": " of these groups match.",
    "rule.advancedHint": 'Each group is met when ALL or ANY of its conditions are met, as you choose. Tick "not" to turn a condition around: "not Minimum photos 3" means fewer than 3 photos. A group without conditions is not saved.',
    "rule.addRule": "+ Add group",
    "rule.removeRule": "Remove group",
    "rule.confirmRemoveGroup": "Confirm removal",
    "rule.confirmRemoveGroupLabel": (p, f) => `Confirm removal of group ${f.number(p.number)}`,
    "rule.removeGroupPrompt": (p, f) => `Click again to remove group ${f.number(p.number)} and its conditions.`,
    "rule.ruleSuffix": " of these are met",
    "rule.noConditions": "No conditions yet. Add one below.",
    "rule.removeCondition": "Remove condition",
    "rule.removeConditionLabel": (p) => `Remove ${p.condition}`,
    "rule.not": "not",
    "rule.notTitle": "Turn this condition around",
    "rule.notLabel": (p) => `not: turn "${p.condition}" around`,
    "rule.joiner.all": "AND",
    "rule.joiner.any": "OR",
    "rule.ruleTitle": (p, f) => `Group ${f.number(p.number)}: met if `,
    "rule.ruleMatchLabel": (p, f) => `How group ${f.number(p.number)} combines its conditions`,
    "rule.removeRuleLabel": (p, f) => `Remove group ${f.number(p.number)}`,
    "rule.addConditionLabel": (p, f) => `Add a condition to group ${f.number(p.number)}`,
    "rule.addCondition": "+ Add condition\u2026",
    "rule.ruleCount": (p, f) => `${f.number(p.count)} of ${f.number(p.maximum)} groups`,
    "rule.simpleUnavailable.all": "Simple view is not available: the groups combine with ALL.",
    "rule.simpleUnavailable.not": 'Simple view is not available: the rule uses "not".',
    "rule.simpleUnavailable.severalAll": "Simple view is not available: more than one group needs ALL of several conditions.",
    "rule.simpleUnavailable.duplicate": "Simple view is not available: a condition appears in more than one group.",
    "rule.savedNoConditions": "Rule saved. It has no conditions yet, so every sender qualifies.",
    "rule.savedVacuous": "Rule saved. With nothing in the ALL box, every sender qualifies, so the ANY box has no effect.",
    "rule.saved": "Rule saved. Open JoyClub tabs update at once.",
    "rule.notSaved": (p) => `${p.problem} The rule was not saved.`,
    "rule.saveFailed": "JoyFox could not save the rule. Nothing was changed. Change the field again, or reload the page to see the saved rule.",
    "rule.deleteAll": "Delete whole contact rule",
    "rule.confirmDeleteAll": "Confirm delete",
    "rule.deletePrompt": "Click again to delete the whole contact rule. JoyFox then stops sorting the inbox for this account.",
    "rule.removed": "Contact rule deleted. JoyFox no longer sorts the inbox for this account.",
    "rule.removeFailed": "JoyFox could not delete the rule. Nothing was changed. Try again. If it keeps failing, reload the page.",
    "rule.stale.account.saved": "The active account changed, so the rule was not saved. Check the active account on the Accounts tab before you change the rule again.",
    "rule.stale.account.removed": "The active account changed, so the rule was not deleted. Check the active account on the Accounts tab before you delete a rule again.",
    "rule.stale.rule.saved": "The rule was changed in another tab. It was not saved. The form now shows the saved rule.",
    "rule.stale.rule.removed": "The rule was changed in another tab. It was not deleted. The form now shows the saved rule.",
    "rule.changedElsewhere": "The rule was changed in another tab. The form now shows the saved rule.",
    // Options page: templates
    "templates.readFailed": "JoyFox could not read your templates. No template was changed. Reload the page to try again.",
    "templates.heading": "Message templates",
    "templates.hint": `On a JoyClub conversation, the "JoyFox templates" button below the message field inserts a template at the cursor. You can still edit the text, and you always click JoyClub's Send button yourself. JoyFox never sends a message.`,
    // `[Accounts](#accounts)` is drawn as a link to the Accounts tab.
    "templates.noAccount": "Choose an active account on the [Accounts](#accounts) tab to store templates.",
    "templates.empty": "No templates yet. Add one below.",
    "templates.inFolder": (p) => `Templates in ${p.folder}`,
    "templates.edit": "Edit",
    "templates.editLabel": (p) => `Edit template ${p.name}`,
    "templates.editing": (p) => `Editing ${p.name}.`,
    "templates.delete": "Delete",
    "templates.confirmDelete": "Confirm delete",
    "templates.deleteLabel": (p) => `Delete template ${p.name}`,
    "templates.confirmDeleteLabel": (p) => `Confirm delete: template ${p.name}`,
    "templates.deletePrompt": (p) => `Click "Confirm delete" to delete ${p.name}.`,
    "templates.deleted": (p) => `Deleted ${p.name}.`,
    "templates.addForm": "Add a template",
    "templates.name": "Name",
    "templates.folder": "Folder (optional, General if empty)",
    "templates.text": "Text",
    "templates.saveChanges": "Save changes",
    "templates.add": "Add template",
    "templates.cancel": "Cancel editing",
    "templates.saved": (p) => `Saved ${p.name}.`,
    "templates.added": (p) => `Added ${p.name}.`,
    "templates.accountChanged": "The active account changed, so nothing was changed. Check the active account on the Accounts tab before you try again.",
    // Options page: your data
    "entity.extensionAccounts": "Account record",
    "entity.joyClubMembers": "Members",
    "entity.profileSnapshots": "Profile snapshots",
    "entity.userNotes": "Notes",
    "entity.userTags": "Tags",
    "entity.trustSignals": "Trust outcomes",
    "entity.contactRules": "Contact rules",
    "entity.conversationClassifications": "Manual placements",
    "entity.savedSearches": "Saved searches",
    "entity.eventMetadata": "Event notes",
    "entity.spendLogEntries": "Spending log",
    "entity.syncConfigs": "Sync settings",
    "entity.extensionPreferences": "Preferences",
    "entity.messageTemplates": "Message templates",
    "entity.spamPhrases": "Spam phrases",
    "entity.messageObservations": "Cached message text (normalized)",
    "entity.senderSpamOverrides": "Not-spam corrections",
    "entity.actionLogs": "Action log",
    "entity.messagePhraseMatches": "Message phrase matches",
    "entity.cachedMessages": "Stored messages (for search)",
    "data.readFailed": "JoyFox could not read its stored data. Nothing was changed. Reload the page to try again.",
    "data.hint": "Everything JoyFox stores stays in this browser profile. You can inspect it, save it as a JSON file and delete it here. Deleting here never changes anything on JoyClub.",
    // Import is on the Accounts tab (owner decision); this line points there.
    "data.importPointer": "To import a file, go to [Accounts](#accounts).",
    "data.noAccounts": "No accounts yet.",
    "data.accountPicker": "Account to inspect (does not change the active account)",
    "data.caption": "Stored records for this account",
    "data.col.type": "Data type",
    "data.col.records": "Records",
    "data.col.actions": "Actions",
    "data.show": "Show",
    "data.hide": "Hide",
    "data.showLabel": (p) => `Show ${p.label}`,
    "data.hideLabel": (p) => `Hide ${p.label}`,
    "data.deleteAll": "Delete all",
    "data.deleteAllLabel": (p) => `Delete all ${p.label}`,
    "data.deleteAllPrompt": (p, f) => `Click "Confirm" to delete all ${f.number(p.count)} ${p.label} records of this account.`,
    "data.deletedAll": (p) => `Deleted all ${p.label} of this account.`,
    "data.recordsTitle": (p, f) => `${p.label} (${f.number(p.count)})`,
    "data.accountRecordHint": "The account record is removed only with the whole account, on the [Accounts](#accounts) tab.",
    "data.recordSummary": (p) => `${p.id} (updated ${p.updated})`,
    // A record with a name a person knows: a member's nickname, a template's
    // or saved search's name, an event's title or an account's label.
    "data.recordSummaryNamed": (p) => `${p.name}: ${p.id} (updated ${p.updated})`,
    // A record with a name a person reads, in delete labels and messages.
    "data.recordNamed": (p) => `${p.name} (${p.id})`,
    "data.valueYes": "yes",
    "data.valueNo": "no",
    "data.valueEmpty": "(empty)",
    "data.rawJson": "Stored JSON",
    "data.moreCharacters": (p, f) => `\u2026and ${f.number(p.count)} more characters (see "Stored JSON")`,
    "data.moreValues": (p, f) => `\u2026and ${f.number(p.count)} more (see "Stored JSON")`,
    "data.delete": "Delete",
    "data.deleteRecordLabel": (p) => `Delete record ${p.record}`,
    "data.deleteRecordPrompt": (p) => `Click "Confirm" to delete record ${p.record}.`,
    "data.deletedRecord": (p) => `Deleted record ${p.record}.`,
    "data.showMore": (p, f) => `Show ${f.number(p.count)} more`,
    "data.exportAccount": "Export this account (JSON)",
    "data.exportedAccount": "Export of this account created.",
    "data.deleteAccountData": "Delete this account's data",
    "data.deleteAccountDataLabel": "Delete this account's data (every record)",
    "data.deleteAccountDataPrompt": 'Click "Confirm" to delete every record of this account. The account itself stays in Accounts.',
    "data.deletedAccountData": "Deleted all data of this account. The account itself is kept.",
    "data.allAccounts": "All accounts",
    "data.retentionLabel": "Profile snapshots kept per member",
    "data.retentionHint": (p, f) => `JoyFox keeps the newest snapshots of each member's profile facts, always at least the latest one. Lowering the number deletes older snapshots at once, in every account. From ${f.number(p.minimum)} to ${f.number(p.maximum)}; the default is ${f.number(p.default)}. Click "Save" to apply.`,
    "data.retentionSave": "Save",
    "data.retentionConfirm": "Save and delete",
    "data.retentionConfirmPrompt": (p, f) => `Lowering the number deletes older snapshots at once, in every account: each member keeps only ${f.plural(
      p.keep,
      {
        one: "the newest snapshot",
        other: `the newest ${f.number(p.keep)} snapshots`
      }
    )}. Click "Save and delete" to confirm.`,
    "data.retentionSaved": (p, f) => p.deleted === 0 ? "Saved. No snapshot needed deleting." : `Saved. ${f.plural(p.deleted, {
      one: "1 older snapshot was",
      other: `${f.number(p.deleted)} older snapshots were`
    })} deleted.`,
    "data.retentionInvalid": (p, f) => `Enter a whole number from ${f.number(p.minimum)} to ${f.number(p.maximum)}. Nothing was changed.`,
    "data.retentionFailed": "JoyFox could not save the setting. The field shows the number in use now. Try again.",
    "data.reminderLabel": "Remind me to export all data after (days)",
    "data.reminderHint": (p, f) => `JoyFox data stays in this browser profile, also when you close the browser. If you remove JoyFox or lose the profile, the data is gone, so a full export is your backup. This page asks for one when the last full export is older than this number of days. 0 turns the reminder off. From ${f.number(p.minimum)} to ${f.number(p.maximum)}; the default is ${f.number(p.default)}. Click "Save" to apply.`,
    "data.reminderSave": "Save",
    "data.reminderSaved": (p, f) => p.days === 0 ? "Saved. The export reminder is off." : `Saved. JoyFox reminds you ${f.plural(p.days, {
      one: "1 day",
      other: `${f.number(p.days)} days`
    })} after the last full export.`,
    "data.reminderInvalid": (p, f) => `Enter a whole number from ${f.number(p.minimum)} to ${f.number(p.maximum)}. Nothing was changed.`,
    "data.reminderNever": 'You have not exported all JoyFox data yet. If you remove JoyFox or lose this browser profile, the data is gone. Click "Export all JoyFox data (JSON)" to save a backup.',
    "data.reminderDue": (p, f) => `Your last full export was ${f.plural(p.days, {
      one: "1 day ago",
      other: `${f.number(p.days)} days ago`
    })}. If you remove JoyFox or lose this browser profile, newer data is gone. Click "Export all JoyFox data (JSON)" to save a backup.`,
    "data.lastExport": (p, f) => p.days === 0 ? "Last full export: today." : `Last full export: ${f.plural(p.days, {
      one: "1 day ago",
      other: `${f.number(p.days)} days ago`
    })}.`,
    "data.exportAll": "Export all JoyFox data (JSON)",
    "data.exportedAll": "Export of all JoyFox data created.",
    "data.deleteEverything": "Delete all JoyFox data",
    "data.deleteEverythingLabel": "Delete all JoyFox data in this browser",
    "data.deleteEverythingPrompt": 'Click "Confirm" to delete every account, every record and every JoyFox setting in this browser. This cannot be undone.',
    "data.deletedEverything": "Deleted all JoyFox data in this browser.",
    "data.confirm": "Confirm",
    "data.confirmLabel": (p) => `Confirm: ${p.label}`,
    "data.actionFailed": "JoyFox could not finish the delete. Some records may be deleted already: the counts shown now are what is still stored. Try again.",
    "data.exportFailed": "JoyFox could not create the export. Nothing was exported. Try again.",
    "data.import.title": "Import",
    "data.import.hint": "Import a JoyFox export file: everything, or one account. It is merged into what is stored here. An account with the same JoyClub identifier is merged into the existing one. For the same note, rule or placement the newer version wins; existing tags and corrections are kept. The import starts when you choose the file, and you then see what changed.",
    "data.import.fileLabel": "JoyFox export file (JSON)",
    "data.import.summary.all": (p, f) => `This full export holds ${f.number(p.total)} account(s): ${f.number(p.matched)} merged into an existing account, ${f.number(p.added)} added as new.`,
    "data.import.summary.account": (p, f) => `This single-account export holds ${f.number(p.total)} account(s): ${f.number(p.matched)} merged into an existing account, ${f.number(p.added)} added as new.`,
    "data.import.caption": "What the import changed",
    "data.import.col.added": "Added",
    "data.import.col.replaced": "Replaced (newer)",
    "data.import.col.kept": "Kept",
    "data.import.col.duplicates": "Skipped duplicates",
    "data.import.noRecords": "The file holds no records.",
    // Setting names in the import result. A setting JoyFox does not name is
    // shown by its stored key.
    "data.setting.activeAccount": "active account",
    "data.setting.language": "language",
    "data.setting.messageCaching": "store messages",
    "data.setting.messageRetention": "keep messages for",
    "data.setting.quickIgnoreDelete": "Ignore and Delete button",
    "data.setting.stripCollapsed": "JoyFox bar collapsed",
    "data.setting.templatePicker": "template picker",
    "data.setting.sharedEventException": "shared-event exception",
    "data.setting.snapshotRetention": "snapshots kept per member",
    "data.setting.exportReminder": "export reminder",
    "data.setting.diagnostics": "diagnostics",
    "data.import.settingsUnknown": "The file also holds settings that this version of JoyFox does not know. They were not imported.",
    "data.import.settingsSkipped": (p) => `Settings in the file that are never imported (they switch features on): ${p.keys}.`,
    "data.import.settingsNotSaved": (p) => `Settings that could not be saved: ${p.keys}.`,
    "data.import.settingsAdded": (p) => `Settings added (only those not set here): ${p.keys}.`,
    "data.import.running": "Importing the file.",
    "data.import.nothing": "Everything in this file is already stored. Nothing was changed.",
    "data.import.complete": (p, f) => `Import complete: ${f.number(p.added)} record(s) added, ${f.number(p.replaced)} replaced by a newer version.`,
    "data.import.completeSettingsFailed": (p, f) => `Import complete: ${f.number(p.added)} record(s) added, ${f.number(p.replaced)} replaced by a newer version. Some settings could not be saved (listed above). Set them again yourself.`,
    "data.import.incomplete": "JoyFox could not finish the import. Choose the file again to try again: records already stored are not added twice.",
    "data.import.unreadable": "JoyFox could not check that file. Nothing was imported. Choose the file again. If it still fails, reload the page, or export the file from JoyFox again.",
    // Errors the UI shows (ExtensionError.display). No final full stop: the
    // panels add a suffix such as "Nothing was changed." An error without a
    // display message gets the panel's own failure text instead, which says
    // what to do next.
    "error.withSuffix.nothingChanged": (p) => `${p.error}. Nothing was changed.`,
    "error.withSuffix.nothingImported": (p) => `${p.error}. Nothing was imported.`,
    "error.withSuffix.nothingDeleted": (p) => `${p.error}. Nothing was deleted.`,
    "error.withSuffix.nothingExported": (p) => `${p.error}. Nothing was exported. Try again.`,
    "error.withSuffix.settingNotChanged": (p) => `${p.error}. The setting was not changed. Try again.`,
    "error.account.emptyIdentifier": "Enter your JoyClub account identifier first",
    "error.account.duplicate": "An account with this identifier is already in the list. Use that account, or enter another identifier",
    "error.account.notRegistered": "That account is no longer in the list, for example because it was removed in another tab",
    "error.account.gone": "That account no longer exists",
    "error.account.changed": "The active account changed",
    "error.template.noName": "A template needs a name",
    "error.template.nameTooLong": (p, f) => `A template name can have at most ${f.number(p.maximum)} characters`,
    "error.template.folderTooLong": (p, f) => `A folder name can have at most ${f.number(p.maximum)} characters`,
    "error.template.noText": "A template needs some text",
    "error.template.tooLong": (p, f) => `A template can have at most ${f.number(p.maximum)} characters`,
    "error.template.deleted": "That template was deleted meanwhile",
    "error.data.changedDuringCheck": "Stored data changed while the file was checked. Choose the file again",
    "error.data.unknownType": "Unknown data type",
    "error.data.accountRecord": "The account record is removed only with the whole account",
    // The next step ends each refusal that a correct export file fixes.
    "error.import.tooLarge": "The file is too large to be a JoyFox export. Choose a file exported by JoyFox",
    "error.import.notJson": "The file is not a JoyFox export. Choose a file exported by JoyFox",
    "error.import.notExport": "The file is not a JoyFox export. Choose a file exported by JoyFox",
    "error.import.noVersion": "The file does not say which JoyFox version made it. Choose a file exported by JoyFox",
    "error.import.newerVersion": "The file comes from a newer JoyFox version. Update JoyFox first",
    "error.import.noScope": "The file does not say if it holds one account or all data. Choose a file exported by JoyFox",
    "error.import.noAccountNamed": "The file is an export of one account, but it does not name the account. Choose a file exported by JoyFox",
    "error.import.unknownType": "The file holds a type of data that JoyFox does not know. Choose a file exported by JoyFox",
    "error.import.notList": (p) => `The ${p.entity} part of the file is damaged. Choose a file exported by JoyFox`,
    "error.import.notRecord": (p, f) => `Record ${f.number(p.index)} in ${p.entity} is damaged. Choose a file exported by JoyFox`,
    "error.import.forbiddenKey": (p, f) => `Record ${f.number(p.index)} in ${p.entity} holds a field name that JoyFox does not allow. Choose a file exported by JoyFox`,
    "error.import.unknownField": (p, f) => `Record ${f.number(p.index)} in ${p.entity} holds a field that JoyFox does not know. Choose a file exported by JoyFox`,
    "error.import.tooLong": (p, f) => `Record ${f.number(p.index)} in ${p.entity} holds a text longer than ${f.number(p.maximum)} characters. Choose a file exported by JoyFox`,
    "error.import.invalid": (p, f) => `Record ${f.number(p.index)} in ${p.entity} is damaged. Choose a file exported by JoyFox`,
    "error.import.future": (p, f) => `Record ${f.number(p.index)} in ${p.entity} has a date in the future. Check the clock of the computer that made the file`,
    "error.import.otherAccount": (p, f) => `Record ${f.number(p.index)} in ${p.entity} belongs to another account. Choose a file exported by JoyFox`,
    "error.import.notOwnScope": (p, f) => `Account record ${f.number(p.index)} is damaged. Choose a file exported by JoyFox`,
    "error.import.twice": (p, f) => `Record ${f.number(p.index)} in ${p.entity} is in the file twice. Choose a file exported by JoyFox`,
    "error.import.sameIdentifier": "Two accounts in the file have the same identifier. Choose a file exported by JoyFox",
    "error.import.noAccountRecord": "The file is an export of one account, but it does not hold that account. Choose a file exported by JoyFox",
    "error.import.settingsInvalid": "The settings in the file are damaged. Choose a file exported by JoyFox",
    "error.import.settingsForbidden": "The settings in the file hold a name that JoyFox does not allow. Choose a file exported by JoyFox",
    "error.import.unknownSetting": "The file holds a setting that JoyFox does not use. Choose a file exported by JoyFox",
    "error.import.orphans": "Some records in the file belong to an account that the file does not hold. Choose a file exported by JoyFox",
    "error.import.sameRecordTwice": "Two records in the file would become the same record here. Choose a file exported by JoyFox"
  };

  // src/i18n/message.ts
  var MESSAGE_PARAMS = {
    "legacy.text": { text: "string" },
    "triage.reason.unknownValue": { field: "message" },
    "triage.reason.atOrAbove": {
      field: "message",
      value: "number",
      minimum: "number"
    },
    "triage.reason.belowMinimum": {
      field: "message",
      value: "number",
      minimum: "number"
    },
    "triage.reason.accountAgeRangeAbove": {
      min: "number",
      max: "number",
      minimum: "number"
    },
    "triage.reason.accountAgeRangeBelow": {
      min: "number",
      max: "number",
      minimum: "number"
    },
    "triage.reason.accountAgeRangeCoarse": {
      min: "number",
      max: "number",
      minimum: "number"
    },
    "triage.reason.phraseSeenNow": { text: "string" },
    "triage.reason.phraseSeenBefore": { text: "string" },
    "triage.reason.phraseNotInLatest": { text: "string" },
    "triage.reason.phraseNotSeen": { text: "string" },
    "triage.reason.trustAtOrAbove": { score: "number", minimum: "number" },
    "triage.reason.trustBelow": { score: "number", minimum: "number" },
    "triage.reason.negatedMet": { reason: "message", condition: "message" },
    "triage.reason.negatedNotMet": { reason: "message", condition: "message" },
    "triage.reason.unknownNeedsReview": { reason: "message" },
    "triage.reason.unknownMet": { reason: "message" },
    "triage.reason.unknownNotMet": { reason: "message" },
    "triage.reason.numbered": { number: "number", reason: "message" },
    "triage.reason.userMoved": { placement: "message" },
    "triage.headline.doesNotMeet": { placement: "message" },
    "trust.reason.positive": { count: "number" },
    "trust.reason.negative": { count: "number" },
    "trust.reason.neutral": { count: "number" },
    "spam.detail.belowMinimum": { words: "number", minimum: "number" },
    "spam.detail.duplicate": { percent: "number" },
    "spam.detail.phraseSimilar": { percent: "number" },
    "action.where.before": { step: "message" },
    "action.where.during": { step: "message" },
    "action.failure.control-missing": { step: "message" },
    "action.failure.confirmation-missing": { step: "message" },
    "action.failure.not-verified": { step: "message" },
    "action.failure.unverifiable": { step: "message", where: "message" },
    "action.failure.member-mismatch": { where: "message" },
    "action.failure.conversation-mismatch": { where: "message" },
    "action.failure.identity-unavailable": { where: "message" },
    "action.failure.account-changed": { where: "message" },
    "action.failure.turned-off": { where: "message" },
    "action.failure.superseded": { where: "message" },
    "action.failure.log-unavailable": { where: "message" },
    "action.failure.handoff-failed": { where: "message" },
    "action.failure.timeout": { step: "message" },
    "action.failure.step-error": { where: "message" },
    "triage.conditions.summary": { count: "number" },
    "triage.condition.line": { outcome: "message", condition: "message" },
    "triage.condition.lineNegated": { outcome: "message", condition: "message" },
    "triage.placementLine": { placement: "message", source: "message" },
    "triage.movedOn": { date: "string", placement: "message" },
    "mark.trustFailed": { placement: "message" },
    "triage.unknownFacts.one": { fact: "message" },
    "triage.unknownFacts.two": { first: "message", second: "message" },
    "triage.unknownFacts.three": {
      first: "message",
      second: "message",
      third: "message"
    },
    "trust.score.value": { score: "number" },
    "trust.contribution": { points: "number", reason: "message" },
    "inbox.viewCount": { view: "message", count: "number" },
    "inbox.badge": { text: "message" },
    "inbox.whyNamed": { name: "string" },
    "notes.removeTag": { label: "string" },
    "notes.summary.tags": { count: "number" },
    "notes.summary.noteAndTags": { count: "number" },
    "notes.length": { count: "number", maximum: "number" },
    "accounts.nameWithIdentifier": { label: "string", identifier: "string" },
    "accounts.useLabel": { name: "string" },
    "accounts.nowActive": { name: "string" },
    "accounts.renameLabel": { name: "string" },
    "accounts.renameField": { identifier: "string" },
    "accounts.renamed": { name: "string" },
    "accounts.removeLabel": { name: "string" },
    "accounts.confirmRemoveLabel": { name: "string" },
    "accounts.removePrompt": { name: "string" },
    "accounts.removed": { name: "string" },
    "accounts.removedNoneActive": { name: "string" },
    "accounts.removedNoneLeft": { name: "string" },
    "accounts.added": { name: "string" },
    "rule.unknownLabel": { condition: "message" },
    "rule.valueLabel": { condition: "message" },
    "rule.textLabel": { condition: "message" },
    "rule.textProblem": { maximum: "number", condition: "message" },
    "rule.numberProblem": {
      minimum: "number",
      maximum: "number",
      condition: "message"
    },
    "rule.fieldNumberProblem": { minimum: "number", maximum: "number" },
    "rule.fieldTextProblem": { maximum: "number" },
    "rule.removeConditionLabel": { condition: "message" },
    "rule.notLabel": { condition: "message" },
    "rule.ruleTitle": { number: "number" },
    "rule.ruleMatchLabel": { number: "number" },
    "rule.removeRuleLabel": { number: "number" },
    "rule.confirmRemoveGroupLabel": { number: "number" },
    "rule.removeGroupPrompt": { number: "number" },
    "rule.addConditionLabel": { number: "number" },
    "rule.ruleCount": { count: "number", maximum: "number" },
    "rule.notSaved": { problem: "message" },
    "listing.removeTag": { tag: "string" },
    "listing.summary.event": { state: "string" },
    "listing.summary.venue": { state: "string" },
    "eventFilter.tag": { tag: "string" },
    "events.count": { shown: "number", total: "number" },
    "events.untitled": { id: "string" },
    "events.past": { when: "string" },
    "events.venue": { venue: "string" },
    "eventFilter.count": { shown: "number", loaded: "number" },
    "typeFilter.count": { shown: "number", loaded: "number" },
    "typeFilter.unknownHidden": { count: "number" },
    "compat.shared": { count: "number" },
    "triage.sharedEvent.attending": { event: "string", when: "string" },
    "triage.sharedEvent.attended": { event: "string", when: "string" },
    "events.guests": { count: "number" },
    "signals.photos": { count: "number" },
    "signals.words": { count: "number" },
    "signals.tagCount": { count: "number" },
    "signals.trust": { score: "number" },
    "signals.editor.label": { member: "string" },
    "member.number": { id: "string" },
    "signals.filter.count": { hidden: "number", loaded: "number" },
    "messages.retentionHint": { default: "number" },
    "messages.retentionConfirmPrompt": { months: "number" },
    "data.retentionConfirmPrompt": { keep: "number" },
    "messages.retentionSaved": { deleted: "number" },
    "messages.retentionInvalid": { minimum: "number", maximum: "number" },
    "messages.count": { count: "number" },
    "messages.countLimited": { count: "number", shown: "number" },
    "messages.sentTo": { member: "string", when: "string" },
    "messages.receivedFrom": { member: "string", when: "string" },
    "messages.storedAt": { when: "string" },
    "compat.own": { count: "number" },
    "compat.badge": { count: "number" },
    "compat.badgeLabel": { count: "number" },
    "listing.tooManyTags.event": { maximum: "number" },
    "listing.tooManyTags.venue": { maximum: "number" },
    "searches.nameTooLong": { maximum: "number" },
    "searches.full": { maximum: "number" },
    "searches.saved": { name: "string" },
    "searches.noMatch": { name: "string" },
    "searches.deleteLabel": { name: "string" },
    "searches.confirmDelete": { name: "string" },
    "searches.deleted": { name: "string" },
    "searches.running": { name: "string" },
    "searches.shown": { name: "string" },
    "picker.result.too-long": { over: "number", limit: "number" },
    "rule.preset.describe.complete": { photos: "number", words: "number" },
    "rule.preset.describe.highTrust": {
      photos: "number",
      words: "number",
      days: "number"
    },
    "rule.preset.applied": { preset: "message" },
    "templates.inFolder": { folder: "string" },
    "templates.editLabel": { name: "string" },
    "templates.editing": { name: "string" },
    "templates.deleteLabel": { name: "string" },
    "templates.confirmDeleteLabel": { name: "string" },
    "templates.deletePrompt": { name: "string" },
    "templates.deleted": { name: "string" },
    "templates.saved": { name: "string" },
    "templates.added": { name: "string" },
    "data.showLabel": { label: "message" },
    "data.hideLabel": { label: "message" },
    "data.deleteAllLabel": { label: "message" },
    "data.deleteAllPrompt": { count: "number", label: "message" },
    "data.deletedAll": { label: "message" },
    "data.recordsTitle": { label: "message", count: "number" },
    "data.recordSummary": { id: "string", updated: "string" },
    "data.recordSummaryNamed": {
      name: "string",
      id: "string",
      updated: "string"
    },
    "data.recordNamed": { name: "string", id: "string" },
    "data.deleteRecordLabel": { record: "string" },
    "data.deleteRecordPrompt": { record: "string" },
    "data.deletedRecord": { record: "string" },
    "data.showMore": { count: "number" },
    "data.retentionHint": {
      minimum: "number",
      maximum: "number",
      default: "number"
    },
    "data.retentionSaved": { deleted: "number" },
    "data.retentionInvalid": { minimum: "number", maximum: "number" },
    "data.reminderHint": {
      minimum: "number",
      maximum: "number",
      default: "number"
    },
    "data.reminderSaved": { days: "number" },
    "data.reminderInvalid": { minimum: "number", maximum: "number" },
    "data.reminderDue": { days: "number" },
    "data.lastExport": { days: "number" },
    "data.moreValues": { count: "number" },
    "data.moreCharacters": { count: "number" },
    "data.confirmLabel": { label: "message" },
    "data.import.summary.all": {
      matched: "number",
      added: "number",
      total: "number"
    },
    "data.import.summary.account": {
      matched: "number",
      added: "number",
      total: "number"
    },
    "data.import.settingsSkipped": { keys: "string" },
    "data.import.settingsNotSaved": { keys: "string" },
    "data.import.settingsAdded": { keys: "string" },
    "data.import.complete": { added: "number", replaced: "number" },
    "data.import.completeSettingsFailed": { added: "number", replaced: "number" },
    "error.withSuffix.nothingChanged": { error: "message" },
    "error.withSuffix.nothingImported": { error: "message" },
    "error.withSuffix.nothingDeleted": { error: "message" },
    "error.withSuffix.nothingExported": { error: "message" },
    "error.withSuffix.settingNotChanged": { error: "message" },
    "error.template.nameTooLong": { maximum: "number" },
    "error.template.folderTooLong": { maximum: "number" },
    "error.template.tooLong": { maximum: "number" },
    "error.import.notList": { entity: "message" },
    "error.import.notRecord": { index: "number", entity: "message" },
    "error.import.forbiddenKey": { index: "number", entity: "message" },
    "error.import.unknownField": { index: "number", entity: "message" },
    "error.import.tooLong": {
      index: "number",
      entity: "message",
      maximum: "number"
    },
    "error.import.invalid": { index: "number", entity: "message" },
    "error.import.future": { index: "number", entity: "message" },
    "error.import.otherAccount": { index: "number", entity: "message" },
    "error.import.notOwnScope": { index: "number" },
    "error.import.twice": { index: "number", entity: "message" }
  };
  function isMessageKey(value) {
    return typeof value === "string" && Object.hasOwn(en, value);
  }
  function paramsOf(key2) {
    return Object.hasOwn(MESSAGE_PARAMS, key2) ? MESSAGE_PARAMS[key2] : null;
  }
  var isRecord = (value) => typeof value === "object" && value !== null && !Array.isArray(value);
  var MAX_DEPTH = 8;
  function isMessage(value, depth = 0) {
    if (depth > MAX_DEPTH || !isRecord(value)) return false;
    if (!isMessageKey(value.key)) return false;
    const spec = paramsOf(value.key);
    if (spec === null) return Object.keys(value).every((name) => name === "key");
    if (!Object.keys(value).every((name) => name === "key" || name === "params"))
      return false;
    const params = value.params;
    if (!isRecord(params)) return false;
    const names = Object.keys(spec);
    if (Object.keys(params).length !== names.length) return false;
    return names.every((name) => {
      if (!Object.hasOwn(params, name)) return false;
      const param = params[name];
      switch (spec[name]) {
        case "string":
          return typeof param === "string";
        case "number":
          return typeof param === "number" && Number.isFinite(param);
        case "message":
          return isMessage(param, depth + 1);
        default:
          return false;
      }
    });
  }
  function message(key2, ...params) {
    return params.length > 0 ? { key: key2, params: params[0] } : { key: key2 };
  }

  // src/storage/local-settings.ts
  function runtimeArea() {
    const area = globalThis.browser?.storage?.local;
    if (!area)
      throw new ExtensionError(
        "StorageError",
        "browser.storage.local is unavailable in this context"
      );
    return area;
  }
  var runtimeSettingsArea = {
    async get(keys) {
      return await runtimeArea().get(keys);
    },
    async set(items) {
      await runtimeArea().set(items);
    },
    async remove(keys) {
      await runtimeArea().remove(keys);
    },
    async getAll() {
      return await runtimeArea().get(null);
    },
    async clear() {
      await runtimeArea().clear();
    }
  };

  // src/storage/account-lock.ts
  var fallback = /* @__PURE__ */ new Map();
  var fallbackExclusive = Promise.resolve();
  var fallbackShared = /* @__PURE__ */ new Set();
  var DATA_LOCK_NAME = "joyfox:data";
  function accountLockName(accountId) {
    return `joyfox:account:${encodeURIComponent(accountId)}`;
  }
  function webLocks() {
    const locks = globalThis.navigator?.locks;
    return locks?.request?.bind(locks);
  }
  function withSharedDataLock(action) {
    const request = webLocks();
    if (request)
      return request(
        DATA_LOCK_NAME,
        { mode: "shared" },
        () => action()
      );
    const run = fallbackExclusive.then(() => action());
    const settled = run.catch(() => void 0);
    fallbackShared.add(settled);
    void settled.then(() => fallbackShared.delete(settled));
    return run;
  }
  function withExclusiveDataLock(action) {
    const request = webLocks();
    if (request) return request(DATA_LOCK_NAME, () => action());
    const prior = Promise.all([fallbackExclusive, ...fallbackShared]);
    const run = prior.then(() => action());
    fallbackExclusive = run.catch(() => void 0);
    return run;
  }
  function accountOnly(accountId, action) {
    const request = webLocks();
    const name = accountLockName(accountId);
    if (request) return request(name, () => action());
    const previous = fallback.get(name) ?? Promise.resolve();
    const run = previous.then(action, action);
    const settled = run.catch(() => void 0);
    fallback.set(name, settled);
    void settled.then(() => {
      if (fallback.get(name) === settled) fallback.delete(name);
    });
    return run;
  }
  function withAccountLock(accountId, action) {
    return withSharedDataLock(() => accountOnly(accountId, action));
  }
  function withAccountLocks(accountIds, action) {
    const ordered = [...new Set(accountIds)].sort();
    const acquire = (index) => index === ordered.length ? action() : accountOnly(ordered[index], () => acquire(index + 1));
    return withSharedDataLock(() => acquire(0));
  }

  // src/domain/snapshot-order.ts
  var newestCaptureFirst = (a, b) => Date.parse(b.capturedAt) - Date.parse(a.capturedAt) || b.id.localeCompare(a.id);

  // src/storage/reason-migration.ts
  var USER_MOVED = {
    qualified: "You moved this sender to Qualified.",
    "needs-review": "You moved this sender to Needs Review.",
    quarantined: "You moved this sender to Quarantined."
  };
  function migrateReasons(reasons, placement) {
    if (!Array.isArray(reasons)) return reasons;
    const own = typeof placement === "string" && Object.hasOwn(USER_MOVED, placement) ? placement : void 0;
    return reasons.map((reason) => {
      if (typeof reason !== "string") return reason;
      if (own && reason === USER_MOVED[own])
        return message("triage.reason.userMoved", {
          placement: { key: `placement.${own}` }
        });
      return { key: "legacy.text", params: { text: reason } };
    });
  }

  // src/storage/database.ts
  var DATABASE_NAME = "joyfox";
  var DATABASE_VERSION = 5;
  var VERSION_1_ENTITY_NAMES = [
    "extensionAccounts",
    "joyClubMembers",
    "profileSnapshots",
    "userNotes",
    "userTags",
    "trustSignals",
    "contactRules",
    "conversationClassifications",
    "savedSearches",
    "eventMetadata",
    "spendLogEntries",
    "syncConfigs",
    "extensionPreferences",
    "messageTemplates",
    "spamPhrases",
    "actionLogs"
  ];
  var VERSION_2_ENTITY_NAMES = [
    "messageObservations",
    "senderSpamOverrides"
  ];
  var VERSION_3_ENTITY_NAMES = ["messagePhraseMatches"];
  var VERSION_5_ENTITY_NAMES = ["cachedMessages"];
  var ENTITY_NAMES = [
    ...VERSION_1_ENTITY_NAMES,
    ...VERSION_2_ENTITY_NAMES,
    ...VERSION_3_ENTITY_NAMES,
    ...VERSION_5_ENTITY_NAMES
  ];
  var connection;
  function migrateToVersion4(db, transaction) {
    const name = "conversationClassifications";
    if (!transaction || !db.objectStoreNames.contains(name)) return;
    const cursor = transaction.objectStore(name).openCursor();
    cursor.onsuccess = () => {
      const current = cursor.result;
      if (!current) return;
      const record = current.value;
      current.update({
        ...record,
        reasons: migrateReasons(record.reasons, record.placement)
      });
      current.continue();
    };
  }
  function openDatabase() {
    if (connection) return connection;
    const opening = new Promise((resolve, reject) => {
      const request = indexedDB.open(DATABASE_NAME, DATABASE_VERSION);
      request.onupgradeneeded = (event) => {
        const db = request.result;
        const createStores = (names) => {
          for (const name of names) {
            const store = db.createObjectStore(name, { keyPath: "storageKey" });
            store.createIndex("accountId", "accountId", { unique: false });
            store.createIndex("updatedAt", "updatedAt", { unique: false });
          }
        };
        if (event.oldVersion < 1) createStores(VERSION_1_ENTITY_NAMES);
        if (event.oldVersion < 2) createStores(VERSION_2_ENTITY_NAMES);
        if (event.oldVersion < 3) createStores(VERSION_3_ENTITY_NAMES);
        if (event.oldVersion < 4) migrateToVersion4(db, request.transaction);
        if (event.oldVersion < 5) createStores(VERSION_5_ENTITY_NAMES);
      };
      request.onsuccess = () => {
        const db = request.result;
        db.onversionchange = () => {
          db.close();
          if (connection === opening) connection = void 0;
        };
        resolve(db);
      };
      request.onerror = () => reject(request.error);
      request.onblocked = () => console.warn(
        "JoyFox: database upgrade is blocked by another open connection"
      );
    }).catch((error) => {
      if (connection === opening) connection = void 0;
      throw error;
    });
    connection = opening;
    return opening;
  }
  function requestResult(request) {
    return new Promise((resolve, reject) => {
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }
  function transactionDone(transaction) {
    return new Promise((resolve, reject) => {
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error);
      transaction.onabort = () => reject(transaction.error);
    });
  }
  async function commitAll(transaction, work) {
    const done = transactionDone(transaction);
    done.catch(() => void 0);
    try {
      await work();
    } catch (error) {
      try {
        transaction.abort();
      } catch {
      }
      throw error;
    }
    await done;
  }

  // src/domain/iso-date.ts
  var ISO_DATE = /^(\d{4})-(\d{2})-(\d{2})(?:T(\d{2}):(\d{2})(?::(\d{2})(?:\.\d{1,9})?)?(?:Z|[+-](\d{2}):(\d{2})))?$/;
  function isStrictIsoDate(value) {
    const match = ISO_DATE.exec(value);
    if (!match) return false;
    const [, y, m, d, hh, mm, ss, oh, om] = match;
    const year = Number(y);
    const month = Number(m);
    const day = Number(d);
    const calendar = new Date(Date.UTC(year, month - 1, day));
    if (calendar.getUTCFullYear() !== year || calendar.getUTCMonth() !== month - 1 || calendar.getUTCDate() !== day)
      return false;
    if (hh !== void 0 && (Number(hh) > 23 || Number(mm) > 59)) return false;
    if (ss !== void 0 && Number(ss) > 59) return false;
    if (oh !== void 0 && (Number(oh) > 23 || Number(om) > 59)) return false;
    return Number.isFinite(Date.parse(value));
  }

  // src/events/event-date.ts
  function validDay(year, month, day) {
    const date = new Date(Date.UTC(year, month - 1, day));
    return date.getUTCFullYear() === year && date.getUTCMonth() === month - 1 && date.getUTCDate() === day;
  }
  function isWallTime(value) {
    const match = /^(\d{4})-(\d{2})-(\d{2})(?:T(\d{2}):(\d{2}))?$/u.exec(value);
    if (!match) return false;
    if (!validDay(Number(match[1]), Number(match[2]), Number(match[3])))
      return false;
    return match[4] === void 0 || Number(match[4]) <= 23 && Number(match[5]) <= 59;
  }

  // src/notes/limits.ts
  var MAX_NOTE_LENGTH = 4e3;
  var MAX_TAG_LENGTH = 64;

  // src/events/listing.ts
  var normalizeTag = (label) => label.trim().replace(/\s+/gu, " ");
  var tagKey = (label) => normalizeTag(label).toLowerCase();
  var MAX_EVENT_TAGS = 20;
  var MAX_EVENT_ATTENDEES = 2e3;
  var MAX_LISTING_TEXT_LENGTH = 300;
  var listingRecordId = (kind, id) => `${kind}:${id}`;
  var kindOf = (record) => record.kind ?? "event";
  function cleanTags(tags) {
    const seen = /* @__PURE__ */ new Set();
    const result = [];
    for (const raw of tags) {
      const label = normalizeTag(raw);
      const key2 = tagKey(label);
      if (label.length === 0 || seen.has(key2)) continue;
      seen.add(key2);
      result.push(label);
    }
    return result;
  }
  var cutListingText = (text) => {
    const clean = text?.replace(/\s+/gu, " ").trim();
    return clean ? clean.slice(0, MAX_LISTING_TEXT_LENGTH) : void 0;
  };
  function compareListings(a, b) {
    const aStart = a.startLocal ?? "\uFFFF";
    const bStart = b.startLocal ?? "\uFFFF";
    return aStart.localeCompare(bStart) || (a.title ?? "").localeCompare(b.title ?? "") || a.id.localeCompare(b.id);
  }

  // src/extraction/preferences.ts
  var MAX_PREFERENCE_TAGS = 500;
  var MAX_PREFERENCE_LABEL_LENGTH = 100;
  var normalizeLabel = (label) => label.replace(/\s+/gu, " ").trim();

  // src/messages/message-settings.ts
  var MESSAGE_CACHING_KEY = "joyfox.messageCaching";
  var MESSAGE_RETENTION_KEY = "joyfox.messageRetentionMonths";
  var DEFAULT_MESSAGE_RETENTION_MONTHS = 12;
  var MIN_MESSAGE_RETENTION_MONTHS = 1;
  var MAX_MESSAGE_RETENTION_MONTHS = 120;
  var MAX_MESSAGE_TEXT_LENGTH = 1e4;
  var MESSAGE_ID_PATTERN = /^cm-message-[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/u;
  var CONVERSATION_ID_PATTERN = /^personal-\d+-\d+$/u;
  var isMessageCaching = (value) => value !== false;
  function isMessageRetention(value) {
    return typeof value === "number" && Number.isInteger(value) && value >= MIN_MESSAGE_RETENTION_MONTHS && value <= MAX_MESSAGE_RETENTION_MONTHS;
  }
  async function readMessageSettings(settings) {
    try {
      const stored = await settings.get([
        MESSAGE_CACHING_KEY,
        MESSAGE_RETENTION_KEY
      ]);
      const months = stored[MESSAGE_RETENTION_KEY];
      return {
        caching: isMessageCaching(stored[MESSAGE_CACHING_KEY]),
        retentionMonths: isMessageRetention(months) ? months : DEFAULT_MESSAGE_RETENTION_MONTHS
      };
    } catch {
      return {
        caching: false,
        retentionMonths: DEFAULT_MESSAGE_RETENTION_MONTHS
      };
    }
  }
  function retentionCutoff(now, months) {
    const cutoff = new Date(now.getTime());
    cutoff.setUTCMonth(cutoff.getUTCMonth() - months);
    return cutoff.toISOString();
  }
  var messageTime = (message2) => message2.sentAt ?? message2.createdAt;

  // src/qualification/facts.ts
  var UNKNOWN_FACTS = Object.freeze({
    verification: "unknown",
    personallyKnown: "unknown",
    photoCount: "unknown",
    profileWordCount: "unknown",
    joinedAt: "unknown",
    joinedWindow: "unknown"
  });

  // src/qualification/engine.ts
  var DAY_MS = 24 * 60 * 60 * 1e3;

  // src/rules/message-phrase.ts
  function normalizePhrase(text) {
    return text.normalize("NFKC").replace(/[\uFE0E\uFE0F]/gu, "").toUpperCase().toLowerCase().replace(/\u00DF/gu, "ss").replace(/\u03C2/gu, "\u03C3").replace(/\s+/gu, " ").trim();
  }
  var MAX_PHRASE_LENGTH = 100;
  var MAX_NORMALIZED_PHRASE_LENGTH = 400;

  // src/rules/contact-rule.ts
  var NUMERIC_CONDITION_KINDS = /* @__PURE__ */ new Set([
    "minimumPhotos",
    "minimumProfileWords",
    "minimumAccountAgeDays",
    "minimumTrustScore"
  ]);
  var TEXT_CONDITION_KINDS = /* @__PURE__ */ new Set([
    "firstMessageContains"
  ]);
  var CONDITION_KINDS = [
    "verified",
    "personallyKnown",
    "minimumPhotos",
    "minimumProfileWords",
    "minimumAccountAgeDays",
    "notTemplateSpam",
    "minimumTrustScore",
    "firstMessageContains"
  ];
  var CONDITION_TEXT = {
    verified: "condition.verified",
    personallyKnown: "condition.personallyKnown",
    minimumPhotos: "condition.minimumPhotos",
    minimumProfileWords: "condition.minimumProfileWords",
    minimumAccountAgeDays: "condition.minimumAccountAgeDays",
    notTemplateSpam: "condition.notTemplateSpam",
    minimumTrustScore: "condition.minimumTrustScore",
    firstMessageContains: "condition.firstMessageContains"
  };
  var RULE_LIMITS = Object.freeze({
    maxDepth: 4,
    maxChildren: 32,
    maxValue: 1e5,
    minTrustValue: -1e3,
    maxTextLength: MAX_PHRASE_LENGTH
  });
  function contactRuleProblem(value) {
    if (!value || typeof value !== "object") return "The rule must be an object";
    const rule = value;
    if (![1, 2, 3].includes(rule.schemaVersion))
      return "Unsupported rule schema version";
    if (!["all", "man", "woman", "couple"].includes(rule.audience))
      return "Unsupported rule audience";
    if (typeof rule.enabled !== "boolean") return "enabled must be a boolean";
    if (!["needs-review", "quarantined"].includes(rule.defaultPlacement))
      return "defaultPlacement must be needs-review or quarantined";
    return nodeProblem(rule.root, 1, rule.schemaVersion, true);
  }
  function schemaVersionFor(root) {
    const uses = (test) => {
      const walk = (node) => node.type === "group" ? node.children.some(walk) : test(node);
      return walk(root);
    };
    if (uses((condition) => TEXT_CONDITION_KINDS.has(condition.kind))) return 3;
    return uses((condition) => condition.negate === true) ? 2 : 1;
  }
  function nodeProblem(value, depth, version, mustBeGroup = false) {
    if (!value || typeof value !== "object")
      return "A rule node must be an object";
    const node = value;
    if (node.type === "group") {
      if (depth > RULE_LIMITS.maxDepth) return "The rule is nested too deeply";
      if (node.match !== "all" && node.match !== "any")
        return "A group must match all or any";
      if (!Array.isArray(node.children)) return "A group needs a children array";
      if (node.children.length > RULE_LIMITS.maxChildren)
        return "A group has too many conditions";
      for (const child of node.children) {
        const problem = nodeProblem(child, depth + 1, version);
        if (problem) return problem;
      }
      return void 0;
    }
    if (mustBeGroup) return "The rule root must be a group";
    if (node.type !== "condition") return "Unknown rule node type";
    if (!CONDITION_KINDS.includes(node.kind))
      return "Unknown condition kind";
    if (!["needs-review", "met", "not-met"].includes(node.whenUnknown))
      return "whenUnknown has an unsupported value";
    if (node.negate !== void 0 && (node.negate !== true || version === 1))
      return "negate must be true, and needs rule schema version 2";
    const kind = node.kind;
    if (TEXT_CONDITION_KINDS.has(kind)) {
      if (version === 1 || version === 2)
        return "This condition needs rule schema version 3";
      const text = node.text;
      const phrase = typeof text === "string" ? normalizePhrase(text) : "";
      if (typeof text !== "string" || text !== text.trim() || text.length > RULE_LIMITS.maxTextLength || phrase.length === 0 || // Every phrase a rule accepts must also fit a stored match, or an
      // export would hold a match that import refuses.
      phrase.length > MAX_NORMALIZED_PHRASE_LENGTH)
        return `A condition text must be 1 to ${RULE_LIMITS.maxTextLength} characters, with no space at either end`;
    } else if (node.text !== void 0) return "This condition takes no text";
    if (NUMERIC_CONDITION_KINDS.has(kind)) {
      const minimum = kind === "minimumTrustScore" ? RULE_LIMITS.minTrustValue : 0;
      if (typeof node.value !== "number" || !Number.isSafeInteger(node.value) || node.value < minimum || node.value > RULE_LIMITS.maxValue)
        return "A condition threshold must be a whole number in range";
    } else if (node.value !== void 0)
      return "This condition takes no threshold";
    return void 0;
  }
  var PLACEMENT_TEXT = {
    qualified: "placement.qualified",
    "needs-review": "placement.needs-review",
    quarantined: "placement.quarantined"
  };

  // src/storage/member-directory.ts
  var MAX_NICKNAME_LENGTH = 64;
  function cleanNickname(value) {
    if (typeof value !== "string") return void 0;
    const nickname = value.replace(/\s+/gu, " ").trim();
    if (nickname.length === 0 || nickname.length > MAX_NICKNAME_LENGTH)
      return void 0;
    return /[\u0000-\u001f\u007f]/u.test(nickname) ? void 0 : nickname;
  }
  async function nicknamesOf(members, accountId) {
    const names = /* @__PURE__ */ new Map();
    for (const member of await members.list(accountId))
      if (member.nickname) names.set(member.joyClubMemberId, member.nickname);
    return names;
  }

  // src/storage/validation.ts
  var ValidationError = class extends Error {
  };
  function requireString(record, field) {
    const value = record[field];
    if (typeof value !== "string" || value.length === 0)
      throw new ValidationError(`${field} must be a non-empty string`);
    return value;
  }
  function requireNumber(record, field) {
    const value = record[field];
    if (typeof value !== "number" || !Number.isFinite(value))
      throw new ValidationError(`${field} must be a finite number`);
    return value;
  }
  function requireBoolean(record, field) {
    const value = record[field];
    if (typeof value !== "boolean")
      throw new ValidationError(`${field} must be a boolean`);
    return value;
  }
  function requireArray(record, field) {
    const value = record[field];
    if (!Array.isArray(value))
      throw new ValidationError(`${field} must be an array`);
    return value;
  }
  function requireDate(record, field) {
    const value = requireString(record, field);
    if (!Number.isFinite(Date.parse(value)))
      throw new ValidationError(`${field} must be an ISO-compatible date`);
  }
  function requireEnum(record, field, values) {
    if (!values.includes(requireString(record, field)))
      throw new ValidationError(`${field} has an unsupported value`);
  }
  function requireStringArray(record, field) {
    if (!requireArray(record, field).every((value) => typeof value === "string"))
      throw new ValidationError(`${field} must contain only strings`);
  }
  function requireMessageArray(record, field) {
    if (!requireArray(record, field).every((value) => isMessage(value)))
      throw new ValidationError(`${field} must contain only catalog messages`);
  }
  function optionalString(record, field) {
    if (record[field] !== void 0) requireString(record, field);
  }
  function allowOnly(record, fields2, entityName) {
    const unexpected = Object.keys(record).find(
      (field) => !fields2.includes(field)
    );
    if (unexpected)
      throw new ValidationError(
        `${entityName} contains unsupported field ${unexpected}`
      );
  }
  function validateActionSteps(record) {
    for (const value of requireArray(record, "steps")) {
      if (!value || typeof value !== "object")
        throw new ValidationError("steps must contain objects");
      const step = value;
      requireString(step, "name");
      requireBoolean(step, "ok");
      requireDate(step, "at");
      optionalString(step, "errorCode");
    }
  }
  function validateProfileSnapshot(record) {
    requireString(record, "memberId");
    requireDate(record, "capturedAt");
    if (record.verification !== "unknown" && typeof record.verification !== "boolean")
      throw new ValidationError("verification must be boolean or unknown");
    for (const field of ["photoCount", "profileWordCount"]) {
      if (record[field] !== "unknown" && (typeof record[field] !== "number" || !Number.isInteger(record[field]) || record[field] < 0))
        throw new ValidationError(
          `${field} must be a non-negative integer or unknown`
        );
    }
    if (record.joinedAt !== "unknown") requireDate(record, "joinedAt");
    const hasEarliest = record.joinedEarliest !== void 0;
    const hasLatest = record.joinedLatest !== void 0;
    if (hasEarliest !== hasLatest)
      throw new ValidationError(
        "joinedEarliest and joinedLatest must be present together"
      );
    if (hasEarliest) {
      for (const field of ["joinedEarliest", "joinedLatest"])
        if (!isStrictIsoDate(requireString(record, field)))
          throw new ValidationError(`${field} must be a strict ISO 8601 date`);
      if (Date.parse(record.joinedEarliest) > Date.parse(record.joinedLatest))
        throw new ValidationError(
          "joinedEarliest must not be after joinedLatest"
        );
    }
    if (record.positivePreferences !== void 0) {
      const labels = record.positivePreferences;
      if (!Array.isArray(labels) || labels.some(
        (label, index) => typeof label !== "string" || label.length === 0 || label !== normalizeLabel(label) || index > 0 && !(labels[index - 1] < label)
      ))
        throw new ValidationError(
          "positivePreferences must be normalized labels, sorted and unique"
        );
    }
    if (record.ownProfile !== void 0 && record.ownProfile !== true)
      throw new ValidationError("ownProfile must be true when present");
  }
  function validateSyncConfig(record) {
    allowOnly(
      record,
      [
        "id",
        "accountId",
        "createdAt",
        "updatedAt",
        "endpoint",
        "lastSyncedAt",
        "keyDerivation"
      ],
      "SyncConfig"
    );
    requireString(record, "endpoint");
    const keyDerivation = record.keyDerivation;
    if (!keyDerivation || typeof keyDerivation !== "object")
      throw new ValidationError("keyDerivation is required");
    const parameters = keyDerivation;
    allowOnly(
      parameters,
      ["algorithm", "iterations", "hash", "salt"],
      "keyDerivation"
    );
    if (parameters.algorithm !== "PBKDF2" || parameters.hash !== "SHA-256")
      throw new ValidationError("Unsupported key derivation parameters");
    if (!Number.isInteger(requireNumber(parameters, "iterations")) || requireNumber(parameters, "iterations") <= 0)
      throw new ValidationError("iterations must be a positive integer");
    requireString(parameters, "salt");
  }
  function validateEntity(entityName, entity) {
    const record = entity;
    requireString(record, "id");
    requireString(record, "accountId");
    requireDate(record, "createdAt");
    requireDate(record, "updatedAt");
    switch (entityName) {
      case "extensionAccounts":
        requireString(record, "joyClubAccountId");
        optionalString(record, "label");
        break;
      case "joyClubMembers":
        requireString(record, "joyClubMemberId");
        if (record.nickname !== void 0 && cleanNickname(record.nickname) !== record.nickname)
          throw new ValidationError("nickname must be a clean nickname");
        break;
      case "profileSnapshots":
        validateProfileSnapshot(record);
        break;
      case "userNotes":
        requireString(record, "memberId");
        requireString(record, "body");
        break;
      case "userTags":
        requireString(record, "memberId");
        requireString(record, "label");
        break;
      case "trustSignals":
        requireString(record, "memberId");
        requireEnum(record, "kind", ["positive", "negative", "neutral"]);
        requireDate(record, "occurredAt");
        break;
      case "contactRules": {
        requireString(record, "name");
        const problem = contactRuleProblem(record);
        if (problem) throw new ValidationError(problem);
        break;
      }
      case "conversationClassifications":
        requireString(record, "memberId");
        optionalString(record, "conversationId");
        requireEnum(record, "placement", [
          "qualified",
          "needs-review",
          "quarantined"
        ]);
        requireEnum(record, "source", ["user"]);
        requireDate(record, "decidedAt");
        requireMessageArray(record, "reasons");
        optionalString(record, "ruleId");
        break;
      case "savedSearches":
        requireString(record, "name");
        requireString(record, "url");
        break;
      case "eventMetadata":
        requireString(record, "eventId");
        if (record.kind !== void 0) {
          requireEnum(record, "kind", ["event", "venue"]);
          if (!/^\d{1,12}$/u.test(record.eventId))
            throw new ValidationError("eventId must be JoyClub's number");
          if (record.id !== `${record.kind}:${record.eventId}`)
            throw new ValidationError("id must be <kind>:<eventId>");
        }
        optionalString(record, "title");
        if (record.startLocal !== void 0 && !isWallTime(requireString(record, "startLocal")))
          throw new ValidationError("startLocal must be YYYY-MM-DD[THH:mm]");
        if (record.path !== void 0 && !/^\/(event|club)\/\d{1,12}\.[^/]+\.html$/u.test(
          requireString(record, "path")
        ))
          throw new ValidationError("path must be a JoyClub event or venue path");
        if (record.venueId !== void 0 && !/^\d{1,12}$/u.test(requireString(record, "venueId")))
          throw new ValidationError("venueId must be JoyClub's number");
        optionalString(record, "venueName");
        optionalString(record, "note");
        requireStringArray(record, "tags");
        requireEnum(record, "attendance", [
          "interested",
          "attending",
          "not-attending",
          "attended",
          "unknown"
        ]);
        if (record.attendees !== void 0) {
          const ids = record.attendees;
          if (!Array.isArray(ids) || ids.length > MAX_EVENT_ATTENDEES || ids.some(
            (id, index) => typeof id !== "string" || // The member-ID shape every handler accepts (triage-service).
            !/^\d{1,20}$/u.test(id) || index > 0 && !(ids[index - 1] < id)
          ))
            throw new ValidationError(
              `attendees must be up to ${MAX_EVENT_ATTENDEES} member IDs, sorted and unique`
            );
        }
        if (record.attendeesSeenAt !== void 0)
          requireDate(record, "attendeesSeenAt");
        break;
      case "spendLogEntries":
        requireDate(record, "occurredAt");
        requireNumber(record, "amountMinor");
        requireString(record, "currency");
        requireEnum(record, "category", ["coins", "membership", "other"]);
        break;
      case "syncConfigs":
        validateSyncConfig(record);
        if (record.lastSyncedAt !== void 0)
          requireDate(record, "lastSyncedAt");
        break;
      case "extensionPreferences":
        requireString(record, "key");
        break;
      case "messageTemplates":
        requireString(record, "name");
        requireString(record, "body");
        optionalString(record, "folder");
        break;
      case "spamPhrases":
        requireString(record, "phrase");
        requireBoolean(record, "enabled");
        break;
      case "messageObservations":
        allowOnly(
          record,
          [
            "id",
            "accountId",
            "createdAt",
            "updatedAt",
            "memberId",
            "conversationId",
            "observedAt",
            "normalizedText"
          ],
          "MessageObservation"
        );
        requireString(record, "memberId");
        requireDate(record, "observedAt");
        requireString(record, "normalizedText");
        optionalString(record, "conversationId");
        break;
      case "senderSpamOverrides":
        requireString(record, "memberId");
        requireEnum(record, "decision", ["not-spam"]);
        requireDate(record, "decidedAt");
        optionalString(record, "reason");
        break;
      case "cachedMessages": {
        const messageId = requireString(record, "messageId");
        if (!MESSAGE_ID_PATTERN.test(messageId))
          throw new ValidationError("messageId must be JoyClub's message ID");
        if (record.id !== `message:${messageId}`)
          throw new ValidationError("id must be message:<messageId>");
        const conversationId = requireString(record, "conversationId");
        if (!CONVERSATION_ID_PATTERN.test(conversationId))
          throw new ValidationError("conversationId must be personal-<n>-<n>");
        const memberId = requireString(record, "memberId");
        if (!conversationId.split("-").slice(1).includes(memberId))
          throw new ValidationError("memberId must be in the conversation");
        requireEnum(record, "direction", ["sent", "received"]);
        if (record.sentAt !== void 0) requireDate(record, "sentAt");
        const text = requireString(record, "text");
        if (text.trim().length === 0 || text.length > MAX_MESSAGE_TEXT_LENGTH)
          throw new ValidationError(
            `text must hold 1 to ${MAX_MESSAGE_TEXT_LENGTH} characters`
          );
        break;
      }
      case "messagePhraseMatches":
        allowOnly(
          record,
          [
            "id",
            "accountId",
            "createdAt",
            "updatedAt",
            "memberId",
            "phrase",
            "matchedAt"
          ],
          "MessagePhraseMatch"
        );
        requireString(record, "memberId");
        if (requireString(record, "phrase").length > MAX_NORMALIZED_PHRASE_LENGTH)
          throw new ValidationError("phrase is too long");
        requireDate(record, "matchedAt");
        break;
      case "actionLogs":
        requireString(record, "action");
        optionalString(record, "memberId");
        optionalString(record, "conversationId");
        validateActionSteps(record);
        break;
    }
  }

  // src/storage/repository.ts
  var keyPart = (value) => encodeURIComponent(value);
  var key = (accountId, id) => `${keyPart(accountId)}:${keyPart(id)}`;
  var storageKeyFor = key;
  function withoutStorageKey(stored) {
    const copy = { ...stored };
    delete copy.storageKey;
    return copy;
  }
  var IndexedDbRepository = class {
    constructor(entityName) {
      this.entityName = entityName;
    }
    async get(accountId, id) {
      const db = await openDatabase();
      const stored = await requestResult(
        db.transaction(this.entityName).objectStore(this.entityName).get(key(accountId, id))
      );
      if (!stored) return void 0;
      return withoutStorageKey(stored);
    }
    async list(accountId) {
      const db = await openDatabase();
      const records = await requestResult(
        db.transaction(this.entityName).objectStore(this.entityName).index("accountId").getAll(accountId)
      );
      return records.map(withoutStorageKey);
    }
    /**
     * Stores one record. `retention` is passed to the store's retention policy,
     * if it has one (profile snapshots: how many to keep per member).
     */
    async put(accountId, entity, retention) {
      if (entity.accountId !== accountId)
        throw new ValidationError(
          "Entity account does not match repository scope"
        );
      validateEntity(this.entityName, entity);
      const db = await openDatabase();
      const transaction = db.transaction(this.entityName, "readwrite");
      const store = transaction.objectStore(this.entityName);
      await commitAll(transaction, async () => {
        store.put({ ...entity, storageKey: key(accountId, entity.id) });
        await this.applyRetention?.(store, accountId, entity, retention);
      });
    }
    async delete(accountId, id) {
      const db = await openDatabase();
      const transaction = db.transaction(this.entityName, "readwrite");
      transaction.objectStore(this.entityName).delete(key(accountId, id));
      await transactionDone(transaction);
    }
  };

  // src/storage/snapshot-retention.ts
  var SNAPSHOT_RETENTION_KEY = "joyfox.snapshotRetention";
  var DEFAULT_SNAPSHOT_RETENTION = 20;
  var MIN_SNAPSHOT_RETENTION = 1;
  var MAX_SNAPSHOT_RETENTION = 100;
  function isSnapshotRetention(value) {
    return typeof value === "number" && Number.isInteger(value) && value >= MIN_SNAPSHOT_RETENTION && value <= MAX_SNAPSHOT_RETENTION;
  }
  async function readSnapshotRetention(settings) {
    try {
      const value = (await settings.get([SNAPSHOT_RETENTION_KEY]))[SNAPSHOT_RETENTION_KEY];
      return isSnapshotRetention(value) ? value : DEFAULT_SNAPSHOT_RETENTION;
    } catch {
      return DEFAULT_SNAPSHOT_RETENTION;
    }
  }

  // src/storage/repositories.ts
  var PROFILE_SNAPSHOT_RETENTION = DEFAULT_SNAPSHOT_RETENTION;
  function snapshotsBeyond(snapshots, keep) {
    const byMember = /* @__PURE__ */ new Map();
    for (const snapshot of snapshots) {
      const member = `${snapshot.accountId}\0${snapshot.memberId}`;
      const list = byMember.get(member) ?? [];
      list.push(snapshot);
      byMember.set(member, list);
    }
    return [...byMember.values()].flatMap(
      (list) => list.sort(newestCaptureFirst).slice(Math.max(keep, 1))
    );
  }
  var ExtensionAccountRepository = class extends IndexedDbRepository {
    constructor() {
      super("extensionAccounts");
    }
    /**
     * The account directory is the one store that must be readable without an
     * account scope, because the scope itself is chosen from its contents. Every
     * account record is self-scoped (`accountId === id`), so this reads the
     * directory and never another account's data.
     */
    async listAllAccounts() {
      const db = await openDatabase();
      const stored = await requestResult(
        db.transaction("extensionAccounts").objectStore("extensionAccounts").getAll()
      );
      return stored.map(withoutStorageKey);
    }
    /**
     * Stores a new account only if no stored account has its JoyClub
     * identifier. The check and the write share one readwrite transaction, and
     * IndexedDB runs such transactions on this store one at a time, in every
     * extension context, so two creates can never both pass the check.
     * Returns `false`, writing nothing, for a duplicate.
     */
    async addIfIdentifierFree(account) {
      validateEntity("extensionAccounts", account);
      if (account.accountId !== account.id)
        throw new ValidationError("An account must be its own scope");
      const db = await openDatabase();
      const transaction = db.transaction("extensionAccounts", "readwrite");
      const store = transaction.objectStore("extensionAccounts");
      let added = false;
      await commitAll(transaction, async () => {
        const stored = await requestResult(
          store.getAll()
        );
        if (stored.some(
          (existing) => existing.joyClubAccountId === account.joyClubAccountId
        ))
          return;
        store.put({
          ...account,
          storageKey: storageKeyFor(account.id, account.id)
        });
        added = true;
      });
      return added;
    }
  };
  var JoyClubMemberRepository = class extends IndexedDbRepository {
    constructor() {
      super("joyClubMembers");
    }
  };
  var ProfileSnapshotRepository = class extends IndexedDbRepository {
    constructor() {
      super("profileSnapshots");
    }
    async applyRetention(store, accountId, entity, retention = PROFILE_SNAPSHOT_RETENTION) {
      const stored = await requestResult(
        store.index("accountId").getAll(accountId)
      );
      const member = stored.filter(
        (snapshot) => snapshot.memberId === entity.memberId
      );
      for (const obsolete of snapshotsBeyond(member, retention))
        store.delete(obsolete.storageKey);
    }
    /**
     * Keeps only the newest `keep` snapshots of every member in every account,
     * in one transaction: after the user lowers the setting, the snapshots
     * already stored follow it too. Returns how many were deleted.
     */
    async pruneAll(keep) {
      const db = await openDatabase();
      const transaction = db.transaction("profileSnapshots", "readwrite");
      const store = transaction.objectStore("profileSnapshots");
      let deleted = 0;
      await commitAll(transaction, async () => {
        const all = await requestResult(
          store.getAll()
        );
        for (const obsolete of snapshotsBeyond(all, keep)) {
          store.delete(obsolete.storageKey);
          deleted += 1;
        }
      });
      return deleted;
    }
  };
  var UserNoteRepository = class extends IndexedDbRepository {
    constructor() {
      super("userNotes");
    }
  };
  var UserTagRepository = class extends IndexedDbRepository {
    constructor() {
      super("userTags");
    }
  };
  var TrustSignalRepository = class extends IndexedDbRepository {
    constructor() {
      super("trustSignals");
    }
  };
  var ContactRuleRepository = class extends IndexedDbRepository {
    constructor() {
      super("contactRules");
    }
  };
  var ConversationClassificationRepository = class extends IndexedDbRepository {
    constructor() {
      super("conversationClassifications");
    }
  };
  var SavedSearchRepository = class extends IndexedDbRepository {
    constructor() {
      super("savedSearches");
    }
  };
  var EventMetadataRepository = class extends IndexedDbRepository {
    constructor() {
      super("eventMetadata");
    }
  };
  var SpendLogEntryRepository = class extends IndexedDbRepository {
    constructor() {
      super("spendLogEntries");
    }
  };
  var SyncConfigRepository = class extends IndexedDbRepository {
    constructor() {
      super("syncConfigs");
    }
  };
  var ExtensionPreferenceRepository = class extends IndexedDbRepository {
    constructor() {
      super("extensionPreferences");
    }
  };
  var MessageTemplateRepository = class extends IndexedDbRepository {
    constructor() {
      super("messageTemplates");
    }
  };
  var SpamPhraseRepository = class extends IndexedDbRepository {
    constructor() {
      super("spamPhrases");
    }
  };
  var MESSAGE_OBSERVATION_RETENTION_DAYS = 365;
  var MessageObservationRepository = class extends IndexedDbRepository {
    constructor() {
      super("messageObservations");
    }
    /**
     * The window is measured from this write, using `updatedAt`, which the
     * writer always sets to now. Measuring from the record's own `observedAt`
     * would let a caller backdate one message and drag the cutoff back with it,
     * keeping everything expired alive.
     *
     * The record being written is never purged here, so `put` cannot report
     * storing something this pass deleted in the same transaction.
     */
    async applyRetention(store, accountId, entity) {
      const cutoff = Date.parse(entity.updatedAt) - MESSAGE_OBSERVATION_RETENTION_DAYS * 24 * 60 * 60 * 1e3;
      const stored = await requestResult(
        store.index("accountId").getAll(accountId)
      );
      for (const observation of stored)
        if (observation.id !== entity.id && Date.parse(observation.observedAt) < cutoff)
          store.delete(observation.storageKey);
    }
  };
  var SenderSpamOverrideRepository = class extends IndexedDbRepository {
    constructor() {
      super("senderSpamOverrides");
    }
  };
  var ActionLogRepository = class extends IndexedDbRepository {
    constructor() {
      super("actionLogs");
    }
  };
  var MessagePhraseMatchRepository = class extends IndexedDbRepository {
    constructor() {
      super("messagePhraseMatches");
    }
  };
  var CachedMessageRepository = class extends IndexedDbRepository {
    constructor() {
      super("cachedMessages");
    }
    /**
     * Deletes every cached message, in every account, older than `cutoff`
     * (an ISO date), in one transaction. A message's age counts from when it
     * was sent, or from when it was stored when the page showed no time.
     * Returns how many were deleted.
     */
    async pruneOlderThan(cutoff) {
      const db = await openDatabase();
      const transaction = db.transaction("cachedMessages", "readwrite");
      const store = transaction.objectStore("cachedMessages");
      let deleted = 0;
      await commitAll(transaction, async () => {
        const all = await requestResult(
          store.getAll()
        );
        for (const message2 of all)
          if (Date.parse(messageTime(message2)) < Date.parse(cutoff)) {
            store.delete(message2.storageKey);
            deleted += 1;
          }
      });
      return deleted;
    }
  };
  var repositories = {
    extensionAccounts: new ExtensionAccountRepository(),
    joyClubMembers: new JoyClubMemberRepository(),
    profileSnapshots: new ProfileSnapshotRepository(),
    userNotes: new UserNoteRepository(),
    userTags: new UserTagRepository(),
    trustSignals: new TrustSignalRepository(),
    contactRules: new ContactRuleRepository(),
    conversationClassifications: new ConversationClassificationRepository(),
    savedSearches: new SavedSearchRepository(),
    eventMetadata: new EventMetadataRepository(),
    spendLogEntries: new SpendLogEntryRepository(),
    syncConfigs: new SyncConfigRepository(),
    extensionPreferences: new ExtensionPreferenceRepository(),
    messageTemplates: new MessageTemplateRepository(),
    spamPhrases: new SpamPhraseRepository(),
    messageObservations: new MessageObservationRepository(),
    senderSpamOverrides: new SenderSpamOverrideRepository(),
    actionLogs: new ActionLogRepository(),
    messagePhraseMatches: new MessagePhraseMatchRepository(),
    cachedMessages: new CachedMessageRepository()
  };
  async function exportAccount(accountId) {
    const db = await openDatabase();
    const transaction = db.transaction([...ENTITY_NAMES]);
    const entries = await Promise.all(
      ENTITY_NAMES.map(
        async (name) => [
          name,
          (await requestResult(
            transaction.objectStore(name).index("accountId").getAll(accountId)
          )).map(withoutStorageKey)
        ]
      )
    );
    return {
      schemaVersion: DATABASE_VERSION,
      exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
      scope: "account",
      accountId,
      entities: Object.fromEntries(entries)
    };
  }
  async function exportAllData() {
    const db = await openDatabase();
    const transaction = db.transaction([...ENTITY_NAMES]);
    const entries = await Promise.all(
      ENTITY_NAMES.map(
        async (name) => [
          name,
          (await requestResult(
            transaction.objectStore(name).getAll()
          )).map(withoutStorageKey)
        ]
      )
    );
    return {
      schemaVersion: DATABASE_VERSION,
      exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
      scope: "all",
      entities: Object.fromEntries(entries)
    };
  }
  async function countAccountRecords(accountId) {
    const db = await openDatabase();
    const transaction = db.transaction([...ENTITY_NAMES]);
    const entries = await Promise.all(
      ENTITY_NAMES.map(
        async (name) => [
          name,
          await requestResult(
            transaction.objectStore(name).index("accountId").count(accountId)
          )
        ]
      )
    );
    return Object.fromEntries(entries);
  }
  async function deleteAccountEntities(accountId, names) {
    if (names.length === 0) return;
    const db = await openDatabase();
    const transaction = db.transaction([...names], "readwrite");
    await commitAll(transaction, async () => {
      for (const name of names) {
        const store = transaction.objectStore(name);
        const keys = await requestResult(
          store.index("accountId").getAllKeys(accountId)
        );
        for (const recordKey of keys) store.delete(recordKey);
      }
    });
  }
  async function deleteAccountData(accountId) {
    await deleteAccountEntities(accountId, ENTITY_NAMES);
  }
  async function clearAllData() {
    const db = await openDatabase();
    const transaction = db.transaction([...ENTITY_NAMES], "readwrite");
    await commitAll(transaction, () => {
      for (const name of ENTITY_NAMES) transaction.objectStore(name).clear();
    });
  }
  async function countAllRecords() {
    const db = await openDatabase();
    const transaction = db.transaction([...ENTITY_NAMES]);
    const counts = await Promise.all(
      ENTITY_NAMES.map(
        (name) => requestResult(transaction.objectStore(name).count())
      )
    );
    return counts.reduce((sum, count) => sum + count, 0);
  }
  async function putRecords(writes) {
    if (writes.length === 0) return;
    for (const { name, entity } of writes) validateEntity(name, entity);
    const names = [...new Set(writes.map((write) => write.name))];
    const db = await openDatabase();
    const transaction = db.transaction(names, "readwrite");
    await commitAll(transaction, () => {
      for (const { name, entity } of writes)
        transaction.objectStore(name).put({
          ...entity,
          storageKey: storageKeyFor(entity.accountId, entity.id)
        });
    });
  }

  // src/accounts/account-service.ts
  var ACTIVE_ACCOUNT_SETTING_KEY = "joyfox.activeAccountId";
  var AccountService = class {
    constructor(accounts2 = new ExtensionAccountRepository(), settings = runtimeSettingsArea, now = () => (/* @__PURE__ */ new Date()).toISOString(), newId = () => crypto.randomUUID()) {
      this.accounts = accounts2;
      this.settings = settings;
      this.now = now;
      this.newId = newId;
    }
    async listAccounts() {
      const accounts2 = await this.accounts.listAllAccounts();
      return accounts2.sort(
        (a, b) => a.createdAt.localeCompare(b.createdAt) || a.id.localeCompare(b.id)
      );
    }
    async createAccount(input) {
      const joyClubAccountId = input.joyClubAccountId.trim();
      if (joyClubAccountId.length === 0)
        throw new ExtensionError(
          "IdentityMismatch",
          "An account needs a non-empty identifier",
          { display: message("error.account.emptyIdentifier") }
        );
      const timestamp = this.now();
      const id = this.newId();
      const label = input.label?.trim();
      const account = {
        id,
        // An extension account is its own scope. Keeping `accountId` equal to
        // `id` means the account directory obeys the same scoping rule as every
        // other store instead of needing an exception.
        accountId: id,
        joyClubAccountId,
        ...label ? { label } : {},
        createdAt: timestamp,
        updatedAt: timestamp
      };
      await withAccountLock(id, async () => {
        if (!await this.accounts.addIfIdentifierFree(account))
          throw new ExtensionError(
            "IdentityMismatch",
            "That account identifier is already registered",
            { display: message("error.account.duplicate") }
          );
        if (await this.getActiveAccount() === void 0)
          await this.settings.set({ [ACTIVE_ACCOUNT_SETTING_KEY]: id });
      });
      return account;
    }
    /**
     * Changes only the display label. The JoyClub identifier never changes: an
     * import matches accounts by it. The label is checked as on create: it is
     * trimmed, and an empty one is dropped so the identifier shows instead.
     */
    async renameAccount(accountId, label) {
      const trimmed = label.trim();
      return withAccountLock(accountId, async () => {
        const account = await this.accounts.get(accountId, accountId);
        if (!account)
          throw new ExtensionError(
            "IdentityMismatch",
            "That account no longer exists",
            { display: message("error.account.gone") }
          );
        const renamed = { ...account, updatedAt: this.now() };
        delete renamed.label;
        if (trimmed) renamed.label = trimmed;
        await this.accounts.put(accountId, renamed);
        return renamed;
      });
    }
    async getActiveAccountId() {
      const stored = await this.settings.get([ACTIVE_ACCOUNT_SETTING_KEY]);
      const value = stored[ACTIVE_ACCOUNT_SETTING_KEY];
      return typeof value === "string" && value.length > 0 ? value : void 0;
    }
    /**
     * Returns the active account only when the pointer still resolves to a
     * stored account. A dangling pointer yields `undefined` so the caller shows
     * "no active account" rather than operating on an unknown scope.
     */
    async getActiveAccount() {
      const activeId = await this.getActiveAccountId();
      if (!activeId) return void 0;
      return this.accounts.get(activeId, activeId);
    }
    /**
     * Holds the locks of the account being left and the account being
     * activated. A write that checked, under its account's lock, that its
     * account is active therefore finishes before the switch, or sees the
     * switch and refuses.
     */
    async setActiveAccount(accountId) {
      for (; ; ) {
        const current = await this.getActiveAccountId();
        const switched = await withAccountLocks(
          current ? [current, accountId] : [accountId],
          async () => {
            if (await this.getActiveAccountId() !== current) return false;
            if (await this.accounts.get(accountId, accountId) === void 0)
              throw new ExtensionError(
                "IdentityMismatch",
                "Cannot activate an account that is not registered",
                { display: message("error.account.notRegistered") }
              );
            await this.settings.set({ [ACTIVE_ACCOUNT_SETTING_KEY]: accountId });
            return true;
          }
        );
        if (switched) return;
      }
    }
    async clearActiveAccount() {
      await this.settings.remove([ACTIVE_ACCOUNT_SETTING_KEY]);
    }
    /**
     * Removes the account and every record scoped to it. The pointer is cleared
     * first so an interrupted delete can never leave the extension active on a
     * half-removed scope. No other account becomes active. Returns whether the
     * removed account was the active one, so the caller can say so.
     */
    async deleteAccount(accountId) {
      return withAccountLock(accountId, async () => {
        const wasActive = await this.getActiveAccountId() === accountId;
        if (wasActive) await this.clearActiveAccount();
        await deleteAccountData(accountId);
        return wasActive;
      });
    }
  };

  // src/i18n/catalog/de.ts
  var de = {
    // Shared labels
    "placement.qualified": "Qualifiziert",
    "placement.needs-review": "Zu pr\xFCfen",
    "placement.quarantined": "Junk",
    "condition.verified": "Verifiziert",
    "condition.personallyKnown": "Pers\xF6nlich bekannt",
    "condition.minimumPhotos": "Mindestanzahl Fotos",
    "condition.minimumProfileWords": "Mindestanzahl W\xF6rter im Profil",
    "condition.minimumAccountAgeDays": "Mindestalter des Kontos in Tagen",
    "condition.notTemplateSpam": "Nicht als Vorlagen-Spam markiert",
    "condition.minimumTrustScore": "Mindest-Vertrauenswert (lokal)",
    "condition.firstMessageContains": "Erste Nachricht enth\xE4lt",
    "field.accountAgeDays": "Kontoalter in Tagen",
    "field.photoCount": "Anzahl der Fotos",
    "field.profileWordCount": "W\xF6rter im Profil",
    "outcome.qualified": "Qualifiziert",
    "outcome.partial-information": "Unvollst\xE4ndige Angaben",
    "outcome.does-not-meet-rule": "Erf\xFCllt die Regel nicht",
    "common.close": "Schlie\xDFen",
    "common.openOptions": "JoyFox-Einstellungen \xF6ffnen",
    "common.saveFailed": "JoyFox konnte diese \xC4nderung nicht speichern. Es wurde nichts ge\xE4ndert. Versuche es noch einmal. Wenn es weiter nicht klappt, lade die Seite neu.",
    "legacy.text": (p) => p.text,
    "common.textUnavailable": "(Dieser Text kann nicht angezeigt werden.)",
    // Triage reasons
    "triage.reason.unknownValue": (p) => `${p.field}: unbekannt. Der Wert wurde weder daf\xFCr noch dagegen gez\xE4hlt.`,
    "triage.reason.atOrAbove": (p, f) => `${p.field}: ${f.number(p.value)}. Das erreicht den geforderten Mindestwert ${f.number(p.minimum)}.`,
    "triage.reason.belowMinimum": (p, f) => `${p.field}: ${f.number(p.value)}. Das liegt unter dem geforderten Mindestwert ${f.number(p.minimum)}.`,
    "triage.reason.accountAgeRangeAbove": (p, f) => `Kontoalter: zwischen ${f.number(p.min)} und ${f.number(p.max)} Tagen. Das erreicht den geforderten Mindestwert ${f.number(p.minimum)}.`,
    "triage.reason.accountAgeRangeBelow": (p, f) => `Kontoalter: zwischen ${f.number(p.min)} und ${f.number(p.max)} Tagen. Das liegt unter dem geforderten Mindestwert ${f.number(p.minimum)}.`,
    "triage.reason.accountAgeRangeCoarse": (p, f) => `Kontoalter: zwischen ${f.number(p.min)} und ${f.number(p.max)} Tagen. Das ist zu ungenau f\xFCr einen Vergleich mit dem geforderten Mindestwert ${f.number(p.minimum)}, deshalb wurde es weder daf\xFCr noch dagegen gez\xE4hlt.`,
    "triage.reason.verificationUnknown": "Der Verifizierungsstatus ist unbekannt. Er wurde weder daf\xFCr noch dagegen gez\xE4hlt.",
    "triage.reason.verified": "Das Profil ist verifiziert, wie deine Regel es verlangt.",
    "triage.reason.notVerified": "Das Profil ist nicht verifiziert. Deine Regel verlangt das aber.",
    "triage.reason.personallyKnownUnknown": "Ob du dieses Mitglied pers\xF6nlich kennst, ist unbekannt. Das wurde weder daf\xFCr noch dagegen gez\xE4hlt.",
    "triage.reason.personallyKnown": "Du hast dieses Mitglied als pers\xF6nlich bekannt markiert, wie deine Regel es verlangt.",
    "triage.reason.notPersonallyKnown": "Du hast dieses Mitglied nicht als pers\xF6nlich bekannt markiert. Deine Regel verlangt das aber.",
    "triage.reason.noCriteria": "Es sind keine Kriterien eingestellt, deshalb ist jede Person qualifiziert.",
    "triage.reason.spamFlagged": "Eine Nachricht dieser Person sieht wie eine kopierte Vorlage aus.",
    "triage.reason.spamNotFlagged": "Keine Nachricht dieser Person sieht wie eine kopierte Vorlage aus.",
    "triage.reason.spamOverridden": "Du hast diese Person als \u201Ekein Spam\u201C markiert.",
    "triage.reason.spamUnknown": "JoyFox hat die Nachrichten dieser Person nicht auf Vorlagen gepr\xFCft. Der Spam-Status ist deshalb unbekannt.",
    "triage.reason.phraseSeenNow": (p) => `Die neueste Nachricht dieser Person enth\xE4lt \u201E${p.text}\u201C.`,
    "triage.reason.phraseSeenBefore": (p) => `Eine fr\xFChere Nachricht dieser Person aus deinem Posteingang enth\xE4lt \u201E${p.text}\u201C.`,
    "triage.reason.phraseNotInLatest": (p) => `Die neueste Nachricht dieser Person enth\xE4lt \u201E${p.text}\u201C nicht. Der Posteingang zeigt nur die neueste Nachricht, deshalb kann JoyFox nicht sehen, ob die erste Nachricht es enthielt.`,
    "triage.reason.phraseNotSeen": (p) => `JoyFox hat keine Nachricht dieser Person gesehen, die \u201E${p.text}\u201C enth\xE4lt. Nur der Posteingang zeigt JoyFox Nachrichten.`,
    "triage.reason.trustUnknown": "Du hast zu diesem Mitglied nichts erfasst. Der lokale Vertrauenswert ist deshalb unbekannt.",
    "triage.reason.trustAtOrAbove": (p, f) => `Dein lokaler Vertrauenswert: ${f.number(p.score)}. Das erreicht den geforderten Mindestwert ${f.number(p.minimum)}.`,
    "triage.reason.trustBelow": (p, f) => `Dein lokaler Vertrauenswert: ${f.number(p.score)}. Das liegt unter dem geforderten Mindestwert ${f.number(p.minimum)}.`,
    "triage.reason.negatedMet": (p) => `${p.reason} Deine Regel sagt \u201Enicht ${p.condition}\u201C, deshalb z\xE4hlt das als erf\xFCllt.`,
    "triage.reason.negatedNotMet": (p) => `${p.reason} Deine Regel sagt \u201Enicht ${p.condition}\u201C, deshalb z\xE4hlt das als nicht erf\xFCllt.`,
    "triage.reason.unknownNeedsReview": (p) => `${p.reason} Deine Regel ordnet unbekannte Werte in \u201EZu pr\xFCfen\u201C ein.`,
    "triage.reason.unknownMet": (p) => `${p.reason} Deine Regel z\xE4hlt einen unbekannten Wert als erf\xFCllt.`,
    "triage.reason.unknownNotMet": (p) => `${p.reason} Deine Regel z\xE4hlt einen unbekannten Wert als nicht erf\xFCllt.`,
    "triage.reason.numbered": (p, f) => `Gruppe ${f.number(p.number)}: ${p.reason}`,
    "triage.reason.userMoved": (p) => `Du hast diese Person nach \u201E${p.placement}\u201C verschoben.`,
    "triage.headline.noConditions": "Deine Kontaktregel hat keine Pflichtbedingungen, deshalb ist jede Person qualifiziert.",
    "triage.headline.meets": "Diese Person erf\xFCllt deine Kontaktregel.",
    "triage.headline.undecided": "JoyFox konnte nicht entscheiden, weil einige Angaben unbekannt sind.",
    "triage.headline.doesNotMeet": (p) => `Diese Person erf\xFCllt deine Kontaktregel nicht und kommt deshalb nach \u201E${p.placement}\u201C.`,
    // Trust score
    "trust.reason.positive": (p, f) => `Du hast ${f.plural(p.count, {
      one: "1 positive Erfahrung",
      other: `${f.number(p.count)} positive Erfahrungen`
    })} erfasst.`,
    "trust.reason.negative": (p, f) => `Du hast ${f.plural(p.count, {
      one: "1 negative Erfahrung",
      other: `${f.number(p.count)} negative Erfahrungen`
    })} erfasst.`,
    "trust.reason.neutral": (p, f) => `Du hast ${f.plural(p.count, {
      one: "1 neutrale Erfahrung",
      other: `${f.number(p.count)} neutrale Erfahrungen`
    })} erfasst. Neutrale Erfahrungen z\xE4hlen 0.`,
    "trust.reason.personallyKnown": "Du hast dieses Mitglied als pers\xF6nlich bekannt markiert.",
    "trust.reason.spamFlagged": "Eine Nachricht dieses Mitglieds sieht wie eine kopierte Vorlage aus.",
    "trust.scopeNote": "Beruht nur auf dem, was du in diesem Browser erfasst und gesehen hast. Es ist keine Bewertung von JoyClub oder der Community.",
    // Template spam detector
    "spam.detail.override": "Du hast diese Person als \u201Ekein Spam\u201C markiert. Ihre Nachrichten werden deshalb nie markiert.",
    "spam.detail.belowMinimum": (p, f) => `Die Nachricht hat ${f.plural(p.words, {
      one: "1 Wort",
      other: `${f.number(p.words)} W\xF6rter`
    })}. F\xFCr den Vorlagenvergleich sind mindestens ${f.number(p.minimum)} n\xF6tig.`,
    "spam.detail.duplicate": (p, f) => `Diese Nachricht gleicht stark einer fr\xFCheren Nachricht an dich (${f.number(p.percent)} % \xE4hnlich).`,
    "spam.detail.knownPhrase": "Die Nachricht enth\xE4lt eine Formulierung aus deiner Liste bekannter Vorlagen.",
    "spam.detail.phraseSimilar": (p, f) => `Die Nachricht gleicht stark einer Formulierung aus deiner Liste bekannter Vorlagen (${f.number(p.percent)} % \xE4hnlich).`,
    "spam.detail.noMatch": "Die Nachricht gleicht keiner fr\xFCheren Nachricht und keiner bekannten Vorlagen-Formulierung.",
    // Quick Ignore and Delete (M9). JoyClub's own German labels name its
    // controls (live-evidence/10-ignore.md).
    "action.step.ignore": "Profil ignorieren",
    "action.step.delete": "In den Papierkorb schieben",
    "action.where.before": (p) => `vor \u201E${p.step}\u201C`,
    "action.where.during": (p) => `w\xE4hrend \u201E${p.step}\u201C`,
    "action.failure.control-missing": (p) => `JoyFox hat auf dieser Seite JoyClubs Option \u201E${p.step}\u201C nicht gefunden.`,
    "action.failure.confirmation-missing": (p) => `JoyClubs Best\xE4tigung f\xFCr \u201E${p.step}\u201C ist nicht erschienen.`,
    "action.failure.not-verified": (p) => `JoyClub hat nicht angezeigt, dass \u201E${p.step}\u201C geklappt hat.`,
    "action.failure.unverifiable": (p) => `JoyFox kann JoyClubs Ergebnis f\xFCr \u201E${p.step}\u201C auf dieser Seite nicht sehen und hat deshalb ${p.where} angehalten.`,
    "action.failure.member-mismatch": (p) => `Die Seite hat ein anderes Mitglied gezeigt. JoyFox hat deshalb ${p.where} angehalten.`,
    "action.failure.conversation-mismatch": (p) => `Die Seite hat eine andere Unterhaltung gezeigt. JoyFox hat deshalb ${p.where} angehalten.`,
    "action.failure.identity-unavailable": (p) => `JoyFox konnte nicht best\xE4tigen, welches Mitglied oder welche Unterhaltung die Seite zeigt, und hat deshalb ${p.where} angehalten.`,
    "action.failure.account-changed": (p) => `Das aktive JoyFox-Konto hat sich ge\xE4ndert. JoyFox hat deshalb ${p.where} angehalten.`,
    "action.failure.turned-off": (p) => `\u201EIgnorieren und l\xF6schen\u201C wurde ausgeschaltet. JoyFox hat deshalb ${p.where} angehalten.`,
    "action.failure.superseded": (p) => `Ein neuerer JoyFox-Vorgang f\xFCr dieses Mitglied hat begonnen. JoyFox hat deshalb ${p.where} angehalten.`,
    "action.failure.log-unavailable": (p) => `JoyFox konnte nicht in sein Aktionsprotokoll schreiben und hat deshalb ${p.where} angehalten.`,
    "action.failure.handoff-failed": (p) => `JoyFox konnte nicht zum Profil des Mitglieds wechseln und hat deshalb ${p.where} angehalten.`,
    "action.failure.timeout": (p) => `JoyClub hat w\xE4hrend \u201E${p.step}\u201C nicht rechtzeitig reagiert.`,
    "action.failure.step-error": (p) => `Ein unerwarteter Fehler hat JoyFox ${p.where} angehalten.`,
    "action.stepText.ignore.done": "Profil ignorieren: erledigt. JoyClub ignoriert dieses Mitglied.",
    "action.stepText.ignore.not-done": "Profil ignorieren: nicht erledigt.",
    "action.stepText.ignore.unknown": "Profil ignorieren: nicht best\xE4tigt. JoyFox hat den Schritt begonnen, aber keine Best\xE4tigung von JoyClub gesehen.",
    "action.stepText.delete.done": "In den Papierkorb schieben: erledigt. JoyClub hat die Unterhaltung in den Papierkorb verschoben.",
    "action.stepText.delete.not-done": "In den Papierkorb schieben: nicht erledigt.",
    "action.stepText.delete.unknown": "In den Papierkorb schieben: nicht best\xE4tigt. JoyFox hat den Schritt begonnen, aber keine Best\xE4tigung von JoyClub gesehen.",
    "action.next.ignore": "N\xE4chster Schritt: \xD6ffne das Profil des Mitglieds und pr\xFCfe, ob es ignoriert wird. Wenn nicht, ignoriere es dort selbst.",
    "action.next.delete": "N\xE4chster Schritt: \xD6ffne die Unterhaltung und pr\xFCfe, ob sie im Papierkorb ist. Wenn nicht, verschiebe sie selbst mit \u201EIn den Papierkorb schieben\u201C.",
    "action.next.showList": "\u201EIn den Papierkorb schieben\u201C klappt nur, w\xE4hrend diese Unterhaltung in der ClubMail-Liste daneben zu sehen ist. Mach das Fenster breiter oder scrolle die Liste, bis die Unterhaltung erscheint, und versuche es dann noch einmal.",
    "action.self.ignore": "Du kannst es selbst tun: \xD6ffne das Profil des Mitglieds und ignoriere es dort mit \u201EProfil ignorieren\u201C.",
    "action.self.delete": "Du kannst es selbst tun: Verschiebe die Unterhaltung mit \u201EIn den Papierkorb schieben\u201C in den Papierkorb.",
    "action.report.finished": "\u201EIgnorieren und l\xF6schen\u201C ist fertig.",
    "action.report.undo": "R\xFCckg\xE4ngig machen: Hol die Unterhaltung aus JoyClubs Papierkorb zur\xFCck. \xD6ffne dann das Profil des Mitglieds und w\xE4hle im Men\xFC \u201EProfil nicht mehr ignorieren\u201C.",
    "action.report.running": "\u201EIgnorieren und l\xF6schen\u201C l\xE4uft.",
    "action.report.stopped": "\u201EIgnorieren und l\xF6schen\u201C wurde angehalten.",
    "action.report.interrupted": "\u201EIgnorieren und l\xF6schen\u201C wurde unterbrochen, zum Beispiel weil der Tab geschlossen wurde.",
    "action.report.nothingChanged": "Auf JoyClub wurde nichts ge\xE4ndert.",
    "action.report.notUndone": "JoyFox hat nichts r\xFCckg\xE4ngig gemacht.",
    "action.deleteReport.finished": "\u201EL\xF6schen\u201C ist fertig.",
    "action.deleteReport.undo": "R\xFCckg\xE4ngig machen: Hol die Unterhaltung aus JoyClubs Papierkorb zur\xFCck.",
    "action.deleteReport.running": "\u201EL\xF6schen\u201C l\xE4uft.",
    "action.deleteReport.stopped": "\u201EL\xF6schen\u201C wurde angehalten.",
    "action.deleteReport.interrupted": "\u201EL\xF6schen\u201C wurde unterbrochen, zum Beispiel weil der Tab geschlossen wurde.",
    // Content script: the Delete and Ignore and Delete buttons and notice
    "quick.progress.Started": "\u201EIgnorieren und l\xF6schen\u201C l\xE4uft. JoyFox pr\xFCft die Seite.",
    "quick.delete.progress.Started": "\u201EL\xF6schen\u201C l\xE4uft. JoyFox pr\xFCft die Seite.",
    "quick.progress.DeleteRequested": "Die Unterhaltung wird in den Papierkorb verschoben.",
    "quick.progress.DeleteConfirmed": "Papierkorb erledigt. JoyFox \xF6ffnet das Profil des Mitglieds, um es dort zu ignorieren.",
    "quick.progress.IgnoreRequested": "Das Mitglied wird auf JoyClub ignoriert.",
    "quick.button": "Ignorieren und l\xF6schen",
    "quick.region": "JoyFox: Aktionen f\xFCr die Unterhaltung",
    "quick.delete.button": "L\xF6schen",
    "quick.delete.scope": "Ein Klick verschiebt diese Unterhaltung in JoyClubs Papierkorb und kehrt dann zur ClubMail-Liste zur\xFCck. Das Mitglied wird nicht ignoriert. JoyFox h\xE4lt beim ersten Problem an und sagt dir, was erledigt wurde. JoyFox sendet nie eine Nachricht.",
    "quick.scope": "Experimentell. Ein Klick verschiebt diese Unterhaltung in JoyClubs Papierkorb, \xF6ffnet dann das Profil des Mitglieds und ignoriert es dort. JoyFox h\xE4lt beim ersten Problem an und sagt dir, was erledigt wurde. JoyFox sendet nie eine Nachricht.",
    "quick.needsList": "Klappt nur, w\xE4hrend diese Unterhaltung in der ClubMail-Liste daneben zu sehen ist. Mach das Fenster breiter oder scrolle die Liste, bis die Unterhaltung erscheint.",
    "quick.noProfile": "JoyFox findet den Link zum Profil dieses Mitglieds nicht. Dort ist \u201EProfil ignorieren\u201C. JoyFox hat deshalb nichts getan. Du kannst es selbst tun: Verschiebe die Unterhaltung mit \u201EIn den Papierkorb schieben\u201C in den Papierkorb. \xD6ffne dann das Profil des Mitglieds und ignoriere es dort mit \u201EProfil ignorieren\u201C.",
    "quick.resumed": "\u201EIgnorieren und l\xF6schen\u201C, fortgesetzt aus der Unterhaltung:",
    "quick.waitingMenu": "JoyFox wartet auf JoyClubs Profilmen\xFC \u2026",
    "quick.previous": "Dein letztes \u201EIgnorieren und l\xF6schen\u201C f\xFCr dieses Mitglied:",
    "quick.previousOther": "Dein letztes \u201EIgnorieren und l\xF6schen\u201C f\xFCr dieses Mitglied, in einer anderen Unterhaltung:",
    "quick.otherResult": "Dein letztes \u201EIgnorieren und l\xF6schen\u201C, f\xFCr eine andere Unterhaltung:",
    "quick.delete.previous": "Dein letztes \u201EL\xF6schen\u201C f\xFCr dieses Mitglied:",
    "quick.delete.previousOther": "Dein letztes \u201EL\xF6schen\u201C f\xFCr dieses Mitglied, in einer anderen Unterhaltung:",
    "quick.delete.otherResult": "Dein letztes \u201EL\xF6schen\u201C, f\xFCr eine andere Unterhaltung:",
    "quick.otherRunning": "Ein JoyFox-Vorgang l\xE4uft noch f\xFCr eine andere Unterhaltung. Warte, bis er fertig ist.",
    "quick.busy": "Ein anderer JoyFox-Vorgang f\xFCr dieses Mitglied l\xE4uft noch, zum Beispiel in einem anderen Tab. Hier wurde nichts getan.",
    "quick.junk.done": "Als Junk markiert: Die Person ist in \u201EJunk\u201C, und ein negatives Ergebnis ist festgehalten.",
    "quick.junk.busy": "Ein anderer JoyFox-Vorgang f\xFCr dieses Mitglied l\xE4uft noch. JoyFox hat den Papierkorb-Schritt deshalb nicht begonnen.",
    "quick.junk.notTrashed": "Die Unterhaltung wurde nicht in den Papierkorb verschoben.",
    "quick.delete.unexpected": "\u201EL\xF6schen\u201C wurde durch einen unerwarteten Fehler angehalten. Vielleicht hat JoyFox die Unterhaltung in den Papierkorb verschoben: Pr\xFCfe selbst JoyClubs Papierkorb.",
    "quick.unexpected": "\u201EIgnorieren und l\xF6schen\u201C wurde durch einen unerwarteten Fehler angehalten. Vielleicht hat JoyFox einen Schritt erledigt: Pr\xFCfe selbst das Profil des Mitglieds und die Unterhaltung.",
    // Content script: triage explanation, member bar and trust controls
    "triage.outcome.met": "Erf\xFCllt",
    "triage.outcome.not-met": "Nicht erf\xFCllt",
    "triage.outcome.needs-review": "Zu pr\xFCfen",
    "triage.conditions.summary": (p, f) => `Alle gepr\xFCften Bedingungen (${f.number(p.count)})`,
    "triage.condition.line": (p) => `${p.outcome}: ${p.condition}. `,
    "triage.condition.lineNegated": (p) => `${p.outcome}: nicht ${p.condition}. `,
    "triage.placementLine": (p) => `Einordnung: ${p.placement} (${p.source}).`,
    "triage.source.override": "deine eigene Wahl",
    "triage.source.rule": "deine Kontaktregel",
    "triage.source.sharedEvent": "die Ausnahme f\xFCr gemeinsame Events",
    "triage.sharedEvent.attending": (p) => `Auf der G\xE4steliste von \u201E${p.event}\u201C${p.when ? ` (${p.when})` : ""}, das du mit \u201EIch gehe hin\u201C markiert hast.`,
    "triage.sharedEvent.attended": (p) => `Auf der G\xE4steliste von \u201E${p.event}\u201C${p.when ? ` (${p.when})` : ""}, das du mit \u201EIch war dort\u201C markiert hast.`,
    "triage.sharedEvent.optOut": "Das gemeinsame Event f\xFCr diese Person nicht verwenden",
    "triage.movedOn": (p) => `Du hast diese Person am ${p.date} verschoben. Deine Regel allein w\xFCrde sie in \u201E${p.placement}\u201C einordnen.`,
    "triage.place.group": "Diese Person einordnen",
    "triage.useRule": "Wieder meine Regel verwenden",
    "mark.group": "Diese Person markieren",
    "mark.qualified": "Als qualifiziert markieren",
    "mark.junk": "Als Junk markieren",
    "mark.trustFailed": (p) => `JoyFox hat diese Person in \u201E${p.placement}\u201C eingeordnet, konnte das Vertrauensergebnis aber nicht festhalten und hat deshalb dort angehalten. Du kannst es auf der Unterhaltung oder dem Profil des Mitglieds festhalten.`,
    "mark.junk.noTrash": "Die Person ist in \u201EJunk\u201C, und ein negatives Ergebnis ist festgehalten. JoyFox konnte diese Unterhaltung hier nicht in den Papierkorb verschieben. Verschiebe sie selbst mit \u201EIn den Papierkorb schieben\u201C.",
    "triage.profileFact.minimumPhotos": "Anzahl der Fotos",
    "triage.profileFact.minimumProfileWords": "W\xF6rter im Profil",
    "triage.profileFact.minimumAccountAgeDays": "Kontoalter",
    "triage.unknownFacts.one": (p) => `${p.fact}: unbekannt. \xD6ffne das Profil, dann liest JoyFox den Wert.`,
    "triage.unknownFacts.two": (p) => `${p.first} und ${p.second}: unbekannt. \xD6ffne das Profil, dann liest JoyFox die Werte.`,
    "triage.unknownFacts.three": (p) => `${p.first}, ${p.second} und ${p.third}: unbekannt. \xD6ffne das Profil, dann liest JoyFox die Werte.`,
    "trust.score.none": "Lokaler Vertrauenswert: noch keine Eintr\xE4ge.",
    "trust.score.value": (p, f) => `Lokaler Vertrauenswert: ${f.number(p.score)}.`,
    "trust.details.summary": "So setzt sich der Wert zusammen",
    "trust.contribution": (p, f) => `${p.points > 0 ? "+" : ""}${f.number(p.points)}: ${p.reason}`,
    "trust.log.group": "Erfahrung mit diesem Mitglied erfassen",
    "trust.log.positive": "Positive Erfahrung erfassen",
    "trust.log.neutral": "Neutrale Erfahrung erfassen",
    "trust.log.negative": "Negative Erfahrung erfassen",
    "trust.log.undo": "Letzte Erfahrung zur\xFCcknehmen",
    "bar.placementPrefix": "Einordnung: ",
    "bar.yourChoice": "(deine Wahl)",
    "bar.sharedEvent": "(gemeinsames Event)",
    "bar.openProfile": "Profil \xF6ffnen",
    "bar.log": "Erfassen:",
    "bar.positive": "Positiv",
    "bar.neutral": "Neutral",
    "bar.negative": "Negativ",
    "bar.undo": "Zur\xFCcknehmen",
    "bar.details": "Details",
    "strip.collapse": "JoyFox einklappen",
    "strip.expand": "JoyFox ausklappen",
    "bar.scoreDetails": "Details zum Wert",
    "panel.ruleOff.no-rule": "Es ist keine Kontaktregel gespeichert, deshalb ordnet JoyFox diese Person nicht ein.",
    "panel.ruleOff.rule-disabled": "Deine Kontaktregel ist ausgeschaltet, deshalb ordnet JoyFox diese Person nicht ein.",
    "panel.ruleOff.other": "JoyFox kann diese Person gerade nicht einordnen. Lade die Seite neu, um es noch einmal zu versuchen.",
    "panel.ruleOff.no-account": "Es ist kein JoyFox-Konto aktiv, deshalb zeigt JoyFox zu diesem Mitglied nichts an.",
    // Content script: inbox triage
    "inbox.region": "JoyFox-Sortierung",
    "inbox.views": "Nachrichten zeigen",
    "inbox.view.default": "Posteingang",
    "inbox.view.all": "Alle zeigen",
    "inbox.viewCount": (p, f) => `${p.view} (${f.number(p.count)})`,
    "inbox.about": "\xDCber diese Ansichten",
    "inbox.aboutText": "\u201EPosteingang\u201C blendet Zeilen aus \u201EJunk\u201C nur in dieser Ansicht aus. Nichts wird gel\xF6scht, und JoyFox \xE4ndert nichts auf JoyClub.",
    "inbox.checking": "Wird eingeordnet \u2026",
    "inbox.badge": (p) => `JoyFox: ${p.text}. Details.`,
    "inbox.why": "Details",
    "inbox.whyNamed": (p) => `Details: ${p.name}`,
    "inbox.rowGone": "Diese Zeile wird nicht mehr angezeigt.",
    "inbox.unidentified": "JoyFox konnte die Profilnummer dieser Person nicht lesen und deine Regel deshalb nicht pr\xFCfen. Die Zeile bleibt sichtbar.",
    "inbox.stillChecking": "JoyFox pr\xFCft diese Person noch.",
    "inbox.setup.no-account": "Es ist kein JoyFox-Konto aktiv, deshalb sortiert JoyFox diesen Posteingang nicht.",
    "inbox.setup.no-rule": "Es ist keine Kontaktregel gespeichert, deshalb sortiert JoyFox diesen Posteingang nicht.",
    // Content script: notes and tags
    "notes.region": "JoyFox-Notizen und -Tags",
    "notes.scope": "Nur f\xFCr dich in JoyFox: gespeichert nur in diesem Browser, unter dem aktiven JoyFox-Konto. JoyFox sendet sie nie irgendwohin.",
    "notes.saved": "Notiz gespeichert.",
    "notes.removed": "Notiz entfernt.",
    "notes.conflict": "Diese Notiz wurde in einem anderen Tab oder in der JoyFox-Datenansicht ge\xE4ndert. JoyFox hat deinen Text deshalb nicht gespeichert. Er steht noch im Feld. Speichere noch einmal, um die gespeicherte Notiz zu ersetzen, oder verwirf deine \xC4nderungen, um sie zu sehen.",
    "notes.refused": "Das aktive JoyFox-Konto hat sich ge\xE4ndert, deshalb wurde nichts gespeichert. Text, den du f\xFCr das vorherige Konto eingegeben hast, wurde verworfen.",
    "notes.emptyTag": "Gib zuerst einen Tag ein. Es wurde nichts hinzugef\xFCgt.",
    "notes.emptyNote": "Gib zuerst eine Notiz ein. Es wurde nichts gespeichert.",
    "notes.tagAdded": "Tag hinzugef\xFCgt.",
    "notes.tagExists": "Diesen Tag hat das Mitglied schon.",
    "notes.tagRemoved": "Tag entfernt.",
    "notes.privateNote": "Private Notiz",
    "notes.length": (p, f) => `${f.number(p.count)} von ${f.number(p.maximum)} Zeichen`,
    "notes.pasteCut": "Nur ein Teil des eingef\xFCgten Texts hat gepasst. Der Rest wurde nicht eingef\xFCgt.",
    "notes.discard": "Meine \xC4nderungen verwerfen",
    "notes.save": "Notiz speichern",
    "notes.tags": "Tags",
    "notes.noTags": "Noch keine Tags.",
    "notes.remove": "Entfernen",
    "notes.removeTag": (p) => `Tag ${p.label} entfernen`,
    "notes.addTagLabel": "Tag hinzuf\xFCgen",
    "notes.addTag": "Hinzuf\xFCgen",
    "notes.summary.none": "Deine Notizen und Tags (noch keine)",
    "notes.summary.note": "Deine Notizen und Tags (eine Notiz)",
    "notes.summary.tags": (p, f) => `Deine Notizen und Tags (${f.plural(p.count, {
      one: "1 Tag",
      other: `${f.number(p.count)} Tags`
    })})`,
    "notes.summary.noteAndTags": (p, f) => `Deine Notizen und Tags (eine Notiz und ${f.plural(p.count, {
      one: "1 Tag",
      other: `${f.number(p.count)} Tags`
    })})`,
    // Content script: template picker
    "listing.heading.event": "JoyFox: deine Notizen zu diesem Event",
    "listing.heading.venue": "JoyFox: deine Notizen zu diesem Club",
    "listing.summary.event": (p) => `JoyFox: deine Notizen zu diesem Event (${p.state})`,
    "listing.summary.venue": (p) => `JoyFox: deine Notizen zu diesem Club (${p.state})`,
    "listing.summary.none": "noch keine",
    "listing.summary.note": "eine Notiz",
    "listing.loading": "Deine Notizen werden geladen \u2026",
    "listing.readFailed": "JoyFox konnte deine Notizen zu dieser Seite nicht lesen. Lade die Seite neu, um es noch einmal zu versuchen.",
    "listing.noAccount": "W\xE4hle in den JoyFox-Einstellungen ein Konto aus oder f\xFCge eines hinzu, um Notizen zu Events zu speichern.",
    "listing.attendanceLabel": "Deine Teilnahme",
    "listing.attendance.unknown": "Kein Status",
    "listing.attendance.interested": "Interessiert",
    "listing.attendance.attending": "Ich gehe hin",
    "listing.attendance.not-attending": "Ich gehe nicht hin",
    "listing.attendance.attended": "Ich war dort",
    "listing.noteLabel": "Deine Notiz",
    "listing.saveNote": "Notiz speichern",
    "listing.tagsLabel": "Deine Tags",
    "listing.tagLabel": "Neuer Tag",
    "listing.addTag": "Tag hinzuf\xFCgen",
    "listing.removeTag": (p) => `Tag ${p.tag} entfernen`,
    "listing.emptyTag": "Gib zuerst einen Tag ein. Es wurde nichts hinzugef\xFCgt.",
    "listing.tooManyTags.event": (p, f) => `Du kannst einem Event h\xF6chstens ${f.number(p.maximum)} Tags geben. Entferne zuerst einen.`,
    "listing.tooManyTags.venue": (p, f) => `Du kannst einem Club h\xF6chstens ${f.number(p.maximum)} Tags geben. Entferne zuerst einen.`,
    "listing.privacy": "Privat: nur in diesem Browser gespeichert. JoyClub sieht nichts, und deine Anmeldung bei JoyClub \xE4ndert sich nicht.",
    "listing.saved": "Gespeichert.",
    "listing.tracked.event": "Gespeichert. JoyFox verfolgt dieses Event jetzt.",
    "listing.tracked.venue": "Gespeichert. JoyFox verfolgt diesen Club jetzt.",
    "listing.removed.event": "Es ist keine Notiz, kein Tag und keine Teilnahme mehr eingetragen, deshalb verfolgt JoyFox dieses Event nicht mehr.",
    "listing.removed.venue": "Es ist keine Notiz und kein Tag mehr eingetragen, deshalb verfolgt JoyFox diesen Club nicht mehr.",
    "listing.conflict": "Diese Notizen wurden in einem anderen Tab ge\xE4ndert, deshalb hat JoyFox nicht gespeichert. Jetzt werden die gespeicherten Notizen angezeigt; deine eingegebene Notiz steht noch im Feld.",
    "listing.refused": "Das aktive JoyFox-Konto hat sich ge\xE4ndert, deshalb wurde nichts gespeichert.",
    "events.heading": "Deine Events",
    "events.hint": "Alle Events und Clubs, zu denen du auf JoyClub eine Notiz, einen Tag oder deine Teilnahme eingetragen hast, nach Datum. JoyFox beh\xE4lt sie, auch wenn JoyClub ein Event entfernt. Um einen Eintrag zu \xE4ndern, \xF6ffne ihn auf JoyClub.",
    "events.readFailed": "JoyFox konnte deine Events nicht lesen. Lade die Seite neu, um es noch einmal zu versuchen.",
    "events.noAccount": "W\xE4hle zuerst ein Konto aus oder f\xFCge eines hinzu. Jedes Konto hat eigene Events.",
    "events.empty": "Noch keine verfolgten Events. \xD6ffne ein Event auf JoyClub und trage eine Notiz, einen Tag oder deine Teilnahme ein.",
    "events.count": (p, f) => `${f.number(p.shown)} von ${f.number(p.total)} verfolgten Events angezeigt.`,
    "events.filterLabel": "Zeigen",
    "events.filter.all": "Alle verfolgten Events",
    "events.searchLabel": "In meinen Notizen, Tags und Titeln suchen",
    "events.noDate": "Kein Datum",
    "events.untitled": (p) => `Event ${p.id}`,
    "events.past": (p) => `${p.when} (vorbei)`,
    "events.venue": (p) => `Club: ${p.venue}`,
    "events.venuesHeading": "Deine Clubs",
    "events.guests": (p, f) => f.plural(p.count, {
      one: "1 Gast gespeichert",
      other: `${f.number(p.count)} G\xE4ste gespeichert`
    }),
    "events.exception.label": "Ausnahme f\xFCr gemeinsame Events: eine Person als \u201EQualifiziert\u201C einordnen, wenn sie auf der G\xE4steliste eines Events steht, das ich mit \u201EIch gehe hin\u201C oder \u201EIch war dort\u201C markiert habe",
    "events.exception.hint": "Standardm\xE4\xDFig aus. JoyFox speichert die G\xE4steliste eines verfolgten Events, wenn du die Event-Seite \xF6ffnest, so weit JoyClub sie geladen hat, und l\xF6scht sie, wenn du das Event nicht mehr verfolgst. Eine Person, die du selbst markiert hast, beh\xE4lt deine Wahl, und im Bereich \u201EDetails\u201C kannst du die Ausnahme f\xFCr eine Person abschalten.",
    "events.exception.saved": "Gespeichert.",
    "events.exception.saveFailed": "JoyFox konnte diese Einstellung nicht speichern. Versuche es noch einmal.",
    "quickSetting.heading": "Ignorieren und l\xF6schen",
    "quickSetting.label": "Die Schaltfl\xE4che \u201EIgnorieren und l\xF6schen\u201C in ClubMail-Unterhaltungen zeigen",
    "quickSetting.hint": "Experimentell und standardm\xE4\xDFig an. Ein Klick schiebt die Unterhaltung in JoyClubs Papierkorb, \xF6ffnet das Profil des Mitglieds im selben Tab und ignoriert das Mitglied dort. Das funktioniert nur, solange die ClubMail-Liste neben der Unterhaltung zu sehen ist. JoyFox handelt nur, wenn du klickst. Das \u201EAktionsprotokoll\u201C unter \u201EDeine Daten\u201C h\xE4lt jeden Schritt fest. Diese Einstellung steuert nur \u201EIgnorieren und l\xF6schen\u201C: Die Schaltfl\xE4che \u201EL\xF6schen\u201C und \u201EAls Junk markieren\u201C verschieben eine Unterhaltung auch dann in JoyClubs Papierkorb, wenn sie aus ist.",
    "quickSetting.risk": "Bemerkt JoyClub ein Werkzeug, das f\xFCr dich klickt, kann dein Konto eingeschr\xE4nkt oder geschlossen werden. Von allen JoyFox-Funktionen hat diese das h\xF6chste Risiko.",
    "quickSetting.undo": "Um es r\xFCckg\xE4ngig zu machen, stelle die Unterhaltung aus JoyClubs Papierkorb wieder her. \xD6ffne dann das Profil des Mitglieds und w\xE4hle im Men\xFC \u201EProfil nicht mehr ignorieren\u201C.",
    "quickSetting.saved": "Gespeichert. Offene ClubMail-Tabs folgen sofort.",
    "quickSetting.saveFailed": "JoyFox konnte diese Einstellung nicht speichern. Versuche es noch einmal.",
    "sharedEvents.heading": "Gemeinsame Events",
    "sharedEvents.intro": "Dieses Mitglied steht auf der gespeicherten G\xE4steliste dieser Events, die du verfolgst:",
    "eventFilter.label": "JoyFox: zeigen",
    "eventFilter.all": "Alle geladenen Events und Dates",
    "eventFilter.tracked": "Nur Events, die JoyFox verfolgt",
    "eventFilter.note": "Nur Events mit deiner Notiz",
    "eventFilter.attending": "Nur Events, zu denen du gehst",
    "eventFilter.interested": "Nur Events, die dich interessieren",
    "eventFilter.tag": (p) => `Nur Events mit deinem Tag: ${p.tag}`,
    "eventFilter.count": (p, f) => `${f.number(p.shown)} von ${f.number(p.loaded)} geladenen Events angezeigt. Sp\xE4ter geladene Events werden auch gepr\xFCft.`,
    "eventFilter.readFailed": "JoyFox konnte deine Event-Notizen nicht lesen. Lade die Seite neu, um es noch einmal zu versuchen.",
    "eventFilter.noAccount": "W\xE4hle in den JoyFox-Einstellungen ein Konto aus oder f\xFCge eines hinzu, um nach deinen Notizen zu filtern.",
    "eventFilter.badge": "JoyFox",
    "eventFilter.hasNote": "Notiz",
    "typeFilter.legend": "Profiltyp",
    "typeFilter.man": "Mann",
    "typeFilter.woman": "Frau",
    "typeFilter.couple": "Paar",
    "typeFilter.unknown": "Unbekannt",
    "typeFilter.count": (p, f) => `${f.number(p.shown)} von ${f.number(p.loaded)} geladenen angezeigt`,
    "typeFilter.unknownHidden": (p, f) => `${f.number(p.count)} mit unbekanntem Typ ausgeblendet`,
    "typeFilter.scrollHint": "Nach unten scrollen, um mehr zu laden.",
    "typeFilter.unknownMark": "Typ unbekannt",
    "messages.heading": "Nachrichtensuche",
    "messages.hint": "JoyFox speichert die ClubMail-Nachrichten, die du \xF6ffnest, gesendete und empfangene, damit du sie hier durchsuchen kannst. Es speichert nur, was eine Unterhaltung auf dem Bildschirm zeigt, und l\xE4dt nie \xE4ltere Nachrichten. Der Text bleibt in diesem Browser, und eine Exportdatei enth\xE4lt ihn auch. Wenn du JoyFox in privaten Fenstern erlaubst, speichert es die Nachrichten, die du dort \xF6ffnest, genauso.",
    "messages.caching": "Die Nachrichten speichern, die ich in ClubMail \xF6ffne",
    "messages.cachingOn": "Das Speichern von Nachrichten ist an.",
    "messages.cachingOff": "Das Speichern von Nachrichten ist aus. Schon gespeicherte Nachrichten bleiben, bis sie \xE4lter als die hier eingestellte Zeit sind oder bis du sie unter \u201EDeine Daten\u201C l\xF6schst.",
    "messages.offHint": "Das Speichern ist aus: JoyFox speichert keine neuen Nachrichten. Die Suche umfasst weiter die schon gespeicherten Nachrichten.",
    "messages.retentionLabel": "Nachrichten behalten f\xFCr (Monate)",
    "messages.retentionSave": "Speichern",
    "messages.retentionHint": (p, f) => `\xC4ltere Nachrichten werden automatisch gel\xF6scht. Eine kleinere Zahl l\xF6scht \xE4ltere Nachrichten sofort. Standard ist ${f.number(p.default)}. Klicke zum \xDCbernehmen auf \u201ESpeichern\u201C.`,
    "messages.retentionConfirm": "Speichern und l\xF6schen",
    "messages.retentionConfirmPrompt": (p, f) => `Eine kleinere Zahl l\xF6scht die gespeicherten Nachrichten, die \xE4lter als ${f.plural(
      p.months,
      { one: "1 Monat", other: `${f.number(p.months)} Monate` }
    )} sind, sofort. Klicke zum Best\xE4tigen auf \u201ESpeichern und l\xF6schen\u201C.`,
    "messages.retentionSaved": (p, f) => p.deleted === 0 ? "Gespeichert. Keine \xE4ltere Nachricht musste gel\xF6scht werden." : `Gespeichert. ${f.plural(p.deleted, {
      one: "1 \xE4ltere Nachricht wurde",
      other: `${f.number(p.deleted)} \xE4ltere Nachrichten wurden`
    })} gel\xF6scht.`,
    "messages.retentionInvalid": (p, f) => `Gib eine ganze Zahl von ${f.number(p.minimum)} bis ${f.number(p.maximum)} ein. Es wurde nichts ge\xE4ndert.`,
    "messages.noAccount": "W\xE4hle zuerst ein Konto aus oder f\xFCge eines hinzu.",
    "messages.readFailed": "JoyFox konnte deine gespeicherten Nachrichten nicht lesen. Lade die Seite neu, um es noch einmal zu versuchen.",
    "messages.searchLabel": "Meine Nachrichten durchsuchen",
    "messages.count": (p, f) => p.count === 0 ? "Keine gespeicherte Nachricht enth\xE4lt das." : `${f.plural(p.count, {
      one: "1 Nachricht",
      other: `${f.number(p.count)} Nachrichten`
    })} gefunden.`,
    "messages.countLimited": (p, f) => `${f.number(p.count)} Nachrichten gefunden. Die neuesten ${f.number(p.shown)} werden angezeigt.`,
    "messages.sentTo": (p) => `Du an ${p.member} \xB7 ${p.when}`,
    "messages.receivedFrom": (p) => `${p.member} an dich \xB7 ${p.when}`,
    "messages.storedAt": (p) => `gespeichert ${p.when}`,
    "signals.state.complete": "Vollst\xE4ndig",
    "signals.state.incomplete": "Unvollst\xE4ndig",
    "signals.state.unknown": "Vollst\xE4ndigkeit unbekannt",
    "signals.state.unknownShort": "Unbekannt",
    "signals.photos": (p, f) => f.plural(p.count, {
      one: "1 Foto",
      other: `${f.number(p.count)} Fotos`
    }),
    "signals.photosUnknown": "Fotos unbekannt",
    "signals.words": (p, f) => f.plural(p.count, {
      one: "1 Wort",
      other: `${f.number(p.count)} W\xF6rter`
    }),
    "signals.wordsUnknown": "W\xF6rter unbekannt",
    "signals.verified": "verifiziert",
    "signals.notVerified": "nicht verifiziert",
    "signals.verificationUnknown": "Verifizierung unbekannt",
    "signals.heading": "Vollst\xE4ndigkeit des Profils",
    "signals.trust": (p, f) => `Vertrauen ${p.score > 0 ? "+" : ""}${f.number(p.score)}`,
    "signals.trustNoneShort": "Vertrauen \u2013",
    "signals.noteAdd": "Notiz hinzuf\xFCgen",
    "signals.noteEdit": "Notiz",
    "signals.tagsLabel": "Deine Tags",
    "signals.tagCount": (p, f) => f.plural(p.count, {
      one: "1 Tag",
      other: `${f.number(p.count)} Tags`
    }),
    "signals.editor.label": (p) => `JoyFox: Notiz und Tags f\xFCr ${p.member}`,
    "member.number": (p) => `Mitglied ${p.id}`,
    "signals.editor.loading": "Wird geladen \u2026",
    "signals.editor.close": "Schlie\xDFen",
    "signals.editor.noAccount": "W\xE4hle in den JoyFox-Einstellungen ein Konto aus oder f\xFCge eines hinzu, um Notizen zu f\xFChren.",
    "signals.editor.readFailed": "JoyFox konnte die Notizen zu diesem Mitglied nicht lesen. Schlie\xDFe die Notiz und \xF6ffne sie erneut.",
    "signals.filter.label": "JoyFox: unvollst\xE4ndige Profile ausblenden",
    "signals.filter.count": (p, f) => `${f.number(p.hidden)} von ${f.number(p.loaded)} geladenen Profilen ausgeblendet. Profile, \xFCber die JoyFox nichts wei\xDF, bleiben sichtbar.`,
    "compat.heading": "Gemeinsame Vorlieben",
    "compat.shared": (p, f) => `Du teilst ${f.plural(p.count, {
      one: "1 Vorliebe",
      other: `${f.number(p.count)} Vorlieben`
    })} mit diesem Mitglied:`,
    "compat.none": "Du teilst keine Vorlieben mit diesem Mitglied.",
    "compat.listToggle": "Gemeinsame Vorlieben anzeigen",
    "compat.own": (p, f) => `Das ist dein Profil. JoyFox vergleicht andere Profile mit ${f.plural(
      p.count,
      {
        one: "deiner 1 positiven Vorliebe",
        other: `deinen ${f.number(p.count)} positiven Vorlieben`
      }
    )}.`,
    "compat.ownUnknown": "\xD6ffne einmal dein eigenes JoyClub-Profil, damit JoyFox deine Vorlieben kennt.",
    "compat.unreadable": "JoyFox konnte die Vorlieben dieses Profils noch nicht lesen.",
    "compat.missing": "Dieses Profil zeigt keine Vorlieben zum Vergleichen.",
    "compat.readFailed": "JoyFox konnte deine Vorlieben nicht laden. Lade die Seite neu, um es noch einmal zu versuchen.",
    "compat.noAccount": "W\xE4hle in den JoyFox-Einstellungen ein Konto aus oder f\xFCge eines hinzu, um Vorlieben zu vergleichen.",
    "compat.badge": (p, f) => `${f.number(p.count)} gemeinsam`,
    "compat.badgeLabel": (p, f) => `JoyFox: ${f.plural(p.count, {
      one: "1 gemeinsame Vorliebe",
      other: `${f.number(p.count)} gemeinsame Vorlieben`
    })}`,
    "compat.sort.button": "Nach gemeinsamen Vorlieben sortieren",
    "compat.sort.on": "Nach gemeinsamen Vorlieben sortiert. Mitglieder, deren Profil du noch nicht ge\xF6ffnet hast, stehen am Ende.",
    "compat.sort.unavailable": "JoyFox kann die Ergebnisse so, wie JoyClub sie gerade zeigt, nicht sortieren. Ihre Reihenfolge ist unver\xE4ndert.",
    "searches.heading": "Gespeicherte JoyFox-Suchen",
    "searches.loading": "Gespeicherte Suchen werden geladen \u2026",
    "searches.readFailed": "JoyFox konnte deine gespeicherten Suchen nicht lesen. Lade die Seite neu, um es noch einmal zu versuchen.",
    "searches.empty": "Noch keine gespeicherten Suchen.",
    "searches.noAccount": "W\xE4hle in den JoyFox-Einstellungen ein Konto aus oder f\xFCge eines hinzu, um Suchen zu speichern.",
    "searches.save": "Diese Suche speichern",
    "searches.nameLabel": "Name f\xFCr diese Suche",
    "searches.confirmSave": "Speichern",
    "searches.cancel": "Abbrechen",
    "searches.noName": "Gib zuerst einen Namen ein. Es wurde nichts gespeichert.",
    "searches.nameTooLong": (p, f) => `Ein Name darf h\xF6chstens ${f.number(p.maximum)} Zeichen haben. Es wurde nichts gespeichert.`,
    "searches.notSearchAddress": "Die Adresse dieser Seite ist keine Suche, die JoyFox speichern kann. Es wurde nichts gespeichert.",
    "searches.full": (p, f) => `Du hast ${f.number(p.maximum)} gespeicherte Suchen, mehr beh\xE4lt JoyFox nicht. L\xF6sche zuerst eine.`,
    "searches.refused": "Das aktive JoyFox-Konto hat sich ge\xE4ndert, deshalb wurde nichts ge\xE4ndert.",
    "searches.saved": (p) => `\u201E${p.name}\u201C gespeichert.`,
    "searches.noMatch": (p) => `\u201E${p.name}\u201C passt nicht mehr zur Suchadresse von JoyClub, deshalb hat JoyFox die Suche nicht ge\xF6ffnet. F\xFChre die Suche noch einmal aus und speichere sie neu.`,
    "searches.running": (p) => `\u201E${p.name}\u201C wird ausgef\xFChrt \u2026`,
    "searches.runningUnnamed": "Die gespeicherte Suche wird ausgef\xFChrt \u2026",
    "searches.shown": (p) => `\u201E${p.name}\u201C wird angezeigt.`,
    "searches.shownUnnamed": "Die gespeicherte Suche wird angezeigt.",
    "searches.runFailed": "JoyFox konnte die gespeicherte Suche nicht ausf\xFChren. \xD6ffne den Filter von JoyClub und klicke auf \u201EAnwenden\u201C.",
    "searches.deleteLabel": (p) => `Gespeicherte Suche ${p.name} l\xF6schen`,
    "searches.confirmDelete": (p) => `Klicke noch einmal auf \u2715, um \u201E${p.name}\u201C zu l\xF6schen.`,
    "searches.deleted": (p) => `\u201E${p.name}\u201C gel\xF6scht.`,
    "picker.toggle": "JoyFox-Vorlagen",
    "picker.loading": "Vorlagen werden geladen \u2026",
    "picker.readFailed": "JoyFox konnte deine Vorlagen nicht laden. Es wurde nichts eingef\xFCgt. Klicke noch einmal auf \u201EJoyFox-Vorlagen\u201C, um es erneut zu versuchen.",
    "picker.empty": "Noch keine Vorlagen. Lege sie in den JoyFox-Einstellungen an.",
    "picker.noAccount": "Kein JoyFox-Konto ist aktiv. W\xE4hle eines in den JoyFox-Einstellungen.",
    "picker.result.inserted": "Vorlage eingef\xFCgt. Pr\xFCfe den Text und klicke dann selbst auf JoyClubs \u201ESenden\u201C.",
    "picker.result.not-editable": "Das Nachrichtenfeld kann gerade nicht bearbeitet werden. Es wurde nichts eingef\xFCgt. Warte, bis du in das Nachrichtenfeld tippen kannst, und versuche es dann noch einmal.",
    "picker.result.too-long": (p, f) => `Mit der Vorlage w\xE4re die Nachricht ${f.plural(p.over, {
      one: "1 Zeichen",
      other: `${f.number(p.over)} Zeichen`
    })} zu lang. Das Nachrichtenfeld fasst h\xF6chstens ${f.number(p.limit)} Zeichen. Es wurde nichts eingef\xFCgt. K\xFCrze deinen Text oder die Vorlage.`,
    "picker.result.altered": "JoyClub hat den Text nach dem Einf\xFCgen ge\xE4ndert. Pr\xFCfe das Nachrichtenfeld, bevor du sendest.",
    "templates.folder.general": "Allgemein",
    "templates.folder.eventConfirmation": "Event-Zusage",
    "templates.folder.eventCancellation": "Event-Absage",
    // Options page: shell and tabs
    "options.title": "JoyFox-Einstellungen",
    "options.intro": "JoyFox speichert alles lokal in diesem Browserprofil. Die Sortierung des Posteingangs bleibt aus, bis du eine Kontaktregel speicherst.",
    "options.tabs.start": "Erste Schritte",
    "options.tabs.accounts": "Konten",
    "options.tabs.rule": "Kontaktregel",
    "options.tabs.templates": "Vorlagen",
    "options.tabs.events": "Events",
    "options.tabs.messages": "Nachrichten",
    "options.tabs.data": "Deine Daten",
    "options.importRegion": "JoyFox-Daten importieren",
    "options.languageSaveFailed": "JoyFox konnte die Sprache nicht speichern. Versuche es noch einmal.",
    // Options page: Get started
    "start.state.done": "Erledigt",
    "start.state.off": "Gespeichert, aber ausgeschaltet",
    "start.state.todo": "Noch nicht erledigt",
    "start.state.doneOpen": "Erledigt: keine Bedingungen, deshalb ist jede Person qualifiziert",
    "start.ready": "JoyFox ist eingerichtet. \xD6ffne deinen JoyClub-Posteingang, um ihn sortiert zu sehen.",
    "start.intro": "Drei Schritte, ein paar Minuten. Alles bleibt in diesem Browser.",
    "start.introAccess": "Vier Schritte, ein paar Minuten. Alles bleibt in diesem Browser.",
    "start.readFailed": "JoyFox konnte seine Einrichtung nicht lesen. Lade die Seite neu, um es noch einmal zu versuchen.",
    "start.step.access": "Erlaube JoyFox den Zugriff auf joyclub.de. Der Zugriff ist gerade aus, deshalb kann JoyFox auf JoyClub nicht arbeiten.",
    "start.step.account": "F\xFCge dein JoyClub-Konto unter [Konten](#accounts) hinzu. JoyFox macht das erste Konto aktiv.",
    "start.step.chooseAccount": "W\xE4hle das aktive Konto unter [Konten](#accounts) aus.",
    "start.step.rule": "Speichere eine Kontaktregel unter [Kontaktregel](#rule). Die Sortierung des Posteingangs bleibt aus, bis eine Regel gespeichert und eingeschaltet ist.",
    "start.step.inbox": "\xD6ffne deinen JoyClub-Posteingang (www.joyclub.de, ClubMail). JoyFox zeigt seine Tabs \xFCber der Liste.",
    // Options page: site access (Get started)
    "access.allow": "Zugriff auf joyclub.de erlauben",
    "access.granted": "Der Zugriff auf joyclub.de ist an. Lade offene JoyClub-Tabs neu, damit JoyFox dort arbeiten kann.",
    "access.refused": "Der Zugriff auf joyclub.de ist weiterhin aus. JoyFox kann auf JoyClub erst arbeiten, wenn du den Zugriff hier oder unter about:addons erlaubst.",
    // Options page: accounts
    "accounts.readFailed": "JoyFox konnte die gespeicherten Konten nicht lesen. Es wurde kein Konto ge\xE4ndert. Lade die Seite neu, um es noch einmal zu versuchen.",
    "accounts.hint": "JoyFox kann nicht lesen, mit welchem JoyClub-Login ein Tab arbeitet. Aktiv ist das Konto, das du hier ausw\xE4hlst. JoyFox speichert deine Notizen, Tags, Regeln, Vorlagen und andere Daten unter diesem Konto.",
    "accounts.activeLabel": "Aktives Konto:",
    "accounts.noneSelected": "Keines ausgew\xE4hlt",
    "accounts.empty": "Noch keine Konten. F\xFCge unten ein Konto hinzu, um JoyFox zu verwenden.",
    "accounts.list": "Gespeicherte Konten",
    "accounts.nameWithIdentifier": (p) => `${p.label} (${p.identifier})`,
    "accounts.active": "Aktiv",
    "accounts.inactive": "Nicht aktiv",
    "accounts.use": "Dieses Konto verwenden",
    "accounts.useLabel": (p) => `Dieses Konto verwenden: ${p.name}`,
    "accounts.nowActive": (p) => `Aktives Konto ist jetzt ${p.name}.`,
    "accounts.rename": "Umbenennen",
    "accounts.renameLabel": (p) => `Umbenennen: Konto ${p.name}`,
    "accounts.renameField": (p) => `Neuer Anzeigename f\xFCr ${p.identifier}`,
    "accounts.renameSave": "Speichern",
    "accounts.renameCancel": "Abbrechen",
    "accounts.renamed": (p) => `Anzeigename gespeichert. JoyFox zeigt dieses Konto jetzt als ${p.name}.`,
    "accounts.remove": "Entfernen",
    "accounts.confirmRemove": "Entfernen best\xE4tigen",
    "accounts.removeLabel": (p) => `Entfernen: Konto ${p.name}`,
    "accounts.confirmRemoveLabel": (p) => `Entfernen best\xE4tigen: Konto ${p.name} und alle seine Daten`,
    "accounts.removePrompt": (p) => `Wenn du ${p.name} entfernst, l\xF6scht JoyFox alles, was es f\xFCr dieses Konto gespeichert hat, zum Beispiel Notizen, Tags, Regeln, Vorlagen, Nachrichten, Event-Notizen und gespeicherte Suchen. Klicke zum Best\xE4tigen noch einmal.`,
    "accounts.removed": (p) => `${p.name} und die gespeicherten Daten wurden entfernt.`,
    "accounts.removedNoneActive": (p) => `${p.name} und die gespeicherten Daten wurden entfernt. Jetzt ist kein Konto aktiv. W\xE4hle eines mit \u201EDieses Konto verwenden\u201C.`,
    "accounts.removedNoneLeft": (p) => `${p.name} und die gespeicherten Daten wurden entfernt. Es gibt keine Konten mehr. F\xFCge ein Konto hinzu, um JoyFox zu verwenden.`,
    "accounts.addForm": "Konto hinzuf\xFCgen",
    "accounts.identifier": "JoyClub-Kontokennung",
    "accounts.identifierHint": "Dein JoyClub-Nickname eignet sich gut. JoyFox verwendet ihn nur, um deine Konten zu unterscheiden und Importe zuzuordnen. JoyFox pr\xFCft ihn nicht. Du kannst ihn sp\xE4ter nicht \xE4ndern.",
    "accounts.label": "Anzeigename (optional)",
    "accounts.labelHint": "Nur JoyFox zeigt diesen Namen. Wenn du ihn leer l\xE4sst, zeigt JoyFox die Kennung.",
    "accounts.add": "Konto hinzuf\xFCgen",
    "accounts.added": (p) => `${p.name} wurde hinzugef\xFCgt.`,
    // Options page: contact rule
    "rule.readFailed": "JoyFox konnte die Kontaktregel nicht lesen. Es wurde keine Regel ge\xE4ndert. Lade die Seite neu, um es noch einmal zu versuchen.",
    "rule.hint": "Die Regel \xE4ndert nur, wie JoyFox deinen eigenen Posteingang in \u201EQualifiziert\u201C, \u201EZu pr\xFCfen\u201C und \u201EJunk\u201C gruppiert. Sie h\xE4lt keine Nachricht auf, l\xF6scht nichts, und die sendende Person sieht nichts davon.",
    "rule.noAccount": "W\xE4hle zuerst ein Konto aus oder f\xFCge eines hinzu. Jedes Konto hat seine eigene Regel.",
    "rule.newer": "Diese Regel wurde mit einer neueren JoyFox-Version erstellt und kann hier nicht bearbeitet werden. L\xF6sche sie, um eine neue anzulegen.",
    "rule.note.saved": "F\xFCr das aktive Konto ist eine Regel gespeichert.",
    "rule.note.none": "F\xFCr das aktive Konto ist keine Regel gespeichert, deshalb sortiert JoyFox den Posteingang nicht.",
    "rule.enabled": "Meinen JoyClub-Posteingang mit dieser Regel sortieren",
    "rule.placementLabel": "Einordnung, wenn die Regel nicht erf\xFCllt ist:",
    "rule.spamHint": "Der Spam-Status ist vorerst unbekannt: JoyFox pr\xFCft Nachrichten noch nicht auf Vorlagen. Nur deine eigenen Korrekturen \u201Ekein Spam\u201C z\xE4hlen. Der Posteingang zeigt nur das Verifizierungssymbol. Fotos, W\xF6rter im Profil und Kontoalter stammen aus Profilen, die du vorher ge\xF6ffnet hast.",
    "rule.autosaveHint": "\xC4nderungen werden automatisch gespeichert: ein K\xE4stchen oder eine Auswahl sofort, eine Zahl oder ein Text, sobald du das Feld verl\xE4sst.",
    "rule.firstMessageHint": "\u201EErste Nachricht enth\xE4lt\u201C liest die Nachrichtenvorschau in deinem Posteingang und beachtet keine Gro\xDF- und Kleinschreibung. Der Posteingang zeigt nur die neueste Nachricht. Wenn eine Person mehr als eine Nachricht gesendet hat, ist die Vorschau deshalb vielleicht nicht die erste. Wenn die Vorschau deinen Text nicht enth\xE4lt, z\xE4hlt die Bedingung nach deiner Wahl unter \u201EWenn JoyFox das nicht sehen kann\u201C. Sobald JoyFox deinen Text sieht, bleibt die Bedingung erf\xFCllt.",
    "rule.preset.label": "Mit einer Vorgabe beginnen",
    "rule.preset.choose": "Vorgabe w\xE4hlen \u2026",
    "rule.preset.apply": "Vorgabe \xFCbernehmen",
    "rule.preset.confirm": "Bedingungen ersetzen",
    "rule.preset.confirmPrompt": "Die Vorgabe ersetzt alle Bedingungen unten. Klicke zur Best\xE4tigung auf \u201EBedingungen ersetzen\u201C.",
    "rule.preset.hint": "Eine Vorgabe setzt die Bedingungen unten und speichert sie. Danach kannst du sie wie jede andere Regel \xE4ndern.",
    "rule.preset.open": "Offen",
    "rule.preset.complete": "Nur vollst\xE4ndige Profile",
    "rule.preset.verified": "Verifizierte Mitglieder",
    "rule.preset.highTrust": "Mitglieder mit hohem Vertrauen",
    "rule.preset.custom": "Eigene",
    "rule.preset.describe.open": "Keine Bedingungen: Jede Person ist qualifiziert.",
    "rule.preset.describe.complete": (p, f) => `Eine Person braucht mindestens ${f.number(p.photos)} Fotos und mindestens ${f.number(p.words)} W\xF6rter im Profil.`,
    "rule.preset.describe.verified": "Eine Person muss von JoyClub verifiziert sein.",
    "rule.preset.describe.highTrust": (p, f) => `Eine Person muss von JoyClub verifiziert sein und braucht mindestens ${f.number(p.photos)} Fotos, mindestens ${f.number(p.words)} W\xF6rter im Profil und ein Konto, das mindestens ${f.number(p.days)} Tage alt ist.`,
    "rule.preset.describe.custom": "Entfernt alle Bedingungen, damit du die gew\xFCnschten ankreuzen kannst.",
    "rule.preset.applied": (p) => `Vorgabe \u201E${p.preset}\u201C \xFCbernommen und gespeichert. Du kannst ihre Bedingungen unten \xE4ndern.`,
    "rule.preset.appliedOpen": "Vorgabe \u201EOffen\u201C \xFCbernommen und gespeichert. Die Regel hat keine Bedingungen, deshalb ist jede Person qualifiziert.",
    "rule.preset.appliedCustom": "Alle Bedingungen entfernt und gespeichert. Kreuze die gew\xFCnschten Bedingungen an. Bis dahin ist jede Person qualifiziert.",
    "rule.editor": "Editor:",
    "rule.simple": "Einfach",
    "rule.advanced": "Erweitert",
    "rule.match.all": "ALLEN",
    "rule.match.any": "MINDESTENS EINER",
    "rule.box.all": "Eine Person ist qualifiziert, wenn ALLE diese Bedingungen erf\xFCllt sind",
    "rule.box.any": "Oder eine Person ist qualifiziert, wenn MINDESTENS EINE dieser Bedingungen erf\xFCllt ist",
    "rule.unknown.needs-review": "In \u201EZu pr\xFCfen\u201C einordnen",
    "rule.unknown.met": "Als erf\xFCllt z\xE4hlen",
    "rule.unknown.not-met": "Als nicht erf\xFCllt z\xE4hlen",
    "rule.unknownPrompt": "Wenn JoyFox das nicht sehen kann:",
    "rule.unknownLabel": (p) => `${p.condition}: wenn JoyFox das nicht sehen kann`,
    "rule.valueLabel": (p) => `${p.condition}: Wert`,
    "rule.numberProblem": (p, f) => `Gib f\xFCr \u201E${p.condition}\u201C eine ganze Zahl von ${f.number(p.minimum)} bis ${f.number(p.maximum)} ein.`,
    "rule.textPlaceholder": "Wort, Formulierung oder Emoji",
    "rule.textLabel": (p) => `${p.condition}: Wort, Formulierung oder Emoji`,
    "rule.textProblem": (p, f) => `Gib f\xFCr \u201E${p.condition}\u201C ein Wort, eine Formulierung oder ein Emoji mit h\xF6chstens ${f.number(p.maximum)} Zeichen ein.`,
    "rule.fieldNumberProblem": (p, f) => `Gib eine ganze Zahl von ${f.number(p.minimum)} bis ${f.number(p.maximum)} ein.`,
    "rule.fieldTextProblem": (p, f) => `Gib ein Wort, eine Formulierung oder ein Emoji mit h\xF6chstens ${f.number(p.maximum)} Zeichen ein.`,
    "rule.textHint": "Gib ein Wort, eine Formulierung oder ein Emoji ein, um diese Bedingung zu verwenden.",
    "rule.spamNote": "(noch nicht gepr\xFCft: immer unbekannt)",
    "rule.combine.label": "Wie die Gruppen verkn\xFCpft werden",
    "rule.combine.prefix": "Eine Person ist qualifiziert bei ",
    "rule.combine.suffix": " dieser Gruppen.",
    "rule.advancedHint": "Jede Gruppe ist erf\xFCllt bei ALLEN oder MINDESTENS EINER ihrer Bedingungen, wie du es w\xE4hlst. Setze ein H\xE4kchen bei \u201Enicht\u201C, um eine Bedingung umzukehren: \u201Enicht Mindestanzahl Fotos 3\u201C bedeutet weniger als 3 Fotos. Eine Gruppe ohne Bedingungen wird nicht gespeichert.",
    "rule.addRule": "+ Gruppe hinzuf\xFCgen",
    "rule.removeRule": "Gruppe entfernen",
    "rule.confirmRemoveGroup": "Entfernen best\xE4tigen",
    "rule.confirmRemoveGroupLabel": (p, f) => `Entfernen best\xE4tigen: Gruppe ${f.number(p.number)}`,
    "rule.removeGroupPrompt": (p, f) => `Klicke noch einmal, um Gruppe ${f.number(p.number)} und ihre Bedingungen zu entfernen.`,
    "rule.ruleSuffix": " dieser Bedingungen",
    "rule.noConditions": "Noch keine Bedingungen. F\xFCge unten eine hinzu.",
    "rule.removeCondition": "Bedingung entfernen",
    "rule.removeConditionLabel": (p) => `${p.condition} entfernen`,
    "rule.not": "nicht",
    "rule.notTitle": "Diese Bedingung umkehren",
    "rule.notLabel": (p) => `nicht: \u201E${p.condition}\u201C umkehren`,
    "rule.joiner.all": "UND",
    "rule.joiner.any": "ODER",
    "rule.ruleTitle": (p, f) => `Gruppe ${f.number(p.number)}: erf\xFCllt bei `,
    "rule.ruleMatchLabel": (p, f) => `Wie Gruppe ${f.number(p.number)} ihre Bedingungen verkn\xFCpft`,
    "rule.removeRuleLabel": (p, f) => `Gruppe entfernen: Nr. ${f.number(p.number)}`,
    "rule.addConditionLabel": (p, f) => `Bedingung zu Gruppe ${f.number(p.number)} hinzuf\xFCgen`,
    "rule.addCondition": "+ Bedingung hinzuf\xFCgen \u2026",
    "rule.ruleCount": (p, f) => `${f.number(p.count)} von ${f.number(p.maximum)} Gruppen`,
    "rule.simpleUnavailable.all": "Die einfache Ansicht ist nicht verf\xFCgbar: Die Gruppen sind mit ALLEN verkn\xFCpft.",
    "rule.simpleUnavailable.not": "Die einfache Ansicht ist nicht verf\xFCgbar: Die Regel verwendet \u201Enicht\u201C.",
    "rule.simpleUnavailable.severalAll": "Die einfache Ansicht ist nicht verf\xFCgbar: Mehr als eine Gruppe verlangt ALLE von mehreren Bedingungen.",
    "rule.simpleUnavailable.duplicate": "Die einfache Ansicht ist nicht verf\xFCgbar: Eine Bedingung steht in mehr als einer Gruppe.",
    "rule.savedNoConditions": "Regel gespeichert. Sie hat noch keine Bedingungen, deshalb ist jede Person qualifiziert.",
    "rule.savedVacuous": "Regel gespeichert. Ohne Eintr\xE4ge im ALLE-Kasten ist jede Person qualifiziert, deshalb wirkt der MINDESTENS-EINE-Kasten nicht.",
    "rule.saved": "Regel gespeichert. Offene JoyClub-Tabs werden sofort aktualisiert.",
    "rule.notSaved": (p) => `${p.problem} Die Regel wurde nicht gespeichert.`,
    "rule.saveFailed": "JoyFox konnte die Regel nicht speichern. Es wurde nichts ge\xE4ndert. \xC4ndere das Feld noch einmal, oder lade die Seite neu, um die gespeicherte Regel zu sehen.",
    "rule.deleteAll": "Ganze Kontaktregel l\xF6schen",
    "rule.confirmDeleteAll": "L\xF6schen best\xE4tigen",
    "rule.deletePrompt": "Klicke noch einmal, um die ganze Kontaktregel zu l\xF6schen. JoyFox sortiert den Posteingang f\xFCr dieses Konto dann nicht mehr.",
    "rule.removed": "Kontaktregel gel\xF6scht. JoyFox sortiert den Posteingang f\xFCr dieses Konto nicht mehr.",
    "rule.removeFailed": "JoyFox konnte die Regel nicht l\xF6schen. Es wurde nichts ge\xE4ndert. Versuche es noch einmal. Wenn es weiter nicht klappt, lade die Seite neu.",
    "rule.stale.account.saved": "Das aktive Konto hat sich ge\xE4ndert, deshalb wurde die Regel nicht gespeichert. Pr\xFCfe im Tab \u201EKonten\u201C das aktive Konto, bevor du die Regel noch einmal \xE4nderst.",
    "rule.stale.account.removed": "Das aktive Konto hat sich ge\xE4ndert, deshalb wurde die Regel nicht gel\xF6scht. Pr\xFCfe im Tab \u201EKonten\u201C das aktive Konto, bevor du noch einmal eine Regel l\xF6schst.",
    "rule.stale.rule.saved": "Die Regel wurde in einem anderen Tab ge\xE4ndert. Sie wurde nicht gespeichert. Das Formular zeigt jetzt die gespeicherte Regel.",
    "rule.stale.rule.removed": "Die Regel wurde in einem anderen Tab ge\xE4ndert. Sie wurde nicht gel\xF6scht. Das Formular zeigt jetzt die gespeicherte Regel.",
    "rule.changedElsewhere": "Die Regel wurde in einem anderen Tab ge\xE4ndert. Das Formular zeigt jetzt die gespeicherte Regel.",
    // Options page: templates
    "templates.readFailed": "JoyFox konnte deine Vorlagen nicht lesen. Es wurde keine Vorlage ge\xE4ndert. Lade die Seite neu, um es noch einmal zu versuchen.",
    "templates.heading": "Nachrichtenvorlagen",
    "templates.hint": "In einer JoyClub-Unterhaltung f\xFCgt die Schaltfl\xE4che \u201EJoyFox-Vorlagen\u201C unter dem Nachrichtenfeld eine Vorlage an der Cursorposition ein. Du kannst den Text danach noch \xE4ndern, und du klickst JoyClubs \u201ESenden\u201C immer selbst. JoyFox sendet nie eine Nachricht.",
    "templates.noAccount": "W\xE4hle unter [Konten](#accounts) ein aktives Konto, um Vorlagen zu speichern.",
    "templates.empty": "Noch keine Vorlagen. F\xFCge unten eine hinzu.",
    "templates.inFolder": (p) => `Vorlagen in ${p.folder}`,
    "templates.edit": "Bearbeiten",
    "templates.editLabel": (p) => `Bearbeiten: Vorlage ${p.name}`,
    "templates.editing": (p) => `Du bearbeitest ${p.name}.`,
    "templates.delete": "L\xF6schen",
    "templates.confirmDelete": "L\xF6schen best\xE4tigen",
    "templates.deleteLabel": (p) => `L\xF6schen: Vorlage ${p.name}`,
    "templates.confirmDeleteLabel": (p) => `L\xF6schen best\xE4tigen: Vorlage ${p.name}`,
    "templates.deletePrompt": (p) => `Klicke auf \u201EL\xF6schen best\xE4tigen\u201C, um ${p.name} zu l\xF6schen.`,
    "templates.deleted": (p) => `${p.name} wurde gel\xF6scht.`,
    "templates.addForm": "Vorlage hinzuf\xFCgen",
    "templates.name": "Name",
    "templates.folder": "Ordner (optional, leer bedeutet Allgemein)",
    "templates.text": "Text",
    "templates.saveChanges": "\xC4nderungen speichern",
    "templates.add": "Vorlage hinzuf\xFCgen",
    "templates.cancel": "Bearbeiten abbrechen",
    "templates.saved": (p) => `${p.name} wurde gespeichert.`,
    "templates.added": (p) => `${p.name} wurde hinzugef\xFCgt.`,
    "templates.accountChanged": "Das aktive Konto hat sich ge\xE4ndert, deshalb wurde nichts ge\xE4ndert. Pr\xFCfe im Tab \u201EKonten\u201C das aktive Konto, bevor du es noch einmal versuchst.",
    // Options page: your data
    "entity.extensionAccounts": "Kontodatensatz",
    "entity.joyClubMembers": "Mitglieder",
    "entity.profileSnapshots": "Profil-Momentaufnahmen",
    "entity.userNotes": "Notizen",
    "entity.userTags": "Tags",
    "entity.trustSignals": "Erfasste Erfahrungen",
    "entity.contactRules": "Kontaktregeln",
    "entity.conversationClassifications": "Eigene Einordnungen",
    "entity.savedSearches": "Gespeicherte Suchen",
    "entity.eventMetadata": "Event-Notizen",
    "entity.spendLogEntries": "Ausgabenprotokoll",
    "entity.syncConfigs": "Sync-Einstellungen",
    "entity.extensionPreferences": "Einstellungen",
    "entity.messageTemplates": "Nachrichtenvorlagen",
    "entity.spamPhrases": "Spam-Formulierungen",
    "entity.messageObservations": "Zwischengespeicherte Nachrichtentexte (normalisiert)",
    "entity.senderSpamOverrides": "Korrekturen \u201Ekein Spam\u201C",
    "entity.actionLogs": "Aktionsprotokoll",
    "entity.messagePhraseMatches": "Gefundene Formulierungen in Nachrichten",
    "entity.cachedMessages": "Gespeicherte Nachrichten (f\xFCr die Suche)",
    "data.readFailed": "JoyFox konnte die gespeicherten Daten nicht lesen. Es wurde nichts ge\xE4ndert. Lade die Seite neu, um es noch einmal zu versuchen.",
    "data.hint": "Alles, was JoyFox speichert, bleibt in diesem Browserprofil. Hier kannst du es ansehen, als JSON-Datei speichern und l\xF6schen. L\xF6schen hier \xE4ndert nie etwas auf JoyClub.",
    "data.importPointer": "Eine Datei importierst du unter [Konten](#accounts).",
    "data.noAccounts": "Noch keine Konten.",
    "data.accountPicker": "Konto zum Ansehen (\xE4ndert das aktive Konto nicht)",
    "data.caption": "Gespeicherte Datens\xE4tze dieses Kontos",
    "data.col.type": "Datentyp",
    "data.col.records": "Datens\xE4tze",
    "data.col.actions": "Aktionen",
    "data.show": "Zeigen",
    "data.hide": "Ausblenden",
    "data.showLabel": (p) => `Zeigen: ${p.label}`,
    "data.hideLabel": (p) => `Ausblenden: ${p.label}`,
    "data.deleteAll": "Alle l\xF6schen",
    "data.deleteAllLabel": (p) => `Alle l\xF6schen: ${p.label}`,
    "data.deleteAllPrompt": (p, f) => `Klicke auf \u201EBest\xE4tigen\u201C, um alle ${f.number(p.count)} Datens\xE4tze \u201E${p.label}\u201C dieses Kontos zu l\xF6schen.`,
    "data.deletedAll": (p) => `Alle Datens\xE4tze \u201E${p.label}\u201C dieses Kontos wurden gel\xF6scht.`,
    "data.recordsTitle": (p, f) => `${p.label} (${f.number(p.count)})`,
    "data.accountRecordHint": "Der Kontodatensatz wird nur mit dem ganzen Konto entfernt, unter [Konten](#accounts).",
    "data.recordSummary": (p) => `${p.id} (ge\xE4ndert: ${p.updated})`,
    "data.recordSummaryNamed": (p) => `${p.name}: ${p.id} (ge\xE4ndert: ${p.updated})`,
    "data.recordNamed": (p) => `${p.name} (${p.id})`,
    "data.valueYes": "ja",
    "data.valueNo": "nein",
    "data.valueEmpty": "(leer)",
    "data.rawJson": "Gespeichertes JSON",
    "data.moreCharacters": (p, f) => `\u2026und ${f.number(p.count)} weitere Zeichen (siehe \u201EGespeichertes JSON\u201C)`,
    "data.moreValues": (p, f) => `\u2026und ${f.number(p.count)} weitere (siehe \u201EGespeichertes JSON\u201C)`,
    "data.delete": "L\xF6schen",
    "data.deleteRecordLabel": (p) => `L\xF6schen: Datensatz ${p.record}`,
    "data.deleteRecordPrompt": (p) => `Klicke auf \u201EBest\xE4tigen\u201C, um den Datensatz ${p.record} zu l\xF6schen.`,
    "data.deletedRecord": (p) => `Datensatz ${p.record} wurde gel\xF6scht.`,
    "data.showMore": (p, f) => `${f.number(p.count)} weitere zeigen`,
    "data.exportAccount": "Dieses Konto exportieren (JSON)",
    "data.exportedAccount": "Der Export dieses Kontos wurde erstellt.",
    "data.deleteAccountData": "Daten dieses Kontos l\xF6schen",
    "data.deleteAccountDataLabel": "Daten dieses Kontos l\xF6schen (alle Datens\xE4tze)",
    "data.deleteAccountDataPrompt": "Klicke auf \u201EBest\xE4tigen\u201C, um alle Datens\xE4tze dieses Kontos zu l\xF6schen. Das Konto selbst bleibt unter \u201EKonten\u201C.",
    "data.deletedAccountData": "Alle Daten dieses Kontos wurden gel\xF6scht. Das Konto selbst bleibt erhalten.",
    "data.allAccounts": "Alle Konten",
    "data.retentionLabel": "Gespeicherte Profil-Momentaufnahmen je Mitglied",
    "data.retentionHint": (p, f) => `JoyFox beh\xE4lt die neuesten Momentaufnahmen der Profilangaben jedes Mitglieds, immer mindestens die letzte. Eine kleinere Zahl l\xF6scht \xE4ltere Momentaufnahmen sofort, in allen Konten. Von ${f.number(p.minimum)} bis ${f.number(p.maximum)}; Standard ist ${f.number(p.default)}. Klicke auf \u201ESpeichern\u201C, um die Zahl zu \xFCbernehmen.`,
    "data.retentionSave": "Speichern",
    "data.retentionConfirm": "Speichern und l\xF6schen",
    "data.retentionConfirmPrompt": (p, f) => `Eine kleinere Zahl l\xF6scht \xE4ltere Momentaufnahmen sofort, in allen Konten: F\xFCr jedes Mitglied bleibt nur ${f.plural(
      p.keep,
      {
        one: "die neueste Momentaufnahme",
        other: `die neuesten ${f.number(p.keep)} Momentaufnahmen`
      }
    )}. Klicke zum Best\xE4tigen auf \u201ESpeichern und l\xF6schen\u201C.`,
    "data.retentionSaved": (p, f) => p.deleted === 0 ? "Gespeichert. Keine Momentaufnahme musste gel\xF6scht werden." : `Gespeichert. ${f.plural(p.deleted, {
      one: "1 \xE4ltere Momentaufnahme wurde",
      other: `${f.number(p.deleted)} \xE4ltere Momentaufnahmen wurden`
    })} gel\xF6scht.`,
    "data.retentionInvalid": (p, f) => `Gib eine ganze Zahl von ${f.number(p.minimum)} bis ${f.number(p.maximum)} ein. Es wurde nichts ge\xE4ndert.`,
    "data.retentionFailed": "JoyFox konnte die Einstellung nicht speichern. Das Feld zeigt die Zahl, die jetzt gilt. Versuche es noch einmal.",
    "data.reminderLabel": "An den Export aller Daten erinnern nach (Tagen)",
    "data.reminderHint": (p, f) => `JoyFox-Daten bleiben in diesem Browserprofil, auch wenn du den Browser schlie\xDFt. Wenn du JoyFox entfernst oder das Profil verlierst, sind die Daten weg. Ein vollst\xE4ndiger Export ist deine Sicherung. Diese Seite bittet um einen, wenn der letzte vollst\xE4ndige Export \xE4lter als diese Zahl von Tagen ist. 0 schaltet die Erinnerung aus. Von ${f.number(p.minimum)} bis ${f.number(p.maximum)}; Standard ist ${f.number(p.default)}. Klicke auf \u201ESpeichern\u201C, um die Zahl zu \xFCbernehmen.`,
    "data.reminderSave": "Speichern",
    "data.reminderSaved": (p, f) => p.days === 0 ? "Gespeichert. Die Export-Erinnerung ist aus." : `Gespeichert. JoyFox erinnert dich ${f.plural(p.days, {
      one: "1 Tag",
      other: `${f.number(p.days)} Tage`
    })} nach dem letzten vollst\xE4ndigen Export.`,
    "data.reminderInvalid": (p, f) => `Gib eine ganze Zahl von ${f.number(p.minimum)} bis ${f.number(p.maximum)} ein. Es wurde nichts ge\xE4ndert.`,
    "data.reminderNever": "Du hast noch nicht alle JoyFox-Daten exportiert. Wenn du JoyFox entfernst oder dieses Browserprofil verlierst, sind die Daten weg. Klicke auf \u201EAlle JoyFox-Daten exportieren (JSON)\u201C, um eine Sicherung zu speichern.",
    "data.reminderDue": (p, f) => `Dein letzter vollst\xE4ndiger Export war ${f.plural(p.days, {
      one: "vor 1 Tag",
      other: `vor ${f.number(p.days)} Tagen`
    })}. Wenn du JoyFox entfernst oder dieses Browserprofil verlierst, sind neuere Daten weg. Klicke auf \u201EAlle JoyFox-Daten exportieren (JSON)\u201C, um eine Sicherung zu speichern.`,
    "data.lastExport": (p, f) => p.days === 0 ? "Letzter vollst\xE4ndiger Export: heute." : `Letzter vollst\xE4ndiger Export: ${f.plural(p.days, {
      one: "vor 1 Tag",
      other: `vor ${f.number(p.days)} Tagen`
    })}.`,
    "data.exportAll": "Alle JoyFox-Daten exportieren (JSON)",
    "data.exportedAll": "Der Export aller JoyFox-Daten wurde erstellt.",
    "data.deleteEverything": "Alle JoyFox-Daten l\xF6schen",
    "data.deleteEverythingLabel": "Alle JoyFox-Daten l\xF6schen (in diesem Browser)",
    "data.deleteEverythingPrompt": "Klicke auf \u201EBest\xE4tigen\u201C, um alle Konten, alle Datens\xE4tze und alle JoyFox-Einstellungen in diesem Browser zu l\xF6schen. Das kann nicht r\xFCckg\xE4ngig gemacht werden.",
    "data.deletedEverything": "Alle JoyFox-Daten in diesem Browser wurden gel\xF6scht.",
    "data.confirm": "Best\xE4tigen",
    "data.confirmLabel": (p) => `Best\xE4tigen: ${p.label}`,
    "data.actionFailed": "JoyFox konnte das L\xF6schen nicht abschlie\xDFen. Einige Datens\xE4tze sind vielleicht schon gel\xF6scht: Die angezeigten Zahlen zeigen, was noch gespeichert ist. Versuche es noch einmal.",
    "data.exportFailed": "JoyFox konnte den Export nicht erstellen. Es wurde nichts exportiert. Versuche es noch einmal.",
    "data.import.title": "Importieren",
    "data.import.hint": "Importiere eine JoyFox-Exportdatei: alles oder ein Konto. Sie wird mit dem zusammengef\xFChrt, was hier gespeichert ist. Ein Konto mit derselben JoyClub-Kennung wird mit dem vorhandenen Konto zusammengef\xFChrt. Bei derselben Notiz, Regel oder Einordnung gewinnt die neuere Version. Vorhandene Tags und Korrekturen bleiben erhalten. Der Import beginnt, sobald du die Datei w\xE4hlst, und danach siehst du, was sich ge\xE4ndert hat.",
    "data.import.fileLabel": "JoyFox-Exportdatei (JSON)",
    "data.import.summary.all": (p, f) => `Dieser vollst\xE4ndige Export enth\xE4lt ${f.plural(p.total, {
      one: "1 Konto",
      other: `${f.number(p.total)} Konten`
    })}: ${f.number(p.matched)} mit einem vorhandenen Konto zusammengef\xFChrt, ${f.number(p.added)} neu hinzugef\xFCgt.`,
    "data.import.summary.account": (p, f) => `Dieser Export eines einzelnen Kontos enth\xE4lt ${f.plural(p.total, {
      one: "1 Konto",
      other: `${f.number(p.total)} Konten`
    })}: ${f.number(p.matched)} mit einem vorhandenen Konto zusammengef\xFChrt, ${f.number(p.added)} neu hinzugef\xFCgt.`,
    "data.import.caption": "Was der Import ge\xE4ndert hat",
    "data.import.col.added": "Hinzugef\xFCgt",
    "data.import.col.replaced": "Ersetzt (neuer)",
    "data.import.col.kept": "Behalten",
    "data.import.col.duplicates": "\xDCbersprungene Duplikate",
    "data.import.noRecords": "Die Datei enth\xE4lt keine Datens\xE4tze.",
    "data.setting.activeAccount": "aktives Konto",
    "data.setting.language": "Sprache",
    "data.setting.messageCaching": "Nachrichten speichern",
    "data.setting.messageRetention": "Nachrichten behalten f\xFCr",
    "data.setting.quickIgnoreDelete": "Schaltfl\xE4che \u201EIgnorieren und l\xF6schen\u201C",
    "data.setting.stripCollapsed": "JoyFox-Leiste eingeklappt",
    "data.setting.templatePicker": "Vorlagenauswahl",
    "data.setting.sharedEventException": "Ausnahme f\xFCr gemeinsame Events",
    "data.setting.snapshotRetention": "Momentaufnahmen je Mitglied",
    "data.setting.exportReminder": "Export-Erinnerung",
    "data.setting.diagnostics": "Diagnose",
    "data.import.settingsUnknown": "Die Datei enth\xE4lt au\xDFerdem Einstellungen, die diese JoyFox-Version nicht kennt. Sie wurden nicht importiert.",
    "data.import.settingsSkipped": (p) => `Einstellungen in der Datei, die nie importiert werden (sie schalten Funktionen ein): ${p.keys}.`,
    "data.import.settingsNotSaved": (p) => `Einstellungen, die nicht gespeichert werden konnten: ${p.keys}.`,
    "data.import.settingsAdded": (p) => `Hinzugef\xFCgte Einstellungen (nur solche, die hier nicht gesetzt waren): ${p.keys}.`,
    "data.import.running": "Die Datei wird importiert.",
    "data.import.nothing": "Alles in dieser Datei ist schon gespeichert. Es wurde nichts ge\xE4ndert.",
    "data.import.complete": (p, f) => `Import abgeschlossen: ${f.number(p.added)} Datens\xE4tze hinzugef\xFCgt, ${f.number(p.replaced)} durch eine neuere Version ersetzt.`,
    "data.import.completeSettingsFailed": (p, f) => `Import abgeschlossen: ${f.number(p.added)} Datens\xE4tze hinzugef\xFCgt, ${f.number(p.replaced)} durch eine neuere Version ersetzt. Einige Einstellungen konnten nicht gespeichert werden (siehe oben). Stelle sie selbst noch einmal ein.`,
    "data.import.incomplete": "JoyFox konnte den Import nicht abschlie\xDFen. W\xE4hle die Datei noch einmal, um es erneut zu versuchen: Bereits gespeicherte Datens\xE4tze werden nicht doppelt hinzugef\xFCgt.",
    "data.import.unreadable": "JoyFox konnte diese Datei nicht pr\xFCfen. Es wurde nichts importiert. W\xE4hle die Datei noch einmal. Wenn es weiter nicht klappt, lade die Seite neu oder exportiere die Datei noch einmal aus JoyFox.",
    // Errors the UI shows
    "error.withSuffix.nothingChanged": (p) => `${p.error}. Es wurde nichts ge\xE4ndert.`,
    "error.withSuffix.nothingImported": (p) => `${p.error}. Es wurde nichts importiert.`,
    "error.withSuffix.nothingDeleted": (p) => `${p.error}. Es wurde nichts gel\xF6scht.`,
    "error.withSuffix.nothingExported": (p) => `${p.error}. Es wurde nichts exportiert. Versuche es noch einmal.`,
    "error.withSuffix.settingNotChanged": (p) => `${p.error}. Die Einstellung wurde nicht ge\xE4ndert. Versuche es noch einmal.`,
    "error.account.emptyIdentifier": "Gib zuerst die Kennung deines JoyClub-Kontos ein",
    "error.account.duplicate": "Ein Konto mit dieser Kennung ist schon in der Liste. Verwende dieses Konto oder gib eine andere Kennung ein",
    "error.account.notRegistered": "Dieses Konto ist nicht mehr in der Liste, zum Beispiel weil es in einem anderen Tab entfernt wurde",
    "error.account.gone": "Dieses Konto gibt es nicht mehr",
    "error.account.changed": "Das aktive Konto hat sich ge\xE4ndert",
    "error.template.noName": "Eine Vorlage braucht einen Namen",
    "error.template.nameTooLong": (p, f) => `Der Name einer Vorlage darf h\xF6chstens ${f.number(p.maximum)} Zeichen haben`,
    "error.template.folderTooLong": (p, f) => `Der Name eines Ordners darf h\xF6chstens ${f.number(p.maximum)} Zeichen haben`,
    "error.template.noText": "Eine Vorlage braucht Text",
    "error.template.tooLong": (p, f) => `Eine Vorlage darf h\xF6chstens ${f.number(p.maximum)} Zeichen haben`,
    "error.template.deleted": "Diese Vorlage wurde inzwischen gel\xF6scht",
    "error.data.changedDuringCheck": "Die gespeicherten Daten haben sich ge\xE4ndert, w\xE4hrend JoyFox die Datei gepr\xFCft hat. W\xE4hle die Datei noch einmal",
    "error.data.unknownType": "Unbekannter Datentyp",
    "error.data.accountRecord": "Der Kontodatensatz wird nur mit dem ganzen Konto entfernt",
    "error.import.tooLarge": "Die Datei ist zu gro\xDF f\xFCr einen JoyFox-Export. W\xE4hle eine Datei, die JoyFox exportiert hat",
    "error.import.notJson": "Die Datei ist kein JoyFox-Export. W\xE4hle eine Datei, die JoyFox exportiert hat",
    "error.import.notExport": "Die Datei ist kein JoyFox-Export. W\xE4hle eine Datei, die JoyFox exportiert hat",
    "error.import.noVersion": "Die Datei sagt nicht, welche JoyFox-Version sie erstellt hat. W\xE4hle eine Datei, die JoyFox exportiert hat",
    "error.import.newerVersion": "Die Datei stammt aus einer neueren JoyFox-Version. Aktualisiere zuerst JoyFox",
    "error.import.noScope": "Die Datei sagt nicht, ob sie ein Konto oder alle Daten enth\xE4lt. W\xE4hle eine Datei, die JoyFox exportiert hat",
    "error.import.noAccountNamed": "Die Datei ist der Export eines Kontos, nennt das Konto aber nicht. W\xE4hle eine Datei, die JoyFox exportiert hat",
    "error.import.unknownType": "Die Datei enth\xE4lt eine Art von Daten, die JoyFox nicht kennt. W\xE4hle eine Datei, die JoyFox exportiert hat",
    "error.import.notList": (p) => `Der Teil \u201E${p.entity}\u201C der Datei ist besch\xE4digt. W\xE4hle eine Datei, die JoyFox exportiert hat`,
    "error.import.notRecord": (p, f) => `Eintrag ${f.number(p.index)} in \u201E${p.entity}\u201C ist besch\xE4digt. W\xE4hle eine Datei, die JoyFox exportiert hat`,
    "error.import.forbiddenKey": (p, f) => `Eintrag ${f.number(p.index)} in \u201E${p.entity}\u201C enth\xE4lt einen Feldnamen, den JoyFox nicht erlaubt. W\xE4hle eine Datei, die JoyFox exportiert hat`,
    "error.import.unknownField": (p, f) => `Eintrag ${f.number(p.index)} in \u201E${p.entity}\u201C enth\xE4lt ein Feld, das JoyFox nicht kennt. W\xE4hle eine Datei, die JoyFox exportiert hat`,
    "error.import.tooLong": (p, f) => `Eintrag ${f.number(p.index)} in \u201E${p.entity}\u201C enth\xE4lt einen Text mit mehr als ${f.number(p.maximum)} Zeichen. W\xE4hle eine Datei, die JoyFox exportiert hat`,
    "error.import.invalid": (p, f) => `Eintrag ${f.number(p.index)} in \u201E${p.entity}\u201C ist besch\xE4digt. W\xE4hle eine Datei, die JoyFox exportiert hat`,
    "error.import.future": (p, f) => `Eintrag ${f.number(p.index)} in \u201E${p.entity}\u201C hat ein Datum in der Zukunft. Pr\xFCfe die Uhr des Computers, der die Datei erstellt hat`,
    "error.import.otherAccount": (p, f) => `Eintrag ${f.number(p.index)} in \u201E${p.entity}\u201C geh\xF6rt zu einem anderen Konto. W\xE4hle eine Datei, die JoyFox exportiert hat`,
    "error.import.notOwnScope": (p, f) => `Kontodatensatz ${f.number(p.index)} ist besch\xE4digt. W\xE4hle eine Datei, die JoyFox exportiert hat`,
    "error.import.twice": (p, f) => `Eintrag ${f.number(p.index)} in \u201E${p.entity}\u201C kommt in der Datei zweimal vor. W\xE4hle eine Datei, die JoyFox exportiert hat`,
    "error.import.sameIdentifier": "Zwei Konten in der Datei haben dieselbe Kennung. W\xE4hle eine Datei, die JoyFox exportiert hat",
    "error.import.noAccountRecord": "Die Datei ist der Export eines Kontos, enth\xE4lt dieses Konto aber nicht. W\xE4hle eine Datei, die JoyFox exportiert hat",
    "error.import.settingsInvalid": "Die Einstellungen in der Datei sind besch\xE4digt. W\xE4hle eine Datei, die JoyFox exportiert hat",
    "error.import.settingsForbidden": "Die Einstellungen in der Datei enthalten einen Namen, den JoyFox nicht erlaubt. W\xE4hle eine Datei, die JoyFox exportiert hat",
    "error.import.unknownSetting": "Die Datei enth\xE4lt eine Einstellung, die JoyFox nicht verwendet. W\xE4hle eine Datei, die JoyFox exportiert hat",
    "error.import.orphans": "Einige Datens\xE4tze in der Datei geh\xF6ren zu einem Konto, das die Datei nicht enth\xE4lt. W\xE4hle eine Datei, die JoyFox exportiert hat",
    "error.import.sameRecordTwice": "Zwei Datens\xE4tze in der Datei w\xFCrden hier zum selben Datensatz. W\xE4hle eine Datei, die JoyFox exportiert hat"
  };

  // src/i18n/translator.ts
  var CATALOGS = { en, de };
  var TAGS = { en: "en-US", de: "de-DE" };
  var locale = "en";
  var listeners = /* @__PURE__ */ new Set();
  function currentLocale() {
    return locale;
  }
  function setLocale(next) {
    if (next === locale) return;
    locale = next;
    for (const listener of Array.from(listeners)) listener(next);
  }
  function onLocaleChange(listener) {
    listeners.add(listener);
    return () => listeners.delete(listener);
  }
  var numberFormats = /* @__PURE__ */ new Map();
  var dateFormats = /* @__PURE__ */ new Map();
  var dateTimeFormats = /* @__PURE__ */ new Map();
  var pluralRules = /* @__PURE__ */ new Map();
  var wallDateFormats = /* @__PURE__ */ new Map();
  var wallDateTimeFormats = /* @__PURE__ */ new Map();
  function cached(map, make) {
    let value = map.get(locale);
    if (!value) {
      value = make(TAGS[locale]);
      map.set(locale, value);
    }
    return value;
  }
  function formatNumber(value) {
    return cached(numberFormats, (tag) => new Intl.NumberFormat(tag)).format(
      value
    );
  }
  function formatExactNumber(value) {
    const text = String(value);
    const parts = /^(-?)(\d+)(?:\.(\d+))?(?:e([+-]\d+))?$/u.exec(text);
    if (!parts) return text;
    const [, sign, whole, fraction, exponent] = parts;
    const format2 = cached(numberFormats, (tag) => new Intl.NumberFormat(tag));
    const decimal = format2.formatToParts(1.5).find((part) => part.type === "decimal")?.value ?? ".";
    return sign + format2.format(BigInt(whole)) + (fraction ? decimal + fraction : "") + (exponent ? `E${Number(exponent)}` : "");
  }
  function formatDate(iso) {
    const time = Date.parse(iso);
    if (!Number.isFinite(time)) return iso;
    return cached(
      dateFormats,
      (tag) => new Intl.DateTimeFormat(tag, { dateStyle: "medium", timeZone: "UTC" })
    ).format(time);
  }
  function formatDateTime(iso) {
    const time = Date.parse(iso);
    if (!Number.isFinite(time)) return iso;
    return cached(
      dateTimeFormats,
      (tag) => new Intl.DateTimeFormat(tag, {
        year: "numeric",
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        timeZone: "UTC",
        timeZoneName: "short"
      })
    ).format(time);
  }
  function formatWallTime(local) {
    const parts = /^(\d{4})-(\d{2})-(\d{2})(?:T(\d{2}):(\d{2}))?$/u.exec(local);
    if (!parts) return local;
    const [, year, month, day, hour, minute] = parts;
    const time = Date.UTC(
      Number(year),
      Number(month) - 1,
      Number(day),
      Number(hour ?? 0),
      Number(minute ?? 0)
    );
    const withTime = hour !== void 0;
    return cached(
      withTime ? wallDateTimeFormats : wallDateFormats,
      (tag) => withTime ? new Intl.DateTimeFormat(tag, {
        weekday: "short",
        year: "numeric",
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        timeZone: "UTC"
      }) : new Intl.DateTimeFormat(tag, {
        weekday: "short",
        year: "numeric",
        month: "short",
        day: "numeric",
        timeZone: "UTC"
      })
    ).format(time);
  }
  var format = {
    number: formatNumber,
    plural(value, forms) {
      return cached(pluralRules, (tag) => new Intl.PluralRules(tag)).select(
        value
      ) === "one" ? forms.one : forms.other;
    }
  };
  var reported = /* @__PURE__ */ new Set();
  function fallback2(value) {
    const key2 = typeof value === "object" && value !== null && typeof value.key === "string" ? value.key : "?";
    if (!reported.has(key2)) {
      reported.add(key2);
      console.warn(`JoyFox: cannot show message "${key2}"`);
    }
    return CATALOGS[locale]["common.textUnavailable"];
  }
  function render(message2) {
    const entry = CATALOGS[locale][message2.key];
    if (typeof entry === "string") return entry;
    const spec = paramsOf(message2.key) ?? {};
    const given = message2.params;
    const params = {};
    for (const [name, kind] of Object.entries(spec))
      params[name] = kind === "message" ? render(given[name]) : given[name];
    return entry(params, format);
  }
  function t(first, ...rest) {
    const value = typeof first === "string" ? rest.length > 0 ? { key: first, params: rest[0] } : { key: first } : first;
    if (!isMessage(value)) return fallback2(value);
    return render(value);
  }
  function errorDisplay(error) {
    return isExtensionError(error) ? error.display : void 0;
  }

  // src/i18n/dom.ts
  function applyStaticText(root) {
    const scope = "documentElement" in root ? root.documentElement : root;
    if ("documentElement" in root)
      root.documentElement.setAttribute("lang", currentLocale());
    const nodes = [
      ...scope.matches("[data-i18n], [data-i18n-attr]") ? [scope] : [],
      ...Array.from(scope.querySelectorAll("[data-i18n], [data-i18n-attr]"))
    ];
    for (const node of nodes) {
      const key2 = node.getAttribute("data-i18n");
      if (key2 !== null) {
        const text = plainText(key2);
        if (text !== void 0 && node.textContent !== text)
          node.textContent = text;
      }
      for (const pair of (node.getAttribute("data-i18n-attr") ?? "").split(";")) {
        const [name, attrKey] = pair.split(":").map((part) => part.trim());
        if (!name || !attrKey) continue;
        const text = plainText(attrKey);
        if (text !== void 0) node.setAttribute(name, text);
      }
    }
  }
  function plainText(key2) {
    if (!isMessageKey(key2) || paramsOf(key2) !== null) {
      console.warn(`JoyFox: no plain catalog text for "${key2}"`);
      return void 0;
    }
    return t({ key: key2 });
  }

  // src/i18n/locale.ts
  var LOCALE_KEY = "joyfox.locale";
  var isLocale = (value) => value === "en" || value === "de";
  function resolveDefaultLocale(uiLanguage) {
    return /^de(?:[-_]|$)/iu.test(uiLanguage.trim()) ? "de" : "en";
  }
  function firefoxLanguage() {
    try {
      const api = globalThis.browser?.i18n;
      return api?.getUILanguage?.() ?? "";
    } catch {
      return "";
    }
  }
  function localeFromSetting(value, uiLanguage = firefoxLanguage) {
    return isLocale(value) ? value : resolveDefaultLocale(uiLanguage());
  }
  async function readLocale(area, uiLanguage = firefoxLanguage) {
    let stored;
    try {
      stored = (await area.get([LOCALE_KEY]))[LOCALE_KEY];
    } catch {
      stored = void 0;
    }
    return localeFromSetting(stored, uiLanguage);
  }

  // src/storage/triage-revision.ts
  var TRIAGE_REVISION_KEY = "joyfox.triageRevision";
  async function bumpTriageRevision(settings = runtimeSettingsArea) {
    try {
      await settings.set({ [TRIAGE_REVISION_KEY]: crypto.randomUUID() });
    } catch {
    }
  }

  // src/ui/focus.ts
  var FOCUS_KEY = "data-joyfox-focus";
  function rememberFocus(root) {
    const active = root?.ownerDocument.activeElement;
    if (!root || !active || !root.contains(active)) return void 0;
    const key2 = active.getAttribute(FOCUS_KEY);
    if (!key2) return void 0;
    if (active.tagName === "INPUT" || active.tagName === "TEXTAREA") {
      const field = active;
      try {
        return { key: key2, start: field.selectionStart, end: field.selectionEnd };
      } catch {
        return { key: key2 };
      }
    }
    return { key: key2 };
  }
  var usable = (node) => node && !node.disabled && !node.closest("[hidden]") && !(node.closest("details:not([open])") && node.tagName !== "SUMMARY") ? node : void 0;
  function findKey(root, key2) {
    for (const node of Array.from(
      root.querySelectorAll(`[${FOCUS_KEY}]`)
    ))
      if (node.getAttribute(FOCUS_KEY) === key2) return node;
    return void 0;
  }
  function restoreFocus(root, memo, fallbacks = []) {
    if (!memo) return false;
    const target = [memo.key, ...fallbacks].map((key2) => usable(findKey(root, key2))).find((node) => node !== void 0);
    if (!target) return false;
    const same = target.getAttribute(FOCUS_KEY) === memo.key;
    target.focus({ preventScroll: same && !memo.scroll });
    if (target.getAttribute(FOCUS_KEY) === memo.key && memo.start !== void 0 && memo.start !== null && "setSelectionRange" in target) {
      try {
        target.setSelectionRange(
          memo.start,
          memo.end ?? memo.start
        );
      } catch {
      }
    }
    return true;
  }

  // src/options/confirm.ts
  var confirmTiming = {
    graceMs: 500,
    now: () => Date.now()
  };
  function confirmAllowed(event, armedAt) {
    return event.detail <= 1 && confirmTiming.now() - armedAt >= confirmTiming.graceMs;
  }

  // src/options/status-line.ts
  var StatusLine = class {
    node;
    #message;
    constructor(document2) {
      this.node = document2.createElement("p");
      this.node.className = "joyfox-panel__status";
      this.node.setAttribute("aria-live", "polite");
    }
    set(message2, kind) {
      this.#message = message2;
      this.node.dataset.kind = kind;
      this.node.setAttribute("role", kind === "error" ? "alert" : "status");
      this.node.textContent = message2 ? t(message2) : "";
    }
    clear() {
      this.set(void 0, "info");
    }
    /** Show the message again, in the current language. */
    redraw() {
      const text = this.#message ? t(this.#message) : "";
      if (this.node.textContent !== text) this.node.textContent = text;
    }
  };

  // src/options/account-panel.ts
  var PANEL_CLASS = "joyfox-account-panel";
  var MOUNTED = "data-joyfox-account-panel";
  var mounted = /* @__PURE__ */ new WeakMap();
  var RENAME_FIELD_ID = "joyfox-account-rename";
  function element(document2, tag, className, text) {
    const node = document2.createElement(tag);
    node.className = className;
    if (text !== void 0) node.textContent = text;
    return node;
  }
  function fullName(account) {
    const label = account.label?.trim();
    return label && label !== account.joyClubAccountId ? t("accounts.nameWithIdentifier", {
      label,
      identifier: account.joyClubAccountId
    }) : account.joyClubAccountId;
  }
  var focusFell = (document2) => !document2.activeElement || document2.activeElement === document2.body;
  var AccountPanel = class {
    constructor(root, service = new AccountService(), onChange = () => void 0) {
      this.root = root;
      this.service = service;
      this.onChange = onChange;
      this.root.classList.add(PANEL_CLASS);
      this.root.setAttribute(MOUNTED, "true");
      this.#status = new StatusLine(this.root.ownerDocument);
      this.#status.clear();
    }
    #pendingRemoval;
    /** When the pending removal was armed, for the confirm grace period. */
    #armedAt = 0;
    /** The account whose label is being edited, if any. */
    #renaming;
    /** Set while an add runs, so a double submit cannot add the account twice. */
    #adding = false;
    /** Where the next draw puts focus, whatever had it before. */
    #focusNext;
    /**
     * The control that had focus when an action started. A control disabled
     * while the action runs drops focus to the page; the draw after the
     * action puts it back.
     */
    #focusBefore;
    /** Created once and re-attached on every render (see `StatusLine`). */
    #status;
    async render() {
      const document2 = this.root.ownerDocument;
      const accounts2 = await this.service.listAccounts();
      const activeId = (await this.service.getActiveAccount())?.id;
      if (this.#pendingRemoval && !accounts2.some((a) => a.id === this.#pendingRemoval))
        this.#pendingRemoval = void 0;
      if (this.#renaming && !accounts2.some((a) => a.id === this.#renaming))
        this.#renaming = void 0;
      const typed = Array.from(
        this.root.querySelectorAll(".joyfox-panel__form input"),
        (input) => [input.id, input.value]
      );
      const renameInput = this.root.querySelector(
        `#${RENAME_FIELD_ID}`
      );
      const renameDraft = renameInput && renameInput.dataset.accountId === this.#renaming ? renameInput.value : void 0;
      const focus = rememberFocus(this.root) ?? (focusFell(document2) ? this.#focusBefore : void 0);
      this.root.replaceChildren();
      const heading = element(
        document2,
        "h2",
        "joyfox-panel__heading",
        t("options.tabs.accounts")
      );
      heading.id = "joyfox-accounts-heading";
      this.root.append(heading);
      this.root.setAttribute("aria-labelledby", heading.id);
      this.root.append(this.#renderActiveSummary(document2, accounts2, activeId));
      this.root.append(
        this.#renderList(document2, accounts2, activeId, renameDraft)
      );
      this.root.append(this.#renderAddForm(document2));
      this.root.append(
        element(document2, "p", "joyfox-panel__hint", t("accounts.hint"))
      );
      this.#status.redraw();
      this.root.append(this.#status.node);
      for (const [id, value] of typed) {
        const input = this.root.querySelector(`#${id}`);
        if (input) input.value = value;
      }
      const next = this.#focusNext;
      this.#focusNext = void 0;
      if (next) restoreFocus(this.root, next);
      else restoreFocus(this.root, focus, this.#fallbacks(focus));
    }
    /**
     * Where focus goes when its control is gone after a draw: the same row's
     * next control, else the account list, else the add form (no account is
     * left).
     */
    #fallbacks(focus) {
      const [kind, ...rest] = focus?.key.split(":") ?? [];
      const id = rest.join(":");
      const list = ["accounts-list", "add:identifier"];
      switch (kind) {
        case "use":
          return [`rename:${id}`, `remove:${id}`, ...list];
        case "rename-field":
        case "rename-save":
        case "rename-cancel":
          return [`rename:${id}`, ...list];
        case "rename":
        case "remove":
          return list;
        default:
          return [];
      }
    }
    #renderActiveSummary(document2, accounts2, activeId) {
      const active = accounts2.find((account) => account.id === activeId);
      const summary = element(document2, "p", "joyfox-panel__active");
      const label = element(
        document2,
        "span",
        "joyfox-panel__active-label",
        t("accounts.activeLabel")
      );
      const value = element(
        document2,
        "strong",
        active ? "joyfox-panel__active-value" : "joyfox-panel__active-value joyfox-panel__active-value--none",
        active ? fullName(active) : t("accounts.noneSelected")
      );
      summary.append(label, document2.createTextNode(" "), value);
      return summary;
    }
    #renderList(document2, accounts2, activeId, renameDraft) {
      if (accounts2.length === 0)
        return element(document2, "p", "joyfox-panel__empty", t("accounts.empty"));
      const list = element(document2, "ul", "joyfox-panel__list");
      list.setAttribute("aria-label", t("accounts.list"));
      list.tabIndex = -1;
      list.setAttribute(FOCUS_KEY, "accounts-list");
      for (const account of accounts2) {
        const item = element(document2, "li", "joyfox-panel__item");
        item.dataset.accountId = account.id;
        const isActive = account.id === activeId;
        if (isActive) {
          item.setAttribute("aria-current", "true");
          item.classList.add("joyfox-panel__item--active");
        }
        const name = element(
          document2,
          "span",
          "joyfox-panel__item-name",
          fullName(account)
        );
        item.append(name);
        item.append(
          element(
            document2,
            "span",
            "joyfox-panel__item-state",
            t(isActive ? "accounts.active" : "accounts.inactive")
          )
        );
        if (!isActive) item.append(this.#activateButton(document2, account));
        const renaming = this.#renaming === account.id;
        if (!renaming) item.append(this.#renameButton(document2, account));
        item.append(this.#removeButton(document2, account));
        if (renaming)
          item.append(this.#renderRenameForm(document2, account, renameDraft));
        list.append(item);
      }
      return list;
    }
    #activateButton(document2, account) {
      const button = element(
        document2,
        "button",
        "joyfox-panel__activate",
        t("accounts.use")
      );
      button.type = "button";
      button.setAttribute(FOCUS_KEY, `use:${account.id}`);
      button.setAttribute(
        "aria-label",
        t("accounts.useLabel", { name: fullName(account) })
      );
      button.addEventListener("click", () => {
        void this.#run(async () => {
          this.#pendingRemoval = void 0;
          await this.service.setActiveAccount(account.id);
          this.#setStatus(
            message("accounts.nowActive", { name: fullName(account) }),
            "info"
          );
        });
      });
      return button;
    }
    /**
     * Opens a field for a new display label. Only the label changes: the
     * JoyClub identifier is how an import finds the account, so it stays.
     */
    #renameButton(document2, account) {
      const button = element(
        document2,
        "button",
        "joyfox-account__rename",
        t("accounts.rename")
      );
      button.type = "button";
      button.setAttribute(FOCUS_KEY, `rename:${account.id}`);
      button.setAttribute(
        "aria-label",
        t("accounts.renameLabel", { name: fullName(account) })
      );
      button.addEventListener("click", () => {
        if (this.#pendingRemoval) this.#status.clear();
        this.#pendingRemoval = void 0;
        this.#renaming = account.id;
        const label = account.label ?? "";
        this.#focusNext = {
          key: `rename-field:${account.id}`,
          start: 0,
          end: label.length
        };
        void this.render();
      });
      return button;
    }
    #renderRenameForm(document2, account, draft) {
      const form = element(document2, "form", "joyfox-account__rename-form");
      const field = element(document2, "p", "joyfox-panel__field");
      const label = element(
        document2,
        "label",
        "joyfox-panel__field-label",
        t("accounts.renameField", { identifier: account.joyClubAccountId })
      );
      label.htmlFor = RENAME_FIELD_ID;
      const input = element(document2, "input", "joyfox-panel__field-input");
      input.id = RENAME_FIELD_ID;
      input.name = RENAME_FIELD_ID;
      input.type = "text";
      input.autocomplete = "off";
      input.value = draft ?? account.label ?? "";
      input.dataset.accountId = account.id;
      input.setAttribute(FOCUS_KEY, `rename-field:${account.id}`);
      const hint = element(
        document2,
        "span",
        "joyfox-panel__hint",
        t("accounts.labelHint")
      );
      hint.id = `${RENAME_FIELD_ID}-hint`;
      input.setAttribute("aria-describedby", hint.id);
      field.append(label, input, hint);
      const save = element(
        document2,
        "button",
        "joyfox-panel__submit",
        t("accounts.renameSave")
      );
      save.type = "submit";
      save.setAttribute(FOCUS_KEY, `rename-save:${account.id}`);
      const cancel = element(
        document2,
        "button",
        "joyfox-account__rename-cancel",
        t("accounts.renameCancel")
      );
      cancel.type = "button";
      cancel.setAttribute(FOCUS_KEY, `rename-cancel:${account.id}`);
      const close = () => {
        this.#renaming = void 0;
        this.#status.clear();
        this.#focusNext = { key: `rename:${account.id}` };
        void this.render();
      };
      cancel.addEventListener("click", close);
      input.addEventListener("keydown", (event) => {
        if (event.key !== "Escape") return;
        event.preventDefault();
        close();
      });
      form.addEventListener("submit", (event) => {
        event.preventDefault();
        const value = input.value;
        void this.#run(async () => {
          this.#pendingRemoval = void 0;
          const renamed = await this.service.renameAccount(account.id, value);
          this.#renaming = void 0;
          this.#setStatus(
            message("accounts.renamed", { name: fullName(renamed) }),
            "info"
          );
        });
      });
      form.append(field, save, document2.createTextNode(" "), cancel);
      return form;
    }
    /**
     * Removing an account deletes every record stored under it, so the button
     * asks for a second, explicit click instead of acting on the first. A node
     * drawn unarmed can only arm, and a confirm must be a single click after the
     * grace period, so a double-click can never arm and confirm in one gesture.
     */
    #removeButton(document2, account) {
      const confirming = this.#pendingRemoval === account.id;
      const button = element(
        document2,
        "button",
        "joyfox-panel__remove",
        t(confirming ? "accounts.confirmRemove" : "accounts.remove")
      );
      button.type = "button";
      button.setAttribute(FOCUS_KEY, `remove:${account.id}`);
      button.setAttribute(
        "aria-label",
        t(confirming ? "accounts.confirmRemoveLabel" : "accounts.removeLabel", {
          name: fullName(account)
        })
      );
      button.addEventListener("click", (event) => {
        if (!confirming) {
          if (event.detail > 1) return;
          void this.#run(async () => {
            this.#pendingRemoval = account.id;
            this.#armedAt = confirmTiming.now();
            this.#setStatus(
              message("accounts.removePrompt", { name: fullName(account) }),
              "info"
            );
          });
          return;
        }
        if (this.#pendingRemoval !== account.id) return;
        if (!confirmAllowed(event, this.#armedAt)) return;
        this.#pendingRemoval = void 0;
        void this.#run(async () => {
          const wasActive = await this.service.deleteAccount(account.id);
          const left = await this.service.listAccounts().then(
            (all) => all.length,
            () => void 0
          );
          const name = fullName(account);
          this.#setStatus(
            left === 0 ? message("accounts.removedNoneLeft", { name }) : wasActive ? message("accounts.removedNoneActive", { name }) : message("accounts.removed", { name }),
            "info"
          );
        });
      });
      return button;
    }
    #renderAddForm(document2) {
      const form = element(document2, "form", "joyfox-panel__form");
      form.setAttribute("aria-label", t("accounts.addForm"));
      const identifier = this.#field(
        document2,
        "joyfox-account-identifier",
        "add:identifier",
        t("accounts.identifier"),
        t("accounts.identifierHint"),
        true
      );
      const label = this.#field(
        document2,
        "joyfox-account-label",
        "add:label",
        t("accounts.label"),
        t("accounts.labelHint"),
        false
      );
      const submit = element(
        document2,
        "button",
        "joyfox-panel__submit",
        t("accounts.add")
      );
      submit.type = "submit";
      submit.setAttribute(FOCUS_KEY, "add:submit");
      form.append(identifier.wrapper, label.wrapper, submit);
      form.addEventListener("submit", (event) => {
        event.preventDefault();
        if (this.#adding) return;
        this.#adding = true;
        const focus = rememberFocus(this.root);
        submit.disabled = true;
        void this.#run(async () => {
          this.#pendingRemoval = void 0;
          const account = await this.service.createAccount({
            joyClubAccountId: identifier.input.value,
            label: label.input.value
          });
          this.#setStatus(
            message("accounts.added", { name: fullName(account) }),
            "info"
          );
          identifier.input.value = "";
          label.input.value = "";
        }, focus).finally(() => {
          this.#adding = false;
          submit.disabled = false;
        });
      });
      return form;
    }
    #field(document2, id, focusKey, labelText, hintText, required) {
      const wrapper = element(document2, "p", "joyfox-panel__field");
      const label = element(
        document2,
        "label",
        "joyfox-panel__field-label",
        labelText
      );
      label.htmlFor = id;
      const input = element(document2, "input", "joyfox-panel__field-input");
      input.id = id;
      input.name = id;
      input.type = "text";
      input.required = required;
      input.autocomplete = "off";
      input.setAttribute(FOCUS_KEY, focusKey);
      const hint = element(document2, "span", "joyfox-panel__hint", hintText);
      hint.id = `${id}-hint`;
      input.setAttribute("aria-describedby", hint.id);
      wrapper.append(label, input, hint);
      return { wrapper, input };
    }
    #setStatus(message2, kind) {
      this.#status.set(message2, kind);
    }
    /**
     * Every action re-renders from storage afterwards, so the panel always shows
     * committed state rather than what the click was expected to do. `focus` is
     * the control that started it, for when its focus drops meanwhile.
     */
    async #run(action, focus = rememberFocus(this.root)) {
      this.#focusBefore = focus;
      try {
        await action();
      } catch (error) {
        this.#pendingRemoval = void 0;
        const display = errorDisplay(error);
        this.#setStatus(
          display ? message("error.withSuffix.nothingChanged", { error: display }) : message("common.saveFailed"),
          "error"
        );
      }
      this.onChange();
      try {
        await this.render();
      } finally {
        if (this.#focusBefore === focus) this.#focusBefore = void 0;
      }
    }
  };
  async function mountAccountPanel(root, service, onChange) {
    const panel = mounted.get(root) ?? new AccountPanel(root, service, onChange);
    mounted.set(root, panel);
    await panel.render();
    return panel;
  }

  // src/storage/revision.ts
  async function bumpRevision(key2, settings = runtimeSettingsArea) {
    try {
      await settings.set({ [key2]: crypto.randomUUID() });
    } catch {
    }
  }

  // src/storage/event-revision.ts
  var EVENT_REVISION_KEY = "joyfox.eventRevision";

  // src/actions/ignore-delete.ts
  var QUICK_IGNORE_DELETE = "quick-ignore-delete";
  var QUICK_DELETE = "quick-delete";
  var QUICK_ACTIONS = [
    QUICK_IGNORE_DELETE,
    QUICK_DELETE
  ];
  var isQuickAction = (value) => QUICK_ACTIONS.includes(value);
  var NEXT = {
    [QUICK_IGNORE_DELETE]: {
      Started: "DeleteRequested",
      DeleteRequested: "DeleteConfirmed",
      DeleteConfirmed: "IgnoreRequested",
      IgnoreRequested: "IgnoreConfirmed",
      IgnoreConfirmed: "Completed"
    },
    // Delete alone: `Started`, `DeleteRequested`, `DeleteConfirmed`,
    // `Completed`, or `Failed` from any state that is not terminal.
    [QUICK_DELETE]: {
      Started: "DeleteRequested",
      DeleteRequested: "DeleteConfirmed",
      DeleteConfirmed: "Completed"
    }
  };
  var ACTION_FAILURES = [
    "control-missing",
    "confirmation-missing",
    "not-verified",
    "unverifiable",
    "member-mismatch",
    "conversation-mismatch",
    "identity-unavailable",
    "account-changed",
    "turned-off",
    "superseded",
    "log-unavailable",
    "handoff-failed",
    "timeout",
    "step-error"
  ];
  var STEP_ORDER = ["delete", "ignore"];
  var ACTION_STEPS = {
    [QUICK_IGNORE_DELETE]: STEP_ORDER,
    [QUICK_DELETE]: ["delete"]
  };
  var STEP_STATES = {
    ignore: { requested: "IgnoreRequested", confirmed: "IgnoreConfirmed" },
    delete: { requested: "DeleteRequested", confirmed: "DeleteConfirmed" }
  };
  var STEP_TIMEOUT_MS = 15e3;
  var STALE_AFTER_MS = 12e4;
  var STARTED_STALE_AFTER_MS = 2 * STEP_TIMEOUT_MS;
  function staleAfterMs(last) {
    return last === "Started" ? STARTED_STALE_AFTER_MS : STALE_AFTER_MS;
  }
  function outcome(steps, step) {
    const names = new Set(steps.map((item) => item.name));
    const states = STEP_STATES[step];
    if (names.has(states.confirmed)) return "done";
    if (names.has(states.requested)) return "unknown";
    return "not-done";
  }
  function failureText(failure, step, outcome2) {
    const name = message(`action.step.${step}`);
    const where = message(
      outcome2 === "not-done" ? "action.where.before" : "action.where.during",
      { step: name }
    );
    switch (failure) {
      case "control-missing":
      case "confirmation-missing":
      case "not-verified":
      case "timeout":
        return message(`action.failure.${failure}`, { step: name });
      case "unverifiable":
        return message("action.failure.unverifiable", { step: name, where });
      default:
        return message(`action.failure.${failure}`, { where });
    }
  }
  var stepText = (step, outcome2) => message(`action.stepText.${step}.${outcome2}`);
  var actionOf = (log) => log.action === QUICK_DELETE ? QUICK_DELETE : QUICK_IGNORE_DELETE;
  function reportOperation(log, now) {
    const action = actionOf(log);
    const steps = log.steps;
    const last = steps.at(-1);
    const lastState = last?.name;
    const ignore = outcome(steps, "ignore");
    const remove = outcome(steps, "delete");
    const failure = lastState === "Failed" && ACTION_FAILURES.includes(last?.errorCode) ? last?.errorCode : void 0;
    const lastAt = Date.parse(last?.at ?? log.updatedAt);
    const status = lastState === "Completed" ? "completed" : lastState === "Failed" ? "failed" : !Number.isFinite(lastAt) || now - lastAt > staleAfterMs(lastState) ? "interrupted" : "running";
    if (action === QUICK_DELETE)
      return deleteReport(status, remove, ignore, failure);
    const lines = [];
    if (status === "completed") {
      lines.push(message("action.report.finished"), stepText("delete", "done"));
      lines.push(stepText("ignore", "done"), message("action.report.undo"));
      return { status, ignore, delete: remove, lines };
    }
    if (status === "running") {
      lines.push(message("action.report.running"));
      return { status, ignore, delete: remove, lines };
    }
    lines.push(
      message(
        status === "failed" ? "action.report.stopped" : "action.report.interrupted"
      )
    );
    if (failure) {
      const step = remove === "done" ? "ignore" : "delete";
      lines.push(failureText(failure, step, step === "ignore" ? ignore : remove));
      if (failure === "unverifiable" && step === "delete")
        lines.push(message("action.next.showList"));
    }
    lines.push(stepText("delete", remove), stepText("ignore", ignore));
    const untouched = ignore === "not-done" && remove === "not-done";
    lines.push(
      message(
        untouched ? "action.report.nothingChanged" : "action.report.notUndone"
      )
    );
    if (untouched) {
      lines.push(message("action.self.delete"), message("action.self.ignore"));
    } else {
      if (remove !== "done") lines.push(message("action.next.delete"));
      if (ignore !== "done") lines.push(message("action.next.ignore"));
    }
    return {
      status,
      ignore,
      delete: remove,
      ...failure ? { failure } : {},
      lines
    };
  }
  function deleteReport(status, remove, ignore, failure) {
    const lines = [];
    if (status === "completed") {
      lines.push(
        message("action.deleteReport.finished"),
        stepText("delete", "done"),
        message("action.deleteReport.undo")
      );
      return { status, ignore, delete: remove, lines };
    }
    if (status === "running") {
      lines.push(message("action.deleteReport.running"));
      return { status, ignore, delete: remove, lines };
    }
    lines.push(
      message(
        status === "failed" ? "action.deleteReport.stopped" : "action.deleteReport.interrupted"
      )
    );
    if (failure) {
      lines.push(failureText(failure, "delete", remove));
      if (failure === "unverifiable") lines.push(message("action.next.showList"));
    }
    lines.push(stepText("delete", remove));
    const untouched = remove === "not-done";
    lines.push(
      message(
        untouched ? "action.report.nothingChanged" : "action.report.notUndone"
      ),
      message(untouched ? "action.self.delete" : "action.next.delete")
    );
    return {
      status,
      ignore,
      delete: remove,
      ...failure ? { failure } : {},
      lines
    };
  }

  // src/actions/quick-action-setting.ts
  var QUICK_ACTION_KEY = "joyfox.quickIgnoreDelete";

  // src/storage/message-revision.ts
  var MESSAGE_REVISION_KEY = "joyfox.messageRevision";
  var bumpMessageRevision = (settings) => bumpRevision(MESSAGE_REVISION_KEY, settings);

  // src/messages/message-cache-service.ts
  var searchable = (text) => text.replace(/\s+/gu, " ").trim().toLocaleLowerCase("de");
  var MessageCacheService = class {
    constructor(settings, messages2 = new CachedMessageRepository(), now = () => /* @__PURE__ */ new Date()) {
      this.settings = settings;
      this.messages = messages2;
      this.now = now;
    }
    async store(accountId, conversationId, memberId, seen) {
      const { caching, retentionMonths } = await readMessageSettings(
        this.settings
      );
      if (!caching) return { status: "off" };
      const now = this.now();
      const timestamp = now.toISOString();
      const cutoff = Date.parse(retentionCutoff(now, retentionMonths));
      let stored = 0;
      for (const message2 of seen) {
        const id = `message:${message2.messageId}`;
        const existing = await this.messages.get(accountId, id);
        const sentAt = message2.sentAt ?? existing?.sentAt;
        if (sentAt && Date.parse(sentAt) < cutoff) continue;
        if (existing && existing.conversationId !== conversationId) continue;
        if (existing && existing.text === message2.text && existing.sentAt === sentAt)
          continue;
        await this.messages.put(accountId, {
          id,
          accountId,
          messageId: message2.messageId,
          conversationId,
          memberId,
          direction: message2.direction,
          ...sentAt ? { sentAt } : {},
          text: message2.text,
          createdAt: existing?.createdAt ?? timestamp,
          updatedAt: timestamp
        });
        stored += 1;
      }
      const deleted = await this.prune();
      return { status: "stored", stored, deleted };
    }
    /**
     * Every stored message of the account that contains the query, newest
     * first. Case and spacing do not matter. An empty query finds nothing.
     */
    async search(accountId, query) {
      const needle = searchable(query);
      if (!needle) return { messages: [] };
      const all = await this.messages.list(accountId);
      return {
        messages: all.filter((message2) => searchable(message2.text).includes(needle)).sort(
          (a, b) => Date.parse(messageTime(b)) - Date.parse(messageTime(a)) || a.id.localeCompare(b.id)
        )
      };
    }
    /**
     * Deletes every message older than the window now in effect. A deletion
     * sets the message revision, so open options pages ("Messages" and "Your
     * data") drop what is gone.
     */
    async prune() {
      const { retentionMonths } = await readMessageSettings(this.settings);
      const deleted = await this.messages.pruneOlderThan(
        retentionCutoff(this.now(), retentionMonths)
      );
      if (deleted > 0) await bumpMessageRevision(this.settings);
      return deleted;
    }
    /** Saves the window, then deletes what is older at once. */
    async setRetention(months) {
      if (!isMessageRetention(months))
        throw new RangeError("Invalid message retention");
      await this.settings.set({ [MESSAGE_RETENTION_KEY]: months });
      return this.prune();
    }
  };

  // src/storage/export-reminder.ts
  var EXPORT_REMINDER_KEY = "joyfox.exportReminderDays";
  var LAST_EXPORT_KEY = "joyfox.lastExportAt";
  var DEFAULT_EXPORT_REMINDER_DAYS = 14;
  var MIN_EXPORT_REMINDER_DAYS = 0;
  var MAX_EXPORT_REMINDER_DAYS = 365;
  var DAY_MS2 = 24 * 60 * 60 * 1e3;
  function isExportReminderDays(value) {
    return typeof value === "number" && Number.isInteger(value) && value >= MIN_EXPORT_REMINDER_DAYS && value <= MAX_EXPORT_REMINDER_DAYS;
  }
  var isDate = (value) => typeof value === "string" && !Number.isNaN(Date.parse(value));
  async function readExportReminder(settings) {
    try {
      const stored = await settings.get([EXPORT_REMINDER_KEY, LAST_EXPORT_KEY]);
      const days = stored[EXPORT_REMINDER_KEY];
      const last = stored[LAST_EXPORT_KEY];
      return {
        days: isExportReminderDays(days) ? days : DEFAULT_EXPORT_REMINDER_DAYS,
        ...isDate(last) ? { lastExportAt: last } : {}
      };
    } catch {
      return { days: DEFAULT_EXPORT_REMINDER_DAYS };
    }
  }
  function daysSinceExport(lastExportAt, now) {
    const elapsed = now.getTime() - Date.parse(lastExportAt);
    return Math.max(0, Math.floor(elapsed / DAY_MS2));
  }
  function exportDue(reminder, now) {
    if (reminder.days === 0) return false;
    if (!reminder.lastExportAt) return true;
    return daysSinceExport(reminder.lastExportAt, now) >= reminder.days;
  }

  // src/spam/normalize.ts
  function normalizeMessage(text) {
    return text.normalize("NFKC").replace(new RegExp("\\p{Default_Ignorable_Code_Point}+", "gu"), "").toLowerCase().replace(/[\p{P}\p{S}]/gu, " ").replace(/\s+/gu, " ").trim();
  }

  // src/templates/template-service.ts
  var MAX_TEMPLATE_NAME_LENGTH = 80;
  var MAX_TEMPLATE_FOLDER_LENGTH = 40;
  var MAX_TEMPLATE_BODY_LENGTH = 4e3;
  var DEFAULT_FOLDER = "templates.folder.general";
  var SUGGESTED_FOLDERS = [
    DEFAULT_FOLDER,
    "templates.folder.eventConfirmation",
    "templates.folder.eventCancellation"
  ];
  var collapse = (value) => value.trim().replace(/\s+/gu, " ");
  function normalizeTemplateBody(body) {
    return body.replace(/\r\n?/gu, "\n");
  }
  function folderOf(template, general = "") {
    return template.folder ?? general;
  }
  function compareTemplates(a, b, general = "") {
    return folderOf(a, general).localeCompare(folderOf(b, general)) || a.name.localeCompare(b.name) || a.id.localeCompare(b.id);
  }
  function invalid(text, display) {
    return new ExtensionError("ExtractionInvalid", text, { display });
  }
  var TemplateService = class {
    constructor(templates2 = new MessageTemplateRepository(), accounts2 = new ExtensionAccountRepository(), now = () => (/* @__PURE__ */ new Date()).toISOString(), newId = () => `template:${crypto.randomUUID()}`) {
      this.templates = templates2;
      this.accounts = accounts2;
      this.now = now;
      this.newId = newId;
    }
    async list(accountId) {
      const templates2 = await this.templates.list(accountId);
      return templates2.sort(compareTemplates);
    }
    async save(accountId, input, guard) {
      const name = collapse(input.name);
      const folder = collapse(input.folder ?? "");
      const body = normalizeTemplateBody(input.body);
      if (name.length === 0)
        throw invalid(
          "A template needs a name",
          message("error.template.noName")
        );
      if (name.length > MAX_TEMPLATE_NAME_LENGTH)
        throw invalid(
          `A template name can have at most ${MAX_TEMPLATE_NAME_LENGTH} characters`,
          message("error.template.nameTooLong", {
            maximum: MAX_TEMPLATE_NAME_LENGTH
          })
        );
      if (folder.length > MAX_TEMPLATE_FOLDER_LENGTH)
        throw invalid(
          `A folder name can have at most ${MAX_TEMPLATE_FOLDER_LENGTH} characters`,
          message("error.template.folderTooLong", {
            maximum: MAX_TEMPLATE_FOLDER_LENGTH
          })
        );
      if (body.trim().length === 0)
        throw invalid(
          "A template needs some text",
          message("error.template.noText")
        );
      if (body.length > MAX_TEMPLATE_BODY_LENGTH)
        throw invalid(
          `A template can have at most ${MAX_TEMPLATE_BODY_LENGTH} characters`,
          message("error.template.tooLong", {
            maximum: MAX_TEMPLATE_BODY_LENGTH
          })
        );
      return withAccountLock(accountId, async () => {
        await this.#requireAccount(accountId, guard);
        const existing = input.id ? await this.templates.get(accountId, input.id) : void 0;
        if (input.id && !existing)
          throw new ExtensionError(
            "StorageError",
            "That template was deleted meanwhile",
            { display: message("error.template.deleted") }
          );
        const timestamp = this.now();
        const template = {
          id: existing?.id ?? this.newId(),
          accountId,
          name,
          body,
          ...folder ? { folder } : {},
          createdAt: existing?.createdAt ?? timestamp,
          updatedAt: timestamp
        };
        await this.templates.put(accountId, template);
        return template;
      });
    }
    async delete(accountId, id, guard) {
      await withAccountLock(accountId, async () => {
        await this.#requireAccount(accountId, guard);
        await this.templates.delete(accountId, id);
      });
    }
    async #requireAccount(accountId, guard) {
      if (!await this.accounts.get(accountId, accountId))
        throw new ExtensionError(
          "IdentityMismatch",
          "That account no longer exists",
          { display: message("error.account.gone") }
        );
      if (guard && await guard.activeAccountId() !== accountId)
        throw new ExtensionError(
          "IdentityMismatch",
          "The active account changed",
          { display: message("error.account.changed") }
        );
    }
  };

  // src/storage/member-revision.ts
  var MEMBER_REVISION_KEY = "joyfox.memberRevision";

  // src/storage/saved-search-revision.ts
  var SAVED_SEARCH_REVISION_KEY = "joyfox.savedSearchRevision";

  // src/data/import.ts
  var MAX_IMPORT_BYTES = 50 * 1024 * 1024;
  var KEEP_EXISTING = /* @__PURE__ */ new Set([
    "extensionAccounts",
    // A member record's nickname changes (2026-09-27), so members keep the
    // newer version by `updatedAt`, like notes.
    "userTags",
    "senderSpamOverrides",
    "trustSignals",
    "profileSnapshots",
    "messageObservations",
    "messagePhraseMatches",
    "cachedMessages",
    "actionLogs",
    "messageTemplates",
    // A file must never redirect an existing sync endpoint.
    "syncConfigs"
  ]);
  var CHANGE_MARKERS = /* @__PURE__ */ new Set([
    LAST_EXPORT_KEY,
    TRIAGE_REVISION_KEY,
    "joyfox.actionRevision",
    "joyfox.notesRevision",
    SAVED_SEARCH_REVISION_KEY,
    EVENT_REVISION_KEY,
    MESSAGE_REVISION_KEY,
    MEMBER_REVISION_KEY
  ]);
  var IMPORTED_SETTINGS = {
    "joyfox.templatePicker": (value) => typeof value === "boolean",
    // The UI language. Imported only when valid and none is stored, like
    // every setting here.
    [LOCALE_KEY]: isLocale,
    // How many profile snapshots are kept per member (V1-12).
    [SNAPSHOT_RETENTION_KEY]: isSnapshotRetention,
    // How many days after a full export the backup reminder shows.
    [EXPORT_REMINDER_KEY]: isExportReminderDays,
    // Message caching (V1-4): the switch and how long messages are kept.
    [MESSAGE_CACHING_KEY]: (value) => typeof value === "boolean",
    [MESSAGE_RETENTION_KEY]: isMessageRetention,
    // Whether the JoyFox strip is collapsed: layout only, never a feature.
    "joyfox.stripCollapsed": (value) => typeof value === "boolean"
  };
  var BASE_FIELDS = ["id", "accountId", "createdAt", "updatedAt"];
  var ENTITY_FIELDS = {
    extensionAccounts: ["joyClubAccountId", "label"],
    joyClubMembers: ["joyClubMemberId", "nickname"],
    profileSnapshots: [
      "memberId",
      "capturedAt",
      "verification",
      "photoCount",
      "profileWordCount",
      "joinedAt",
      "joinedEarliest",
      "joinedLatest",
      "positivePreferences",
      "ownProfile"
    ],
    userNotes: ["memberId", "body"],
    userTags: ["memberId", "label"],
    trustSignals: ["memberId", "kind", "occurredAt"],
    contactRules: [
      "name",
      "schemaVersion",
      "audience",
      "enabled",
      "defaultPlacement",
      "root"
    ],
    conversationClassifications: [
      "memberId",
      "conversationId",
      "placement",
      "source",
      "decidedAt",
      "ruleId",
      "reasons"
    ],
    savedSearches: ["name", "url", "filters"],
    eventMetadata: [
      "eventId",
      "kind",
      "title",
      "startLocal",
      "path",
      "venueId",
      "venueName",
      "note",
      "tags",
      "attendance",
      "attendees",
      "attendeesSeenAt"
    ],
    spendLogEntries: ["occurredAt", "amountMinor", "currency", "category"],
    syncConfigs: ["endpoint", "lastSyncedAt", "keyDerivation"],
    extensionPreferences: ["key", "value"],
    messageTemplates: ["name", "body", "folder"],
    spamPhrases: ["phrase", "enabled"],
    messageObservations: [
      "memberId",
      "conversationId",
      "observedAt",
      "normalizedText"
    ],
    senderSpamOverrides: ["memberId", "decision", "decidedAt", "reason"],
    actionLogs: ["memberId", "conversationId", "action", "steps"],
    messagePhraseMatches: ["memberId", "phrase", "matchedAt"],
    cachedMessages: [
      "messageId",
      "conversationId",
      "memberId",
      "direction",
      "sentAt",
      "text"
    ]
  };
  var FORBIDDEN_KEYS = /* @__PURE__ */ new Set([
    "__proto__",
    "constructor",
    "prototype"
  ]);
  function hasForbiddenKey(value, depth = 0) {
    if (depth > 64) return true;
    if (Array.isArray(value))
      return value.some((item) => hasForbiddenKey(item, depth + 1));
    if (typeof value !== "object" || value === null) return false;
    return Object.keys(value).some(
      (key2) => FORBIDDEN_KEYS.has(key2) || hasForbiddenKey(value[key2], depth + 1)
    );
  }
  var STEP_FIELDS = ["name", "ok", "at", "errorCode"];
  var GROUP_FIELDS = ["type", "match", "children"];
  var CONDITION_FIELDS = [
    "type",
    "kind",
    "value",
    "text",
    "whenUnknown",
    "negate"
  ];
  var extraKey = (value, allowed) => Object.keys(value).find((key2) => !allowed.includes(key2));
  function ruleNodeExtra(node, depth = 0) {
    if (!isObject(node) || depth > 16) return void 0;
    if (node.type === "group") {
      const extra = extraKey(node, GROUP_FIELDS);
      if (extra) return extra;
      for (const child of Array.isArray(node.children) ? node.children : []) {
        const nested = ruleNodeExtra(child, depth + 1);
        if (nested) return nested;
      }
      return void 0;
    }
    return extraKey(node, CONDITION_FIELDS);
  }
  function domainProblem(name, record) {
    const tooLong = (field, limit) => typeof record[field] === "string" && record[field].length > limit ? {
      text: `${field} is longer than ${limit} characters`,
      field,
      maximum: limit
    } : void 0;
    switch (name) {
      case "actionLogs":
        for (const step of Array.isArray(record.steps) ? record.steps : []) {
          const extra = isObject(step) ? extraKey(step, STEP_FIELDS) : void 0;
          if (extra)
            return {
              text: `an action step holds an unknown field (${extra})`,
              field: extra
            };
        }
        return void 0;
      case "contactRules": {
        const extra = ruleNodeExtra(record.root);
        return extra ? {
          text: `a rule condition holds an unknown field (${extra})`,
          field: extra
        } : void 0;
      }
      case "profileSnapshots": {
        const labels = Array.isArray(record.positivePreferences) ? record.positivePreferences : [];
        if (labels.length > MAX_PREFERENCE_TAGS)
          return { text: `more than ${MAX_PREFERENCE_TAGS} preferences` };
        return labels.some(
          (label) => typeof label === "string" && label.length > MAX_PREFERENCE_LABEL_LENGTH
        ) ? {
          text: `a preference is longer than ${MAX_PREFERENCE_LABEL_LENGTH} characters`,
          field: "positivePreferences",
          maximum: MAX_PREFERENCE_LABEL_LENGTH
        } : void 0;
      }
      case "cachedMessages":
        return tooLong("text", MAX_MESSAGE_TEXT_LENGTH);
      case "userNotes":
        return tooLong("body", MAX_NOTE_LENGTH);
      case "userTags":
        return tooLong("label", MAX_TAG_LENGTH);
      case "messageTemplates":
        return tooLong("name", MAX_TEMPLATE_NAME_LENGTH) ?? tooLong("folder", MAX_TEMPLATE_FOLDER_LENGTH) ?? tooLong("body", MAX_TEMPLATE_BODY_LENGTH);
      case "messageObservations":
        return typeof record.normalizedText === "string" && normalizeMessage(record.normalizedText) !== record.normalizedText ? { text: "normalizedText is not in normalized form" } : void 0;
      case "messagePhraseMatches":
        return typeof record.phrase === "string" && normalizePhrase(record.phrase) !== record.phrase ? { text: "phrase is not in normalized form" } : tooLong("phrase", MAX_NORMALIZED_PHRASE_LENGTH);
      case "eventMetadata": {
        const tags = Array.isArray(record.tags) ? record.tags : [];
        if (tags.length > MAX_EVENT_TAGS)
          return { text: `more than ${MAX_EVENT_TAGS} tags` };
        if (tags.some(
          (tag) => typeof tag === "string" && tag.length > MAX_TAG_LENGTH
        ))
          return {
            text: `a tag is longer than ${MAX_TAG_LENGTH} characters`,
            field: "tags",
            maximum: MAX_TAG_LENGTH
          };
        return tooLong("note", MAX_NOTE_LENGTH) ?? tooLong("title", MAX_LISTING_TEXT_LENGTH) ?? tooLong("venueName", MAX_LISTING_TEXT_LENGTH);
      }
      default:
        return void 0;
    }
  }
  var FUTURE_TOLERANCE_MS = 24 * 60 * 60 * 1e3;
  var DATE_FIELDS = [
    "createdAt",
    "updatedAt",
    "capturedAt",
    "occurredAt",
    "decidedAt",
    "observedAt",
    "matchedAt",
    "sentAt",
    "attendeesSeenAt",
    "lastSyncedAt",
    "joinedAt",
    "joinedEarliest",
    "joinedLatest"
  ];
  function datedInFuture(record, now) {
    const late = (value) => typeof value === "string" && Date.parse(value) > now + FUTURE_TOLERANCE_MS;
    if (DATE_FIELDS.some((field) => late(record[field]))) return true;
    return Array.isArray(record.steps) && record.steps.some((step) => isObject(step) && late(step.at));
  }
  function refuse(text, display) {
    return new ExtensionError("ExtractionInvalid", text, { display });
  }
  var entityLabel = (name) => message(`entity.${name}`);
  var isObject = (value) => typeof value === "object" && value !== null && !Array.isArray(value);
  var emptyEntities = () => Object.fromEntries(
    ENTITY_NAMES.map((name) => [name, []])
  );
  function parseImportFile(text, now = Date.now()) {
    let data2;
    try {
      data2 = JSON.parse(text);
    } catch {
      throw refuse(
        "The file is not a JoyFox export (not valid JSON)",
        message("error.import.notJson")
      );
    }
    if (!isObject(data2) || !isObject(data2.entities))
      throw refuse(
        "The file is not a JoyFox export",
        message("error.import.notExport")
      );
    const version = data2.schemaVersion;
    if (typeof version !== "number" || !Number.isInteger(version) || version < 1)
      throw refuse(
        "The file has no valid schema version",
        message("error.import.noVersion")
      );
    if (version > DATABASE_VERSION)
      throw refuse(
        "The file comes from a newer JoyFox version. Update JoyFox first",
        message("error.import.newerVersion")
      );
    const scope = data2.scope;
    if (scope !== "all" && scope !== "account")
      throw refuse(
        "The file has no valid export scope",
        message("error.import.noScope")
      );
    const rawAccountId = scope === "account" ? data2.accountId : void 0;
    if (scope === "account" && (typeof rawAccountId !== "string" || rawAccountId.length === 0))
      throw refuse(
        "The account export names no account",
        message("error.import.noAccountNamed")
      );
    const accountId = rawAccountId;
    const entities = emptyEntities();
    for (const [name, records] of Object.entries(data2.entities)) {
      if (!ENTITY_NAMES.includes(name))
        throw refuse(
          `The file holds an unknown data type (${name})`,
          message("error.import.unknownType")
        );
      const entity = entityLabel(name);
      if (!Array.isArray(records))
        throw refuse(
          `The file's ${name} list is not a list`,
          message("error.import.notList", { entity })
        );
      const seen = /* @__PURE__ */ new Set();
      records.forEach((raw, position) => {
        const index = position + 1;
        const at = { index, entity };
        if (!isObject(raw))
          throw refuse(
            `Record ${index} of ${name} is not a record`,
            message("error.import.notRecord", at)
          );
        if (hasForbiddenKey(raw))
          throw refuse(
            `Record ${index} of ${name} holds a forbidden key`,
            message("error.import.forbiddenKey", at)
          );
        const record = { ...raw };
        delete record.storageKey;
        const allowed = [...BASE_FIELDS, ...ENTITY_FIELDS[name]];
        const extra = Object.keys(record).find((key3) => !allowed.includes(key3));
        if (extra)
          throw refuse(
            `Record ${index} of ${name} holds an unknown field (${extra})`,
            message("error.import.unknownField", at)
          );
        if (name === "conversationClassifications" && version < 4)
          record.reasons = migrateReasons(record.reasons, record.placement);
        const problem = domainProblem(name, record);
        if (problem)
          throw refuse(
            `Record ${index} of ${name} is invalid: ${problem.text}`,
            problem.field === void 0 ? message("error.import.invalid", at) : problem.maximum === void 0 ? message("error.import.unknownField", at) : message("error.import.tooLong", {
              ...at,
              maximum: problem.maximum
            })
          );
        if (datedInFuture(record, now))
          throw refuse(
            `Record ${index} of ${name} is dated in the future`,
            message("error.import.future", at)
          );
        try {
          validateEntity(
            name,
            record
          );
        } catch (error) {
          const reason = error instanceof ValidationError ? error.message : "it is invalid";
          throw refuse(
            `Record ${index} of ${name} is invalid: ${reason}`,
            message("error.import.invalid", at)
          );
        }
        const stored = record;
        if (scope === "account" && stored.accountId !== accountId)
          throw refuse(
            `Record ${index} of ${name} belongs to another account`,
            message("error.import.otherAccount", at)
          );
        if (name === "extensionAccounts" && stored.id !== stored.accountId)
          throw refuse(
            `Account record ${index} is not its own scope`,
            message("error.import.notOwnScope", { index })
          );
        const key2 = `${stored.accountId}\0${stored.id}`;
        if (seen.has(key2))
          throw refuse(
            `Record ${index} of ${name} appears twice`,
            message("error.import.twice", at)
          );
        seen.add(key2);
        entities[name].push(stored);
      });
    }
    const identifiers = /* @__PURE__ */ new Set();
    for (const account of entities.extensionAccounts) {
      if (identifiers.has(account.joyClubAccountId))
        throw refuse(
          "Two accounts in the file have the same identifier",
          message("error.import.sameIdentifier")
        );
      identifiers.add(account.joyClubAccountId);
    }
    if (scope === "account" && !entities.extensionAccounts.some((account) => account.id === accountId))
      throw refuse(
        "The account export holds no account record",
        message("error.import.noAccountRecord")
      );
    const settings = {};
    if (scope === "all" && data2.settings !== void 0) {
      if (!isObject(data2.settings))
        throw refuse(
          "The file's settings are invalid",
          message("error.import.settingsInvalid")
        );
      if (hasForbiddenKey(data2.settings))
        throw refuse(
          "The file's settings hold a forbidden key",
          message("error.import.settingsForbidden")
        );
      for (const [key2, value] of Object.entries(data2.settings)) {
        if (!key2.startsWith("joyfox."))
          throw refuse(
            `The file holds a setting JoyFox does not use (${key2})`,
            message("error.import.unknownSetting")
          );
        settings[key2] = value;
      }
    }
    return {
      scope,
      schemaVersion: version,
      ...accountId ? { accountId } : {},
      entities,
      settings
    };
  }
  var templateKey = (template) => JSON.stringify([template.name, template.folder ?? "", template.body]);
  function planImport(file, stored, newId = () => crypto.randomUUID()) {
    const counts = Object.fromEntries(
      ENTITY_NAMES.map((name) => [
        name,
        { added: 0, replaced: 0, kept: 0, duplicates: 0 }
      ])
    );
    const writes = [];
    const sources = [];
    const storedAccounts = stored.entities.extensionAccounts;
    const scopeMap = /* @__PURE__ */ new Map();
    const accounts2 = { matched: 0, added: 0 };
    for (const account of file.entities.extensionAccounts) {
      const same = storedAccounts.find(
        (existing) => existing.joyClubAccountId === account.joyClubAccountId
      );
      if (same) {
        scopeMap.set(account.id, same.id);
        accounts2.matched += 1;
        counts.extensionAccounts.kept += 1;
        continue;
      }
      const taken = storedAccounts.some((existing) => existing.id === account.id);
      const id = taken ? newId() : account.id;
      scopeMap.set(account.id, id);
      accounts2.added += 1;
      counts.extensionAccounts.added += 1;
      const added = { ...account, id, accountId: id };
      writes.push({ name: "extensionAccounts", entity: added });
      sources.push(`extensionAccounts:${account.id}`);
    }
    const accountTargets = /* @__PURE__ */ new Set([
      ...storedAccounts.map((account) => account.id),
      ...scopeMap.values()
    ]);
    const target = (scope) => {
      const mapped = scopeMap.get(scope);
      if (mapped) return mapped;
      if (accountTargets.has(scope))
        throw refuse(
          "Some records in the file belong to an account the file does not hold",
          message("error.import.orphans")
        );
      return scope;
    };
    const written = /* @__PURE__ */ new Set();
    const record = (name, entity) => {
      const key2 = `${name}\0${entity.accountId}\0${entity.id}`;
      if (written.has(key2))
        throw refuse(
          "The file holds the same record twice after merging accounts",
          message("error.import.sameRecordTwice")
        );
      written.add(key2);
      writes.push({ name, entity });
    };
    for (const name of ENTITY_NAMES) {
      if (name === "extensionAccounts") continue;
      const existing = /* @__PURE__ */ new Map();
      for (const record2 of stored.entities[name])
        existing.set(`${record2.accountId}\0${record2.id}`, record2);
      const templates2 = /* @__PURE__ */ new Set();
      if (name === "messageTemplates")
        for (const record2 of stored.entities.messageTemplates)
          templates2.add(`${record2.accountId}\0${templateKey(record2)}`);
      for (const source of file.entities[name]) {
        const entity = { ...source, accountId: target(source.accountId) };
        const current = existing.get(`${entity.accountId}\0${entity.id}`);
        if (!current) {
          if (name === "messageTemplates") {
            const key2 = `${entity.accountId}\0${templateKey(entity)}`;
            if (templates2.has(key2)) {
              counts[name].duplicates += 1;
              continue;
            }
            templates2.add(key2);
          }
          counts[name].added += 1;
          record(name, entity);
          sources.push(`${name}:${source.accountId}:${source.id}`);
          continue;
        }
        if (!KEEP_EXISTING.has(name) && Date.parse(entity.updatedAt) > Date.parse(current.updatedAt)) {
          counts[name].replaced += 1;
          record(name, entity);
          sources.push(`${name}:${source.accountId}:${source.id}`);
        } else counts[name].kept += 1;
      }
    }
    const settings = {};
    const settingsSkipped = [];
    for (const [key2, value] of Object.entries(file.settings)) {
      if (key2 === ACTIVE_ACCOUNT_SETTING_KEY) continue;
      const valid = IMPORTED_SETTINGS[key2];
      if (!valid?.(value)) {
        if (!CHANGE_MARKERS.has(key2)) settingsSkipped.push(key2);
        continue;
      }
      if (!(key2 in stored.settings)) settings[key2] = value;
    }
    const storedActive = stored.settings[ACTIVE_ACCOUNT_SETTING_KEY];
    const activeExists = typeof storedActive === "string" && storedAccounts.some((account) => account.id === storedActive);
    let activeSource;
    if (!activeExists) {
      const fileActive = file.settings[ACTIVE_ACCOUNT_SETTING_KEY];
      activeSource = typeof fileActive === "string" && scopeMap.has(fileActive) ? fileActive : file.entities.extensionAccounts[0]?.id;
      const candidate = activeSource && scopeMap.get(activeSource);
      if (candidate) settings[ACTIVE_ACCOUNT_SETTING_KEY] = candidate;
    }
    const settingsAdded = Object.keys(settings).sort();
    return {
      scope: file.scope,
      accounts: accounts2,
      counts,
      settingsAdded,
      settingsSkipped: settingsSkipped.sort(),
      writes,
      settings,
      // Signed by what the settings come from, not a moved account's new
      // random ID, so the preview and the apply agree.
      signature: JSON.stringify([
        accounts2,
        counts,
        {
          ...settings,
          ...activeSource ? { [ACTIVE_ACCOUNT_SETTING_KEY]: activeSource } : {}
        },
        sources
      ])
    };
  }

  // src/data/data-service.ts
  var ENTITY_LABELS = Object.fromEntries(
    ENTITY_NAMES.map((name) => [name, `entity.${name}`])
  );
  var ACCOUNT_BOUND_ENTITIES = [
    "extensionAccounts"
  ];
  function isDeletableEntity(name) {
    return !ACCOUNT_BOUND_ENTITIES.includes(name);
  }
  var newestFirst = (a, b) => b.updatedAt.localeCompare(a.updatedAt) || a.id.localeCompare(b.id);
  var DataService = class {
    constructor(accounts2 = new AccountService(), settings = runtimeSettingsArea) {
      this.accounts = accounts2;
      this.settings = settings;
    }
    counts(accountId) {
      return countAccountRecords(accountId);
    }
    async records(accountId, name) {
      const records = await repositories[name].list(accountId);
      return records.sort(newestFirst);
    }
    exportAccount(accountId) {
      return exportAccount(accountId);
    }
    async exportAll() {
      const [data2, settings] = await Promise.all([
        exportAllData(),
        this.settingsSnapshot()
      ]);
      return { ...data2, settings };
    }
    async deleteRecord(accountId, name, id) {
      this.#requireDeletable(name);
      await this.#locked(
        accountId,
        () => repositories[name].delete(accountId, id)
      );
    }
    async deleteEntity(accountId, name) {
      this.#requireDeletable(name);
      await this.#locked(
        accountId,
        () => deleteAccountEntities(accountId, [name])
      );
    }
    /**
     * Deletes every record in the account except the account itself, so the
     * account stays registered (and active, if it was) with no data under it.
     * Removing the account too is the Accounts panel's "Remove".
     */
    async clearAccountData(accountId) {
      await this.#locked(
        accountId,
        () => deleteAccountEntities(accountId, ENTITY_NAMES.filter(isDeletableEntity))
      );
    }
    /**
     * Deletes everything JoyFox stores in this browser profile: every record
     * in every store, whatever its scope, and every `storage.local` setting.
     * The active pointer goes first, so a page or write that runs meanwhile
     * sees no active account instead of a half-deleted one. The exclusive data
     * lock is held while the stores and settings are emptied, and both are
     * checked empty before success is reported.
     */
    async deleteEverything() {
      await this.settings.remove([ACTIVE_ACCOUNT_SETTING_KEY]);
      await withExclusiveDataLock(async () => {
        await clearAllData();
        await this.settings.clear();
        if (await countAllRecords() > 0 || Object.keys(await this.settings.getAll()).length > 0)
          throw new Error("Data was written while deleting");
      });
    }
    /** How many profile snapshots are kept per member (V1-12). */
    snapshotRetention() {
      return readSnapshotRetention(this.settings);
    }
    /**
     * Saves how many profile snapshots are kept per member, then deletes the
     * older snapshots of every member in every account at once. Holds the
     * exclusive data lock, so no capture or import overlaps the purge. Returns
     * how many snapshots were deleted.
     */
    async setSnapshotRetention(keep) {
      if (!isSnapshotRetention(keep))
        throw new ExtensionError("StorageError", "Invalid snapshot retention", {
          display: message("data.retentionInvalid", {
            minimum: MIN_SNAPSHOT_RETENTION,
            maximum: MAX_SNAPSHOT_RETENTION
          })
        });
      return withExclusiveDataLock(async () => {
        await this.settings.set({ [SNAPSHOT_RETENTION_KEY]: keep });
        return repositories.profileSnapshots.pruneAll(keep);
      });
    }
    /** The export reminder setting and the last full export (never fails). */
    exportReminder() {
      return readExportReminder(this.settings);
    }
    /** Saves how many days after a full export the reminder shows; 0 is off. */
    async setExportReminderDays(days) {
      if (!isExportReminderDays(days))
        throw new ExtensionError("StorageError", "Invalid export reminder", {
          display: message("data.reminderInvalid", {
            minimum: MIN_EXPORT_REMINDER_DAYS,
            maximum: MAX_EXPORT_REMINDER_DAYS
          })
        });
      await this.settings.set({ [EXPORT_REMINDER_KEY]: days });
    }
    /** Notes that a full export was saved now, which resets the reminder. */
    async recordFullExport(at = /* @__PURE__ */ new Date()) {
      await this.settings.set({ [LAST_EXPORT_KEY]: at.toISOString() });
    }
    /**
     * Check a file and show what importing it would change, without writing.
     * The returned signature must be passed to `applyImport`.
     */
    async previewImport(text) {
      return planImport(parseImportFile(text), await this.#snapshot());
    }
    /**
     * Merge a file into stored data. Holds the exclusive data lock, so no write
     * overlaps it, and plans again from current data: if the result differs
     * from the preview, nothing is written. All records are written in one
     * transaction, so a failure leaves stored records unchanged.
     * Settings, then the snapshot limit (V1-12), follow as best-effort steps.
     */
    async applyImport(text, signature) {
      const file = parseImportFile(text);
      const plan = await withExclusiveDataLock(async () => {
        const current = planImport(file, await this.#snapshot());
        if (current.signature !== signature)
          throw new ExtensionError(
            "StorageError",
            "Stored data changed while the file was checked. Choose the file again",
            { display: message("error.data.changedDuringCheck") }
          );
        await putRecords(current.writes);
        let settingsSaved = true;
        if (Object.keys(current.settings).length > 0)
          try {
            await this.settings.set(current.settings);
          } catch {
            settingsSaved = false;
          }
        try {
          await repositories.profileSnapshots.pruneAll(
            await readSnapshotRetention(this.settings)
          );
        } catch {
        }
        try {
          await new MessageCacheService(this.settings).prune();
        } catch {
        }
        return { ...current, settingsSaved };
      });
      await bumpTriageRevision(this.settings);
      return plan;
    }
    async #snapshot() {
      const [data2, settings] = await Promise.all([
        exportAllData(),
        this.settings.getAll()
      ]);
      return { entities: data2.entities, settings };
    }
    /**
     * Every JoyFox setting in `storage.local` (the active pointer and opt-in
     * flags), for the full export. Values are small and never sensitive.
     */
    settingsSnapshot() {
      return this.settings.getAll();
    }
    #requireDeletable(name) {
      if (!ENTITY_NAMES.includes(name))
        throw new ExtensionError("StorageError", "Unknown data type", {
          display: message("error.data.unknownType")
        });
      if (!isDeletableEntity(name))
        throw new ExtensionError(
          "StorageError",
          "The account record is removed only with the whole account",
          { display: message("error.data.accountRecord") }
        );
    }
    /**
     * The account must still exist inside the lock: a delete for an account
     * removed meanwhile has nothing to act on and reports that plainly.
     */
    async #locked(accountId, action) {
      await withAccountLock(accountId, async () => {
        const directory = await this.accounts.listAccounts();
        if (!directory.some((account) => account.id === accountId))
          throw new ExtensionError(
            "IdentityMismatch",
            "That account no longer exists",
            { display: message("error.account.gone") }
          );
        await action();
      });
      await bumpTriageRevision(this.settings);
    }
  };
  function serializeExport(data2) {
    return `${JSON.stringify(data2, null, 2)}
`;
  }
  function exportFileName(data2) {
    const day = data2.exportedAt.slice(0, 10);
    return data2.scope === "all" ? `joyfox-export-all-${day}.json` : `joyfox-export-account-${day}.json`;
  }

  // src/triage/shared-event.ts
  var SHARED_EVENT_EXCEPTION_KEY = "joyfox.sharedEventException";

  // src/options/record-fields.ts
  var DATE_PATHS = /* @__PURE__ */ new Set([
    "capturedAt",
    "createdAt",
    "decidedAt",
    "joinedAt",
    "joinedEarliest",
    "joinedLatest",
    "lastSyncedAt",
    "matchedAt",
    "observedAt",
    "occurredAt",
    "attendeesSeenAt",
    "sentAt",
    "steps[].at",
    "updatedAt"
  ]);
  var DATE_PATH_STEPS = new Set(
    [...DATE_PATHS].flatMap((path) => {
      const steps = [path];
      for (let index = 0; index < path.length; index += 1)
        if (path[index] === "." || path.startsWith("[]", index))
          steps.push(path.slice(0, index));
      return steps;
    })
  );
  var LONGEST_DATE_STEP = Math.max(
    ...[...DATE_PATH_STEPS].map((step) => step.length)
  );
  function childPath(parent, name, separator = ".") {
    if (parent === void 0 || name.length > LONGEST_DATE_STEP) return void 0;
    const path = parent === "" ? name : `${parent}${separator}${name}`;
    return DATE_PATH_STEPS.has(path) ? path : void 0;
  }
  function readableDate(path, value) {
    if (path === void 0 || !DATE_PATHS.has(path) || !isStrictIsoDate(value))
      return void 0;
    return value.includes("T") ? formatDateTime(value) : formatDate(value);
  }
  function hasNoFields(value) {
    for (const key2 in value) if (Object.hasOwn(value, key2)) return false;
    return true;
  }
  function isEmpty(value) {
    return value === null || value === "" || Array.isArray(value) && value.length === 0 || typeof value === "object" && value !== null && !Array.isArray(value) && hasNoFields(value);
  }
  function span(document2, className, text) {
    const node = document2.createElement("span");
    node.className = className;
    node.textContent = text;
    return node;
  }
  var MAX_SHOWN_VALUES = 200;
  var MAX_SHOWN_CHARACTERS = 1e3;
  function cut(text) {
    if (text.length <= MAX_SHOWN_CHARACTERS) return { shown: text, omitted: 0 };
    let end = MAX_SHOWN_CHARACTERS;
    const last = text.charCodeAt(end - 1);
    if (last >= 55296 && last <= 56319) end -= 1;
    return { shown: text.slice(0, end), omitted: text.length - end };
  }
  function moreCharacters(document2, count) {
    return span(
      document2,
      "joyfox-data__value--more",
      t("data.moreCharacters", { count })
    );
  }
  function renderText(document2, text) {
    const { shown, omitted } = cut(text);
    const node = span(document2, "joyfox-data__value--text", shown);
    if (omitted > 0) node.append(" ", moreCharacters(document2, omitted));
    return node;
  }
  function more(document2, count) {
    return span(
      document2,
      "joyfox-data__value--more",
      t("data.moreValues", { count })
    );
  }
  function renderValue(document2, value, budget, path) {
    budget.left -= 1;
    if (isEmpty(value))
      return span(document2, "joyfox-data__value--empty", t("data.valueEmpty"));
    if (typeof value === "boolean")
      return span(
        document2,
        "joyfox-data__value",
        t(value ? "data.valueYes" : "data.valueNo")
      );
    if (typeof value === "number")
      return span(document2, "joyfox-data__value", formatExactNumber(value));
    if (typeof value === "string") {
      const date = readableDate(path, value);
      if (date !== void 0) {
        const time = document2.createElement("time");
        time.className = "joyfox-data__value";
        time.dateTime = value;
        time.title = value;
        time.textContent = date;
        return time;
      }
      return renderText(document2, value);
    }
    if (Array.isArray(value)) {
      const list = document2.createElement("ul");
      list.className = "joyfox-data__list";
      for (const [index, item] of value.entries()) {
        const entry = document2.createElement("li");
        if (budget.left <= 0) {
          entry.append(more(document2, value.length - index));
          list.append(entry);
          break;
        }
        entry.append(
          renderValue(document2, item, budget, childPath(path, "[]", ""))
        );
        list.append(entry);
      }
      return list;
    }
    if (typeof value === "object" && value !== null)
      return fields(document2, value, budget, path);
    return span(document2, "joyfox-data__value", String(value));
  }
  function fields(document2, record, budget, path) {
    const list = document2.createElement("dl");
    list.className = "joyfox-data__fields";
    let omitted = 0;
    for (const key2 in record) {
      if (!Object.hasOwn(record, key2)) continue;
      const value = record[key2];
      if (value === void 0) continue;
      if (omitted > 0 || budget.left <= 0) {
        omitted += 1;
        continue;
      }
      const term = document2.createElement("dt");
      const shownKey = cut(key2);
      const name = document2.createElement("code");
      name.textContent = shownKey.shown;
      term.append(name);
      if (shownKey.omitted > 0)
        term.append(" ", moreCharacters(document2, shownKey.omitted));
      const description = document2.createElement("dd");
      description.append(
        renderValue(document2, value, budget, childPath(path, key2))
      );
      list.append(term, description);
    }
    if (omitted > 0) {
      const term = document2.createElement("dt");
      term.textContent = "\u2026";
      const description = document2.createElement("dd");
      description.append(more(document2, omitted));
      list.append(term, description);
    }
    return list;
  }
  function renderFields(document2, record) {
    return fields(document2, record, { left: MAX_SHOWN_VALUES }, "");
  }

  // src/options/data-panel.ts
  function element2(document2, tag, className, text) {
    const node = document2.createElement(tag);
    node.className = className;
    if (text !== void 0) node.textContent = text;
    return node;
  }
  function withTabLinks(document2, text) {
    const fragment = document2.createDocumentFragment();
    for (const part of text.split(/(\[[^\]]+\]\(#[a-z]+\))/u)) {
      const link = /^\[([^\]]+)\]\((#[a-z]+)\)$/u.exec(part);
      if (!link) {
        if (part) fragment.append(part);
        continue;
      }
      const anchor = document2.createElement("a");
      anchor.textContent = link[1] ?? "";
      anchor.href = link[2] ?? "";
      fragment.append(anchor);
    }
    return fragment;
  }
  function accountName(account) {
    const label = account.label?.trim();
    return label && label !== account.joyClubAccountId ? t("accounts.nameWithIdentifier", {
      label,
      identifier: account.joyClubAccountId
    }) : account.joyClubAccountId;
  }
  function readText(file) {
    if (typeof file.text === "function") return file.text();
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result ?? ""));
      reader.onerror = () => reject(reader.error ?? new Error("Unreadable file"));
      reader.readAsText(file);
    });
  }
  var RECORD_PAGE_SIZE = 50;
  var browserFileSaver = (name, text) => {
    const document2 = globalThis.document;
    const url = URL.createObjectURL(
      new Blob([text], { type: "application/json" })
    );
    const link = document2.createElement("a");
    link.href = url;
    link.download = name;
    link.hidden = true;
    document2.body.append(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 0);
  };
  function whenOpened(details, fill) {
    let filled = false;
    const run = () => {
      if (filled || !details.open) return;
      filled = true;
      fill();
    };
    details.addEventListener("toggle", run);
    run();
  }
  var SETTING_NAMES = {
    [ACTIVE_ACCOUNT_SETTING_KEY]: "data.setting.activeAccount",
    [LOCALE_KEY]: "data.setting.language",
    [EXPORT_REMINDER_KEY]: "data.setting.exportReminder",
    [MESSAGE_CACHING_KEY]: "data.setting.messageCaching",
    [MESSAGE_RETENTION_KEY]: "data.setting.messageRetention",
    [QUICK_ACTION_KEY]: "data.setting.quickIgnoreDelete",
    "joyfox.templatePicker": "data.setting.templatePicker",
    [SHARED_EVENT_EXCEPTION_KEY]: "data.setting.sharedEventException",
    [SNAPSHOT_RETENTION_KEY]: "data.setting.snapshotRetention",
    "joyfox.diagnostics": "data.setting.diagnostics",
    "joyfox.stripCollapsed": "data.setting.stripCollapsed"
  };
  var isNamedSetting = (key2) => Object.hasOwn(SETTING_NAMES, key2);
  function settingNames(keys) {
    return keys.filter(isNamedSetting).map((key2) => t(SETTING_NAMES[key2])).join(", ");
  }
  var focusFell2 = (document2) => !document2.activeElement || document2.activeElement === document2.body;
  var DELETE_FAILED = {
    suffix: "error.withSuffix.nothingDeleted",
    fallback: "data.actionFailed"
  };
  var EXPORT_FAILED = {
    suffix: "error.withSuffix.nothingExported",
    fallback: "data.exportFailed"
  };
  var SETTING_FAILED = {
    suffix: "error.withSuffix.settingNotChanged",
    fallback: "data.retentionFailed"
  };
  var samePending = (a, b) => JSON.stringify(a) === JSON.stringify(b);
  function memberNames(records) {
    const names = /* @__PURE__ */ new Map();
    for (const record of records) {
      const { joyClubMemberId, nickname } = record;
      if (typeof joyClubMemberId === "string" && typeof nickname === "string")
        names.set(joyClubMemberId, nickname);
    }
    return names;
  }
  var DataPanel = class {
    constructor(root, data2 = new DataService(), accounts2 = new AccountService(), saveFile = browserFileSaver, onChange = () => void 0, importRoot) {
      this.root = root;
      this.data = data2;
      this.accounts = accounts2;
      this.saveFile = saveFile;
      this.onChange = onChange;
      this.importRoot = importRoot;
      this.#status = new StatusLine(root.ownerDocument);
      this.#importStatus = importRoot ? new StatusLine(root.ownerDocument) : this.#status;
    }
    #status;
    /** Import's own status line, beside it when it has its own place. */
    #importStatus;
    #generation = 0;
    /** The account being inspected; not necessarily the active one. */
    #selected;
    #shown;
    #shownLimit = RECORD_PAGE_SIZE;
    /** The records expanded when the panel was last drawn. */
    #openRecords = /* @__PURE__ */ new Set();
    #pending;
    #armedAt = 0;
    /** What the last import changed, shown until the next file choice. */
    #importResult;
    /**
     * True from a file choice until its import settles. The file chooser is
     * disabled meanwhile, so a second choice can never overlap a write.
     */
    #importing = false;
    /** Where the next draw puts focus, whatever had it before. */
    #focusNext;
    /**
     * The control that had focus when an import started. The disabled file
     * chooser drops focus to the page; the draw after the import puts it back.
     */
    #focusBefore;
    /** Nicknames by member ID, for the shown account's records. */
    #names = /* @__PURE__ */ new Map();
    /**
     * The name a person knows a record by, if it has one: a template's or
     * saved search's name, an event's title, an account's label, or the
     * member's nickname.
     */
    #recordName(entity, record) {
      const fields2 = record;
      const text = (value) => typeof value === "string" && value.trim() ? value.trim() : void 0;
      switch (entity) {
        case "messageTemplates":
        case "savedSearches":
          return text(fields2.name);
        case "eventMetadata":
          return text(fields2.title) ?? text(fields2.venueName);
        case "extensionAccounts":
          return text(fields2.label) ?? text(fields2.joyClubAccountId);
      }
      const memberId = fields2.joyClubMemberId ?? fields2.memberId;
      return typeof memberId === "string" ? this.#names.get(memberId) : void 0;
    }
    /** A record's line: its name if it has one, then its ID and date. */
    #summary(entity, record) {
      const updated = formatDate(record.updatedAt);
      const name = this.#recordName(entity, record);
      return name ? t("data.recordSummaryNamed", { name, id: record.id, updated }) : t("data.recordSummary", { id: record.id, updated });
    }
    /** A record in delete labels and messages: its name first, then its ID. */
    #recordText(entity, record) {
      const name = this.#recordName(entity, record);
      return name ? t("data.recordNamed", { name, id: record.id }) : record.id;
    }
    async render() {
      const generation = this.#generation += 1;
      const document2 = this.root.ownerDocument;
      let accounts2;
      let selected;
      let counts;
      let records = [];
      let names = /* @__PURE__ */ new Map();
      const retention = await this.data.snapshotRetention();
      const reminder = await this.data.exportReminder();
      try {
        accounts2 = await this.accounts.listAccounts();
        const activeId = (await this.accounts.getActiveAccount())?.id;
        selected = accounts2.some((a) => a.id === this.#selected) ? this.#selected : activeId ?? accounts2[0]?.id;
        if (selected) {
          counts = await this.data.counts(selected);
          if (this.#shown && selected === this.#selected) {
            records = await this.data.records(selected, this.#shown);
            names = memberNames(
              this.#shown === "joyClubMembers" ? records : await this.data.records(selected, "joyClubMembers")
            );
          }
        }
      } catch {
        if (generation === this.#generation) {
          const focus2 = this.#rememberFocus(document2);
          this.root.textContent = t("data.readFailed");
          this.#importStatus.redraw();
          this.importRoot?.replaceChildren(
            this.#renderImport(document2),
            this.#importStatus.node
          );
          if (this.importRoot) restoreFocus(this.importRoot, focus2);
        }
        return;
      }
      if (generation !== this.#generation) return;
      this.#names = names;
      if (selected !== this.#selected) {
        this.#shown = void 0;
        this.#shownLimit = RECORD_PAGE_SIZE;
        this.#pending = void 0;
      }
      this.#selected = selected;
      this.#openRecords = new Set(
        Array.from(
          this.root.querySelectorAll(".joyfox-data__record")
        ).filter((item) => item.querySelector("details")?.open).map((item) => item.dataset.recordId ?? "")
      );
      const focus = this.#rememberFocus(document2);
      this.root.replaceChildren();
      this.#status.redraw();
      this.#importStatus.redraw();
      const heading = element2(
        document2,
        "h2",
        "joyfox-panel__heading",
        t("options.tabs.data")
      );
      heading.id = "joyfox-data-heading";
      this.root.setAttribute("aria-labelledby", heading.id);
      this.root.append(
        heading,
        element2(document2, "p", "joyfox-panel__hint", t("data.hint"))
      );
      if (this.importRoot) {
        const pointer = element2(document2, "p", "joyfox-panel__hint");
        pointer.append(withTabLinks(document2, t("data.importPointer")));
        this.root.append(pointer);
      }
      if (accounts2.length > 0 && selected && counts) {
        this.root.append(
          this.#renderAccountPicker(document2, accounts2, selected),
          this.#renderCounts(document2, counts)
        );
        if (this.#shown)
          this.root.append(this.#renderRecords(document2, this.#shown, records));
        this.root.append(this.#renderAccountActions(document2));
      } else {
        this.root.append(
          element2(document2, "p", "joyfox-panel__empty", t("data.noAccounts"))
        );
      }
      this.root.append(
        this.#renderRetention(document2, retention),
        this.#renderReminderSetting(document2, reminder.days),
        this.#renderGlobalActions(document2, reminder, accounts2.length > 0),
        this.#status.node
      );
      this.importRoot?.replaceChildren(
        this.#renderImport(document2),
        this.#importStatus.node
      );
      const next = this.#focusNext;
      this.#focusNext = void 0;
      if (next) restoreFocus(this.root, next);
      else if (!restoreFocus(this.root, focus, this.#fallbacks(focus))) {
        if (this.importRoot) restoreFocus(this.importRoot, focus);
      }
    }
    /** The keyed control that has focus, in this panel or in Import. */
    #rememberFocus(document2) {
      return rememberFocus(this.root) ?? rememberFocus(this.importRoot) ?? (focusFell2(document2) ? this.#focusBefore : void 0);
    }
    /**
     * Where focus goes when its control is gone after a draw: after a record
     * is deleted, the list's heading; after a type is emptied, the table.
     */
    #fallbacks(focus) {
      const kind = focus?.key.split(":")[0];
      switch (kind) {
        case "delete":
        case "record":
        case "more":
          return ["records-heading", "counts"];
        case "delete-all":
        case "show":
          return ["counts"];
        default:
          return [];
      }
    }
    #renderAccountPicker(document2, accounts2, selected) {
      const wrapper = element2(document2, "p", "joyfox-panel__field");
      const label = element2(
        document2,
        "label",
        "joyfox-panel__field-label",
        t("data.accountPicker")
      );
      label.htmlFor = "joyfox-data-account";
      const select = element2(document2, "select", "joyfox-data__account");
      select.id = "joyfox-data-account";
      select.setAttribute(FOCUS_KEY, "account-picker");
      for (const account of accounts2) {
        const option = document2.createElement("option");
        option.value = account.id;
        option.textContent = accountName(account);
        option.selected = account.id === selected;
        select.append(option);
      }
      select.addEventListener("change", () => {
        this.#selected = select.value;
        this.#shown = void 0;
        this.#pending = void 0;
        this.#status.clear();
        void this.render();
      });
      wrapper.append(label, select);
      return wrapper;
    }
    #renderCounts(document2, counts) {
      const table = element2(document2, "table", "joyfox-data__counts");
      table.tabIndex = -1;
      table.setAttribute(FOCUS_KEY, "counts");
      const caption = element2(
        document2,
        "caption",
        "joyfox-data__caption",
        t("data.caption")
      );
      const head = document2.createElement("thead");
      const headRow = document2.createElement("tr");
      for (const title of [
        t("data.col.type"),
        t("data.col.records"),
        t("data.col.actions")
      ]) {
        const cell = element2(document2, "th", "", title);
        cell.scope = "col";
        headRow.append(cell);
      }
      head.append(headRow);
      const body = document2.createElement("tbody");
      for (const name of ENTITY_NAMES) {
        const row = document2.createElement("tr");
        row.dataset.entity = name;
        const title = element2(document2, "th", "", t(ENTITY_LABELS[name]));
        title.scope = "row";
        const count = element2(
          document2,
          "td",
          "joyfox-data__count",
          formatNumber(counts[name])
        );
        const cell = document2.createElement("td");
        const actions = element2(document2, "div", "joyfox-data__actions");
        cell.append(actions);
        const label = message(ENTITY_LABELS[name]);
        if (counts[name] > 0) {
          const showing = this.#shown === name;
          const show = this.#button(
            document2,
            "joyfox-data__show",
            t(showing ? "data.hide" : "data.show"),
            t(showing ? "data.hideLabel" : "data.showLabel", { label }),
            () => {
              this.#pending = void 0;
              this.#shown = showing ? void 0 : name;
              this.#shownLimit = RECORD_PAGE_SIZE;
              if (!showing)
                this.#focusNext = { key: "records-heading", scroll: true };
              void this.render();
            }
          );
          show.setAttribute(FOCUS_KEY, `show:${name}`);
          actions.append(show);
          if (isDeletableEntity(name))
            actions.append(
              this.#confirmButton(
                document2,
                `delete-all:${name}`,
                { kind: "entity", entity: name },
                t("data.deleteAll"),
                message("data.deleteAllLabel", { label }),
                message("data.deleteAllPrompt", { count: counts[name], label }),
                (accountId) => this.data.deleteEntity(accountId, name),
                message("data.deletedAll", { label })
              )
            );
        }
        row.append(title, count, cell);
        body.append(row);
      }
      table.append(caption, head, body);
      return table;
    }
    #renderRecords(document2, name, records) {
      const section = element2(document2, "div", "joyfox-data__records");
      const title = element2(
        document2,
        "h3",
        "joyfox-data__records-title",
        t("data.recordsTitle", {
          label: message(ENTITY_LABELS[name]),
          count: records.length
        })
      );
      title.tabIndex = -1;
      title.setAttribute(FOCUS_KEY, "records-heading");
      section.append(title);
      if (!isDeletableEntity(name)) {
        const hint = element2(document2, "p", "joyfox-panel__hint");
        hint.append(withTabLinks(document2, t("data.accountRecordHint")));
        section.append(hint);
      }
      const list = element2(document2, "ul", "joyfox-data__record-list");
      for (const record of records.slice(0, this.#shownLimit)) {
        const item = element2(document2, "li", "joyfox-data__record");
        item.dataset.recordId = record.id;
        const details = element2(document2, "details", "joyfox-data__details");
        const summary = element2(
          document2,
          "summary",
          "",
          this.#summary(name, record)
        );
        summary.setAttribute(FOCUS_KEY, `record:${record.id}`);
        details.append(summary);
        details.open = this.#openRecords.has(record.id);
        whenOpened(details, () => {
          const raw = element2(document2, "details", "joyfox-data__raw");
          raw.append(element2(document2, "summary", "", t("data.rawJson")));
          whenOpened(
            raw,
            () => raw.append(
              element2(
                document2,
                "pre",
                "joyfox-data__json",
                JSON.stringify(record, null, 2)
              )
            )
          );
          const log = record;
          if (name === "actionLogs" && isQuickAction(log.action))
            details.append(this.#renderReport(document2, log));
          details.append(
            renderFields(document2, record),
            raw
          );
        });
        item.append(details);
        if (isDeletableEntity(name)) {
          const shown = this.#recordText(name, record);
          item.append(
            this.#confirmButton(
              document2,
              `delete:${record.id}`,
              { kind: "record", entity: name, id: record.id },
              t("data.delete"),
              message("data.deleteRecordLabel", { record: shown }),
              message("data.deleteRecordPrompt", { record: shown }),
              (accountId) => this.data.deleteRecord(accountId, name, record.id),
              message("data.deletedRecord", { record: shown })
            )
          );
        }
        list.append(item);
      }
      section.append(list);
      if (records.length > this.#shownLimit)
        section.append(
          this.#button(
            document2,
            "joyfox-data__more",
            t("data.showMore", {
              count: Math.min(
                RECORD_PAGE_SIZE,
                records.length - this.#shownLimit
              )
            }),
            void 0,
            () => {
              this.#pending = void 0;
              const first = records[this.#shownLimit];
              if (first)
                this.#focusNext = { key: `record:${first.id}`, scroll: true };
              this.#shownLimit += RECORD_PAGE_SIZE;
              void this.render();
            },
            "more"
          )
        );
      return section;
    }
    /** What an Ignore and Delete run did, from its steps (PRD Section 21.2). */
    #renderReport(document2, log) {
      const list = element2(document2, "ul", "joyfox-data__report");
      try {
        for (const line of reportOperation(log, Date.now()).lines)
          list.append(element2(document2, "li", "", t(line)));
      } catch {
        list.replaceChildren();
      }
      return list;
    }
    #renderAccountActions(document2) {
      const actions = element2(document2, "p", "joyfox-data__account-actions");
      actions.append(
        this.#button(
          document2,
          "joyfox-data__export",
          t("data.exportAccount"),
          void 0,
          () => void this.#guard(async () => {
            this.#pending = void 0;
            const accountId = this.#requireSelected();
            const exported = await this.data.exportAccount(accountId);
            this.saveFile(exportFileName(exported), serializeExport(exported));
            this.#setStatus(message("data.exportedAccount"), "info");
          }, EXPORT_FAILED),
          "export"
        ),
        document2.createTextNode(" "),
        this.#confirmButton(
          document2,
          "delete-account",
          { kind: "account" },
          t("data.deleteAccountData"),
          message("data.deleteAccountDataLabel"),
          message("data.deleteAccountDataPrompt"),
          (accountId) => this.data.clearAccountData(accountId),
          message("data.deletedAccountData")
        )
      );
      return actions;
    }
    /**
     * How many profile snapshots are kept per member (V1-12, PRD 13.3). Saving a
     * lower number deletes older snapshots at once, in every account.
     */
    #renderRetention(document2, current) {
      const section = element2(document2, "div", "joyfox-data__retention");
      const field = element2(document2, "p", "joyfox-panel__field");
      const label = element2(
        document2,
        "label",
        "joyfox-panel__field-label",
        t("data.retentionLabel")
      );
      label.htmlFor = "joyfox-data-retention";
      const input = element2(document2, "input", "joyfox-data__retention-input");
      input.id = "joyfox-data-retention";
      input.type = "number";
      input.step = "1";
      input.min = String(MIN_SNAPSHOT_RETENTION);
      input.max = String(MAX_SNAPSHOT_RETENTION);
      const pending = this.#pending;
      const armed = pending?.kind === "retention" ? pending : void 0;
      input.value = String(armed?.keep ?? current);
      input.setAttribute(FOCUS_KEY, "retention");
      const hint = element2(
        document2,
        "p",
        "joyfox-panel__hint",
        t("data.retentionHint", {
          minimum: MIN_SNAPSHOT_RETENTION,
          maximum: MAX_SNAPSHOT_RETENTION,
          default: DEFAULT_SNAPSHOT_RETENTION
        })
      );
      hint.id = "joyfox-data-retention-hint";
      input.setAttribute("aria-describedby", hint.id);
      const save = this.#button(
        document2,
        "joyfox-data__retention-save",
        t(armed ? "data.retentionConfirm" : "data.retentionSave"),
        void 0,
        (event) => {
          const keep = Number(input.value);
          if (isSnapshotRetention(keep) && keep < current) {
            const live = this.#pending;
            if (!armed || armed.keep !== keep || live?.kind !== "retention" || live.keep !== keep) {
              if (event.detail > 1) return;
              this.#pending = { kind: "retention", keep };
              this.#armedAt = confirmTiming.now();
              this.#setStatus(
                message("data.retentionConfirmPrompt", { keep }),
                "info"
              );
              void this.render();
              return;
            }
            if (!confirmAllowed(event, this.#armedAt)) return;
          }
          void this.#guard(async () => {
            this.#pending = void 0;
            if (!isSnapshotRetention(keep)) {
              this.#setStatus(
                message("data.retentionInvalid", {
                  minimum: MIN_SNAPSHOT_RETENTION,
                  maximum: MAX_SNAPSHOT_RETENTION
                }),
                "error"
              );
              return;
            }
            const deleted = await this.data.setSnapshotRetention(keep);
            this.#setStatus(message("data.retentionSaved", { deleted }), "info");
            this.onChange();
          }, SETTING_FAILED);
        },
        "retention-save"
      );
      input.addEventListener("input", () => {
        if (this.#pending?.kind !== "retention") return;
        this.#pending = void 0;
        save.textContent = t("data.retentionSave");
        this.#status.clear();
      });
      field.append(label, " ", input, " ", save);
      section.append(field, hint);
      return section;
    }
    /**
     * How many days after a full export "Your data" asks for a new one. Saving
     * deletes nothing, so it saves on the first click.
     */
    #renderReminderSetting(document2, current) {
      const section = element2(document2, "div", "joyfox-data__reminder-setting");
      const field = element2(document2, "p", "joyfox-panel__field");
      const label = element2(
        document2,
        "label",
        "joyfox-panel__field-label",
        t("data.reminderLabel")
      );
      label.htmlFor = "joyfox-data-export-reminder";
      const input = element2(document2, "input", "joyfox-data__reminder-input");
      input.id = "joyfox-data-export-reminder";
      input.type = "number";
      input.step = "1";
      input.min = String(MIN_EXPORT_REMINDER_DAYS);
      input.max = String(MAX_EXPORT_REMINDER_DAYS);
      input.value = String(current);
      input.setAttribute(FOCUS_KEY, "export-reminder");
      const hint = element2(
        document2,
        "p",
        "joyfox-panel__hint",
        t("data.reminderHint", {
          minimum: MIN_EXPORT_REMINDER_DAYS,
          maximum: MAX_EXPORT_REMINDER_DAYS,
          default: DEFAULT_EXPORT_REMINDER_DAYS
        })
      );
      hint.id = "joyfox-data-export-reminder-hint";
      input.setAttribute("aria-describedby", hint.id);
      const save = this.#button(
        document2,
        "joyfox-data__reminder-save",
        t("data.reminderSave"),
        void 0,
        () => void this.#guard(async () => {
          this.#pending = void 0;
          const days = input.value.trim() ? Number(input.value) : Number.NaN;
          if (!isExportReminderDays(days)) {
            this.#setStatus(
              message("data.reminderInvalid", {
                minimum: MIN_EXPORT_REMINDER_DAYS,
                maximum: MAX_EXPORT_REMINDER_DAYS
              }),
              "error"
            );
            return;
          }
          await this.data.setExportReminderDays(days);
          this.#setStatus(message("data.reminderSaved", { days }), "info");
        }, SETTING_FAILED),
        "reminder-save"
      );
      field.append(label, " ", input, " ", save);
      section.append(field, hint);
      return section;
    }
    /**
     * The backup line above "Export all": a reminder when a full export is
     * due, else when the last one was. Only a full export counts, as only it
     * holds every account and setting.
     */
    #renderLastExport(document2, reminder, hasAccounts) {
      const now = /* @__PURE__ */ new Date();
      const days = reminder.lastExportAt ? daysSinceExport(reminder.lastExportAt, now) : void 0;
      if (hasAccounts && exportDue(reminder, now))
        return [
          element2(
            document2,
            "p",
            "joyfox-data__reminder",
            days === void 0 ? t("data.reminderNever") : t("data.reminderDue", { days })
          )
        ];
      if (days === void 0) return [];
      return [
        element2(
          document2,
          "p",
          "joyfox-panel__hint joyfox-data__last-export",
          t("data.lastExport", { days })
        )
      ];
    }
    #renderGlobalActions(document2, reminder, hasAccounts) {
      const section = element2(document2, "div", "joyfox-data__global");
      section.append(
        element2(
          document2,
          "h3",
          "joyfox-data__global-title",
          t("data.allAccounts")
        ),
        ...this.#renderLastExport(document2, reminder, hasAccounts),
        this.#button(
          document2,
          "joyfox-data__export-all",
          t("data.exportAll"),
          void 0,
          () => void this.#guard(async () => {
            this.#pending = void 0;
            const exported = await this.data.exportAll();
            this.saveFile(exportFileName(exported), serializeExport(exported));
            this.#setStatus(message("data.exportedAll"), "info");
            try {
              await this.data.recordFullExport();
            } catch {
            }
          }, EXPORT_FAILED),
          "export-all"
        ),
        document2.createTextNode(" "),
        this.#confirmButton(
          document2,
          "delete-everything",
          { kind: "all" },
          t("data.deleteEverything"),
          message("data.deleteEverythingLabel"),
          message("data.deleteEverythingPrompt"),
          () => this.data.deleteEverything(),
          message("data.deletedEverything")
        ),
        ...this.importRoot ? [] : [this.#renderImport(document2)]
      );
      return section;
    }
    /**
     * Import (owner request, ADR 0009): choosing a file imports it. The file is
     * checked first, and a file that fails the check writes nothing. The
     * result shows what the import changed.
     */
    #renderImport(document2) {
      const section = element2(document2, "div", "joyfox-data__import");
      section.append(
        element2(
          document2,
          "h3",
          "joyfox-data__import-title",
          t("data.import.title")
        ),
        element2(document2, "p", "joyfox-panel__hint", t("data.import.hint"))
      );
      const field = element2(document2, "p", "joyfox-panel__field");
      const label = element2(
        document2,
        "label",
        "joyfox-panel__field-label",
        t("data.import.fileLabel")
      );
      label.htmlFor = "joyfox-data-import";
      const input = element2(document2, "input", "joyfox-data__import-file");
      input.type = "file";
      input.id = "joyfox-data-import";
      input.accept = ".json,application/json";
      input.disabled = this.#importing;
      input.setAttribute(FOCUS_KEY, "import-file");
      input.addEventListener("change", () => {
        const file = input.files?.[0];
        if (!file || this.#importing) return;
        this.#importing = true;
        this.#focusBefore = this.#rememberFocus(input.ownerDocument);
        input.disabled = true;
        void this.#importFile(file);
      });
      field.append(label, input);
      section.append(field);
      if (this.#importResult)
        section.append(this.#renderImportResult(document2, this.#importResult));
      return section;
    }
    #renderImportResult(document2, plan) {
      const preview2 = element2(document2, "div", "joyfox-data__import-result");
      const { matched, added } = plan.accounts;
      preview2.append(
        element2(
          document2,
          "p",
          "",
          t(
            plan.scope === "all" ? "data.import.summary.all" : "data.import.summary.account",
            { matched, added, total: matched + added }
          )
        )
      );
      const table = element2(document2, "table", "joyfox-data__counts");
      table.append(
        element2(
          document2,
          "caption",
          "joyfox-data__caption",
          t("data.import.caption")
        )
      );
      const head = document2.createElement("tr");
      for (const title of [
        t("data.col.type"),
        t("data.import.col.added"),
        t("data.import.col.replaced"),
        t("data.import.col.kept"),
        t("data.import.col.duplicates")
      ]) {
        const cell = element2(document2, "th", "", title);
        cell.scope = "col";
        head.append(cell);
      }
      const thead = document2.createElement("thead");
      thead.append(head);
      const body = document2.createElement("tbody");
      let rows = 0;
      for (const name of ENTITY_NAMES) {
        const count = plan.counts[name];
        if (count.added + count.replaced + count.kept + count.duplicates === 0)
          continue;
        rows += 1;
        const row = document2.createElement("tr");
        row.dataset.importEntity = name;
        const title = element2(document2, "th", "", t(ENTITY_LABELS[name]));
        title.scope = "row";
        row.append(title);
        for (const value of [
          count.added,
          count.replaced,
          count.kept,
          count.duplicates
        ])
          row.append(element2(document2, "td", "", formatNumber(value)));
        body.append(row);
      }
      table.append(thead, body);
      preview2.append(
        rows > 0 ? table : element2(document2, "p", "", t("data.import.noRecords"))
      );
      if (plan.settingsSkipped.some(isNamedSetting))
        preview2.append(
          element2(
            document2,
            "p",
            "",
            t("data.import.settingsSkipped", {
              keys: settingNames(plan.settingsSkipped)
            })
          )
        );
      if (!plan.settingsSkipped.every(isNamedSetting))
        preview2.append(
          element2(document2, "p", "", t("data.import.settingsUnknown"))
        );
      if (plan.settingsAdded.length > 0)
        preview2.append(
          element2(
            document2,
            "p",
            "",
            t(
              plan.settingsSaved === false ? "data.import.settingsNotSaved" : "data.import.settingsAdded",
              { keys: settingNames(plan.settingsAdded) }
            )
          )
        );
      return preview2;
    }
    /** Runs with `#importing` set; clears it when the import settles. */
    async #importFile(file) {
      this.#pending = void 0;
      this.#importResult = void 0;
      this.#setImportStatus(message("data.import.running"), "info");
      void this.render();
      let checked = false;
      try {
        if (file.size > MAX_IMPORT_BYTES)
          throw new ExtensionError(
            "ExtractionInvalid",
            "The file is too large to be a JoyFox export",
            { display: message("error.import.tooLarge") }
          );
        const text = await readText(file);
        const preview2 = await this.data.previewImport(text);
        checked = true;
        const plan = await this.data.applyImport(text, preview2.signature);
        this.#importResult = plan;
        if (plan.writes.length === 0 && plan.settingsAdded.length === 0) {
          this.#setImportStatus(message("data.import.nothing"), "info");
        } else {
          const totals = ENTITY_NAMES.reduce(
            (sum, name) => ({
              added: sum.added + plan.counts[name].added,
              replaced: sum.replaced + plan.counts[name].replaced
            }),
            { added: 0, replaced: 0 }
          );
          this.#setImportStatus(
            message(
              plan.settingsSaved ? "data.import.complete" : "data.import.completeSettingsFailed",
              totals
            ),
            plan.settingsSaved ? "info" : "error"
          );
          this.onChange();
        }
      } catch (error) {
        const display = errorDisplay(error);
        this.#setImportStatus(
          display ? message("error.withSuffix.nothingImported", { error: display }) : message(
            checked ? "data.import.incomplete" : "data.import.unreadable"
          ),
          "error"
        );
      } finally {
        this.#importing = false;
      }
      try {
        await this.render();
      } finally {
        this.#focusBefore = void 0;
      }
    }
    #button(document2, className, text, ariaLabel, onClick, focusKey) {
      const node = element2(document2, "button", className, text);
      node.type = "button";
      if (ariaLabel) node.setAttribute("aria-label", ariaLabel);
      if (focusKey) node.setAttribute(FOCUS_KEY, focusKey);
      node.addEventListener("click", onClick);
      return node;
    }
    /**
     * A delete button that acts only on its second click. The first click
     * arms it and says exactly what the second one deletes; any other action
     * disarms it.
     */
    #confirmButton(document2, focusKey, pending, text, ariaLabel, prompt, action, done) {
      const armed = samePending(this.#pending, pending);
      const node = this.#button(
        document2,
        "joyfox-panel__remove",
        armed ? t("data.confirm") : text,
        armed ? t("data.confirmLabel", { label: ariaLabel }) : t(ariaLabel),
        (event) => {
          if (!armed) {
            if (event.detail > 1) return;
            this.#pending = pending;
            this.#armedAt = confirmTiming.now();
            this.#setStatus(prompt, "info");
            void this.render();
            return;
          }
          if (!samePending(this.#pending, pending)) return;
          if (!confirmAllowed(event, this.#armedAt)) return;
          this.#pending = void 0;
          void this.#guard(async () => {
            await action(this.#requireSelected(pending.kind === "all"));
            this.#setStatus(done, "info");
            this.onChange();
          });
        },
        // The same key armed and unarmed, so focus stays on it when it arms.
        focusKey
      );
      return node;
    }
    #requireSelected(optional = false) {
      if (!this.#selected && !optional) throw new Error("No account selected");
      return this.#selected ?? "";
    }
    #setStatus(message2, kind) {
      this.#status.set(message2, kind);
    }
    #setImportStatus(message2, kind) {
      this.#importStatus.set(message2, kind);
    }
    /**
     * Every action redraws from storage, so the panel shows committed state.
     * A refusal (an `ExtensionError`) comes before any change, so its message
     * says what did not happen: for a delete, nothing was deleted. Any other
     * failure may come part-way through "delete everything", so its message
     * points at the redrawn counts instead of claiming nothing changed.
     */
    async #guard(action, failure = DELETE_FAILED) {
      try {
        await action();
      } catch (error) {
        this.#pending = void 0;
        const display = errorDisplay(error);
        this.#setStatus(
          display ? message(failure.suffix, { error: display }) : message(failure.fallback),
          "error"
        );
      }
      await this.render();
    }
  };

  // src/events/event-service.ts
  var EventTrackerService = class {
    constructor(listings = new EventMetadataRepository(), now = () => (/* @__PURE__ */ new Date()).toISOString()) {
      this.listings = listings;
      this.now = now;
    }
    async get(accountId, kind, id) {
      return (await this.#find(accountId, kind, id))?.record;
    }
    /**
     * The stored record for one listing. A record from before V1-5 (imported,
     * with no `kind`) can have another key than `event:<id>`; it is found by
     * its event ID, and `save` moves it to the new key.
     */
    async #find(accountId, kind, id) {
      const key2 = listingRecordId(kind, id);
      const record = await this.listings.get(accountId, key2);
      if (record) return { key: key2, record };
      if (kind !== "event") return void 0;
      const legacy = (await this.listings.list(accountId)).find(
        (item) => item.kind === void 0 && item.eventId === id
      );
      return legacy ? { key: legacy.id, record: legacy } : void 0;
    }
    /**
     * The new version of a record: the time now, but always later than the
     * stored version. Two saves in one clock tick then still give two
     * versions, so a stale editor cannot match the second one.
     */
    #version(existing) {
      const now = this.now();
      const stored = existing ? Date.parse(existing.updatedAt) : Number.NaN;
      if (Number.isNaN(stored) || Date.parse(now) > stored) return now;
      return new Date(stored + 1).toISOString();
    }
    async list(accountId) {
      return (await this.listings.list(accountId)).sort(compareListings);
    }
    /**
     * Store the user's notes on one listing. `expectedUpdatedAt` is the
     * version the editor was drawn from (`null`: no record); a record changed
     * since is not overwritten. Notes left empty (no note, no tags, no
     * attendance) remove the record, so the listing is no longer tracked.
     */
    async save(accountId, kind, id, notes, facts, expectedUpdatedAt) {
      const recordId = listingRecordId(kind, id);
      const found = await this.#find(accountId, kind, id);
      const existing = found?.record;
      if ((existing?.updatedAt ?? null) !== expectedUpdatedAt)
        return { status: "conflict", record: existing };
      const note = notes.note.trim();
      const tags = cleanTags(notes.tags);
      const attendance = kind === "venue" ? "unknown" : notes.attendance;
      if (!note && tags.length === 0 && attendance === "unknown") {
        if (found) await this.listings.delete(accountId, found.key);
        return { status: "removed" };
      }
      const timestamp = this.#version(existing);
      const title = cutListingText(facts.title) ?? existing?.title;
      const startLocal = facts.startLocal ?? existing?.startLocal;
      const path = facts.path ?? existing?.path;
      const venueId = facts.venueId ?? existing?.venueId;
      const venueName = cutListingText(facts.venueName) ?? existing?.venueName;
      const record = {
        id: recordId,
        accountId,
        eventId: id,
        kind,
        ...title ? { title } : {},
        ...startLocal ? { startLocal } : {},
        ...path ? { path } : {},
        ...venueId ? { venueId } : {},
        ...venueName ? { venueName } : {},
        ...note ? { note } : {},
        tags,
        attendance,
        // The guest list read earlier stays while the event is tracked.
        ...existing?.attendees ? { attendees: existing.attendees } : {},
        ...existing?.attendeesSeenAt ? { attendeesSeenAt: existing.attendeesSeenAt } : {},
        createdAt: existing?.createdAt ?? timestamp,
        updatedAt: timestamp
      };
      await this.listings.put(accountId, record);
      if (found && found.key !== recordId)
        await this.listings.delete(accountId, found.key);
      return { status: "saved", record };
    }
    /**
     * V1-13: add the member IDs a tracked event's guest list showed to the
     * ones read before (PRD 9.3). Only a tracked event keeps them. The notes'
     * version (`updatedAt`) does not change, so an open editor is not told of a
     * conflict it could not see.
     */
    async recordAttendees(accountId, eventId, memberIds) {
      const found = await this.#find(accountId, "event", eventId);
      if (!found || kindOf(found.record) !== "event") return "untracked";
      const known = found.record.attendees ?? [];
      const merged = [.../* @__PURE__ */ new Set([...known, ...memberIds])].sort();
      const kept = merged.length > MAX_EVENT_ATTENDEES ? [
        ...known,
        ...merged.filter((id) => !known.includes(id)).slice(0, MAX_EVENT_ATTENDEES - known.length)
      ].sort() : merged;
      if (kept.length === known.length) return "unchanged";
      await this.listings.put(accountId, {
        ...found.record,
        attendees: kept,
        attendeesSeenAt: this.now()
      });
      return "stored";
    }
    /** V1-13: the tracked events whose stored guest list names a member. */
    async forMember(accountId, memberId) {
      return (await this.list(accountId)).filter(
        (record) => kindOf(record) === "event" && (record.attendees ?? []).includes(memberId)
      );
    }
  };

  // src/options/events-panel.ts
  var ATTENDANCE_TEXT = {
    unknown: "listing.attendance.unknown",
    interested: "listing.attendance.interested",
    attending: "listing.attendance.attending",
    "not-attending": "listing.attendance.not-attending",
    attended: "listing.attendance.attended"
  };
  function element3(document2, tag, className, text) {
    const node = document2.createElement(tag);
    node.className = className;
    if (text !== void 0) node.textContent = text;
    return node;
  }
  function today(now) {
    const pad = (value) => String(value).padStart(2, "0");
    return `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`;
  }
  function matches(record, filter, search) {
    if (filter === "note" && !record.note) return false;
    if (filter.startsWith("tag:")) {
      const key2 = filter.slice(4).toLowerCase();
      if (!record.tags.some((tag) => tag.toLowerCase() === key2)) return false;
    } else if (filter !== "all" && filter !== "note" && record.attendance !== filter)
      return false;
    const needle = search.trim().toLowerCase();
    if (!needle) return true;
    const haystack = [record.title, record.note, record.venueName, ...record.tags].filter(Boolean).join("\n").toLowerCase();
    return haystack.includes(needle);
  }
  var EventsPanel = class {
    constructor(root, listings = new EventTrackerService(), accounts2 = new AccountService(), now = () => /* @__PURE__ */ new Date(), settings = runtimeSettingsArea) {
      this.root = root;
      this.listings = listings;
      this.accounts = accounts2;
      this.now = now;
      this.settings = settings;
      this.#status = new StatusLine(root.ownerDocument);
    }
    #generation = 0;
    #accountId;
    #filter = "all";
    #search = "";
    /** V1-13: the shared-event exception; off unless turned on. */
    #exception = false;
    /**
     * What the last change of the exception did. Created once and re-attached
     * on every draw (see `StatusLine`).
     */
    #status;
    async render() {
      const generation = this.#generation += 1;
      let accountId;
      let records;
      try {
        accountId = (await this.accounts.getActiveAccount())?.id;
        records = accountId ? await this.listings.list(accountId) : [];
        this.#exception = await Promise.resolve().then(() => this.settings.get([SHARED_EVENT_EXCEPTION_KEY])).then((stored) => stored[SHARED_EVENT_EXCEPTION_KEY] === true).catch(() => false);
      } catch {
        if (generation === this.#generation)
          this.root.textContent = t("events.readFailed");
        return;
      }
      if (generation !== this.#generation) return;
      if (accountId !== this.#accountId) {
        this.#filter = "all";
        this.#search = "";
      }
      this.#accountId = accountId;
      this.#draw(accountId, records);
    }
    #draw(accountId, records) {
      const document2 = this.root.ownerDocument;
      const focused = document2.activeElement?.id;
      this.root.replaceChildren();
      const heading = element3(
        document2,
        "h2",
        "joyfox-panel__heading",
        t("events.heading")
      );
      heading.id = "joyfox-events-heading";
      this.root.setAttribute("aria-labelledby", heading.id);
      this.root.append(
        heading,
        element3(document2, "p", "joyfox-panel__hint", t("events.hint")),
        this.#exceptionControl(document2)
      );
      if (!accountId) {
        this.root.append(
          element3(document2, "p", "joyfox-panel__empty", t("events.noAccount"))
        );
        return;
      }
      const events2 = records.filter((record) => kindOf(record) === "event");
      const venues = records.filter((record) => kindOf(record) === "venue");
      const tags = [
        ...new Map(
          events2.flatMap((record) => record.tags).map((tag) => [tag.toLowerCase(), tag])
        ).values()
      ].sort((a, b) => a.localeCompare(b));
      if (this.#filter.startsWith("tag:") && !tags.some(
        (tag) => tag.toLowerCase() === this.#filter.slice(4).toLowerCase()
      ))
        this.#filter = "all";
      this.root.append(this.#controls(document2, tags, accountId, records));
      const shown = events2.filter(
        (record) => matches(record, this.#filter, this.#search)
      );
      this.root.append(
        element3(
          document2,
          "p",
          "joyfox-panel__hint",
          t(
            message("events.count", {
              shown: shown.length,
              total: events2.length
            })
          )
        )
      );
      if (events2.length === 0)
        this.root.append(
          element3(document2, "p", "joyfox-panel__empty", t("events.empty"))
        );
      else this.root.append(this.#eventList(document2, shown));
      if (venues.length > 0) {
        this.root.append(element3(document2, "h3", "", t("events.venuesHeading")));
        this.root.append(this.#venueList(document2, venues));
      }
      if (focused) document2.getElementById(focused)?.focus();
    }
    #controls(document2, tags, accountId, records) {
      const row = element3(document2, "div", "joyfox-events__filters");
      const filterLabel = element3(document2, "label", "", t("events.filterLabel"));
      const select = element3(document2, "select", "");
      select.id = "joyfox-events-filter";
      filterLabel.htmlFor = select.id;
      const option = (value, text) => select.append(new Option(text, value, false, value === this.#filter));
      option("all", t("events.filter.all"));
      option("note", t("eventFilter.note"));
      for (const value of [
        "attending",
        "interested",
        "attended",
        "not-attending"
      ])
        option(value, t(ATTENDANCE_TEXT[value]));
      for (const tag of tags)
        option(`tag:${tag}`, t(message("eventFilter.tag", { tag })));
      select.addEventListener("change", () => {
        this.#filter = select.value;
        this.#status.clear();
        this.#draw(accountId, records);
      });
      const searchLabel = element3(document2, "label", "", t("events.searchLabel"));
      const search = element3(document2, "input", "");
      search.type = "search";
      search.id = "joyfox-events-search";
      searchLabel.htmlFor = search.id;
      search.value = this.#search;
      search.addEventListener("input", () => {
        this.#search = search.value;
        this.#status.clear();
        const start2 = search.selectionStart;
        this.#draw(accountId, records);
        const again = this.root.querySelector(
          "#joyfox-events-search"
        );
        again?.setSelectionRange(start2, start2);
      });
      row.append(filterLabel, select, searchLabel, search);
      return row;
    }
    #eventList(document2, events2) {
      const list = element3(document2, "ol", "joyfox-events__list");
      const day = today(this.now());
      for (const record of events2) {
        const item = element3(document2, "li", "joyfox-events__item");
        const when = record.startLocal ? formatWallTime(record.startLocal) : t("events.noDate");
        const past = record.startLocal !== void 0 && record.startLocal.slice(0, 10) < day;
        item.append(
          element3(
            document2,
            "strong",
            "",
            record.title ?? t(message("events.untitled", { id: record.eventId }))
          ),
          element3(
            document2,
            "span",
            "joyfox-events__when",
            past ? t(message("events.past", { when })) : when
          )
        );
        if (record.venueName)
          item.append(
            element3(
              document2,
              "span",
              "",
              t(message("events.venue", { venue: record.venueName }))
            )
          );
        const details = [t(ATTENDANCE_TEXT[record.attendance])];
        if (record.tags.length > 0) details.push(record.tags.join(", "));
        if (record.attendees && record.attendees.length > 0)
          details.push(
            t(message("events.guests", { count: record.attendees.length }))
          );
        item.append(
          element3(
            document2,
            "span",
            "joyfox-events__details",
            details.join(" \xB7 ")
          )
        );
        if (record.note)
          item.append(element3(document2, "p", "joyfox-events__note", record.note));
        list.append(item);
      }
      return list;
    }
    #venueList(document2, venues) {
      const list = element3(document2, "ul", "joyfox-events__list");
      for (const record of [...venues].sort(
        (a, b) => (a.title ?? "").localeCompare(b.title ?? "")
      )) {
        const item = element3(document2, "li", "joyfox-events__item");
        item.append(
          element3(
            document2,
            "strong",
            "",
            record.title ?? t(message("events.untitled", { id: record.eventId }))
          )
        );
        if (record.tags.length > 0)
          item.append(
            element3(
              document2,
              "span",
              "joyfox-events__details",
              record.tags.join(", ")
            )
          );
        if (record.note)
          item.append(element3(document2, "p", "joyfox-events__note", record.note));
        list.append(item);
      }
      return list;
    }
    /** V1-13: the switch for the shared-event exception, off by default. */
    #exceptionControl(document2) {
      const box2 = element3(document2, "div", "joyfox-events__exception");
      const toggle = element3(document2, "input", "");
      toggle.type = "checkbox";
      toggle.id = "joyfox-shared-event-exception";
      toggle.checked = this.#exception;
      const label = element3(document2, "label", "joyfox-events__exception-label");
      label.htmlFor = toggle.id;
      label.append(toggle, " ", t("events.exception.label"));
      toggle.addEventListener("change", () => {
        void this.settings.set({ [SHARED_EVENT_EXCEPTION_KEY]: toggle.checked }).then(() => bumpTriageRevision(this.settings)).then(() => {
          this.#status.set(message("events.exception.saved"), "info");
          return this.render();
        }).catch(() => {
          toggle.checked = this.#exception;
          this.#status.set(message("events.exception.saveFailed"), "error");
        });
      });
      this.#status.redraw();
      box2.append(
        label,
        element3(document2, "p", "joyfox-panel__hint", t("events.exception.hint")),
        this.#status.node
      );
      return box2;
    }
  };

  // src/options/messages-panel.ts
  var MAX_SHOWN_RESULTS = 200;
  function element4(document2, tag, className, text) {
    const node = document2.createElement(tag);
    node.className = className;
    if (text !== void 0) node.textContent = text;
    return node;
  }
  function queryPattern(query) {
    const words = query.trim().split(/\s+/u).filter(Boolean);
    if (words.length === 0) return void 0;
    const escaped = words.map(
      (word) => word.replace(/[.*+?^${}()|[\]\\]/gu, "\\$&")
    );
    return new RegExp(escaped.join("\\s+"), "giu");
  }
  function markedText(document2, text, pattern) {
    const paragraph = element4(document2, "p", "joyfox-messages__text");
    if (!pattern) {
      paragraph.textContent = text;
      return paragraph;
    }
    let last = 0;
    for (const match of text.matchAll(pattern)) {
      const start2 = match.index ?? 0;
      if (match[0].length === 0) continue;
      paragraph.append(text.slice(last, start2));
      paragraph.append(element4(document2, "mark", "", match[0]));
      last = start2 + match[0].length;
    }
    paragraph.append(text.slice(last));
    return paragraph;
  }
  var MessagesPanel = class {
    constructor(root, settings = runtimeSettingsArea, service = new MessageCacheService(settings), accounts2 = new AccountService(), members = new JoyClubMemberRepository()) {
      this.root = root;
      this.settings = settings;
      this.service = service;
      this.accounts = accounts2;
      this.members = members;
      this.#status = new StatusLine(root.ownerDocument);
    }
    #generation = 0;
    #accountId;
    #query = "";
    /** Created once and re-attached on every draw (see `StatusLine`). */
    #status;
    /**
     * A lower number of months that Save armed: it deletes stored messages at
     * once, so it waits for a second click, like every other delete.
     */
    #pendingRetention;
    /** When the lower number was armed, for the confirm grace period. */
    #armedAt = 0;
    /** Nicknames by member ID, for the results of the shown account. */
    #names = /* @__PURE__ */ new Map();
    async render() {
      const generation = this.#generation += 1;
      let accountId;
      let current;
      let found;
      let names;
      try {
        accountId = (await this.accounts.getActiveAccount())?.id;
        if (accountId !== this.#accountId) this.#query = "";
        current = await readMessageSettings(this.settings);
        await this.service.prune();
        found = accountId ? (await this.service.search(accountId, this.#query)).messages : [];
        names = accountId ? await nicknamesOf(this.members, accountId) : /* @__PURE__ */ new Map();
      } catch {
        if (generation === this.#generation)
          this.root.textContent = t("messages.readFailed");
        return;
      }
      if (generation !== this.#generation) return;
      this.#accountId = accountId;
      this.#names = names;
      this.#draw(accountId, current, found);
    }
    #draw(accountId, current, found) {
      const document2 = this.root.ownerDocument;
      const focus = rememberFocus(this.root);
      const field = this.root.querySelector(
        "#joyfox-messages-retention"
      );
      const typed = field && field.value !== field.defaultValue ? field.value : void 0;
      this.root.replaceChildren();
      const heading = element4(
        document2,
        "h2",
        "joyfox-panel__heading",
        t("messages.heading")
      );
      heading.id = "joyfox-messages-heading";
      this.root.setAttribute("aria-labelledby", heading.id);
      this.#status.redraw();
      this.root.append(
        heading,
        element4(document2, "p", "joyfox-panel__hint", t("messages.hint")),
        this.#settingsForm(document2, current, typed),
        this.#status.node
      );
      if (!accountId) {
        this.root.append(
          element4(document2, "p", "joyfox-panel__empty", t("messages.noAccount"))
        );
        restoreFocus(this.root, focus);
        return;
      }
      this.root.append(this.#searchBox(document2));
      const query = this.#query.trim();
      if (query) {
        this.root.append(
          element4(
            document2,
            "p",
            "joyfox-panel__hint",
            t(
              found.length > MAX_SHOWN_RESULTS ? message("messages.countLimited", {
                count: found.length,
                shown: MAX_SHOWN_RESULTS
              }) : message("messages.count", { count: found.length })
            )
          ),
          this.#results(document2, found.slice(0, MAX_SHOWN_RESULTS))
        );
      }
      restoreFocus(this.root, focus);
    }
    #settingsForm(document2, current, typed) {
      const form = element4(document2, "div", "joyfox-messages__settings");
      const caching = element4(document2, "input", "");
      caching.type = "checkbox";
      caching.id = "joyfox-messages-caching";
      caching.setAttribute(FOCUS_KEY, "caching");
      caching.checked = current.caching;
      const cachingLabel = element4(document2, "label", "joyfox-messages__switch");
      cachingLabel.htmlFor = caching.id;
      cachingLabel.append(caching, " ", t("messages.caching"));
      caching.addEventListener("change", () => {
        this.#pendingRetention = void 0;
        void this.#save(async () => {
          await this.settings.set({ [MESSAGE_CACHING_KEY]: caching.checked });
          return message(
            caching.checked ? "messages.cachingOn" : "messages.cachingOff"
          );
        });
      });
      const retentionLabel = element4(
        document2,
        "label",
        "",
        t("messages.retentionLabel")
      );
      const retention = element4(document2, "input", "joyfox-messages__months");
      retention.type = "number";
      retention.id = "joyfox-messages-retention";
      retention.setAttribute(FOCUS_KEY, "retention");
      retention.min = String(MIN_MESSAGE_RETENTION_MONTHS);
      retention.max = String(MAX_MESSAGE_RETENTION_MONTHS);
      retention.defaultValue = String(current.retentionMonths);
      const pending = this.#pendingRetention;
      retention.value = pending !== void 0 ? String(pending) : typed ?? retention.defaultValue;
      retentionLabel.htmlFor = retention.id;
      const retentionHint = element4(
        document2,
        "p",
        "joyfox-panel__hint",
        t(
          message("messages.retentionHint", {
            default: DEFAULT_MESSAGE_RETENTION_MONTHS
          })
        )
      );
      retentionHint.id = "joyfox-messages-retention-hint";
      retention.setAttribute("aria-describedby", retentionHint.id);
      const armed = pending !== void 0;
      const save = element4(
        document2,
        "button",
        "joyfox-messages__save",
        t(armed ? "messages.retentionConfirm" : "messages.retentionSave")
      );
      save.type = "button";
      save.setAttribute(FOCUS_KEY, "retention-save");
      retention.addEventListener("input", () => {
        if (this.#pendingRetention === void 0) return;
        this.#pendingRetention = void 0;
        save.textContent = t("messages.retentionSave");
        this.#status.clear();
      });
      save.addEventListener("click", (event) => {
        const months = Number(retention.value);
        if (!isMessageRetention(months)) {
          this.#pendingRetention = void 0;
          this.#status.set(
            message("messages.retentionInvalid", {
              minimum: MIN_MESSAGE_RETENTION_MONTHS,
              maximum: MAX_MESSAGE_RETENTION_MONTHS
            }),
            "error"
          );
          void this.render();
          return;
        }
        if (armed && this.#pendingRetention === months) {
          if (!confirmAllowed(event, this.#armedAt)) return;
        } else if (months < current.retentionMonths) {
          if (event.detail > 1) return;
          this.#pendingRetention = months;
          this.#armedAt = confirmTiming.now();
          this.#status.set(
            message("messages.retentionConfirmPrompt", { months }),
            "info"
          );
          void this.render();
          return;
        }
        this.#pendingRetention = void 0;
        void this.#save(
          async () => message("messages.retentionSaved", {
            deleted: await this.service.setRetention(months)
          })
        );
      });
      const switchRow = element4(document2, "p", "joyfox-panel__field");
      switchRow.append(cachingLabel);
      form.append(switchRow);
      if (!current.caching)
        form.append(
          element4(document2, "p", "joyfox-panel__hint", t("messages.offHint"))
        );
      const row = element4(document2, "p", "joyfox-panel__field");
      row.append(retentionLabel, retention, save);
      form.append(row, retentionHint);
      return form;
    }
    async #save(write) {
      try {
        this.#status.set(await write(), "info");
      } catch {
        this.#status.set(message("common.saveFailed"), "error");
      }
      await this.render();
    }
    #searchBox(document2) {
      const row = element4(document2, "p", "joyfox-panel__field");
      const label = element4(document2, "label", "", t("messages.searchLabel"));
      const input = element4(document2, "input", "joyfox-messages__search");
      input.type = "search";
      input.id = "joyfox-messages-search";
      input.setAttribute(FOCUS_KEY, "search");
      label.htmlFor = input.id;
      input.value = this.#query;
      input.addEventListener("input", () => {
        this.#query = input.value;
        this.#pendingRetention = void 0;
        this.#status.clear();
        const start2 = input.selectionStart;
        void this.render().then(() => {
          this.root.querySelector("#joyfox-messages-search")?.setSelectionRange(start2, start2);
        });
      });
      row.append(label, input);
      return row;
    }
    #results(document2, found) {
      const list = element4(document2, "ol", "joyfox-messages__list");
      const pattern = queryPattern(this.#query);
      for (const item of found) {
        const entry = element4(document2, "li", "joyfox-messages__item");
        const when = item.sentAt ? formatDateTime(item.sentAt) : t(
          message("messages.storedAt", {
            when: formatDateTime(item.createdAt)
          })
        );
        entry.append(
          element4(
            document2,
            "p",
            "joyfox-messages__meta",
            t(
              message(
                item.direction === "sent" ? "messages.sentTo" : "messages.receivedFrom",
                {
                  member: this.#names.get(item.memberId) ?? t(message("member.number", { id: item.memberId })),
                  when
                }
              )
            )
          ),
          markedText(document2, item.text, pattern)
        );
        list.append(entry);
      }
      return list;
    }
  };

  // src/rules/rule-service.ts
  var GLOBAL_RULE_ID = "rule:global";
  var GLOBAL_RULE_NAME = "Global contact rule";
  function requireAccountId(accountId) {
    if (accountId.trim().length === 0)
      throw new ExtensionError(
        "IdentityMismatch",
        "A contact rule needs an explicit active account"
      );
  }
  var RuleService = class {
    constructor(rules2 = new ContactRuleRepository(), settings = runtimeSettingsArea, now = () => (/* @__PURE__ */ new Date()).toISOString()) {
      this.rules = rules2;
      this.settings = settings;
      this.now = now;
    }
    async getGlobalRule(accountId) {
      requireAccountId(accountId);
      return this.rules.get(accountId, GLOBAL_RULE_ID);
    }
    async saveGlobalRule(accountId, definition2) {
      requireAccountId(accountId);
      const problem = contactRuleProblem(definition2);
      if (problem) throw new ExtensionError("RuleEvaluationError", problem);
      const existing = await this.rules.get(accountId, GLOBAL_RULE_ID);
      const timestamp = this.now();
      const rule = {
        id: GLOBAL_RULE_ID,
        accountId,
        name: GLOBAL_RULE_NAME,
        schemaVersion: definition2.schemaVersion,
        audience: definition2.audience,
        enabled: definition2.enabled,
        defaultPlacement: definition2.defaultPlacement,
        root: copyGroup(definition2.root),
        createdAt: existing?.createdAt ?? timestamp,
        updatedAt: timestamp
      };
      await this.rules.put(accountId, rule);
      await bumpTriageRevision(this.settings);
      return rule;
    }
    async deleteGlobalRule(accountId) {
      requireAccountId(accountId);
      await this.rules.delete(accountId, GLOBAL_RULE_ID);
      await bumpTriageRevision(this.settings);
    }
  };
  function copyNode(node) {
    if (node.type === "group") return copyGroup(node);
    return {
      type: "condition",
      kind: node.kind,
      ...node.value !== void 0 ? { value: node.value } : {},
      ...node.text !== void 0 ? { text: node.text } : {},
      whenUnknown: node.whenUnknown,
      ...node.negate ? { negate: true } : {}
    };
  }
  function copyGroup(group) {
    return {
      type: "group",
      match: group.match,
      children: group.children.map(copyNode)
    };
  }

  // src/options/get-started.ts
  var STATE_TEXT = {
    done: "start.state.done",
    off: "start.state.off",
    todo: "start.state.todo"
  };
  var JOYCLUB_ORIGINS = ["*://*.joyclub.de/*"];
  var browserSiteAccess = () => globalThis.browser?.permissions;
  var hasCondition = (node) => node.type === "condition" || node.children.some(hasCondition);
  async function setupProgress(accounts2, rules2) {
    const active = await accounts2.getActiveAccount();
    if (!active)
      return {
        account: "todo",
        chooseAccount: (await accounts2.listAccounts()).length > 0,
        rule: "todo",
        openRule: false
      };
    const rule = await rules2.getGlobalRule(active.id);
    return {
      account: "done",
      chooseAccount: false,
      rule: !rule ? "todo" : rule.enabled ? "done" : "off",
      // An empty rule is legitimate (the "Open" preset), so the step is done.
      openRule: rule?.enabled === true && !hasCondition(rule.root)
    };
  }
  var GetStartedPanel = class {
    constructor(root, accounts2 = new AccountService(), rules2 = new RuleService(), access = browserSiteAccess()) {
      this.root = root;
      this.accounts = accounts2;
      this.rules = rules2;
      this.access = access;
      this.#status = new StatusLine(root.ownerDocument);
      const redraw = () => void this.render().catch(() => void 0);
      access?.onAdded?.addListener(redraw);
      access?.onRemoved?.addListener(redraw);
    }
    #generation = 0;
    /** The answer to an access request. Created once, kept across draws. */
    #status;
    /** What the status says about access, until Firefox's state disagrees. */
    #accessNote;
    /** An access request is open in Firefox. */
    #requesting = false;
    async render() {
      const generation = ++this.#generation;
      const [progress, access] = await Promise.all([
        setupProgress(this.accounts, this.rules).catch(() => void 0),
        this.#readAccess()
      ]);
      if (generation !== this.#generation) return;
      const document2 = this.root.ownerDocument;
      const text = (tag, value) => {
        const node = document2.createElement(tag);
        node.textContent = value;
        return node;
      };
      const heading = text("h2", t("options.tabs.start"));
      heading.className = "joyfox-panel__heading";
      heading.id = "joyfox-get-started-heading";
      this.root.setAttribute("aria-labelledby", heading.id);
      if (!progress) {
        this.root.replaceChildren(heading, text("p", t("start.readFailed")));
        return;
      }
      const missing = access === "missing";
      if (this.#accessNote === "granted" && missing || this.#accessNote === "refused" && !missing) {
        this.#accessNote = void 0;
        this.#status.clear();
      }
      this.#status.redraw();
      const ready = !missing && progress.account === "done" && progress.rule === "done";
      const summary = text(
        "p",
        t(ready ? "start.ready" : missing ? "start.introAccess" : "start.intro")
      );
      const list = document2.createElement("ol");
      list.className = "joyfox-get-started__steps";
      const withLinks = (label) => {
        const span2 = document2.createElement("span");
        for (const part of label.split(/(\[[^\]]+\]\(#[a-z]+\))/)) {
          const link = /^\[([^\]]+)\]\((#[a-z]+)\)$/.exec(part);
          if (!link) {
            if (part) span2.append(part);
            continue;
          }
          const anchor = document2.createElement("a");
          anchor.textContent = link[1] ?? "";
          anchor.href = link[2] ?? "";
          anchor.setAttribute(FOCUS_KEY, `link:${link[2] ?? ""}`);
          span2.append(anchor);
        }
        return span2;
      };
      const step = (label, state, stateText) => {
        const item = document2.createElement("li");
        if (state) item.dataset.state = state;
        item.append(withLinks(label));
        if (state) {
          const status = text("strong", ` ${t(stateText ?? STATE_TEXT[state])}.`);
          status.className = "joyfox-get-started__state";
          item.append(status);
        }
        return item;
      };
      if (missing)
        list.append(this.#withAllowButton(step(t("start.step.access"), "todo")));
      list.append(
        step(
          t(
            progress.chooseAccount ? "start.step.chooseAccount" : "start.step.account"
          ),
          progress.account
        ),
        step(
          t("start.step.rule"),
          progress.rule,
          progress.openRule ? "start.state.doneOpen" : void 0
        ),
        step(t("start.step.inbox"))
      );
      const focus = rememberFocus(this.root);
      this.root.replaceChildren(heading, summary, list, this.#status.node);
      restoreFocus(this.root, focus, ["access:allow", "link:#accounts"]);
    }
    /** The first step, while Firefox blocks JoyFox on joyclub.de. */
    #withAllowButton(item) {
      const allow = item.ownerDocument.createElement("button");
      allow.type = "button";
      allow.className = "joyfox-get-started__allow";
      allow.textContent = t("access.allow");
      allow.setAttribute(FOCUS_KEY, "access:allow");
      allow.addEventListener("click", () => this.#requestAccess());
      item.append(allow);
      return item;
    }
    /** Whether Firefox lets JoyFox run on joyclub.de. A failed check never blocks. */
    async #readAccess() {
      if (!this.access) return "unknown";
      try {
        const granted = await this.access.contains({ origins: JOYCLUB_ORIGINS });
        return granted ? "granted" : "missing";
      } catch {
        return "unknown";
      }
    }
    /**
     * Ask Firefox for access, then draw again. The request runs inside the
     * click, as Firefox shows its prompt only for a user action.
     */
    #requestAccess() {
      const access = this.access;
      if (!access || this.#requesting) return;
      this.#requesting = true;
      let asked;
      try {
        asked = access.request({ origins: JOYCLUB_ORIGINS });
      } catch {
        asked = Promise.resolve(false);
      }
      void asked.catch(() => false).then((granted) => {
        this.#requesting = false;
        this.#accessNote = granted ? "granted" : "refused";
        this.#status.set(
          message(granted ? "access.granted" : "access.refused"),
          granted ? "info" : "error"
        );
        return this.render();
      }).catch(() => void 0);
    }
  };

  // src/options/quick-action-panel.ts
  var HINTS = [
    ["joyfox-quick-action-hint", "quickSetting.hint"],
    ["joyfox-quick-action-risk", "quickSetting.risk"],
    ["joyfox-quick-action-undo", "quickSetting.undo"]
  ];
  function element5(document2, tag, className, text) {
    const node = document2.createElement(tag);
    node.className = className;
    if (text !== void 0) node.textContent = text;
    return node;
  }
  var QuickActionPanel = class {
    constructor(root, settings = runtimeSettingsArea) {
      this.root = root;
      this.settings = settings;
      this.#status = new StatusLine(root.ownerDocument);
    }
    #generation = 0;
    #on = true;
    /** Created once and re-attached on every draw (see `StatusLine`). */
    #status;
    #focusToggle = false;
    async render() {
      const generation = this.#generation += 1;
      const on = await Promise.resolve().then(() => this.settings.get([QUICK_ACTION_KEY])).then((stored) => stored[QUICK_ACTION_KEY] !== false).catch(() => true);
      if (generation !== this.#generation) return;
      this.#on = on;
      this.#draw();
    }
    #draw() {
      const document2 = this.root.ownerDocument;
      const heading = element5(
        document2,
        "h2",
        "joyfox-panel__heading",
        t("quickSetting.heading")
      );
      heading.id = "joyfox-quick-action-heading";
      this.root.setAttribute("aria-labelledby", heading.id);
      const label = element5(document2, "label", "joyfox-quick-action__label");
      const toggle = element5(document2, "input", "");
      toggle.type = "checkbox";
      toggle.id = "joyfox-quick-action-toggle";
      toggle.checked = this.#on;
      toggle.setAttribute("aria-describedby", HINTS.map(([id]) => id).join(" "));
      label.append(toggle, " ", t("quickSetting.label"));
      toggle.addEventListener("change", () => {
        this.#focusToggle = true;
        void this.settings.set({ [QUICK_ACTION_KEY]: toggle.checked }).then(() => {
          this.#status.set(message("quickSetting.saved"), "info");
          return this.render();
        }).catch(() => {
          toggle.checked = this.#on;
          this.#status.set(message("quickSetting.saveFailed"), "error");
          this.#draw();
        });
      });
      const hints = HINTS.map(([id, key2]) => {
        const hint = element5(document2, "p", "joyfox-panel__hint", t(key2));
        hint.id = id;
        return hint;
      });
      this.#status.redraw();
      this.root.replaceChildren(heading, label, ...hints, this.#status.node);
      if (this.#focusToggle) {
        this.#focusToggle = false;
        toggle.focus();
      }
    }
  };

  // src/rules/rule-builder.ts
  function operand(kind, entry) {
    if (NUMERIC_CONDITION_KINDS.has(kind)) return { value: entry.value ?? 0 };
    if (TEXT_CONDITION_KINDS.has(kind)) return { text: entry.text ?? "" };
    return {};
  }
  var storedOperand = (node) => ({
    ...node.value !== void 0 ? { value: node.value } : {},
    ...node.text !== void 0 ? { text: node.text } : {}
  });
  function box(nodes) {
    const entries = {};
    for (const node of nodes) {
      if (node.type !== "condition" || entries[node.kind] || node.negate)
        return void 0;
      entries[node.kind] = {
        ...storedOperand(node),
        whenUnknown: node.whenUnknown
      };
    }
    return entries;
  }
  function toBuilderForm(rule) {
    if (rule.audience !== "all") return void 0;
    const base = {
      enabled: rule.enabled,
      defaultPlacement: rule.defaultPlacement
    };
    const { root } = rule;
    if (root.match === "all") {
      const all2 = box(root.children);
      return all2 ? { ...base, all: all2, any: {} } : void 0;
    }
    const [first, ...rest] = root.children;
    if (!first || first.type !== "group" || first.match !== "all")
      return void 0;
    const all = box(first.children);
    const any = box(rest);
    return all && any ? { ...base, all, any } : void 0;
  }
  function conditions(entries) {
    return Object.entries(entries).map(
      ([kind, entry]) => ({
        type: "condition",
        kind,
        ...operand(kind, entry),
        whenUnknown: entry.whenUnknown
      })
    );
  }
  function definition(form, root) {
    return {
      schemaVersion: schemaVersionFor(root),
      audience: "all",
      enabled: form.enabled,
      defaultPlacement: form.defaultPlacement,
      root
    };
  }
  function fromBuilderForm(form) {
    return definition(form, {
      type: "group",
      match: "any",
      children: [
        { type: "group", match: "all", children: conditions(form.all) },
        ...conditions(form.any)
      ]
    });
  }
  var MAX_ADVANCED_RULES = 10;
  function advancedEntry(node) {
    return {
      ...storedOperand(node),
      whenUnknown: node.whenUnknown,
      ...node.negate ? { negate: true } : {}
    };
  }
  function toAdvancedForm(rule) {
    if (rule.audience !== "all") return void 0;
    const rules2 = [];
    for (const child of rule.root.children) {
      if (child.type === "condition") {
        rules2.push({
          match: "all",
          conditions: { [child.kind]: advancedEntry(child) }
        });
        continue;
      }
      const conditions2 = {};
      for (const node of child.children) {
        if (node.type !== "condition" || conditions2[node.kind]) return void 0;
        conditions2[node.kind] = advancedEntry(node);
      }
      rules2.push({ match: child.match, conditions: conditions2 });
    }
    return {
      enabled: rule.enabled,
      defaultPlacement: rule.defaultPlacement,
      match: rule.root.match,
      rules: rules2
    };
  }
  function advancedConditions(rule) {
    return CONDITION_KINDS.flatMap((kind) => {
      const entry = rule.conditions[kind];
      if (!entry) return [];
      return [
        {
          type: "condition",
          kind,
          ...operand(kind, entry),
          whenUnknown: entry.whenUnknown,
          ...entry.negate ? { negate: true } : {}
        }
      ];
    });
  }
  function fromAdvancedForm(form) {
    return definition(form, {
      type: "group",
      match: form.match,
      children: form.rules.map((rule) => ({
        type: "group",
        match: rule.match,
        children: advancedConditions(rule)
      })).filter((group) => group.children.length > 0)
    });
  }
  function builderToAdvanced(form) {
    const advanced = toAdvancedForm(fromBuilderForm(form));
    if (!advanced) throw new Error("A two-box rule always fits");
    return {
      ...advanced,
      rules: advanced.rules.filter(
        (rule) => Object.keys(rule.conditions).length > 0
      )
    };
  }
  var isProblem = (value) => "key" in value;
  function advancedToBuilder(form) {
    const rules2 = form.rules.filter(
      (rule) => Object.keys(rule.conditions).length > 0
    );
    if (rules2.length > 1 && form.match === "all")
      return message("rule.simpleUnavailable.all");
    if (rules2.some(
      (rule) => Object.values(rule.conditions).some((entry) => entry?.negate)
    ))
      return message("rule.simpleUnavailable.not");
    const several = (rule) => Object.keys(rule.conditions).length > 1;
    const allRules = rules2.filter(
      (rule) => rule.match === "all" && several(rule)
    );
    if (allRules.length > 1) return message("rule.simpleUnavailable.severalAll");
    const plain = (entry) => ({
      ...entry.value !== void 0 ? { value: entry.value } : {},
      ...entry.text !== void 0 ? { text: entry.text } : {},
      whenUnknown: entry.whenUnknown
    });
    const boxOf = (list) => {
      const entries = {};
      for (const rule of list)
        for (const kind of CONDITION_KINDS) {
          const entry = rule.conditions[kind];
          if (!entry) continue;
          if (entries[kind]) return void 0;
          entries[kind] = plain(entry);
        }
      return entries;
    };
    const [allRule] = rules2.length === 1 && rules2[0]?.match === "all" ? rules2 : allRules;
    const others = rules2.filter((rule) => rule !== allRule);
    const conditions2 = others.flatMap(
      (rule) => CONDITION_KINDS.flatMap((kind) => {
        const entry = rule.conditions[kind];
        return entry ? [{ kind, entry }] : [];
      })
    );
    const first = allRule ? void 0 : conditions2.shift();
    const all = allRule ? boxOf([allRule]) : first ? { [first.kind]: plain(first.entry) } : {};
    const any = boxOf(
      conditions2.map(({ kind, entry }) => ({
        match: "any",
        conditions: { [kind]: entry }
      }))
    );
    if (!all || !any) return message("rule.simpleUnavailable.duplicate");
    return {
      enabled: form.enabled,
      defaultPlacement: form.defaultPlacement,
      all,
      any
    };
  }

  // src/rules/presets.ts
  var COMPLETE_PROFILE = { photos: 3, words: 50 };
  var HIGH_TRUST_ACCOUNT_DAYS = 180;
  var RULE_PRESET_IDS = [
    "open",
    "complete",
    "verified",
    "highTrust",
    "custom"
  ];
  var PRESET_TEXT = {
    open: "rule.preset.open",
    complete: "rule.preset.complete",
    verified: "rule.preset.verified",
    highTrust: "rule.preset.highTrust",
    custom: "rule.preset.custom"
  };
  var PRESET_CONDITIONS = {
    open: [],
    complete: [
      ["minimumPhotos", COMPLETE_PROFILE.photos],
      ["minimumProfileWords", COMPLETE_PROFILE.words]
    ],
    verified: [["verified"]],
    highTrust: [
      ["verified"],
      ["minimumPhotos", COMPLETE_PROFILE.photos],
      ["minimumProfileWords", COMPLETE_PROFILE.words],
      ["minimumAccountAgeDays", HIGH_TRUST_ACCOUNT_DAYS]
    ],
    custom: []
  };
  function isRulePresetId(value) {
    return RULE_PRESET_IDS.includes(value);
  }
  function presetForm(id, base) {
    const all = {};
    for (const [kind, value] of PRESET_CONDITIONS[id])
      all[kind] = {
        ...value !== void 0 ? { value } : {},
        whenUnknown: "needs-review"
      };
    return {
      enabled: base.enabled,
      defaultPlacement: base.defaultPlacement,
      all,
      any: {}
    };
  }

  // src/options/rule-panel.ts
  var failed = (value) => "key" in value;
  var MATCH_TEXT = {
    all: "rule.match.all",
    any: "rule.match.any"
  };
  var BOX_LEGEND = {
    all: "rule.box.all",
    any: "rule.box.any"
  };
  var UNKNOWN_TEXT = {
    "needs-review": "rule.unknown.needs-review",
    met: "rule.unknown.met",
    "not-met": "rule.unknown.not-met"
  };
  var EMPTY_FORM = {
    enabled: true,
    defaultPlacement: "quarantined",
    all: {},
    any: {}
  };
  var noteText = (saved) => t(saved ? "rule.note.saved" : "rule.note.none");
  var conditionName = (kind) => message(CONDITION_TEXT[kind]);
  var numberMinimum = (kind) => kind === "minimumTrustScore" ? RULE_LIMITS.minTrustValue : 0;
  var VALUE_FIELDS = "input[type=number], input.joyfox-rule__text";
  var CONDITION_ROW = ".joyfox-rule__condition[data-kind]";
  function element6(document2, tag, className, text) {
    const node = document2.createElement(tag);
    node.className = className;
    if (text !== void 0) node.textContent = text;
    return node;
  }
  function followBox(controls) {
    for (const field of [controls.value, controls.text, controls.unknown])
      if (field) field.disabled = !controls.on.checked;
  }
  function spamNote(document2, id) {
    const note = element6(
      document2,
      "span",
      "joyfox-rule__condition-note",
      t("rule.spamNote")
    );
    note.id = id;
    return note;
  }
  function numberInput(document2, kind, value) {
    const input = document2.createElement("input");
    input.type = "number";
    input.step = "1";
    input.min = String(
      kind === "minimumTrustScore" ? RULE_LIMITS.minTrustValue : 0
    );
    input.max = String(RULE_LIMITS.maxValue);
    input.value = String(value ?? "");
    input.dataset.condition = kind;
    input.setAttribute(
      "aria-label",
      t("rule.valueLabel", { condition: conditionName(kind) })
    );
    return input;
  }
  function textInput(document2, kind, text) {
    const input = document2.createElement("input");
    input.type = "text";
    input.className = "joyfox-rule__text";
    input.maxLength = RULE_LIMITS.maxTextLength;
    input.placeholder = t("rule.textPlaceholder");
    input.autocomplete = "off";
    input.spellcheck = false;
    input.value = text ?? "";
    input.dataset.condition = kind;
    input.setAttribute(
      "aria-label",
      t("rule.textLabel", { condition: conditionName(kind) })
    );
    return input;
  }
  function unknownSelect(document2, selected = "needs-review") {
    const select = document2.createElement("select");
    for (const handling of Object.keys(UNKNOWN_TEXT))
      select.append(
        new Option(
          t(UNKNOWN_TEXT[handling]),
          handling,
          false,
          handling === selected
        )
      );
    return select;
  }
  function matchSelect(document2, selected, label) {
    const select = document2.createElement("select");
    select.setAttribute("aria-label", label);
    for (const match of ["any", "all"])
      select.append(
        new Option(t(MATCH_TEXT[match]), match, false, match === selected)
      );
    return select;
  }
  function readNumber(input, kind) {
    const raw = input.value.trim();
    const minimum = numberMinimum(kind);
    const value = Number(raw);
    if (raw === "" || !Number.isSafeInteger(value) || value < minimum || value > RULE_LIMITS.maxValue)
      return message("rule.numberProblem", {
        minimum,
        maximum: RULE_LIMITS.maxValue,
        condition: conditionName(kind)
      });
    return value;
  }
  var numberOrNone = (value) => typeof value === "number" ? value : void 0;
  function readText2(input, kind) {
    const text = input.value.trim();
    const phrase = normalizePhrase(text);
    if (phrase.length === 0 || phrase.length > MAX_NORMALIZED_PHRASE_LENGTH || text.length > RULE_LIMITS.maxTextLength)
      return message("rule.textProblem", {
        maximum: RULE_LIMITS.maxTextLength,
        condition: conditionName(kind)
      });
    return { text };
  }
  var NEW_VALUE = {
    minimumPhotos: 3,
    minimumProfileWords: 50,
    minimumAccountAgeDays: 180,
    minimumTrustScore: 1
  };
  function presetDescription(id) {
    const { photos, words } = COMPLETE_PROFILE;
    switch (id) {
      case "open":
        return t("rule.preset.describe.open");
      case "complete":
        return t("rule.preset.describe.complete", { photos, words });
      case "verified":
        return t("rule.preset.describe.verified");
      case "highTrust":
        return t("rule.preset.describe.highTrust", {
          photos,
          words,
          days: HIGH_TRUST_ACCOUNT_DAYS
        });
      case "custom":
        return t("rule.preset.describe.custom");
    }
  }
  function presetNotice(id) {
    if (id === "open") return message("rule.preset.appliedOpen");
    if (id === "custom") return message("rule.preset.appliedCustom");
    return message("rule.preset.applied", { preset: message(PRESET_TEXT[id]) });
  }
  var RulePanel = class {
    constructor(root, rules2 = new RuleService(), accounts2 = new AccountService()) {
      this.root = root;
      this.rules = rules2;
      this.accounts = accounts2;
      this.#status = new StatusLine(root.ownerDocument);
      this.#deleteLine = new StatusLine(root.ownerDocument);
      this.#deleteLine.node.classList.add("joyfox-rule__prompt");
      root.addEventListener("click", (event) => {
        if (this.#armed && !this.#armed.button.contains(event.target))
          this.#disarm();
      });
      root.addEventListener("change", () => this.#disarm());
    }
    #status;
    /**
     * The prompt and failures of "Delete whole contact rule", right under the
     * button at the end of the form, where the user is when they click it.
     */
    #deleteLine;
    /**
     * The button that waits for its second click (a preset that replaces
     * conditions, removing a group, deleting the whole rule), when it was
     * armed, and how to put it back. Any other click or change disarms it.
     */
    #armed;
    /** Each number or text field's note: why a save refuses it, or a hint. */
    #notes = /* @__PURE__ */ new WeakMap();
    /** Makes each note's ID unique, for `aria-describedby`. */
    #noteCount = 0;
    #controls = /* @__PURE__ */ new Map();
    /** The editor this panel shows, once the owner picked one. */
    #view;
    #editor;
    /** The advanced editor's rule list, read in order when saving. */
    #rules;
    #topMatch;
    #simpleButton;
    #simpleReason;
    #advancedButton;
    #enabled;
    #placement;
    /** The line saying whether a rule is saved, updated after an autosave. */
    #note;
    #form;
    /** The account the panel was drawn for, and whether a rule is saved. */
    #accountId;
    #saved = false;
    /**
     * Save and remove run one after another, in click order, so a quick
     * "Save" then "Remove" can never end with the rule saved again.
     */
    #mutations = Promise.resolve();
    /**
     * The stored rule's `updatedAt` the form was drawn from (`none` for no
     * rule). A save or remove checks it inside the account lock, so a form
     * left open in a second tab cannot overwrite or recreate a rule another
     * tab changed since.
     */
    #drawnStamp = "none";
    /** Writes this panel made, so a queued click can tell them from others'. */
    #ownWrites = [];
    #writeSequence = 0;
    /** Bumped per render, so a slower, older render never replaces a newer one. */
    #generation = 0;
    async render() {
      const generation = this.#generation += 1;
      const document2 = this.root.ownerDocument;
      let account;
      let stored;
      try {
        account = await this.accounts.getActiveAccount();
        stored = account ? await this.rules.getGlobalRule(account.id) : void 0;
      } catch {
        if (generation === this.#generation)
          this.root.textContent = t("rule.readFailed");
        return;
      }
      if (generation !== this.#generation) return;
      if (account?.id !== this.#accountId) {
        this.#status.clear();
        this.#deleteLine.clear();
      }
      this.#accountId = account?.id;
      this.#drawnStamp = stored?.updatedAt ?? "none";
      this.#saved = stored !== void 0;
      if (!account) {
        this.#drawShell(document2);
        this.root.append(
          element6(document2, "p", "joyfox-panel__empty", t("rule.noAccount")),
          this.#status.node
        );
        return;
      }
      const simple = stored ? toBuilderForm(stored) : EMPTY_FORM;
      const advanced = stored ? toAdvancedForm(stored) : builderToAdvanced(EMPTY_FORM);
      if (!simple && !advanced) {
        this.#drawShell(document2);
        this.root.append(
          element6(document2, "p", "joyfox-panel__empty", t("rule.newer")),
          this.#status.node,
          this.#removeButton(document2, account.id),
          this.#deleteLine.node
        );
        return;
      }
      const view = simple && (this.#view !== "advanced" || !advanced) ? "simple" : "advanced";
      this.#drawForm(
        document2,
        account.id,
        view === "simple" && simple ? { view, form: simple } : { view: "advanced", form: advanced }
      );
    }
    /**
     * The language changed: draw the panel again. A form on screen is drawn
     * from what it shows now, not from storage, so unsaved input stays,
     * including a number that is not valid yet.
     */
    async localeChanged() {
      const document2 = this.root.ownerDocument;
      const accountId = this.#accountId;
      if (!this.#form?.isConnected || !accountId) return this.render();
      const shown = this.#rules ? { view: "advanced", form: this.#readAdvanced(numberOrNone) } : { view: "simple", form: this.#readSimple(numberOrNone) };
      const fields2 = Array.from(
        this.#form.querySelectorAll(VALUE_FIELDS)
      );
      const typed = fields2.map((input) => input.value);
      const noted = fields2.map((input) => this.#notes.has(input));
      const focused = document2.activeElement?.id;
      this.#drawForm(document2, accountId, shown);
      this.#form.querySelectorAll(VALUE_FIELDS).forEach((input, index) => {
        input.value = typed[index] ?? input.value;
        if (noted[index]) this.#checkField(input);
      });
      this.#updateSimpleReason();
      if (focused) document2.getElementById(focused)?.focus();
    }
    /** The heading and hint every state of the panel starts with. */
    #drawShell(document2) {
      this.#disarm();
      this.root.replaceChildren();
      this.#controls = /* @__PURE__ */ new Map();
      this.#form = void 0;
      this.#rules = void 0;
      this.#status.redraw();
      this.#deleteLine.redraw();
      const heading = element6(
        document2,
        "h2",
        "joyfox-panel__heading",
        t("options.tabs.rule")
      );
      heading.id = "joyfox-rule-heading";
      this.root.setAttribute("aria-labelledby", heading.id);
      this.root.append(heading);
      this.root.append(
        element6(document2, "p", "joyfox-panel__hint", t("rule.hint"))
      );
    }
    #drawForm(document2, accountId, shown) {
      this.#drawShell(document2);
      this.#accountId = accountId;
      this.#note = element6(document2, "p", "", noteText(this.#saved));
      this.#form = this.#renderForm(document2, accountId, shown, this.#saved);
      this.root.append(this.#note, this.#status.node, this.#form);
    }
    #renderForm(document2, accountId, shown, saved) {
      const { form } = shown;
      const node = element6(document2, "form", "joyfox-panel__form");
      node.setAttribute("aria-label", t("options.tabs.rule"));
      const enabledLabel = element6(document2, "label", "joyfox-rule__toggle");
      const enabled = document2.createElement("input");
      enabled.type = "checkbox";
      enabled.checked = form.enabled;
      enabled.id = "joyfox-rule-enabled";
      enabled.setAttribute(FOCUS_KEY, "rule:enabled");
      enabledLabel.append(
        enabled,
        document2.createTextNode(` ${t("rule.enabled")}`)
      );
      this.#enabled = enabled;
      const placementWrapper = element6(document2, "div", "joyfox-panel__field");
      const placementLabel = element6(
        document2,
        "label",
        "",
        t("rule.placementLabel")
      );
      placementLabel.htmlFor = "joyfox-rule-placement";
      const placement = document2.createElement("select");
      placement.id = "joyfox-rule-placement";
      for (const value of ["quarantined", "needs-review"])
        placement.append(
          new Option(
            t(PLACEMENT_TEXT[value]),
            value,
            false,
            value === form.defaultPlacement
          )
        );
      placementWrapper.append(placementLabel, placement);
      this.#placement = placement;
      this.#editor = element6(document2, "div", "joyfox-rule__editor");
      node.append(
        // How saving works, before the first field.
        element6(document2, "p", "joyfox-panel__hint", t("rule.autosaveHint")),
        enabledLabel,
        placementWrapper,
        this.#renderPresets(document2, accountId),
        this.#renderSwitch(document2),
        this.#editor,
        element6(document2, "p", "joyfox-panel__hint", t("rule.spamHint")),
        element6(document2, "p", "joyfox-panel__hint", t("rule.firstMessageHint"))
      );
      if (saved)
        node.append(
          this.#removeButton(document2, accountId),
          this.#deleteLine.node
        );
      this.#autosave = () => {
        const form2 = this.#readForm();
        this.#checkFields();
        const version = this.#version();
        void this.#serial(() => this.#save(accountId, form2, version));
      };
      node.addEventListener("change", (event) => {
        if (event.target.matches(
          ".joyfox-rule__add-condition, .joyfox-rule__preset"
        ))
          return;
        this.#updateSimpleReason();
        if (this.#boxChanged(event.target)) return this.#checkFields();
        this.#autosave();
      });
      node.addEventListener("input", (event) => {
        const field = event.target;
        if (this.#notes.has(field)) this.#checkField(field);
      });
      node.addEventListener("submit", (event) => {
        event.preventDefault();
        this.#autosave();
      });
      if (shown.view === "simple") this.#showSimple(document2, shown.form);
      else this.#showAdvanced(document2, shown.form);
      return node;
    }
    #autosave = () => void 0;
    /**
     * PRD 11.3's presets (V1-11, ADR 0016). A preset fills the Simple editor
     * with its conditions and saves at once; the user can then change them
     * like any other rule. Replacing conditions already shown takes a second
     * click, as the autosave leaves no other way back.
     */
    #renderPresets(document2, accountId) {
      const wrapper = element6(
        document2,
        "div",
        "joyfox-panel__field joyfox-rule__presets"
      );
      const label = element6(document2, "label", "", t("rule.preset.label"));
      label.htmlFor = "joyfox-rule-preset";
      const choice = document2.createElement("select");
      choice.id = "joyfox-rule-preset";
      choice.className = "joyfox-rule__preset";
      choice.append(new Option(t("rule.preset.choose"), "", true, true));
      for (const id of RULE_PRESET_IDS)
        choice.append(new Option(t(PRESET_TEXT[id]), id));
      const apply = element6(
        document2,
        "button",
        "joyfox-rule__preset-apply",
        t("rule.preset.apply")
      );
      apply.type = "button";
      apply.disabled = true;
      const description = element6(
        document2,
        "p",
        "joyfox-panel__hint joyfox-rule__preset-description"
      );
      description.id = "joyfox-rule-preset-description";
      choice.setAttribute("aria-describedby", description.id);
      const prompt = new StatusLine(document2);
      prompt.node.classList.add("joyfox-rule__prompt");
      const show = () => {
        const id = choice.value;
        apply.disabled = !isRulePresetId(id);
        description.textContent = isRulePresetId(id) ? presetDescription(id) : "";
      };
      choice.addEventListener("change", show);
      apply.addEventListener("click", (event) => {
        const id = choice.value;
        if (!isRulePresetId(id)) return;
        if (this.#shownConditionCount() > 0 && !this.#secondClick(apply, event, () => {
          apply.textContent = t("rule.preset.confirm");
          prompt.set(message("rule.preset.confirmPrompt"), "info");
          return () => {
            apply.textContent = t("rule.preset.apply");
            prompt.clear();
          };
        }))
          return;
        choice.focus();
        choice.value = "";
        show();
        this.#applyPreset(document2, accountId, id);
      });
      const row = element6(document2, "div", "joyfox-rule__preset-row");
      row.append(choice, apply);
      wrapper.append(
        label,
        row,
        prompt.node,
        description,
        element6(document2, "p", "joyfox-panel__hint", t("rule.preset.hint"))
      );
      return wrapper;
    }
    /** How many conditions the shown editor holds, valid or not. */
    #shownConditionCount() {
      if (this.#rules)
        return this.#readAdvanced(numberOrNone).rules.reduce(
          (count, rule) => count + Object.keys(rule.conditions).length,
          0
        );
      const form = this.#readSimple(numberOrNone);
      return Object.keys(form.all).length + Object.keys(form.any).length;
    }
    /** Show a preset in the Simple editor and save it. */
    #applyPreset(document2, accountId, id) {
      const form = presetForm(id, {
        enabled: this.#enabled?.checked ?? true,
        defaultPlacement: this.#placement?.value ?? "quarantined"
      });
      this.#view = "simple";
      this.#showSimple(document2, form);
      const version = this.#version();
      const read = {
        definition: fromBuilderForm(form),
        notice: presetNotice(id)
      };
      void this.#serial(() => this.#save(accountId, read, version));
      if (id === "custom")
        this.#editor?.querySelector("input[type=checkbox]")?.focus();
    }
    /** The Simple / Advanced switch, and why Simple is not available. */
    #renderSwitch(document2) {
      const row = element6(document2, "div", "joyfox-rule__switch-row");
      const label = element6(document2, "span", "", t("rule.editor"));
      label.id = "joyfox-rule-editor-label";
      const group = element6(document2, "div", "joyfox-rule__switch");
      group.setAttribute("role", "group");
      group.setAttribute("aria-labelledby", label.id);
      const button = (text, view) => {
        const node = element6(document2, "button", "", text);
        node.type = "button";
        node.dataset.view = view;
        node.addEventListener("click", () => this.#switchTo(document2, view));
        group.append(node);
        return node;
      };
      this.#simpleButton = button(t("rule.simple"), "simple");
      this.#advancedButton = button(t("rule.advanced"), "advanced");
      this.#simpleReason = element6(document2, "span", "joyfox-rule__simple-why");
      this.#simpleReason.id = "joyfox-rule-simple-why";
      this.#simpleButton.setAttribute("aria-describedby", this.#simpleReason.id);
      row.append(label, group, this.#simpleReason);
      return row;
    }
    #switchTo(document2, view) {
      const current = this.#rules ? "advanced" : "simple";
      if (view === current) return;
      if (view === "advanced") {
        const form2 = this.#readSimple(void 0, true);
        if (failed(form2)) {
          this.#checkFields();
          return this.#setStatus(form2, "error");
        }
        this.#view = "advanced";
        this.#showAdvanced(document2, builderToAdvanced(form2));
        return;
      }
      const advanced = this.#readAdvanced();
      if (failed(advanced)) {
        this.#checkFields();
        return this.#setStatus(advanced, "error");
      }
      const form = advancedToBuilder(advanced);
      if (isProblem(form)) return this.#setStatus(form, "error");
      this.#view = "simple";
      this.#showSimple(document2, form);
    }
    #markView(view) {
      this.#simpleButton?.setAttribute("aria-pressed", String(view === "simple"));
      this.#advancedButton?.setAttribute(
        "aria-pressed",
        String(view === "advanced")
      );
      if (view === "simple") this.#setSimpleReason(void 0);
    }
    /** Simple stays offered only while the advanced rule fits two boxes. */
    #setSimpleReason(reason) {
      if (this.#simpleButton) this.#simpleButton.disabled = reason !== void 0;
      if (this.#simpleReason)
        this.#simpleReason.textContent = reason ? t(reason) : "";
    }
    #showSimple(document2, form) {
      this.#controls = /* @__PURE__ */ new Map();
      this.#rules = void 0;
      this.#topMatch = void 0;
      this.#editor?.replaceChildren(
        this.#renderBox(document2, "all", form.all),
        this.#renderBox(document2, "any", form.any)
      );
      this.#markView("simple");
    }
    #showAdvanced(document2, form) {
      this.#controls = /* @__PURE__ */ new Map();
      const intro = element6(document2, "p", "joyfox-rule__combine");
      const top = matchSelect(document2, form.match, t("rule.combine.label"));
      top.id = "joyfox-rule-top-match";
      top.addEventListener("change", () => this.#renumber());
      this.#topMatch = top;
      intro.append(
        element6(document2, "strong", "", t("rule.combine.prefix")),
        top,
        element6(document2, "strong", "", t("rule.combine.suffix"))
      );
      const hint = element6(
        document2,
        "p",
        "joyfox-panel__hint",
        t("rule.advancedHint")
      );
      const rules2 = element6(document2, "div", "joyfox-rule__rules");
      this.#rules = rules2;
      for (const rule of form.rules.length > 0 ? form.rules : [{ match: "all", conditions: {} }])
        rules2.append(this.#renderRule(document2, rule));
      const add = element6(
        document2,
        "button",
        "joyfox-rule__add-rule",
        t("rule.addRule")
      );
      add.type = "button";
      add.addEventListener("click", () => {
        rules2.append(
          this.#renderRule(document2, { match: "all", conditions: {} })
        );
        this.#renumber();
        rules2.lastElementChild?.querySelector(".joyfox-rule__add-condition")?.focus();
      });
      const count = element6(document2, "span", "joyfox-rule__rule-count");
      const addRow = element6(document2, "div", "joyfox-rule__add-row");
      addRow.append(add, count);
      this.#editor?.replaceChildren(intro, hint, rules2, addRow);
      this.#markView("advanced");
      this.#renumber();
    }
    #renderRule(document2, rule) {
      const fieldset = element6(document2, "fieldset", "joyfox-rule__box");
      fieldset.dataset.rule = "";
      const head = element6(document2, "legend", "joyfox-rule__rule-head");
      const title = element6(document2, "strong", "joyfox-rule__rule-title");
      const match = matchSelect(document2, rule.match, "");
      match.className = "joyfox-rule__rule-match";
      const remove = element6(
        document2,
        "button",
        "joyfox-panel__remove joyfox-rule__remove-rule",
        t("rule.removeRule")
      );
      remove.type = "button";
      const prompt = new StatusLine(document2);
      prompt.node.classList.add("joyfox-rule__prompt");
      remove.addEventListener("click", (event) => {
        if (fieldset.querySelector(CONDITION_ROW) && !this.#secondClick(remove, event, () => {
          const number = this.#groupNumber(fieldset);
          remove.textContent = t("rule.confirmRemoveGroup");
          remove.setAttribute(
            "aria-label",
            t("rule.confirmRemoveGroupLabel", { number })
          );
          prompt.set(message("rule.removeGroupPrompt", { number }), "info");
          return () => {
            remove.textContent = t("rule.removeRule");
            remove.setAttribute(
              "aria-label",
              t("rule.removeRuleLabel", {
                number: this.#groupNumber(fieldset)
              })
            );
            prompt.clear();
          };
        }))
          return;
        fieldset.remove();
        this.#renumber();
        this.#autosave();
        this.#editor?.querySelector(".joyfox-rule__add-rule")?.focus();
      });
      head.append(
        title,
        match,
        element6(document2, "strong", "", t("rule.ruleSuffix")),
        remove
      );
      const list = element6(document2, "div", "joyfox-rule__conditions");
      const empty = element6(
        document2,
        "p",
        "joyfox-panel__hint joyfox-rule__empty",
        t("rule.noConditions")
      );
      for (const kind of CONDITION_KINDS) {
        const entry = rule.conditions[kind];
        if (entry) list.append(this.#renderCondition(document2, kind, entry));
      }
      const add = document2.createElement("select");
      add.className = "joyfox-rule__add-condition";
      add.addEventListener("change", () => {
        const kind = add.value;
        add.value = "";
        if (!CONDITION_KINDS.includes(kind)) return;
        const row = this.#renderCondition(document2, kind, {
          whenUnknown: "needs-review",
          ...NUMERIC_CONDITION_KINDS.has(kind) ? { value: NEW_VALUE[kind] } : {}
        });
        list.append(row);
        this.#renumber();
        if (TEXT_CONDITION_KINDS.has(kind)) {
          row.querySelector(".joyfox-rule__text")?.focus();
          return;
        }
        row.querySelector("input[type=number], select")?.focus();
        this.#autosave();
      });
      fieldset.append(head, prompt.node, list, empty, add);
      return fieldset;
    }
    /** A group's number, as the Advanced editor shows it. */
    #groupNumber(fieldset) {
      const groups = this.#rules?.querySelectorAll(":scope > [data-rule]");
      return Array.from(groups ?? []).indexOf(fieldset) + 1;
    }
    #renderCondition(document2, kind, entry) {
      const row = element6(
        document2,
        "div",
        "joyfox-rule__condition joyfox-rule__condition--advanced"
      );
      row.dataset.kind = kind;
      const remove = element6(
        document2,
        "button",
        "joyfox-panel__remove joyfox-rule__remove-condition",
        "\u2715"
      );
      remove.type = "button";
      const condition = conditionName(kind);
      remove.title = t("rule.removeCondition");
      remove.setAttribute(
        "aria-label",
        t("rule.removeConditionLabel", { condition })
      );
      remove.addEventListener("click", () => {
        row.remove();
        this.#renumber();
        this.#autosave();
      });
      const notLabel = element6(document2, "label", "joyfox-rule__not");
      const not = document2.createElement("input");
      not.type = "checkbox";
      not.className = "joyfox-rule__negate";
      not.checked = entry.negate === true;
      not.setAttribute("aria-label", t("rule.notLabel", { condition }));
      notLabel.title = t("rule.notTitle");
      notLabel.append(not, document2.createTextNode(t("rule.not")));
      const mark = () => notLabel.classList.toggle("joyfox-rule__not--on", not.checked);
      not.addEventListener("change", mark);
      mark();
      const name = element6(
        document2,
        "span",
        "joyfox-rule__name",
        t(CONDITION_TEXT[kind])
      );
      row.append(remove, notLabel, name);
      if (NUMERIC_CONDITION_KINDS.has(kind))
        row.append(numberInput(document2, kind, entry.value));
      else row.append(element6(document2, "span", "joyfox-rule__no-value"));
      if (TEXT_CONDITION_KINDS.has(kind)) {
        row.classList.add("joyfox-rule__condition--text");
        row.append(textInput(document2, kind, entry.text));
      }
      const unknown = unknownSelect(document2, entry.whenUnknown);
      unknown.className = "joyfox-rule__unknown";
      unknown.setAttribute("aria-label", t("rule.unknownLabel", { condition }));
      if (kind === "notTemplateSpam") {
        const note = spamNote(document2, this.#noteId());
        name.append(" ", note);
        unknown.setAttribute("aria-describedby", note.id);
      }
      row.append(
        element6(
          document2,
          "span",
          "joyfox-rule__unknown-label",
          t("rule.unknownPrompt")
        ),
        unknown
      );
      return row;
    }
    /**
     * After a rule or condition is added or removed: number the rules, show
     * AND or OR between them, and offer only the conditions a rule lacks.
     */
    #renumber() {
      const rules2 = this.#rules;
      if (!rules2) return;
      const document2 = rules2.ownerDocument;
      const fieldsets = Array.from(
        rules2.querySelectorAll(":scope > [data-rule]")
      );
      rules2.querySelectorAll(":scope > .joyfox-rule__joiner").forEach((node) => node.remove());
      const joiner = t(
        this.#topMatch?.value === "all" ? "rule.joiner.all" : "rule.joiner.any"
      );
      fieldsets.forEach((fieldset, index) => {
        const number = index + 1;
        if (index > 0)
          fieldset.before(element6(document2, "p", "joyfox-rule__joiner", joiner));
        fieldset.querySelector(".joyfox-rule__rule-title").textContent = t(
          "rule.ruleTitle",
          { number }
        );
        fieldset.querySelector(".joyfox-rule__rule-match").setAttribute("aria-label", t("rule.ruleMatchLabel", { number }));
        const remove = fieldset.querySelector(
          ".joyfox-rule__remove-rule"
        );
        remove.disabled = fieldsets.length === 1;
        remove.setAttribute("aria-label", t("rule.removeRuleLabel", { number }));
        const used = new Set(
          Array.from(
            fieldset.querySelectorAll(CONDITION_ROW),
            (row) => row.dataset.kind
          )
        );
        fieldset.querySelector(".joyfox-rule__empty").hidden = used.size > 0;
        const add = fieldset.querySelector(
          ".joyfox-rule__add-condition"
        );
        add.setAttribute("aria-label", t("rule.addConditionLabel", { number }));
        add.replaceChildren(new Option(t("rule.addCondition"), "", true, true));
        for (const kind of CONDITION_KINDS)
          if (!used.has(kind))
            add.append(new Option(t(CONDITION_TEXT[kind]), kind));
        add.hidden = used.size === CONDITION_KINDS.length;
      });
      const button = this.#editor?.querySelector(
        ".joyfox-rule__add-rule"
      );
      if (button) button.disabled = fieldsets.length >= MAX_ADVANCED_RULES;
      const count = this.#editor?.querySelector(".joyfox-rule__rule-count");
      if (count)
        count.textContent = t("rule.ruleCount", {
          count: fieldsets.length,
          maximum: MAX_ADVANCED_RULES
        });
      this.#updateSimpleReason();
    }
    #updateSimpleReason() {
      const form = this.#readAdvanced();
      if (failed(form)) return;
      const simple = advancedToBuilder(form);
      this.#setSimpleReason(isProblem(simple) ? simple : void 0);
    }
    #renderBox(document2, box2, entries) {
      const fieldset = element6(document2, "fieldset", "joyfox-rule__box");
      fieldset.append(element6(document2, "legend", "", t(BOX_LEGEND[box2])));
      for (const kind of CONDITION_KINDS) {
        const entry = entries[kind];
        const id = `joyfox-rule-${box2}-${kind}`;
        const row = element6(document2, "div", "joyfox-rule__condition");
        const on = document2.createElement("input");
        on.type = "checkbox";
        on.id = `${id}-on`;
        on.checked = entry !== void 0;
        const label = element6(document2, "label", "", t(CONDITION_TEXT[kind]));
        label.htmlFor = on.id;
        row.append(on, label);
        const controls = {
          on,
          unknown: document2.createElement("select")
        };
        if (kind === "notTemplateSpam") {
          const note = spamNote(document2, `${id}-note`);
          label.append(" ", note);
          controls.unknown.setAttribute("aria-describedby", note.id);
        }
        if (NUMERIC_CONDITION_KINDS.has(kind)) {
          const value = document2.createElement("input");
          value.type = "number";
          value.step = "1";
          value.min = String(
            kind === "minimumTrustScore" ? RULE_LIMITS.minTrustValue : 0
          );
          value.max = String(RULE_LIMITS.maxValue);
          value.id = `${id}-value`;
          value.value = String(entry?.value ?? "");
          value.dataset.condition = kind;
          value.setAttribute(
            "aria-label",
            t("rule.valueLabel", { condition: conditionName(kind) })
          );
          controls.value = value;
          row.append(value);
        } else {
          const gap = document2.createElement("span");
          gap.className = "joyfox-rule__no-value";
          row.append(gap);
        }
        if (TEXT_CONDITION_KINDS.has(kind)) {
          row.classList.add("joyfox-rule__condition--text");
          const text = textInput(document2, kind, entry?.text);
          text.id = `${id}-text`;
          controls.text = text;
          row.append(text);
        }
        const unknownLabel = element6(
          document2,
          "label",
          "",
          t("rule.unknownPrompt")
        );
        unknownLabel.htmlFor = `${id}-unknown`;
        controls.unknown.id = `${id}-unknown`;
        for (const handling of Object.keys(UNKNOWN_TEXT))
          controls.unknown.append(
            new Option(
              t(UNKNOWN_TEXT[handling]),
              handling,
              false,
              handling === (entry?.whenUnknown ?? "needs-review")
            )
          );
        row.append(unknownLabel, controls.unknown);
        followBox(controls);
        this.#controls.set(`${box2}:${kind}`, controls);
        fieldset.append(row);
      }
      return fieldset;
    }
    /**
     * A Simple row's box was ticked or cleared, and its fields follow it. A
     * ticked number without a value gets the Advanced editor's default, so
     * the tick saves at once. Returns true when a ticked text condition waits
     * for its text: focus moves there, and nothing is saved yet.
     */
    #boxChanged(target) {
      for (const [key2, controls] of this.#controls) {
        if (controls.on !== target) continue;
        followBox(controls);
        if (!controls.on.checked) return false;
        const kind = key2.slice(key2.indexOf(":") + 1);
        const { value, text } = controls;
        if (value && value.value.trim() === "") {
          value.value = String(NEW_VALUE[kind] ?? "");
          value.focus();
        }
        if (text && text.value.trim() === "") {
          text.focus();
          return true;
        }
        return false;
      }
      return false;
    }
    /**
     * Mark each number and text field in use whose value a save refuses, and
     * clear the others. A ticked Simple text condition without text shows a
     * hint instead: a save leaves it out until text is typed.
     */
    #checkFields() {
      this.#form?.querySelectorAll(VALUE_FIELDS).forEach((field) => this.#checkField(field));
    }
    #checkField(field) {
      const kind = field.dataset.condition;
      if (field.disabled) return this.#fieldNote(field, void 0);
      if (field.type === "number")
        return this.#fieldNote(
          field,
          typeof readNumber(field, kind) === "number" ? void 0 : message("rule.fieldNumberProblem", {
            minimum: numberMinimum(kind),
            maximum: RULE_LIMITS.maxValue
          })
        );
      if (!this.#rules && field.value.trim() === "")
        return this.#fieldNote(field, message("rule.textHint"), "hint");
      this.#fieldNote(
        field,
        failed(readText2(field, kind)) ? message("rule.fieldTextProblem", {
          maximum: RULE_LIMITS.maxTextLength
        }) : void 0
      );
    }
    /**
     * Show a note under a field's row, linked to the field, or remove it. An
     * error also marks the field as invalid.
     */
    #fieldNote(field, note, kind = "error") {
      let node = this.#notes.get(field);
      if (!note) {
        node?.remove();
        this.#notes.delete(field);
        field.removeAttribute("aria-invalid");
        field.removeAttribute("aria-describedby");
        return;
      }
      if (!node) {
        node = element6(field.ownerDocument, "span", "joyfox-rule__field-note");
        node.id = this.#noteId();
        field.closest(".joyfox-rule__condition")?.append(node);
        this.#notes.set(field, node);
      }
      node.dataset.note = kind;
      node.textContent = t(note);
      field.setAttribute("aria-describedby", node.id);
      if (kind === "error") field.setAttribute("aria-invalid", "true");
      else field.removeAttribute("aria-invalid");
    }
    #noteId() {
      return `joyfox-rule-note-${this.#noteCount += 1}`;
    }
    /** Read the shown editor, or return the first problem as a message. */
    #readForm() {
      if (this.#rules) {
        const form2 = this.#readAdvanced();
        if (failed(form2)) return form2;
        const definition2 = fromAdvancedForm(form2);
        return {
          definition: definition2,
          ...definition2.root.children.length === 0 ? { notice: message("rule.savedNoConditions") } : {}
        };
      }
      const form = this.#readSimple();
      if (failed(form)) return form;
      const all = Object.keys(form.all).length;
      const any = Object.keys(form.any).length;
      const notice = all + any === 0 ? message("rule.savedNoConditions") : all === 0 ? message("rule.savedVacuous") : void 0;
      return {
        definition: fromBuilderForm(form),
        ...notice ? { notice } : {}
      };
    }
    #readSimple(number, keepEmptyText = false) {
      const form = {
        enabled: this.#enabled?.checked ?? true,
        defaultPlacement: this.#placement?.value ?? "quarantined",
        all: {},
        any: {}
      };
      for (const box2 of ["all", "any"])
        for (const kind of CONDITION_KINDS) {
          const controls = this.#controls.get(`${box2}:${kind}`);
          if (!controls?.on.checked) continue;
          const entry = {
            whenUnknown: controls.unknown.value
          };
          if (controls.value) {
            const read = readNumber(controls.value, kind);
            const value = number ? number(read) : read;
            if (typeof value === "object") return value;
            if (value !== void 0) entry.value = value;
          }
          if (controls.text) {
            if (number) entry.text = controls.text.value;
            else if (controls.text.value.trim() === "") {
              if (!keepEmptyText) continue;
              entry.text = "";
            } else {
              const text = readText2(controls.text, kind);
              if (failed(text)) return text;
              entry.text = text.text;
            }
          }
          form[box2][kind] = entry;
        }
      return form;
    }
    #readAdvanced(number) {
      const form = {
        enabled: this.#enabled?.checked ?? true,
        defaultPlacement: this.#placement?.value ?? "quarantined",
        match: this.#topMatch?.value === "all" ? "all" : "any",
        rules: []
      };
      const fieldsets = this.#rules ? Array.from(
        this.#rules.querySelectorAll(":scope > [data-rule]")
      ) : [];
      for (const fieldset of fieldsets) {
        const match = fieldset.querySelector(
          ".joyfox-rule__rule-match"
        )?.value;
        const rule = {
          match: match === "any" ? "any" : "all",
          conditions: {}
        };
        for (const row of Array.from(
          fieldset.querySelectorAll(CONDITION_ROW)
        )) {
          const kind = row.dataset.kind;
          const entry = {
            whenUnknown: row.querySelector(
              ".joyfox-rule__unknown"
            ).value
          };
          if (row.querySelector(".joyfox-rule__negate")?.checked)
            entry.negate = true;
          const input = row.querySelector("input[type=number]");
          if (input) {
            const read = readNumber(input, kind);
            const value = number ? number(read) : read;
            if (typeof value === "object") return value;
            if (value !== void 0) entry.value = value;
          }
          const textField = row.querySelector(".joyfox-rule__text");
          if (textField) {
            if (number) entry.text = textField.value;
            else {
              const text = readText2(textField, kind);
              if (failed(text)) return text;
              entry.text = text.text;
            }
          }
          rule.conditions[kind] = entry;
        }
        form.rules.push(rule);
      }
      return form;
    }
    async #save(accountId, form, version) {
      if (failed(form)) {
        this.#setStatus(message("rule.notSaved", { problem: form }), "error");
        return;
      }
      try {
        const saved = await withAccountLock(accountId, async () => {
          if (!await this.#isActive(accountId)) return "account";
          if (!await this.#isCurrent(accountId, version)) return "rule";
          const rule = await this.rules.saveGlobalRule(
            accountId,
            form.definition
          );
          this.#recordOwnWrite(rule.updatedAt);
          this.#drawnStamp = rule.updatedAt;
          return "saved";
        });
        if (saved !== "saved") return this.#reportStale("saved", saved);
        this.#markSaved(accountId);
        this.#setStatus(form.notice ?? message("rule.saved"), "info");
      } catch {
        this.#setStatus(message("rule.saveFailed"), "error");
      }
    }
    /** After the first save, say so and offer to delete the rule, in place. */
    #markSaved(accountId) {
      this.#saved = true;
      if (this.#note) this.#note.textContent = noteText(true);
      if (this.#form && !this.#form.querySelector(".joyfox-rule__delete-all"))
        this.#form.append(
          this.#removeButton(this.root.ownerDocument, accountId),
          this.#deleteLine.node
        );
    }
    /**
     * Deleting the whole rule stops the inbox sorting, so it takes a second
     * click. The prompt and any failure show right under the button.
     */
    #removeButton(document2, accountId) {
      const button = element6(
        document2,
        "button",
        "joyfox-panel__remove joyfox-rule__delete-all",
        t("rule.deleteAll")
      );
      button.type = "button";
      button.setAttribute(FOCUS_KEY, "rule:delete-all");
      button.addEventListener("click", (event) => {
        const confirmed = this.#secondClick(button, event, () => {
          button.textContent = t("rule.confirmDeleteAll");
          this.#deleteLine.set(message("rule.deletePrompt"), "info");
          return () => {
            button.textContent = t("rule.deleteAll");
            this.#deleteLine.clear();
          };
        });
        if (!confirmed) return;
        const version = this.#version();
        void this.#serial(async () => {
          try {
            const removed = await withAccountLock(accountId, async () => {
              if (!await this.#isActive(accountId)) return "account";
              if (!await this.#isCurrent(accountId, version)) return "rule";
              await this.rules.deleteGlobalRule(accountId);
              this.#recordOwnWrite("none");
              return "removed";
            });
            if (removed !== "removed")
              return this.#reportStale("removed", removed);
            const focus = rememberFocus(this.root);
            await this.render();
            this.#setStatus(message("rule.removed"), "info");
            restoreFocus(this.root, focus, ["rule:enabled"]);
            this.#status.node.scrollIntoView?.({ block: "nearest" });
          } catch {
            this.#deleteLine.set(message("rule.removeFailed"), "error");
          }
        });
      });
      return button;
    }
    /**
     * A click on a button that acts only on its second click (`confirm.ts`).
     * Returns true when this click confirms: the button is armed, and the
     * click is a single one after the grace period, so a double-click can
     * never arm and confirm in one gesture. Otherwise an unarmed button arms
     * (`arm` shows the prompt and returns how to take it back), and an armed
     * one waits.
     */
    #secondClick(button, event, arm) {
      const armed = this.#armed;
      if (armed?.button === button) {
        if (!confirmAllowed(event, armed.at)) return false;
        this.#disarm();
        return true;
      }
      if (event.detail > 1) return false;
      this.#disarm();
      this.#armed = { button, at: confirmTiming.now(), disarm: arm() };
      return false;
    }
    #disarm() {
      const armed = this.#armed;
      this.#armed = void 0;
      armed?.disarm();
    }
    /**
     * Whether the form's account is still the active one. A form drawn for
     * another account stays clickable until the new render finishes. Checked
     * inside the account lock, so the answer holds for the write that follows.
     */
    async #isActive(accountId) {
      return (await this.accounts.getActiveAccount())?.id === accountId;
    }
    /** The form version a click acts on, captured at click time. */
    #version() {
      return { stamp: this.#drawnStamp, sequence: this.#writeSequence };
    }
    #recordOwnWrite(stamp) {
      this.#writeSequence += 1;
      this.#ownWrites.push({ stamp, sequence: this.#writeSequence });
      if (this.#ownWrites.length > 20) this.#ownWrites.shift();
    }
    /**
     * Whether the stored rule is still the version the click acted on, or one
     * this panel itself wrote after that click (a quick "Save" then "Remove"
     * in the same tab). Any other change came from another tab, even if this
     * panel redrew meanwhile, so the queued write is refused.
     */
    async #isCurrent(accountId, version) {
      const stored = (await this.rules.getGlobalRule(accountId))?.updatedAt;
      const current = stored ?? "none";
      if (current === version.stamp) return true;
      return this.#ownWrites.some(
        (write) => write.sequence > version.sequence && write.stamp === current
      );
    }
    /** Nothing was written; redraw from storage and say why. */
    async #reportStale(action, reason) {
      await this.render();
      this.#setStatus(message(`rule.stale.${reason}.${action}`), "error");
    }
    /**
     * Redraw when the stored rule changed elsewhere (another options tab),
     * but not on unrelated changes, so edits in progress are kept.
     */
    async refreshIfChanged() {
      const account = await this.accounts.getActiveAccount();
      const stored = account ? await this.rules.getGlobalRule(account.id) : void 0;
      if ((stored?.updatedAt ?? "none") === this.#drawnStamp) return;
      await this.render();
      this.#setStatus(message("rule.changedElsewhere"), "info");
    }
    #serial(action) {
      const run = this.#mutations.then(action);
      this.#mutations = run.catch(() => void 0);
      return run;
    }
    #setStatus(text, kind) {
      this.#status.set(text, kind);
    }
  };

  // src/options/tabs.ts
  var OptionsTabs = class {
    constructor(document2, tablist2) {
      this.document = document2;
      this.#tabs = Array.from(
        tablist2.querySelectorAll('[role="tab"]')
      );
      tablist2.addEventListener("keydown", (event) => this.#onKey(event));
      for (const tab of this.#tabs)
        tab.addEventListener("click", (event) => {
          event.preventDefault();
          this.select(this.#name(tab), { push: true });
        });
      document2.defaultView?.addEventListener("hashchange", () => {
        const active = document2.activeElement;
        const fromPanel = active?.closest('[role="tabpanel"]') != null;
        this.select(this.#fromHash(), { focus: fromPanel });
      });
      this.select(this.#fromHash());
    }
    #tabs;
    /** The selected tab's name, as in its `#<name>` link. */
    get selected() {
      const tab = this.#tabs.find(
        (node) => node.getAttribute("aria-selected") === "true"
      );
      return tab ? this.#name(tab) : "";
    }
    select(name, options = {}) {
      const target = this.#tabs.find((tab) => this.#name(tab) === name) ?? this.#tabs[0];
      if (!target) return;
      for (const tab of this.#tabs) {
        const on = tab === target;
        tab.setAttribute("aria-selected", String(on));
        tab.tabIndex = on ? 0 : -1;
        const panel = this.document.getElementById(
          tab.getAttribute("aria-controls") ?? ""
        );
        if (panel) panel.hidden = !on;
      }
      if (options.focus) target.focus();
      const hash = `#${this.#name(target)}`;
      const view = this.document.defaultView;
      if (options.push && view && view.location.hash !== hash)
        view.history.pushState(null, "", hash);
    }
    #name(tab) {
      return (tab.getAttribute("href") ?? "").replace(/^#/, "");
    }
    #fromHash() {
      return (this.document.defaultView?.location.hash ?? "").replace(/^#/, "");
    }
    #onKey(event) {
      const index = this.#tabs.findIndex(
        (tab2) => tab2 === this.document.activeElement
      );
      if (index < 0) return;
      const last = this.#tabs.length - 1;
      const next = event.key === "ArrowRight" ? index === last ? 0 : index + 1 : event.key === "ArrowLeft" ? index === 0 ? last : index - 1 : event.key === "Home" ? 0 : event.key === "End" ? last : void 0;
      if (next === void 0) return;
      event.preventDefault();
      const tab = this.#tabs[next];
      if (tab) this.select(this.#name(tab), { push: true, focus: true });
    }
  };

  // src/options/template-panel.ts
  function element7(document2, tag, className, text) {
    const node = document2.createElement(tag);
    node.className = className;
    if (text !== void 0) node.textContent = text;
    return node;
  }
  var PREVIEW_LENGTH = 120;
  function preview(body) {
    const flat = body.replace(/\s+/gu, " ").trim();
    return flat.length > PREVIEW_LENGTH ? `${flat.slice(0, PREVIEW_LENGTH)}\u2026` : flat;
  }
  var focusFell3 = (document2) => !document2.activeElement || document2.activeElement === document2.body;
  var TemplatePanel = class {
    constructor(root, templates2 = new TemplateService(), accounts2 = new AccountService(), onChange = () => void 0) {
      this.root = root;
      this.templates = templates2;
      this.accounts = accounts2;
      this.onChange = onChange;
      this.#status = new StatusLine(root.ownerDocument);
    }
    #status;
    /** Bumped per render, so a slower, older render never replaces a newer one. */
    #generation = 0;
    /** The account the list and form were drawn for. */
    #accountId;
    #editing;
    #pendingDelete;
    #armedAt = 0;
    #form;
    /** Set while a save runs, so a double submit cannot add a template twice. */
    #saving = false;
    /** Where the next draw puts focus, whatever had it before. */
    #focusNext;
    /**
     * The control that had focus when a save started. The disabled submit
     * button drops focus to the page; the draw after the save puts it back.
     */
    #focusBefore;
    /** The folder each drawn template is listed in, by template ID. */
    #folders = /* @__PURE__ */ new Map();
    #guard = {
      activeAccountId: () => this.accounts.getActiveAccountId()
    };
    async render() {
      const generation = this.#generation += 1;
      const document2 = this.root.ownerDocument;
      let accountId;
      let templates2;
      try {
        accountId = (await this.accounts.getActiveAccount())?.id;
        templates2 = accountId ? await this.templates.list(accountId) : [];
      } catch {
        if (generation === this.#generation)
          this.root.textContent = t("templates.readFailed");
        return;
      }
      if (generation !== this.#generation) return;
      if (accountId !== this.#accountId) {
        this.#editing = void 0;
        this.#pendingDelete = void 0;
        this.#status.clear();
      }
      if (this.#editing && !templates2.some((t2) => t2.id === this.#editing?.id))
        this.#editing = void 0;
      const previous = this.#form;
      const draft = previous && accountId === this.#accountId ? {
        editingId: previous.editingId,
        name: previous.name.value,
        folder: previous.folder.value,
        body: previous.body.value
      } : void 0;
      this.#form = void 0;
      this.#accountId = accountId;
      const focus = rememberFocus(this.root) ?? (focusFell3(document2) ? this.#focusBefore : void 0);
      const folders = this.#folders;
      this.#folders = /* @__PURE__ */ new Map();
      this.root.replaceChildren();
      this.#status.redraw();
      const heading = element7(
        document2,
        "h2",
        "joyfox-panel__heading",
        t("templates.heading")
      );
      heading.id = "joyfox-templates-heading";
      this.root.setAttribute("aria-labelledby", heading.id);
      this.root.append(
        heading,
        element7(document2, "p", "joyfox-panel__hint", t("templates.hint"))
      );
      if (!accountId) {
        const empty = element7(document2, "p", "joyfox-panel__empty");
        empty.append(withTabLinks(document2, t("templates.noAccount")));
        this.root.append(empty, this.#status.node);
        return;
      }
      this.root.append(this.#renderList(document2, accountId, templates2));
      const form = this.#renderForm(document2, accountId);
      if (draft && draft.editingId === form.editingId) {
        form.name.value = draft.name;
        form.folder.value = draft.folder;
        form.body.value = draft.body;
      }
      this.#form = form;
      this.root.append(form.form, this.#status.node);
      const next = this.#focusNext;
      this.#focusNext = void 0;
      if (next) restoreFocus(this.root, next);
      else restoreFocus(this.root, focus, this.#fallbacks(focus, folders));
    }
    /**
     * Where focus goes when its control is gone after a draw: after a delete,
     * the template's folder list, else the name field of the form.
     */
    #fallbacks(focus, folders) {
      if (!focus?.key.startsWith("delete:")) return [];
      const folder = folders.get(focus.key.slice("delete:".length));
      return [
        ...folder === void 0 ? [] : [`folder:${folder}`],
        "field:name"
      ];
    }
    #renderList(document2, accountId, templates2) {
      if (templates2.length === 0)
        return element7(
          document2,
          "p",
          "joyfox-panel__empty",
          t("templates.empty")
        );
      const wrapper = element7(document2, "div", "joyfox-templates__folders");
      let list;
      let folder;
      const general = t(DEFAULT_FOLDER);
      const sorted = [...templates2].sort(
        (a, b) => compareTemplates(a, b, general)
      );
      for (const template of sorted) {
        if (folderOf(template, general) !== folder) {
          folder = folderOf(template, general);
          const title = element7(
            document2,
            "h3",
            "joyfox-templates__folder",
            folder
          );
          list = element7(document2, "ul", "joyfox-panel__list");
          list.setAttribute("aria-label", t("templates.inFolder", { folder }));
          list.tabIndex = -1;
          list.setAttribute(FOCUS_KEY, `folder:${folder}`);
          wrapper.append(title, list);
        }
        list.append(this.#renderItem(document2, accountId, template));
        this.#folders.set(template.id, folder);
      }
      return wrapper;
    }
    #renderItem(document2, accountId, template) {
      const item = element7(document2, "li", "joyfox-panel__item");
      item.dataset.templateId = template.id;
      item.append(
        element7(document2, "span", "joyfox-panel__item-name", template.name),
        element7(
          document2,
          "span",
          "joyfox-templates__preview",
          preview(template.body)
        )
      );
      const name = { name: template.name };
      const edit = element7(
        document2,
        "button",
        "joyfox-templates__edit",
        t("templates.edit")
      );
      edit.type = "button";
      edit.setAttribute(FOCUS_KEY, `edit:${template.id}`);
      edit.setAttribute("aria-label", t("templates.editLabel", name));
      edit.addEventListener("click", () => {
        this.#pendingDelete = void 0;
        this.#editing = template;
        this.#setStatus(message("templates.editing", name), "info");
        this.#focusNext = { key: "field:name" };
        void this.render();
      });
      const confirming = this.#pendingDelete === template.id;
      const remove = element7(
        document2,
        "button",
        "joyfox-panel__remove",
        t(confirming ? "templates.confirmDelete" : "templates.delete")
      );
      remove.type = "button";
      remove.setAttribute(FOCUS_KEY, `delete:${template.id}`);
      remove.setAttribute(
        "aria-label",
        t(
          confirming ? "templates.confirmDeleteLabel" : "templates.deleteLabel",
          name
        )
      );
      remove.addEventListener("click", (event) => {
        if (!confirming) {
          if (event.detail > 1) return;
          this.#pendingDelete = template.id;
          this.#armedAt = confirmTiming.now();
          this.#setStatus(message("templates.deletePrompt", name), "info");
          void this.render();
          return;
        }
        if (this.#pendingDelete !== template.id) return;
        if (!confirmAllowed(event, this.#armedAt)) return;
        void this.#run(accountId, async () => {
          this.#pendingDelete = void 0;
          await this.templates.delete(accountId, template.id, this.#guard);
          if (this.#editing?.id === template.id) this.#editing = void 0;
          this.#setStatus(message("templates.deleted", name), "info");
        });
      });
      item.append(edit, remove);
      return item;
    }
    #renderForm(document2, accountId) {
      const editing = this.#editing;
      const form = element7(document2, "form", "joyfox-panel__form");
      form.setAttribute(
        "aria-label",
        editing ? t("templates.editLabel", { name: editing.name }) : t("templates.addForm")
      );
      const name = this.#input(
        document2,
        form,
        "joyfox-template-name",
        "field:name",
        t("templates.name"),
        MAX_TEMPLATE_NAME_LENGTH
      );
      name.required = true;
      name.value = editing?.name ?? "";
      const folder = this.#input(
        document2,
        form,
        "joyfox-template-folder",
        "field:folder",
        t("templates.folder"),
        MAX_TEMPLATE_FOLDER_LENGTH
      );
      folder.value = editing?.folder ?? "";
      const suggestions = element7(document2, "datalist", "");
      suggestions.id = "joyfox-template-folders";
      for (const key2 of SUGGESTED_FOLDERS) {
        const option = document2.createElement("option");
        option.value = t(key2);
        suggestions.append(option);
      }
      folder.setAttribute("list", suggestions.id);
      form.append(suggestions);
      const bodyField = element7(document2, "p", "joyfox-panel__field");
      const bodyLabel = element7(
        document2,
        "label",
        "joyfox-panel__field-label",
        t("templates.text")
      );
      bodyLabel.htmlFor = "joyfox-template-body";
      const body = element7(document2, "textarea", "joyfox-panel__field-input");
      body.id = "joyfox-template-body";
      body.name = body.id;
      body.setAttribute(FOCUS_KEY, "field:body");
      body.rows = 6;
      body.required = true;
      body.maxLength = MAX_TEMPLATE_BODY_LENGTH;
      body.value = editing?.body ?? "";
      bodyField.append(bodyLabel, body);
      form.append(bodyField);
      const submit = element7(
        document2,
        "button",
        "joyfox-panel__submit",
        t(editing ? "templates.saveChanges" : "templates.add")
      );
      submit.type = "submit";
      submit.setAttribute(FOCUS_KEY, "submit");
      form.append(submit);
      if (editing) {
        const cancel = element7(
          document2,
          "button",
          "joyfox-templates__cancel",
          t("templates.cancel")
        );
        cancel.type = "button";
        cancel.addEventListener("click", () => {
          this.#editing = void 0;
          this.#status.clear();
          this.#focusNext = { key: `edit:${editing.id}` };
          void this.render();
        });
        form.append(cancel);
      }
      form.addEventListener("submit", (event) => {
        event.preventDefault();
        if (this.#saving) return;
        const id = editing?.id;
        const input = {
          ...id ? { id } : {},
          name: name.value,
          folder: folder.value,
          body: body.value
        };
        this.#saving = true;
        const focus = rememberFocus(this.root);
        this.#focusBefore = focus;
        submit.disabled = true;
        void this.#run(accountId, async () => {
          this.#pendingDelete = void 0;
          let saved;
          try {
            saved = await this.templates.save(accountId, input, this.#guard);
          } catch (error) {
            if (id && !(await this.templates.list(accountId)).some((t2) => t2.id === id)) {
              this.#editing = void 0;
              if (this.#form) this.#form.editingId = void 0;
              await this.render();
            }
            throw error;
          }
          this.#editing = void 0;
          this.#form = void 0;
          if (id && focus) this.#focusNext = { key: `edit:${saved.id}` };
          this.#setStatus(
            message(id ? "templates.saved" : "templates.added", {
              name: saved.name
            }),
            "info"
          );
        }).finally(() => {
          this.#saving = false;
          submit.disabled = false;
          if (focusFell3(this.root.ownerDocument))
            restoreFocus(this.root, this.#focusBefore);
          if (this.#focusBefore === focus) this.#focusBefore = void 0;
        });
      });
      return { editingId: editing?.id, form, name, folder, body };
    }
    #input(document2, form, id, focusKey, labelText, maxLength) {
      const wrapper = element7(document2, "p", "joyfox-panel__field");
      const label = element7(
        document2,
        "label",
        "joyfox-panel__field-label",
        labelText
      );
      label.htmlFor = id;
      const input = element7(document2, "input", "joyfox-panel__field-input");
      input.id = id;
      input.name = id;
      input.type = "text";
      input.autocomplete = "off";
      input.maxLength = maxLength;
      input.setAttribute(FOCUS_KEY, focusKey);
      wrapper.append(label, input);
      form.append(wrapper);
      return input;
    }
    #setStatus(message2, kind) {
      this.#status.set(message2, kind);
    }
    /**
     * A write goes to the account the panel was drawn for, and only while it
     * is still the active one. On success the panel redraws from storage; on
     * failure the form keeps what the user typed.
     */
    async #run(accountId, action) {
      try {
        if ((await this.accounts.getActiveAccount())?.id !== accountId) {
          this.#pendingDelete = void 0;
          await this.render();
          this.#setStatus(message("templates.accountChanged"), "error");
          return;
        }
        await action();
      } catch (error) {
        this.#pendingDelete = void 0;
        const display = errorDisplay(error);
        this.#setStatus(
          display ? message("error.withSuffix.nothingChanged", { error: display }) : message("common.saveFailed"),
          "error"
        );
        return;
      }
      this.onChange();
      await this.render();
    }
  };

  // src/options/index.ts
  var find = (id) => document.querySelector(`#${id}`);
  var tablist = document.querySelector('[role="tablist"]');
  if (tablist) new OptionsTabs(document, tablist);
  var quietly = (render2) => () => void render2().catch(() => void 0);
  var startRoot = find("joyfox-get-started");
  var start = startRoot ? new GetStartedPanel(startRoot) : void 0;
  var renderStart = quietly(async () => start?.render());
  var dataRoot = find("joyfox-data");
  var data = dataRoot ? new DataPanel(
    dataRoot,
    void 0,
    void 0,
    void 0,
    () => refreshAll(),
    find("joyfox-import") ?? void 0
  ) : void 0;
  var renderData = quietly(async () => data?.render());
  var templateRoot = find("joyfox-templates");
  var templates = templateRoot ? new TemplatePanel(templateRoot, void 0, void 0, renderData) : void 0;
  var renderTemplates = quietly(async () => templates?.render());
  var eventsRoot = find("joyfox-events");
  var events = eventsRoot ? new EventsPanel(eventsRoot) : void 0;
  var renderEvents = quietly(async () => events?.render());
  var messagesRoot = find("joyfox-messages");
  var messages = messagesRoot ? new MessagesPanel(messagesRoot) : void 0;
  var renderMessages = quietly(async () => messages?.render());
  var ruleRoot = find("joyfox-rule");
  var rules = ruleRoot ? new RulePanel(ruleRoot) : void 0;
  var renderRules = quietly(async () => rules?.render());
  var quickRoot = find("joyfox-quick-action");
  var quick = quickRoot ? new QuickActionPanel(quickRoot) : void 0;
  var renderQuick = quietly(async () => quick?.render());
  var accounts;
  var accountRoot = find("joyfox-accounts");
  var accountsFailed = false;
  function mountAccounts() {
    if (!accountRoot) return;
    void mountAccountPanel(accountRoot, void 0, renderData).then((panel) => {
      accounts = panel;
    }).catch(() => {
      accountsFailed = true;
      accountRoot.textContent = t("accounts.readFailed");
    });
  }
  function refreshAll() {
    if (accounts) void accounts.render().catch(() => void 0);
    renderStart();
    renderRules();
    renderTemplates();
    renderEvents();
    renderMessages();
  }
  var language = document.querySelector("#joyfox-language");
  var languageStatus = language ? new StatusLine(document) : void 0;
  if (language && languageStatus)
    (language.closest(".joyfox-options__title-row") ?? language.parentElement)?.after(languageStatus.node);
  language?.addEventListener("change", () => {
    const value = language.value;
    if (!isLocale(value)) return;
    languageStatus?.clear();
    void runtimeSettingsArea.set({ [LOCALE_KEY]: value }).catch(() => {
      language.value = currentLocale();
      languageStatus?.set(message("options.languageSaveFailed"), "error");
    });
  });
  onLocaleChange((locale2) => {
    applyStaticText(document);
    if (language) language.value = locale2;
    languageStatus?.clear();
    if (accounts) void accounts.render().catch(() => void 0);
    else if (accountsFailed && accountRoot)
      accountRoot.textContent = t("accounts.readFailed");
    renderStart();
    if (rules) void rules.localeChanged().catch(() => void 0);
    renderQuick();
    renderTemplates();
    renderEvents();
    renderMessages();
    renderData();
  });
  var localeHeard = false;
  browser.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (LOCALE_KEY in changes) {
      localeHeard = true;
      setLocale(localeFromSetting(changes[LOCALE_KEY]?.newValue));
    }
    if (ACTIVE_ACCOUNT_SETTING_KEY in changes) {
      if (accounts) void accounts.render().catch(() => void 0);
      renderStart();
      renderRules();
      renderTemplates();
      renderEvents();
      renderMessages();
      renderData();
    } else if (TRIAGE_REVISION_KEY in changes) {
      renderStart();
      if (rules) void rules.refreshIfChanged().catch(() => void 0);
      renderEvents();
      renderMessages();
      renderData();
    }
    if (MESSAGE_REVISION_KEY in changes || MESSAGE_CACHING_KEY in changes || MESSAGE_RETENTION_KEY in changes) {
      renderMessages();
      if (MESSAGE_REVISION_KEY in changes) renderData();
    }
    if (QUICK_ACTION_KEY in changes) renderQuick();
    if (MEMBER_REVISION_KEY in changes) {
      renderMessages();
      renderData();
    }
    if (EVENT_REVISION_KEY in changes || SHARED_EVENT_EXCEPTION_KEY in changes) {
      renderEvents();
      renderData();
    }
  });
  void readLocale(runtimeSettingsArea).then((locale2) => {
    if (!localeHeard) setLocale(locale2);
    applyStaticText(document);
    if (language) language.value = currentLocale();
    mountAccounts();
    renderStart();
    renderRules();
    renderQuick();
    renderTemplates();
    renderEvents();
    renderMessages();
    renderData();
  });
})();
