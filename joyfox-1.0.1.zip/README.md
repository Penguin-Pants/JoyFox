# JoyFox

JoyFox is a local-first Firefox and Chrome extension that enhances pages a user
opens on JoyClub. It does not fetch profiles or call undocumented APIs. It works
on the inbox, conversation, profile, member search, event and venue pages of
www.joyclub.de, whose selectors are verified from live evidence
(`docs/selector-map.md`). JOYCE is not verified yet, and JoyFox stays inactive
there.

## Development

Requires Node.js 22 and npm.

- `npm ci` installs the locked dependencies.
- `npm test` runs unit and synthetic-DOM integration tests.
- `npm run lint` checks source rules and the permission allowlist.
- `npm run format:check` checks formatting.
- `npm run typecheck` checks TypeScript.
- `npm run build:firefox` creates the deterministic unpacked build in
  `dist/firefox`.
- `npm run build:chrome` creates the unpacked Chrome build in `dist/chrome`.
  `npm run package:chrome` also zips it for the Chrome Web Store
  (`docs/chrome.md`).

`docs/building.md` has short steps to build, test and package both versions.

The logo, icons, colors and store images come from the approved brand package in
`assets/brand/`. `docs/branding.md` says which files go into a build and how the
UI uses them.

## Install

- **Firefox, for development:** run `npm run build:firefox`, then load
  `dist/firefox/manifest.json` from `about:debugging` > "This Firefox" > "Load
  Temporary Add-on". Firefox removes it when it closes.
- **Chrome 148 or later, for development:** run `npm run build:chrome`, then
  load `dist/chrome` from `chrome://extensions` ("Developer mode" > "Load
  unpacked").
- **Firefox, a release:** install JoyFox from its page on addons.mozilla.org.
  Mozilla signs it, and Firefox updates it from there (`docs/release.md`).

The extension ID is `joyfox@drclaw`. Firefox keeps an extension's data under its
ID, so a build with a different ID starts empty: export your data under "Your
data" first and import it afterwards.

## Verify a release

The build is deterministic: the same source and the same locked dependencies
give byte-identical files. To check that a release `.xpi` matches its source:

1. Check out the release tag and run `npm ci`, then `npm run build:firefox`
   (Node.js 22).
2. Unpack the `.xpi` (it is a ZIP file), for example
   `unzip joyfox.xpi -d release`.
3. Run `diff -r --exclude=META-INF release dist/firefox`. No output means the
   release holds exactly the files built from the source. `META-INF` holds only
   the signature that Mozilla's signing adds.

## Build from source (for Mozilla's reviewers)

The signed `.xpi` holds code that esbuild bundled from the TypeScript in `src`.
The code is not minified or obfuscated. These steps rebuild it exactly.

- **Operating system:** any system that runs Node.js. The release is built on
  Ubuntu 24.04 LTS (x86-64).
- **Tools:** Node.js 22 or 24 with its npm. Tested with Node.js 22.22.2 and npm
  10.9.7, and with Node.js 24.14.0 and npm 11.9.0 (your default environment):
  both give byte-identical files. The ARM64 build was not tested; the lockfile
  holds esbuild's ARM64 package. Download Node.js from
  <https://nodejs.org/en/download>; npm comes with it. No other tool is needed,
  and nothing is web-based.
- **Commands,** in the unpacked source folder:
  1. `npm ci` installs the exact dependencies in `package-lock.json` from the
     npm registry.
  2. `npm run build:firefox` writes the extension to `dist/firefox`.
- **Compare:** unpack the signed `.xpi` and compare it with `dist/firefox`, as
  under "Verify a release". Only `META-INF`, the signature, differs.
- **Testing:** every feature works on JoyClub pages (www.joyclub.de) and needs a
  signed-in JoyClub account. JoyFox provides no test account. The options page
  (`about:addons` > JoyFox > Preferences) works without one.

## Features

The database is at schema version 4. An existing version 1, 2 or 3 installation
upgrades in place and keeps its records.

JoyFox shows its own text in German or English. It follows the Firefox language
until you pick one with "Sprache / Language" at the top of the options page, and
open JoyClub tabs switch at once (ADR 0014, `docs/manual-acceptance.md`, items
91 to 97).

On a fresh install the options page opens once, and "Get started" at its top
lists the three steps to a triaged inbox. The JoyFox button in the Firefox
toolbar (or in the Extensions menu, until you pin it) opens the options page at
any time. If Firefox does not let JoyFox run on joyclub.de, "Get started" shows
a button to allow it. The options page holds the account switcher. You can
rename an account's display label; its JoyClub identifier stays as entered,
because an import matches accounts by it. JoyFox cannot detect which JoyClub
login a tab uses, so the active account is the one selected there, and every
stored note, tag and rule belongs to it. A private note and tags can be kept for
a member on their profile page and in a conversation with them, below the JoyFox
panel. They are stored only for a verified member ID, never a display name. They
are not shown on your own profile. See `docs/manual-acceptance.md`, items 36
to 42.

The contact rule is built on the options page in plain language, in a Simple or
an Advanced editor (whose parts are groups), and saves on each change. Until an
account is active and a rule is saved, the inbox shows one line with a link to
the options page. "Start from a preset" fills it with one of the PRD's presets:
Open, Complete profiles only, Verified members, High-trust members or Custom
(ADR 0016, `docs/manual-acceptance.md`, items 105 to 107).

On JoyClub's member search, a "JoyFox saved searches" bar above the results
saves the search's address, which holds every filter, under a name, and opens it
again in one click. A saved search whose address no longer matches JoyClub's
search is not opened (V1-3, `docs/manual-acceptance.md`, items 108 to 110).

On an event page, a JoyFox box keeps your own attendance, note and tags for the
event; on a venue page, a note and tags. The box stays closed until JoyFox
tracks the page, and the list filter keeps its choice for the tab, except a tag.
JoyClub's own sign-up is never touched. On "Dates & Events", a filter shows only
the loaded events that carry your tags, note or attendance, and a badge marks
them. The options page's "Events" tab is your personal calendar of every tracked
event, also after JoyClub removes it (V1-5, `docs/manual-acceptance.md`, items
111 to 115).

On the five "My JOY" lists (Profilbesuche, Matches, Mögen mich, Mag ich and
Besuchte Profile), a "Profile type" bar shows only the loaded cards of the types
you tick: Man, Woman, Couple or Unknown. Nothing ticked shows all. The choice
lasts for the tab across the five lists. JoyFox filters only the cards JoyClub
has loaded, and stores nothing about them (V1-14, `docs/manual-acceptance.md`,
items 167 to 171).

The Compatibility Overlay compares a profile's "Vorlieben" with your own. JoyFox
reads your own preferences when you open your own profile. On another member's
profile it frames the tags you both like and lists them on request; on search
results, inbox rows and event guest lists it shows "N shared" for each member
whose profile you opened before, and it can sort the loaded search results by
that number. It never shows a percentage (V1-2, `docs/manual-acceptance.md`,
items 116 to 120).

On search results, inbox rows and event guest lists, JoyFox shows what it knows
about each member: the completeness badge (photos, words, verification), the
local trust score and your own tags, with a button to edit your note and tags
right there. On the member search, "JoyFox: hide incomplete profiles" hides the
loaded results known to be below 3 photos or 50 words (V1-10,
`docs/manual-acceptance.md`, items 125 to 128).

For an event you track, JoyFox stores the guest list the event page shows
(member IDs only) and lists the shared events on each guest's profile. An
optional exception, off by default, places a sender in Qualified when they are
on the guest list of an event you marked Attending or Attended; the "Details"
panel names the event and can turn it off for that sender (V1-13,
`docs/manual-acceptance.md`, items 129 to 132).

Conversation History Search stores the ClubMail messages you open, sent and
received, and the options page's "Messages" tab searches them. It is on by
default and can be turned off there; messages older than 12 months (you choose 1
to 120; lowering the number deletes older messages at once, after a second
click) are deleted automatically, and each message can be deleted under "Your
data". It stores only what a conversation shows on screen (V1-4,
`docs/manual-acceptance.md`, items 121 to 124).

Firefox runs JoyFox in private windows only if you allow it (about:addons >
JoyFox > "Run in Private Windows"); the default is off. If you allow it, JoyFox
stores what it reads in a private window like in a normal window: messages,
profile facts and nicknames stay after the private window closes. Delete them
under "Your data".

The options page also holds message templates and "Your data", where every
stored record can be inspected field by field, exported as JSON and deleted, per
account or for the whole extension. It also sets how many profile snapshots
JoyFox keeps per member (20 by default). A "JoyFox templates" button below
JoyClub's message box inserts a template at the cursor; it never sends. See
`docs/manual-acceptance.md`, items 27 to 35. Import is on the "Accounts" tab,
and "Your data" links to it.

"Mark qualified" and "Mark as junk" in the member bar (conversation and profile
pages) and in the inbox row's "Details" panel place a sender in Qualified or
Junk as your own choice and log one trust outcome, +1 or -1, in one click. On a
conversation page, "Mark as junk" also moves the conversation to JoyClub's
trash. "Use my rule again" clears your choice; a logged outcome stays until you
undo it (ADR 0017).

A "Delete" button on every ClubMail conversation moves it to JoyClub's trash in
one click, then returns to the ClubMail list after 2 seconds. It needs no
setting. It works only while the ClubMail list shows the conversation beside it;
otherwise it is greyed out and says why (ADR 0017, `docs/manual-acceptance.md`,
items 172 to 181, accepted live on 2026-09-30).

Quick Ignore and Delete (M9) has its state machine, action log and on-screen
notice. Its live driver follows F7's evidence: Delete on the conversation page,
then Ignore on the member's profile in the same tab (ADR 0011). It is on by
default, beside "Delete"; untick "Ignore and Delete" on the options page's
"Contact rule" tab to hide it (item 133, ADR 0017). That switch controls only
Ignore and Delete. The manual matrix (`docs/manual-acceptance.md`, items 43
to 54) was accepted on 2026-09-25. If the move to the profile is cancelled, the
conversation page withdraws the hand-off after 15 seconds and says Ignore was
not done (item 98). If another JoyClub page loads in the tab first, that page
drops the hand-off at once (item 100). Both are covered by synthetic tests; item
99, a normal run, checks the hand-off live.

## Disclaimer

Read this before you install JoyFox.

- JoyFox is an independent project. JoyClub does not make, check or support it.
- Nobody has checked whether JoyClub's terms of use allow browser extensions
  like JoyFox. Many platforms forbid automated access. If JoyClub finds that you
  use JoyFox, it can restrict or close your account. The conversation actions
  click JoyClub's own buttons for you and carry the highest risk: "Delete" and
  "Mark as junk" move a conversation to JoyClub's trash with no setting, and
  Quick Ignore and Delete, which also ignores the member, is on by default.
- JoyFox stores information about other members (profile facts, your notes and
  tags) only in your browser. You are responsible for how you use and keep that
  information. For private use by one person, EU data protection law very likely
  does not apply (GDPR Article 2(2)(c)), but no lawyer has confirmed this.
- You use JoyFox at your own risk. It comes with no warranty (see `LICENSE`).

## License

JoyFox is free software under the GNU General Public License, version 3 or (at
your option) any later version (`GPL-3.0-or-later`). See `LICENSE`.
