"use strict";
(() => {
  // src/errors.ts
  var ExtensionError = class extends Error {
    constructor(code, message2, options) {
      super(message2, options);
      this.code = code;
      this.name = "ExtensionError";
      if (options?.display) this.display = options.display;
    }
    /**
     * What the UI shows, in the user's language. The English `message` stays
     * for logs; a panel never shows it (docs/i18n-spec.md, Section 3.10).
     */
    display;
  };

  // src/i18n/catalog/en.ts
  var en = {
    // Shared labels
    "placement.qualified": "Qualified",
    "placement.needs-review": "Needs Review",
    "placement.quarantined": "Junk",
    "condition.verified": "Verified by JoyClub",
    "condition.personallyKnown": "Personally known",
    "condition.minimumPhotos": "Minimum photos",
    "condition.minimumProfileWords": "Minimum profile words",
    "condition.minimumAccountAgeDays": "Minimum account age in days",
    "condition.notTemplateSpam": "Not flagged as template spam",
    "condition.minimumTrustScore": "Minimum local trust score",
    "condition.firstMessageContains": "First message contains",
    "field.accountAgeDays": "Account age in days",
    "field.photoCount": "Photo count",
    "field.profileWordCount": "Profile word count",
    "outcome.qualified": "Qualified",
    "outcome.partial-information": "Partial information",
    "outcome.does-not-meet-rule": "Does not meet rule",
    "common.close": "Close",
    "common.openOptions": "Open JoyFox options",
    "common.saveFailed": "JoyFox could not save that change. Nothing was changed. Try again. If it keeps failing, reload the page.",
    "legacy.text": (p) => p.text,
    // Shown in place of a damaged or unknown text reference, never its key.
    "common.textUnavailable": "(This text cannot be shown.)",
    // Triage reasons (qualification engine, contact rule, triage service)
    "triage.reason.unknownValue": (p) => `${p.field} is unknown, so it was not counted for or against.`,
    "triage.reason.atOrAbove": (p, f) => `${p.field} is ${f.number(p.value)}, at or above the required ${f.number(p.minimum)}.`,
    "triage.reason.belowMinimum": (p, f) => `${p.field} is ${f.number(p.value)}, below the required ${f.number(p.minimum)}.`,
    "triage.reason.accountAgeRangeAbove": (p, f) => `Account age is between ${f.number(p.min)} and ${f.number(p.max)} days, at or above the required ${f.number(p.minimum)}.`,
    "triage.reason.accountAgeRangeBelow": (p, f) => `Account age is between ${f.number(p.min)} and ${f.number(p.max)} days, below the required ${f.number(p.minimum)}.`,
    "triage.reason.accountAgeRangeCoarse": (p, f) => `Account age is between ${f.number(p.min)} and ${f.number(p.max)} days, which is too coarse to compare with the required ${f.number(p.minimum)}, so it was not counted for or against.`,
    "triage.reason.verificationUnknown": "Verification status is unknown, so it was not counted for or against.",
    "triage.reason.verified": "The profile is verified, as the rule requires.",
    "triage.reason.notVerified": "The profile is not verified, which the rule requires.",
    "triage.reason.personallyKnownUnknown": "Whether you know this member personally is unknown, so it was not counted for or against.",
    "triage.reason.personallyKnown": "You marked this member as personally known, as the rule requires.",
    "triage.reason.notPersonallyKnown": "You have not marked this member as personally known, which the rule requires.",
    "triage.reason.noCriteria": "No qualification criteria are configured, so every sender qualifies.",
    "triage.reason.spamFlagged": "A message from this sender looks like a copied template.",
    "triage.reason.spamNotFlagged": "No message from this sender looks like a copied template.",
    "triage.reason.spamOverridden": "You marked this sender as not spam.",
    "triage.reason.spamUnknown": "JoyFox has not checked this sender's messages for templates, so spam status is unknown.",
    "triage.reason.phraseSeenNow": (p) => `The latest message from this sender contains "${p.text}".`,
    "triage.reason.phraseSeenBefore": (p) => `An earlier message from this sender, seen in your inbox, contains "${p.text}".`,
    "triage.reason.phraseNotInLatest": (p) => `The latest message from this sender does not contain "${p.text}". The inbox shows only the latest message, so JoyFox cannot see if the first message contained it.`,
    "triage.reason.phraseNotSeen": (p) => `JoyFox has not seen a message from this sender that contains "${p.text}". Only the inbox shows messages to JoyFox.`,
    "triage.reason.trustUnknown": "You have logged nothing about this member, so the local trust score is unknown.",
    "triage.reason.trustAtOrAbove": (p, f) => `Your local trust score is ${f.number(p.score)}, at or above the required ${f.number(p.minimum)}.`,
    "triage.reason.trustBelow": (p, f) => `Your local trust score is ${f.number(p.score)}, below the required ${f.number(p.minimum)}.`,
    "triage.reason.negatedMet": (p) => `${p.reason} Your rule says "not ${p.condition}", so this counts as met.`,
    "triage.reason.negatedNotMet": (p) => `${p.reason} Your rule says "not ${p.condition}", so this counts as not met.`,
    "triage.reason.unknownNeedsReview": (p) => `${p.reason} Your rule sends unknown values to Needs Review.`,
    "triage.reason.unknownMet": (p) => `${p.reason} Your rule counts an unknown value as met.`,
    "triage.reason.unknownNotMet": (p) => `${p.reason} Your rule counts an unknown value as not met.`,
    "triage.reason.numbered": (p, f) => `Group ${f.number(p.number)}: ${p.reason}`,
    "triage.reason.userMoved": (p) => `You moved this sender to ${p.placement}.`,
    "triage.headline.noConditions": "Your contact rule has no required conditions, so every sender qualifies.",
    "triage.headline.meets": "This sender meets your contact rule.",
    "triage.headline.undecided": "JoyFox could not decide, because some information is unknown.",
    "triage.headline.doesNotMeet": (p) => `This sender does not meet your contact rule, so JoyFox places them in ${p.placement}.`,
    // Trust score
    "trust.reason.positive": (p, f) => `You logged ${f.plural(p.count, {
      one: "1 positive outcome",
      other: `${f.number(p.count)} positive outcomes`
    })}.`,
    "trust.reason.negative": (p, f) => `You logged ${f.plural(p.count, {
      one: "1 negative outcome",
      other: `${f.number(p.count)} negative outcomes`
    })}.`,
    "trust.reason.neutral": (p, f) => `You logged ${f.plural(p.count, {
      one: "1 neutral outcome",
      other: `${f.number(p.count)} neutral outcomes`
    })}, which count 0.`,
    "trust.reason.personallyKnown": "You marked this member as personally known.",
    "trust.reason.spamFlagged": "A message from this member looks like a copied template.",
    "trust.scopeNote": "Based only on what you logged and saw in this browser. It is not a JoyClub or community rating.",
    // Template spam detector
    "spam.detail.override": "You marked this sender as not spam, so their messages are never flagged.",
    "spam.detail.belowMinimum": (p, f) => `The message has ${f.plural(p.words, {
      one: "1 word",
      other: `${f.number(p.words)} words`
    })}, below the ${f.number(p.minimum)} needed before template matching runs.`,
    "spam.detail.duplicate": (p, f) => `This message closely matches an earlier message you received (${f.number(p.percent)}% similar).`,
    "spam.detail.knownPhrase": "The message contains a phrase from your known-template list.",
    "spam.detail.phraseSimilar": (p, f) => `The message closely matches a phrase from your known-template list (${f.number(p.percent)}% similar).`,
    "spam.detail.noMatch": "The message matched no earlier message and no known template phrase.",
    // Quick Ignore and Delete (M9): the report built from ActionLog steps
    "action.step.ignore": "Ignore",
    "action.step.delete": "Delete",
    "action.where.before": (p) => `before ${p.step}`,
    "action.where.during": (p) => `during ${p.step}`,
    "action.failure.control-missing": (p) => `JoyFox could not find JoyClub's ${p.step} option on this page.`,
    "action.failure.confirmation-missing": (p) => `JoyClub's confirmation for ${p.step} did not appear.`,
    "action.failure.not-verified": (p) => `JoyClub did not show that ${p.step} succeeded.`,
    "action.failure.unverifiable": (p) => `JoyFox cannot see JoyClub's result for ${p.step} on this page, so it stopped ${p.where}.`,
    "action.failure.member-mismatch": (p) => `The page showed another member, so JoyFox stopped ${p.where}.`,
    "action.failure.conversation-mismatch": (p) => `The page showed another conversation, so JoyFox stopped ${p.where}.`,
    "action.failure.identity-unavailable": (p) => `JoyFox could not confirm which member or conversation the page shows, so it stopped ${p.where}.`,
    "action.failure.account-changed": (p) => `The active JoyFox account changed, so JoyFox stopped ${p.where}.`,
    "action.failure.turned-off": (p) => `Ignore and Delete was turned off, so JoyFox stopped ${p.where}.`,
    "action.failure.superseded": (p) => `A newer JoyFox run for this member started, so JoyFox stopped ${p.where}.`,
    "action.failure.log-unavailable": (p) => `JoyFox could not write to its action log, so it stopped ${p.where}.`,
    "action.failure.handoff-failed": (p) => `JoyFox could not move on to the member's profile, so it stopped ${p.where}.`,
    "action.failure.timeout": (p) => `JoyClub did not respond in time during ${p.step}.`,
    "action.failure.step-error": (p) => `An unexpected error stopped JoyFox ${p.where}.`,
    "action.stepText.ignore.done": "Ignore: done. JoyClub ignores this member.",
    "action.stepText.ignore.not-done": "Ignore: not done.",
    "action.stepText.ignore.unknown": "Ignore: not confirmed. JoyFox started it but did not see JoyClub confirm it.",
    "action.stepText.delete.done": "Delete: done. JoyClub moved the conversation to the trash.",
    "action.stepText.delete.not-done": "Delete: not done.",
    "action.stepText.delete.unknown": "Delete: not confirmed. JoyFox started it but did not see JoyClub confirm it.",
    "action.next.ignore": "Next: open the member's profile and check whether they are ignored. If not, ignore them there yourself.",
    "action.next.delete": "Next: open the conversation and check whether it is in the trash. If not, move it there yourself with JoyClub's trash button.",
    "action.next.showList": "Delete works only while this conversation shows in the ClubMail list beside it. Widen the window, or scroll the list until the conversation shows, then try again.",
    "action.self.ignore": "You can do it yourself: open the member's profile and ignore them there.",
    "action.self.delete": "You can do it yourself: move the conversation to the trash with JoyClub's trash button.",
    "action.report.finished": "Ignore and Delete finished.",
    "action.report.undo": `To undo, restore the conversation from JoyClub's trash. Then open the member's profile and choose "Profil nicht mehr ignorieren" in its menu.`,
    "action.report.running": "Ignore and Delete is running.",
    "action.report.stopped": "Ignore and Delete stopped.",
    "action.report.interrupted": "Ignore and Delete was interrupted, for example because the tab closed.",
    "action.report.nothingChanged": "Nothing was changed on JoyClub.",
    "action.report.notUndone": "JoyFox did not undo anything.",
    "action.deleteReport.finished": "Delete finished.",
    "action.deleteReport.undo": "To undo, restore the conversation from JoyClub's trash.",
    "action.deleteReport.running": "Delete is running.",
    "action.deleteReport.stopped": "Delete stopped.",
    "action.deleteReport.interrupted": "Delete was interrupted, for example because the tab closed.",
    // Content script: the Delete and Ignore and Delete buttons and notice
    "quick.progress.Started": "Ignore and Delete is running. Checking the page.",
    "quick.delete.progress.Started": "Delete is running. Checking the page.",
    "quick.progress.DeleteRequested": "Moving the conversation to the trash.",
    "quick.progress.DeleteConfirmed": "Delete done. Opening the member's profile to ignore them there.",
    "quick.progress.IgnoreRequested": "Ignoring the member on JoyClub.",
    "quick.button": "Ignore and Delete",
    "quick.region": "JoyFox conversation actions",
    "quick.delete.button": "Delete",
    "quick.delete.scope": "One click moves this conversation to JoyClub's trash, then returns to the ClubMail list. The member is not ignored. JoyFox stops at the first problem and tells you what was done. It never sends a message.",
    "quick.scope": "Experimental. One click moves this conversation to JoyClub's trash, then opens the member's profile and ignores them there. JoyFox stops at the first problem and tells you what was done. It never sends a message.",
    "quick.needsList": "Works only while this conversation shows in the ClubMail list beside it. Widen the window, or scroll the list until the conversation shows.",
    "quick.noProfile": "JoyFox cannot find the link to this member's profile, where Ignore is, so it did nothing. You can do it yourself: move the conversation to the trash with JoyClub's trash button, then open the member's profile and ignore them there.",
    "quick.resumed": "Ignore and Delete, continued from the conversation:",
    "quick.waitingMenu": "Waiting for JoyClub's profile menu\u2026",
    "quick.previous": "Your last Ignore and Delete for this member:",
    "quick.previousOther": "Your last Ignore and Delete for this member, in another conversation:",
    "quick.otherResult": "Your last Ignore and Delete, for another conversation:",
    "quick.delete.previous": "Your last Delete for this member:",
    "quick.delete.previousOther": "Your last Delete for this member, in another conversation:",
    "quick.delete.otherResult": "Your last Delete, for another conversation:",
    "quick.otherRunning": "A JoyFox run is still going for another conversation. Wait until it ends.",
    "quick.busy": "Another JoyFox run for this member is still going, for example in another tab. Nothing was done here.",
    "quick.junk.done": "Mark as junk: the sender is in Junk, and a Negative outcome is logged.",
    "quick.junk.busy": "Another JoyFox run for this member is still going, so JoyFox did not start the trash step.",
    "quick.junk.notTrashed": "The conversation was not moved to the trash.",
    "quick.delete.unexpected": "Delete stopped because of an unexpected error. JoyFox may have moved the conversation to the trash: check JoyClub's trash yourself.",
    "quick.unexpected": "Ignore and Delete stopped because of an unexpected error. JoyFox may have completed a step: check the member's profile and the conversation yourself.",
    // Content script: triage explanation, member bar and trust controls
    "triage.outcome.met": "Met",
    "triage.outcome.not-met": "Not met",
    "triage.outcome.needs-review": "Needs Review",
    "triage.conditions.summary": (p, f) => `All checked conditions (${f.number(p.count)})`,
    "triage.condition.line": (p) => `${p.outcome}: ${p.condition}. `,
    "triage.condition.lineNegated": (p) => `${p.outcome}: not ${p.condition}. `,
    "triage.placementLine": (p) => `Placement: ${p.placement} (${p.source}).`,
    "triage.source.override": "your manual choice",
    "triage.source.rule": "your contact rule",
    "triage.source.sharedEvent": "the shared-event exception",
    "triage.sharedEvent.attending": (p) => `On the guest list of "${p.event}"${p.when ? ` (${p.when})` : ""}, which you marked Attending.`,
    "triage.sharedEvent.attended": (p) => `On the guest list of "${p.event}"${p.when ? ` (${p.when})` : ""}, which you marked Attended.`,
    "triage.sharedEvent.optOut": "Don't use the shared event for this sender",
    "triage.movedOn": (p) => `You moved this sender on ${p.date}. Your rule alone would place them in ${p.placement}.`,
    "triage.place.group": "Place this sender",
    "triage.useRule": "Use my rule again",
    "mark.group": "Mark this sender",
    "mark.qualified": "Mark qualified",
    "mark.junk": "Mark as junk",
    "mark.trustFailed": (p) => `JoyFox placed this sender in ${p.placement} but could not log the trust outcome, so it stopped there. You can log it on the member's conversation or profile page.`,
    "mark.junk.noTrash": "The sender is in Junk, and a Negative outcome is logged. JoyFox could not move this conversation to the trash here. Move it there yourself with JoyClub's trash button.",
    "triage.profileFact.minimumPhotos": "photo count",
    "triage.profileFact.minimumProfileWords": "profile word count",
    "triage.profileFact.minimumAccountAgeDays": "account age",
    "triage.unknownFacts.one": (p) => `The ${p.fact} is unknown. Open the profile and JoyFox reads it.`,
    "triage.unknownFacts.two": (p) => `The ${p.first} and ${p.second} are unknown. Open the profile and JoyFox reads them.`,
    "triage.unknownFacts.three": (p) => `The ${p.first}, ${p.second} and ${p.third} are unknown. Open the profile and JoyFox reads them.`,
    "trust.score.none": "Local trust score: no history yet.",
    "trust.score.value": (p, f) => `Local trust score: ${f.number(p.score)}.`,
    "trust.details.summary": "How the score adds up",
    "trust.contribution": (p, f) => `${p.points > 0 ? "+" : ""}${f.number(p.points)}: ${p.reason}`,
    "trust.log.group": "Log how it went with this member",
    "trust.log.positive": "Log positive",
    "trust.log.neutral": "Log neutral",
    "trust.log.negative": "Log negative",
    "trust.log.undo": "Undo last outcome",
    "bar.placementPrefix": "Placement: ",
    "bar.yourChoice": "(your choice)",
    "bar.sharedEvent": "(shared event)",
    "bar.openProfile": "Open profile",
    "bar.log": "Log:",
    "bar.positive": "Positive",
    "bar.neutral": "Neutral",
    "bar.negative": "Negative",
    "bar.undo": "Undo",
    "bar.details": "Details",
    "strip.collapse": "Collapse JoyFox",
    "strip.expand": "Expand JoyFox",
    "bar.scoreDetails": "Score details",
    "panel.ruleOff.no-rule": "No contact rule is set, so JoyFox does not place this sender.",
    "panel.ruleOff.rule-disabled": "Your contact rule is turned off, so JoyFox does not place this sender.",
    "panel.ruleOff.other": "JoyFox cannot place this sender right now. Reload the page to try again.",
    "panel.ruleOff.no-account": "No JoyFox account is active, so JoyFox shows nothing for this member.",
    // Content script: inbox triage
    "inbox.region": "JoyFox triage",
    "inbox.views": "Show messages",
    "inbox.view.default": "Inbox",
    "inbox.view.all": "Show all",
    "inbox.viewCount": (p, f) => `${p.view} (${f.number(p.count)})`,
    "inbox.about": "About these views",
    "inbox.aboutText": "Inbox hides Junk rows from this view only. Nothing is deleted, and JoyFox changes nothing on JoyClub.",
    "inbox.checking": "Checking",
    "inbox.badge": (p) => `JoyFox: ${p.text}. Details.`,
    "inbox.why": "Details",
    "inbox.whyNamed": (p) => `Details: ${p.name}`,
    "inbox.rowGone": "This row is no longer shown.",
    "inbox.unidentified": "JoyFox could not read this sender's profile number, so it could not check your rule. The row stays visible.",
    "inbox.stillChecking": "JoyFox is still checking this sender.",
    "inbox.setup.no-account": "JoyFox has no active account, so it does not sort this inbox.",
    "inbox.setup.no-rule": "No contact rule is saved, so JoyFox does not sort this inbox.",
    // Content script: notes and tags
    "notes.region": "JoyFox notes and tags",
    "notes.scope": "Private to JoyFox: stored only in this browser, under the active JoyFox account. JoyFox never sends it anywhere.",
    "notes.saved": "Note saved.",
    "notes.removed": "Note removed.",
    "notes.conflict": "This note changed in another tab or in the JoyFox data inspector, so JoyFox did not save your text. It is still in the box. Save again to replace the stored note, or discard your changes to see it.",
    "notes.refused": "The active JoyFox account changed, so nothing was stored. Text typed for the previous account was dropped.",
    "notes.emptyTag": "Type a tag first. Nothing was added.",
    "notes.emptyNote": "Type a note first. Nothing was saved.",
    "notes.tagAdded": "Tag added.",
    "notes.tagExists": "Already tagged.",
    "notes.tagRemoved": "Tag removed.",
    "notes.privateNote": "Private note",
    // Shown under a note box once the text is near its limit.
    "notes.length": (p, f) => `${f.number(p.count)} of ${f.number(p.maximum)} characters`,
    "notes.pasteCut": "Only part of the pasted text fit. The rest was not pasted.",
    "notes.discard": "Discard my changes",
    "notes.save": "Save note",
    "notes.tags": "Tags",
    "notes.noTags": "No tags yet.",
    "notes.remove": "Remove",
    "notes.removeTag": (p) => `Remove tag ${p.label}`,
    "notes.addTagLabel": "Add a tag",
    "notes.addTag": "Add tag",
    "notes.summary.none": "Your notes and tags (none yet)",
    "notes.summary.note": "Your notes and tags (a note)",
    "notes.summary.tags": (p, f) => `Your notes and tags (${f.plural(p.count, {
      one: "1 tag",
      other: `${f.number(p.count)} tags`
    })})`,
    "notes.summary.noteAndTags": (p, f) => `Your notes and tags (a note and ${f.plural(p.count, {
      one: "1 tag",
      other: `${f.number(p.count)} tags`
    })})`,
    // Content script: event and venue notes (V1-5)
    "listing.heading.event": "JoyFox: your notes on this event",
    "listing.heading.venue": "JoyFox: your notes on this venue",
    // The box's summary: what is stored, for example "Attending, 2 tags, a note".
    "listing.summary.event": (p) => `JoyFox: your notes on this event (${p.state})`,
    "listing.summary.venue": (p) => `JoyFox: your notes on this venue (${p.state})`,
    "listing.summary.none": "none yet",
    "listing.summary.note": "a note",
    "listing.loading": "Loading your notes\u2026",
    "listing.readFailed": "JoyFox could not read your notes on this page. Reload the page to try again.",
    "listing.noAccount": "Select or add an account in the JoyFox options to keep notes on events.",
    "listing.attendanceLabel": "Your attendance",
    "listing.attendance.unknown": "No status",
    "listing.attendance.interested": "Interested",
    "listing.attendance.attending": "Attending",
    "listing.attendance.not-attending": "Not attending",
    "listing.attendance.attended": "Attended",
    "listing.noteLabel": "Your note",
    "listing.saveNote": "Save note",
    "listing.tagsLabel": "Your tags",
    "listing.tagLabel": "New tag",
    "listing.addTag": "Add tag",
    "listing.removeTag": (p) => `Remove tag ${p.tag}`,
    "listing.emptyTag": "Type a tag first. Nothing was added.",
    "listing.tooManyTags.event": (p, f) => `You can add at most ${f.number(p.maximum)} tags to an event. Remove one first.`,
    "listing.tooManyTags.venue": (p, f) => `You can add at most ${f.number(p.maximum)} tags to a venue. Remove one first.`,
    "listing.privacy": "Private: stored only in this browser. JoyClub sees nothing, and your sign-up on JoyClub does not change.",
    "listing.saved": "Saved.",
    // The first save of an event or venue.
    "listing.tracked.event": "Saved. JoyFox now tracks this event.",
    "listing.tracked.venue": "Saved. JoyFox now tracks this venue.",
    "listing.removed.event": "No note, tag or attendance is left, so JoyFox no longer tracks this event.",
    "listing.removed.venue": "No note or tag is left, so JoyFox no longer tracks this venue.",
    "listing.conflict": "These notes changed in another tab, so JoyFox did not save. The stored notes are shown now; your typed note is still in the box.",
    "listing.refused": "The active JoyFox account changed, so nothing was saved.",
    // Options page: personal event calendar (V1-5)
    "events.heading": "Your events",
    "events.hint": "Every event and venue you added a note, tag or attendance to on JoyClub, in date order. JoyFox keeps them after JoyClub removes an event. To change one, open it on JoyClub.",
    "events.readFailed": "JoyFox could not read your events. Reload the page to try again.",
    "events.noAccount": "Select or add an account first. Each account has its own events.",
    "events.empty": "No tracked events yet. Open an event on JoyClub and add a note, a tag or your attendance.",
    "events.count": (p, f) => `${f.number(p.shown)} of ${f.number(p.total)} tracked events shown.`,
    "events.filterLabel": "Show",
    "events.filter.all": "All tracked events",
    "events.searchLabel": "Search my notes, tags and titles",
    "events.noDate": "No date",
    "events.untitled": (p) => `Event ${p.id}`,
    "events.past": (p) => `${p.when} (past)`,
    "events.venue": (p) => `Venue: ${p.venue}`,
    "events.venuesHeading": "Your venues",
    "events.guests": (p, f) => f.plural(p.count, {
      one: "1 guest stored",
      other: `${f.number(p.count)} guests stored`
    }),
    "events.exception.label": "Shared-event exception: place a sender in Qualified when they are on the guest list of an event I marked Attending or Attended",
    "events.exception.hint": `Off by default. JoyFox stores a tracked event's guest list when you open the event page, as far as JoyClub has loaded it, and deletes it when you stop tracking the event. A sender you marked yourself keeps your choice, and the "Details" panel can turn the exception off for one sender.`,
    "events.exception.saved": "Saved.",
    "events.exception.saveFailed": "JoyFox could not save this setting. Try again.",
    // Options page: the switch for the experimental Ignore and Delete (M9)
    "quickSetting.heading": "Ignore and Delete",
    "quickSetting.label": 'Show the "Ignore and Delete" button on ClubMail conversations',
    "quickSetting.hint": `Experimental and on by default. One click moves the conversation to JoyClub's trash, opens the member's profile in the same tab and ignores the member there. It works only while the ClubMail list shows beside the conversation. JoyFox acts only when you click. The "Action log" in "Your data" records every step. This setting controls only "Ignore and Delete": the "Delete" button and "Mark as junk" move a conversation to JoyClub's trash also when it is off.`,
    "quickSetting.risk": "If JoyClub finds a tool that clicks for you, it can restrict or close your account. Of all JoyFox features, this one has the highest risk.",
    "quickSetting.undo": `To undo, restore the conversation from JoyClub's trash. Then open the member's profile and choose "Profil nicht mehr ignorieren" in its menu.`,
    "quickSetting.saved": "Saved. Open ClubMail tabs follow at once.",
    "quickSetting.saveFailed": "JoyFox could not save this setting. Try again.",
    "sharedEvents.heading": "Shared events",
    "sharedEvents.intro": "This member is on the stored guest list of these events you track:",
    // Content script: event list filter (V1-5)
    "eventFilter.label": "JoyFox: show",
    "eventFilter.all": "All loaded events and dates",
    "eventFilter.tracked": "Only events JoyFox tracks",
    "eventFilter.note": "Only events with your note",
    "eventFilter.attending": "Only events you attend",
    "eventFilter.interested": "Only events you are interested in",
    "eventFilter.tag": (p) => `Only events with your tag: ${p.tag}`,
    "eventFilter.count": (p, f) => `${f.number(p.shown)} of ${f.number(p.loaded)} loaded events shown. Events loaded later are checked too.`,
    "eventFilter.readFailed": "JoyFox could not read your event notes. Reload the page to try again.",
    "eventFilter.noAccount": "Select or add an account in the JoyFox options to filter by your notes.",
    "eventFilter.badge": "JoyFox",
    "eventFilter.hasNote": "note",
    // Content script: profile type filter on the "My JOY" lists (V1-14)
    "typeFilter.legend": "Profile type",
    "typeFilter.man": "Man",
    "typeFilter.woman": "Woman",
    "typeFilter.couple": "Couple",
    "typeFilter.unknown": "Unknown",
    "typeFilter.count": (p, f) => `Showing ${f.number(p.shown)} of ${f.number(p.loaded)} loaded`,
    "typeFilter.unknownHidden": (p, f) => `${f.number(p.count)} with unknown type hidden`,
    "typeFilter.scrollHint": "Scroll down to load more.",
    "typeFilter.unknownMark": "Type unknown",
    // Options page: message search (V1-4)
    "messages.heading": "Message search",
    "messages.hint": "JoyFox stores the ClubMail messages you open, sent and received, so you can search them here. It stores only what a conversation shows on screen and never loads older messages. The text stays in this browser, and an export file holds it too. If you allow JoyFox in private windows, it stores the messages you open there in the same way.",
    "messages.caching": "Store the messages I open in ClubMail",
    "messages.cachingOn": "Message storing is on.",
    "messages.cachingOff": 'Message storing is off. Messages stored before stay until they are older than the time set here, or until you delete them under "Your data".',
    "messages.offHint": "Storing is off: JoyFox stores no new messages. Search still covers the messages stored before.",
    "messages.retentionLabel": "Keep messages for (months)",
    "messages.retentionSave": "Save",
    "messages.retentionHint": (p, f) => `Messages older than this are deleted automatically. Lowering the number deletes older messages at once. The default is ${f.number(p.default)}. Click "Save" to apply.`,
    // Save asks for a second click when the number goes down, as deletes do.
    "messages.retentionConfirm": "Save and delete",
    "messages.retentionConfirmPrompt": (p, f) => `Lowering the number deletes the stored messages older than ${f.plural(
      p.months,
      { one: "1 month", other: `${f.number(p.months)} months` }
    )} at once. Click "Save and delete" to confirm.`,
    "messages.retentionSaved": (p, f) => p.deleted === 0 ? "Saved. No older message needed deleting." : `Saved. ${f.plural(p.deleted, {
      one: "1 older message was",
      other: `${f.number(p.deleted)} older messages were`
    })} deleted.`,
    "messages.retentionInvalid": (p, f) => `Enter a whole number from ${f.number(p.minimum)} to ${f.number(p.maximum)}. Nothing was changed.`,
    "messages.noAccount": "Select or add an account first.",
    "messages.readFailed": "JoyFox could not read your stored messages. Reload the page to try again.",
    "messages.searchLabel": "Search my messages",
    "messages.count": (p, f) => p.count === 0 ? "No stored message contains this." : `${f.plural(p.count, {
      one: "1 message",
      other: `${f.number(p.count)} messages`
    })} found.`,
    "messages.countLimited": (p, f) => `${f.number(p.count)} messages found. The newest ${f.number(p.shown)} are shown.`,
    // `member` is the member's nickname, or `member.number` when JoyFox has
    // never seen it.
    "messages.sentTo": (p) => `You to ${p.member} \xB7 ${p.when}`,
    "messages.receivedFrom": (p) => `${p.member} to you \xB7 ${p.when}`,
    "messages.storedAt": (p) => `stored ${p.when}`,
    // Content script: profile signals on cards (V1-10)
    "signals.state.complete": "Complete",
    "signals.state.incomplete": "Incomplete",
    "signals.state.unknown": "Completeness unknown",
    // The inbox row's compact line: the full text is in the tooltip.
    "signals.state.unknownShort": "Unknown",
    "signals.photos": (p, f) => f.plural(p.count, {
      one: "1 photo",
      other: `${f.number(p.count)} photos`
    }),
    "signals.photosUnknown": "photos unknown",
    "signals.words": (p, f) => f.plural(p.count, {
      one: "1 word",
      other: `${f.number(p.count)} words`
    }),
    "signals.wordsUnknown": "words unknown",
    "signals.verified": "verified",
    "signals.notVerified": "not verified",
    "signals.verificationUnknown": "verification unknown",
    "signals.heading": "Profile completeness",
    "signals.trust": (p, f) => `Trust ${p.score > 0 ? "+" : ""}${f.number(p.score)}`,
    "signals.trustNoneShort": "Trust \u2013",
    "signals.noteAdd": "Add note",
    "signals.noteEdit": "Note",
    "signals.tagsLabel": "Your tags",
    "signals.tagCount": (p, f) => f.plural(p.count, {
      one: "1 tag",
      other: `${f.number(p.count)} tags`
    }),
    "signals.editor.label": (p) => `JoyFox: note and tags for ${p.member}`,
    // A member whose nickname JoyFox has never seen.
    "member.number": (p) => `Member ${p.id}`,
    "signals.editor.loading": "Loading\u2026",
    "signals.editor.close": "Close",
    "signals.editor.noAccount": "Select or add an account in the JoyFox options to keep notes.",
    "signals.editor.readFailed": "JoyFox could not read this member's notes. Close and try again.",
    "signals.filter.label": "JoyFox: hide incomplete profiles",
    "signals.filter.count": (p, f) => `${f.number(p.hidden)} of ${f.number(p.loaded)} loaded profiles hidden. Profiles JoyFox knows nothing about stay visible.`,
    // Content script: compatibility overlay (V1-2)
    "compat.heading": "Shared preferences",
    "compat.shared": (p, f) => `You share ${f.plural(p.count, {
      one: "1 preference",
      other: `${f.number(p.count)} preferences`
    })} with this member:`,
    "compat.none": "You share no preferences with this member.",
    "compat.listToggle": "Show the shared preferences",
    "compat.own": (p, f) => `This is your profile. JoyFox compares other profiles with your ${f.plural(
      p.count,
      {
        one: "1 positive preference",
        other: `${f.number(p.count)} positive preferences`
      }
    )}.`,
    "compat.ownUnknown": "Open your own JoyClub profile once, so JoyFox knows your preferences.",
    "compat.unreadable": "JoyFox could not read this profile's preferences yet.",
    "compat.missing": "This profile shows no preferences to compare.",
    "compat.readFailed": "JoyFox could not load your preferences. Reload the page to try again.",
    "compat.noAccount": "Select or add an account in the JoyFox options to compare preferences.",
    "compat.badge": (p, f) => `${f.number(p.count)} shared`,
    "compat.badgeLabel": (p, f) => `JoyFox: ${f.plural(p.count, {
      one: "1 shared preference",
      other: `${f.number(p.count)} shared preferences`
    })}`,
    "compat.sort.button": "Sort by shared preferences",
    "compat.sort.on": "Sorted by shared preferences. Members whose profile you have not opened come last.",
    "compat.sort.unavailable": "JoyFox cannot sort the results as JoyClub shows them now. Their order has not changed.",
    // Content script: saved searches (V1-3)
    "searches.heading": "JoyFox saved searches",
    "searches.loading": "Loading saved searches\u2026",
    "searches.readFailed": "JoyFox could not read your saved searches. Reload the page to try again.",
    "searches.empty": "No saved searches yet.",
    "searches.noAccount": "Select or add an account in the JoyFox options to save searches.",
    "searches.save": "Save this search",
    "searches.nameLabel": "Name for this search",
    "searches.confirmSave": "Save",
    "searches.cancel": "Cancel",
    "searches.noName": "Type a name first. Nothing was saved.",
    "searches.nameTooLong": (p, f) => `A name can have at most ${f.number(p.maximum)} characters. Nothing was saved.`,
    "searches.notSearchAddress": "This page's address is not a search JoyFox can save. Nothing was saved.",
    "searches.full": (p, f) => `You have ${f.number(p.maximum)} saved searches, the most JoyFox keeps. Delete one first.`,
    "searches.refused": "The active JoyFox account changed, so nothing was changed.",
    "searches.saved": (p) => `Saved "${p.name}".`,
    "searches.noMatch": (p) => `"${p.name}" no longer matches JoyClub's search address, so JoyFox did not open it. Run the search again and save it again.`,
    "searches.running": (p) => `Running "${p.name}"\u2026`,
    "searches.runningUnnamed": "Running the saved search\u2026",
    "searches.shown": (p) => `Showing "${p.name}".`,
    "searches.shownUnnamed": "Showing the saved search.",
    "searches.runFailed": `JoyFox could not run the saved search. Open JoyClub's filter and click "Anwenden".`,
    "searches.deleteLabel": (p) => `Delete saved search ${p.name}`,
    "searches.confirmDelete": (p) => `Click \u2715 again to delete "${p.name}".`,
    "searches.deleted": (p) => `Deleted "${p.name}".`,
    // Content script: template picker
    "picker.toggle": "JoyFox templates",
    "picker.loading": "Loading templates\u2026",
    "picker.readFailed": 'JoyFox could not load your templates. Nothing was inserted. Click "JoyFox templates" again to try again.',
    "picker.empty": "No templates yet. Add them on the JoyFox options page.",
    "picker.noAccount": "No JoyFox account is active. Choose one on the JoyFox options page.",
    "picker.result.inserted": "Template inserted. Check the text, then click JoyClub's Send button yourself.",
    "picker.result.not-editable": "The message field cannot be edited right now. Nothing was inserted. Wait until you can type in the message field, then try again.",
    "picker.result.too-long": (p, f) => `With the template, the message would be ${f.plural(p.over, {
      one: "1 character",
      other: `${f.number(p.over)} characters`
    })} too long. The message field takes at most ${f.number(p.limit)} characters. Nothing was inserted. Shorten your text or the template.`,
    "picker.result.altered": "JoyClub changed the text after insertion. Check the message field before you send.",
    "templates.folder.general": "General",
    "templates.folder.eventConfirmation": "Event confirmation",
    "templates.folder.eventCancellation": "Event cancellation",
    // Options page: shell and tabs
    "options.title": "JoyFox options",
    "options.intro": "JoyFox stores everything locally in this browser profile. Inbox sorting stays off until you save a contact rule.",
    "options.tabs.start": "Get started",
    "options.tabs.accounts": "Accounts",
    "options.tabs.rule": "Contact rule",
    "options.tabs.templates": "Templates",
    "options.tabs.events": "Events",
    "options.tabs.messages": "Messages",
    "options.tabs.data": "Your data",
    "options.importRegion": "Import JoyFox data",
    "options.languageSaveFailed": "JoyFox could not save the language. Try again.",
    // Options page: Get started
    "start.state.done": "Done",
    "start.state.off": "Saved, but turned off",
    "start.state.todo": "Not done yet",
    "start.state.doneOpen": "Done: no conditions, so every sender qualifies",
    "start.ready": "JoyFox is set up. Open your JoyClub inbox to see it sorted.",
    "start.intro": "Three steps, a few minutes. Everything stays in this browser.",
    "start.introAccess": "Four steps, a few minutes. Everything stays in this browser.",
    "start.readFailed": "JoyFox could not read its setup. Reload the page to try again.",
    "start.step.access": "Allow JoyFox to access joyclub.de. Access is off now, so JoyFox cannot work on JoyClub.",
    "start.step.account": "Add your JoyClub account under [Accounts](#accounts). JoyFox makes the first one active.",
    "start.step.chooseAccount": "Choose the active account under [Accounts](#accounts).",
    "start.step.rule": "Save a contact rule under [Contact rule](#rule). Inbox sorting stays off until a rule is saved and turned on.",
    "start.step.inbox": "Open your JoyClub inbox (www.joyclub.de, ClubMail). JoyFox adds its tabs above the list.",
    // Options page: site access (Get started)
    "access.allow": "Allow access to joyclub.de",
    "access.granted": "Access to joyclub.de is on. Reload any JoyClub tab that is open, so JoyFox can work there.",
    "access.refused": "Access to joyclub.de is still off. JoyFox cannot work on JoyClub until you allow access here or in about:addons.",
    // Options page: accounts
    "accounts.readFailed": "JoyFox could not read its stored accounts. No account was changed. Reload the page to try again.",
    "accounts.hint": "JoyFox cannot read which JoyClub login a tab uses. The active account is the one selected here. JoyFox stores your notes, tags, rules, templates and other data under it.",
    "accounts.activeLabel": "Active account:",
    "accounts.noneSelected": "None selected",
    "accounts.empty": "No accounts yet. Add one below to use JoyFox.",
    "accounts.list": "Stored accounts",
    // An account's label with its JoyClub identifier, so two accounts with
    // similar labels can be told apart.
    "accounts.nameWithIdentifier": (p) => `${p.label} (${p.identifier})`,
    "accounts.active": "Active",
    "accounts.inactive": "Not active",
    "accounts.use": "Use this account",
    "accounts.useLabel": (p) => `Use this account: ${p.name}`,
    "accounts.nowActive": (p) => `Active account is now ${p.name}.`,
    "accounts.rename": "Rename",
    "accounts.renameLabel": (p) => `Rename account ${p.name}`,
    "accounts.renameField": (p) => `New display label for ${p.identifier}`,
    "accounts.renameSave": "Save",
    "accounts.renameCancel": "Cancel",
    "accounts.renamed": (p) => `Label saved. JoyFox now shows this account as ${p.name}.`,
    "accounts.remove": "Remove",
    "accounts.confirmRemove": "Confirm removal",
    "accounts.removeLabel": (p) => `Remove account ${p.name}`,
    "accounts.confirmRemoveLabel": (p) => `Confirm removal of account ${p.name} and all of its data`,
    "accounts.removePrompt": (p) => `Removing ${p.name} deletes everything JoyFox stored for this account, for example notes, tags, rules, templates, messages, event notes and saved searches. Click again to confirm.`,
    "accounts.removed": (p) => `Removed ${p.name} and its stored data.`,
    "accounts.removedNoneActive": (p) => `Removed ${p.name} and its stored data. No account is active now. Choose one with "Use this account".`,
    "accounts.removedNoneLeft": (p) => `Removed ${p.name} and its stored data. No accounts are left. Add one to use JoyFox.`,
    "accounts.addForm": "Add an account",
    "accounts.identifier": "JoyClub account identifier",
    "accounts.identifierHint": "Your JoyClub nickname works well. JoyFox uses it only to tell your accounts apart and to match imports. JoyFox does not check it. You cannot change it later.",
    "accounts.label": "Display label (optional)",
    "accounts.labelHint": "Only JoyFox shows this label. If you leave it empty, JoyFox shows the identifier.",
    "accounts.add": "Add account",
    "accounts.added": (p) => `Added ${p.name}.`,
    // Options page: contact rule
    "rule.readFailed": "JoyFox could not read the contact rule. No rule was changed. Reload the page to try again.",
    "rule.hint": "The rule only changes how JoyFox groups your own inbox into Qualified, Needs Review and Junk. It never stops a message, never deletes anything, and the sender sees nothing.",
    "rule.noAccount": "Select or add an account first. Each account has its own rule.",
    "rule.newer": "This rule was made in a newer version of JoyFox and cannot be edited here. Delete it to start a new one.",
    "rule.note.saved": "A rule is saved for the active account.",
    "rule.note.none": "No rule is saved for the active account, so JoyFox does not sort the inbox.",
    "rule.enabled": "Sort my JoyClub inbox with this rule",
    "rule.placementLabel": "A sender who does not meet the rule goes to",
    "rule.spamHint": 'Spam status is unknown for now: JoyFox does not check messages for templates yet. Only your own "not spam" corrections count. The inbox shows only the verification shield; photos, profile words and account age come from profiles you opened before.',
    "rule.autosaveHint": "Changes are saved automatically: a box or choice at once, a number or text when you leave its field.",
    "rule.firstMessageHint": '"First message contains" reads the message preview in your inbox, ignoring upper and lower case. The inbox shows only the latest message, so when a sender sent more than one, the preview may not be the first. If the preview does not contain your text, the condition counts as your "If JoyFox cannot see this" choice. Once JoyFox sees your text, it stays met.',
    "rule.preset.label": "Start from a preset",
    "rule.preset.choose": "Choose a preset\u2026",
    "rule.preset.apply": "Apply preset",
    "rule.preset.confirm": "Replace conditions",
    "rule.preset.confirmPrompt": 'The preset replaces every condition below. Click "Replace conditions" to confirm.',
    "rule.preset.hint": "A preset fills in the conditions below and saves them. You can then change them like any other rule.",
    "rule.preset.open": "Open",
    "rule.preset.complete": "Complete profiles only",
    "rule.preset.verified": "Verified members",
    "rule.preset.highTrust": "High-trust members",
    "rule.preset.custom": "Custom",
    "rule.preset.describe.open": "No conditions: every sender qualifies.",
    "rule.preset.describe.complete": (p, f) => `A sender needs at least ${f.number(p.photos)} photos and at least ${f.number(p.words)} words of profile text.`,
    "rule.preset.describe.verified": "A sender needs to be verified by JoyClub.",
    "rule.preset.describe.highTrust": (p, f) => `A sender needs to be verified by JoyClub, with at least ${f.number(p.photos)} photos, at least ${f.number(p.words)} words of profile text and an account at least ${f.number(p.days)} days old.`,
    "rule.preset.describe.custom": "Clears all conditions, so you can tick the ones you want.",
    "rule.preset.applied": (p) => `Preset "${p.preset}" applied and saved. You can change its conditions below.`,
    "rule.preset.appliedOpen": 'Preset "Open" applied and saved. The rule has no conditions, so every sender qualifies.',
    "rule.preset.appliedCustom": "All conditions cleared and saved. Tick the conditions you want. Until you do, every sender qualifies.",
    "rule.editor": "Editor:",
    "rule.simple": "Simple",
    "rule.advanced": "Advanced",
    "rule.match.all": "ALL",
    "rule.match.any": "ANY",
    "rule.box.all": "A sender qualifies when ALL of these are met",
    "rule.box.any": "Or a sender qualifies when ANY of these is met",
    "rule.unknown.needs-review": "Send to Needs Review",
    "rule.unknown.met": "Count as met",
    "rule.unknown.not-met": "Count as not met",
    "rule.unknownPrompt": "If JoyFox cannot see this:",
    "rule.unknownLabel": (p) => `${p.condition}: if JoyFox cannot see this`,
    "rule.valueLabel": (p) => `${p.condition} value`,
    "rule.numberProblem": (p, f) => `Enter a whole number from ${f.number(p.minimum)} to ${f.number(p.maximum)} for "${p.condition}".`,
    "rule.textPlaceholder": "Word, phrase or emoji",
    "rule.textLabel": (p) => `${p.condition}: word, phrase or emoji`,
    "rule.textProblem": (p, f) => `Enter a word, phrase or emoji of up to ${f.number(p.maximum)} characters for "${p.condition}".`,
    "rule.fieldNumberProblem": (p, f) => `Enter a whole number from ${f.number(p.minimum)} to ${f.number(p.maximum)}.`,
    "rule.fieldTextProblem": (p, f) => `Enter a word, phrase or emoji of up to ${f.number(p.maximum)} characters.`,
    "rule.textHint": "Type a word, phrase or emoji to use this condition.",
    "rule.spamNote": "(not checked yet: always unknown)",
    "rule.combine.label": "How the groups combine",
    "rule.combine.prefix": "A sender is qualified if ",
    "rule.combine.suffix": " of these groups match.",
    "rule.advancedHint": 'Each group is met when ALL or ANY of its conditions are met, as you choose. Tick "not" to turn a condition around: "not Minimum photos 3" means fewer than 3 photos. A group without conditions is not saved.',
    "rule.addRule": "+ Add group",
    "rule.removeRule": "Remove group",
    "rule.confirmRemoveGroup": "Confirm removal",
    "rule.confirmRemoveGroupLabel": (p, f) => `Confirm removal of group ${f.number(p.number)}`,
    "rule.removeGroupPrompt": (p, f) => `Click again to remove group ${f.number(p.number)} and its conditions.`,
    "rule.ruleSuffix": " of these are met",
    "rule.noConditions": "No conditions yet. Add one below.",
    "rule.removeCondition": "Remove condition",
    "rule.removeConditionLabel": (p) => `Remove ${p.condition}`,
    "rule.not": "not",
    "rule.notTitle": "Turn this condition around",
    "rule.notLabel": (p) => `not: turn "${p.condition}" around`,
    "rule.joiner.all": "AND",
    "rule.joiner.any": "OR",
    "rule.ruleTitle": (p, f) => `Group ${f.number(p.number)}: met if `,
    "rule.ruleMatchLabel": (p, f) => `How group ${f.number(p.number)} combines its conditions`,
    "rule.removeRuleLabel": (p, f) => `Remove group ${f.number(p.number)}`,
    "rule.addConditionLabel": (p, f) => `Add a condition to group ${f.number(p.number)}`,
    "rule.addCondition": "+ Add condition\u2026",
    "rule.ruleCount": (p, f) => `${f.number(p.count)} of ${f.number(p.maximum)} groups`,
    "rule.simpleUnavailable.all": "Simple view is not available: the groups combine with ALL.",
    "rule.simpleUnavailable.not": 'Simple view is not available: the rule uses "not".',
    "rule.simpleUnavailable.severalAll": "Simple view is not available: more than one group needs ALL of several conditions.",
    "rule.simpleUnavailable.duplicate": "Simple view is not available: a condition appears in more than one group.",
    "rule.savedNoConditions": "Rule saved. It has no conditions yet, so every sender qualifies.",
    "rule.savedVacuous": "Rule saved. With nothing in the ALL box, every sender qualifies, so the ANY box has no effect.",
    "rule.saved": "Rule saved. Open JoyClub tabs update at once.",
    "rule.notSaved": (p) => `${p.problem} The rule was not saved.`,
    "rule.saveFailed": "JoyFox could not save the rule. Nothing was changed. Change the field again, or reload the page to see the saved rule.",
    "rule.deleteAll": "Delete whole contact rule",
    "rule.confirmDeleteAll": "Confirm delete",
    "rule.deletePrompt": "Click again to delete the whole contact rule. JoyFox then stops sorting the inbox for this account.",
    "rule.removed": "Contact rule deleted. JoyFox no longer sorts the inbox for this account.",
    "rule.removeFailed": "JoyFox could not delete the rule. Nothing was changed. Try again. If it keeps failing, reload the page.",
    "rule.stale.account.saved": "The active account changed, so the rule was not saved. Check the active account on the Accounts tab before you change the rule again.",
    "rule.stale.account.removed": "The active account changed, so the rule was not deleted. Check the active account on the Accounts tab before you delete a rule again.",
    "rule.stale.rule.saved": "The rule was changed in another tab. It was not saved. The form now shows the saved rule.",
    "rule.stale.rule.removed": "The rule was changed in another tab. It was not deleted. The form now shows the saved rule.",
    "rule.changedElsewhere": "The rule was changed in another tab. The form now shows the saved rule.",
    // Options page: templates
    "templates.readFailed": "JoyFox could not read your templates. No template was changed. Reload the page to try again.",
    "templates.heading": "Message templates",
    "templates.hint": `On a JoyClub conversation, the "JoyFox templates" button below the message field inserts a template at the cursor. You can still edit the text, and you always click JoyClub's Send button yourself. JoyFox never sends a message.`,
    // `[Accounts](#accounts)` is drawn as a link to the Accounts tab.
    "templates.noAccount": "Choose an active account on the [Accounts](#accounts) tab to store templates.",
    "templates.empty": "No templates yet. Add one below.",
    "templates.inFolder": (p) => `Templates in ${p.folder}`,
    "templates.edit": "Edit",
    "templates.editLabel": (p) => `Edit template ${p.name}`,
    "templates.editing": (p) => `Editing ${p.name}.`,
    "templates.delete": "Delete",
    "templates.confirmDelete": "Confirm delete",
    "templates.deleteLabel": (p) => `Delete template ${p.name}`,
    "templates.confirmDeleteLabel": (p) => `Confirm delete: template ${p.name}`,
    "templates.deletePrompt": (p) => `Click "Confirm delete" to delete ${p.name}.`,
    "templates.deleted": (p) => `Deleted ${p.name}.`,
    "templates.addForm": "Add a template",
    "templates.name": "Name",
    "templates.folder": "Folder (optional, General if empty)",
    "templates.text": "Text",
    "templates.saveChanges": "Save changes",
    "templates.add": "Add template",
    "templates.cancel": "Cancel editing",
    "templates.saved": (p) => `Saved ${p.name}.`,
    "templates.added": (p) => `Added ${p.name}.`,
    "templates.accountChanged": "The active account changed, so nothing was changed. Check the active account on the Accounts tab before you try again.",
    // Options page: your data
    "entity.extensionAccounts": "Account record",
    "entity.joyClubMembers": "Members",
    "entity.profileSnapshots": "Profile snapshots",
    "entity.userNotes": "Notes",
    "entity.userTags": "Tags",
    "entity.trustSignals": "Trust outcomes",
    "entity.contactRules": "Contact rules",
    "entity.conversationClassifications": "Manual placements",
    "entity.savedSearches": "Saved searches",
    "entity.eventMetadata": "Event notes",
    "entity.spendLogEntries": "Spending log",
    "entity.syncConfigs": "Sync settings",
    "entity.extensionPreferences": "Preferences",
    "entity.messageTemplates": "Message templates",
    "entity.spamPhrases": "Spam phrases",
    "entity.messageObservations": "Cached message text (normalized)",
    "entity.senderSpamOverrides": "Not-spam corrections",
    "entity.actionLogs": "Action log",
    "entity.messagePhraseMatches": "Message phrase matches",
    "entity.cachedMessages": "Stored messages (for search)",
    "data.readFailed": "JoyFox could not read its stored data. Nothing was changed. Reload the page to try again.",
    "data.hint": "Everything JoyFox stores stays in this browser profile. You can inspect it, save it as a JSON file and delete it here. Deleting here never changes anything on JoyClub.",
    // Import is on the Accounts tab (owner decision); this line points there.
    "data.importPointer": "To import a file, go to [Accounts](#accounts).",
    "data.noAccounts": "No accounts yet.",
    "data.accountPicker": "Account to inspect (does not change the active account)",
    "data.caption": "Stored records for this account",
    "data.col.type": "Data type",
    "data.col.records": "Records",
    "data.col.actions": "Actions",
    "data.show": "Show",
    "data.hide": "Hide",
    "data.showLabel": (p) => `Show ${p.label}`,
    "data.hideLabel": (p) => `Hide ${p.label}`,
    "data.deleteAll": "Delete all",
    "data.deleteAllLabel": (p) => `Delete all ${p.label}`,
    "data.deleteAllPrompt": (p, f) => `Click "Confirm" to delete all ${f.number(p.count)} ${p.label} records of this account.`,
    "data.deletedAll": (p) => `Deleted all ${p.label} of this account.`,
    "data.recordsTitle": (p, f) => `${p.label} (${f.number(p.count)})`,
    "data.accountRecordHint": "The account record is removed only with the whole account, on the [Accounts](#accounts) tab.",
    "data.recordSummary": (p) => `${p.id} (updated ${p.updated})`,
    // A record with a name a person knows: a member's nickname, a template's
    // or saved search's name, an event's title or an account's label.
    "data.recordSummaryNamed": (p) => `${p.name}: ${p.id} (updated ${p.updated})`,
    // A record with a name a person reads, in delete labels and messages.
    "data.recordNamed": (p) => `${p.name} (${p.id})`,
    "data.valueYes": "yes",
    "data.valueNo": "no",
    "data.valueEmpty": "(empty)",
    "data.rawJson": "Stored JSON",
    "data.moreCharacters": (p, f) => `\u2026and ${f.number(p.count)} more characters (see "Stored JSON")`,
    "data.moreValues": (p, f) => `\u2026and ${f.number(p.count)} more (see "Stored JSON")`,
    "data.delete": "Delete",
    "data.deleteRecordLabel": (p) => `Delete record ${p.record}`,
    "data.deleteRecordPrompt": (p) => `Click "Confirm" to delete record ${p.record}.`,
    "data.deletedRecord": (p) => `Deleted record ${p.record}.`,
    "data.showMore": (p, f) => `Show ${f.number(p.count)} more`,
    "data.exportAccount": "Export this account (JSON)",
    "data.exportedAccount": "Export of this account created.",
    "data.deleteAccountData": "Delete this account's data",
    "data.deleteAccountDataLabel": "Delete this account's data (every record)",
    "data.deleteAccountDataPrompt": 'Click "Confirm" to delete every record of this account. The account itself stays in Accounts.',
    "data.deletedAccountData": "Deleted all data of this account. The account itself is kept.",
    "data.allAccounts": "All accounts",
    "data.retentionLabel": "Profile snapshots kept per member",
    "data.retentionHint": (p, f) => `JoyFox keeps the newest snapshots of each member's profile facts, always at least the latest one. Lowering the number deletes older snapshots at once, in every account. From ${f.number(p.minimum)} to ${f.number(p.maximum)}; the default is ${f.number(p.default)}. Click "Save" to apply.`,
    "data.retentionSave": "Save",
    "data.retentionConfirm": "Save and delete",
    "data.retentionConfirmPrompt": (p, f) => `Lowering the number deletes older snapshots at once, in every account: each member keeps only ${f.plural(
      p.keep,
      {
        one: "the newest snapshot",
        other: `the newest ${f.number(p.keep)} snapshots`
      }
    )}. Click "Save and delete" to confirm.`,
    "data.retentionSaved": (p, f) => p.deleted === 0 ? "Saved. No snapshot needed deleting." : `Saved. ${f.plural(p.deleted, {
      one: "1 older snapshot was",
      other: `${f.number(p.deleted)} older snapshots were`
    })} deleted.`,
    "data.retentionInvalid": (p, f) => `Enter a whole number from ${f.number(p.minimum)} to ${f.number(p.maximum)}. Nothing was changed.`,
    "data.retentionFailed": "JoyFox could not save the setting. The field shows the number in use now. Try again.",
    "data.reminderLabel": "Remind me to export all data after (days)",
    "data.reminderHint": (p, f) => `JoyFox data stays in this browser profile, also when you close the browser. If you remove JoyFox or lose the profile, the data is gone, so a full export is your backup. This page asks for one when the last full export is older than this number of days. 0 turns the reminder off. From ${f.number(p.minimum)} to ${f.number(p.maximum)}; the default is ${f.number(p.default)}. Click "Save" to apply.`,
    "data.reminderSave": "Save",
    "data.reminderSaved": (p, f) => p.days === 0 ? "Saved. The export reminder is off." : `Saved. JoyFox reminds you ${f.plural(p.days, {
      one: "1 day",
      other: `${f.number(p.days)} days`
    })} after the last full export.`,
    "data.reminderInvalid": (p, f) => `Enter a whole number from ${f.number(p.minimum)} to ${f.number(p.maximum)}. Nothing was changed.`,
    "data.reminderNever": 'You have not exported all JoyFox data yet. If you remove JoyFox or lose this browser profile, the data is gone. Click "Export all JoyFox data (JSON)" to save a backup.',
    "data.reminderDue": (p, f) => `Your last full export was ${f.plural(p.days, {
      one: "1 day ago",
      other: `${f.number(p.days)} days ago`
    })}. If you remove JoyFox or lose this browser profile, newer data is gone. Click "Export all JoyFox data (JSON)" to save a backup.`,
    "data.lastExport": (p, f) => p.days === 0 ? "Last full export: today." : `Last full export: ${f.plural(p.days, {
      one: "1 day ago",
      other: `${f.number(p.days)} days ago`
    })}.`,
    "data.exportAll": "Export all JoyFox data (JSON)",
    "data.exportedAll": "Export of all JoyFox data created.",
    "data.deleteEverything": "Delete all JoyFox data",
    "data.deleteEverythingLabel": "Delete all JoyFox data in this browser",
    "data.deleteEverythingPrompt": 'Click "Confirm" to delete every account, every record and every JoyFox setting in this browser. This cannot be undone.',
    "data.deletedEverything": "Deleted all JoyFox data in this browser.",
    "data.confirm": "Confirm",
    "data.confirmLabel": (p) => `Confirm: ${p.label}`,
    "data.actionFailed": "JoyFox could not finish the delete. Some records may be deleted already: the counts shown now are what is still stored. Try again.",
    "data.exportFailed": "JoyFox could not create the export. Nothing was exported. Try again.",
    "data.import.title": "Import",
    "data.import.hint": "Import a JoyFox export file: everything, or one account. It is merged into what is stored here. An account with the same JoyClub identifier is merged into the existing one. For the same note, rule or placement the newer version wins; existing tags and corrections are kept. The import starts when you choose the file, and you then see what changed.",
    "data.import.fileLabel": "JoyFox export file (JSON)",
    "data.import.summary.all": (p, f) => `This full export holds ${f.number(p.total)} account(s): ${f.number(p.matched)} merged into an existing account, ${f.number(p.added)} added as new.`,
    "data.import.summary.account": (p, f) => `This single-account export holds ${f.number(p.total)} account(s): ${f.number(p.matched)} merged into an existing account, ${f.number(p.added)} added as new.`,
    "data.import.caption": "What the import changed",
    "data.import.col.added": "Added",
    "data.import.col.replaced": "Replaced (newer)",
    "data.import.col.kept": "Kept",
    "data.import.col.duplicates": "Skipped duplicates",
    "data.import.noRecords": "The file holds no records.",
    // Setting names in the import result. A setting JoyFox does not name is
    // shown by its stored key.
    "data.setting.activeAccount": "active account",
    "data.setting.language": "language",
    "data.setting.messageCaching": "store messages",
    "data.setting.messageRetention": "keep messages for",
    "data.setting.quickIgnoreDelete": "Ignore and Delete button",
    "data.setting.stripCollapsed": "JoyFox bar collapsed",
    "data.setting.templatePicker": "template picker",
    "data.setting.sharedEventException": "shared-event exception",
    "data.setting.snapshotRetention": "snapshots kept per member",
    "data.setting.exportReminder": "export reminder",
    "data.setting.diagnostics": "diagnostics",
    "data.import.settingsUnknown": "The file also holds settings that this version of JoyFox does not know. They were not imported.",
    "data.import.settingsSkipped": (p) => `Settings in the file that are never imported (they switch features on): ${p.keys}.`,
    "data.import.settingsNotSaved": (p) => `Settings that could not be saved: ${p.keys}.`,
    "data.import.settingsAdded": (p) => `Settings added (only those not set here): ${p.keys}.`,
    "data.import.running": "Importing the file.",
    "data.import.nothing": "Everything in this file is already stored. Nothing was changed.",
    "data.import.complete": (p, f) => `Import complete: ${f.number(p.added)} record(s) added, ${f.number(p.replaced)} replaced by a newer version.`,
    "data.import.completeSettingsFailed": (p, f) => `Import complete: ${f.number(p.added)} record(s) added, ${f.number(p.replaced)} replaced by a newer version. Some settings could not be saved (listed above). Set them again yourself.`,
    "data.import.incomplete": "JoyFox could not finish the import. Choose the file again to try again: records already stored are not added twice.",
    "data.import.unreadable": "JoyFox could not check that file. Nothing was imported. Choose the file again. If it still fails, reload the page, or export the file from JoyFox again.",
    // Errors the UI shows (ExtensionError.display). No final full stop: the
    // panels add a suffix such as "Nothing was changed." An error without a
    // display message gets the panel's own failure text instead, which says
    // what to do next.
    "error.withSuffix.nothingChanged": (p) => `${p.error}. Nothing was changed.`,
    "error.withSuffix.nothingImported": (p) => `${p.error}. Nothing was imported.`,
    "error.withSuffix.nothingDeleted": (p) => `${p.error}. Nothing was deleted.`,
    "error.withSuffix.nothingExported": (p) => `${p.error}. Nothing was exported. Try again.`,
    "error.withSuffix.settingNotChanged": (p) => `${p.error}. The setting was not changed. Try again.`,
    "error.account.emptyIdentifier": "Enter your JoyClub account identifier first",
    "error.account.duplicate": "An account with this identifier is already in the list. Use that account, or enter another identifier",
    "error.account.notRegistered": "That account is no longer in the list, for example because it was removed in another tab",
    "error.account.gone": "That account no longer exists",
    "error.account.changed": "The active account changed",
    "error.template.noName": "A template needs a name",
    "error.template.nameTooLong": (p, f) => `A template name can have at most ${f.number(p.maximum)} characters`,
    "error.template.folderTooLong": (p, f) => `A folder name can have at most ${f.number(p.maximum)} characters`,
    "error.template.noText": "A template needs some text",
    "error.template.tooLong": (p, f) => `A template can have at most ${f.number(p.maximum)} characters`,
    "error.template.deleted": "That template was deleted meanwhile",
    "error.data.changedDuringCheck": "Stored data changed while the file was checked. Choose the file again",
    "error.data.unknownType": "Unknown data type",
    "error.data.accountRecord": "The account record is removed only with the whole account",
    // The next step ends each refusal that a correct export file fixes.
    "error.import.tooLarge": "The file is too large to be a JoyFox export. Choose a file exported by JoyFox",
    "error.import.notJson": "The file is not a JoyFox export. Choose a file exported by JoyFox",
    "error.import.notExport": "The file is not a JoyFox export. Choose a file exported by JoyFox",
    "error.import.noVersion": "The file does not say which JoyFox version made it. Choose a file exported by JoyFox",
    "error.import.newerVersion": "The file comes from a newer JoyFox version. Update JoyFox first",
    "error.import.noScope": "The file does not say if it holds one account or all data. Choose a file exported by JoyFox",
    "error.import.noAccountNamed": "The file is an export of one account, but it does not name the account. Choose a file exported by JoyFox",
    "error.import.unknownType": "The file holds a type of data that JoyFox does not know. Choose a file exported by JoyFox",
    "error.import.notList": (p) => `The ${p.entity} part of the file is damaged. Choose a file exported by JoyFox`,
    "error.import.notRecord": (p, f) => `Record ${f.number(p.index)} in ${p.entity} is damaged. Choose a file exported by JoyFox`,
    "error.import.forbiddenKey": (p, f) => `Record ${f.number(p.index)} in ${p.entity} holds a field name that JoyFox does not allow. Choose a file exported by JoyFox`,
    "error.import.unknownField": (p, f) => `Record ${f.number(p.index)} in ${p.entity} holds a field that JoyFox does not know. Choose a file exported by JoyFox`,
    "error.import.tooLong": (p, f) => `Record ${f.number(p.index)} in ${p.entity} holds a text longer than ${f.number(p.maximum)} characters. Choose a file exported by JoyFox`,
    "error.import.invalid": (p, f) => `Record ${f.number(p.index)} in ${p.entity} is damaged. Choose a file exported by JoyFox`,
    "error.import.future": (p, f) => `Record ${f.number(p.index)} in ${p.entity} has a date in the future. Check the clock of the computer that made the file`,
    "error.import.otherAccount": (p, f) => `Record ${f.number(p.index)} in ${p.entity} belongs to another account. Choose a file exported by JoyFox`,
    "error.import.notOwnScope": (p, f) => `Account record ${f.number(p.index)} is damaged. Choose a file exported by JoyFox`,
    "error.import.twice": (p, f) => `Record ${f.number(p.index)} in ${p.entity} is in the file twice. Choose a file exported by JoyFox`,
    "error.import.sameIdentifier": "Two accounts in the file have the same identifier. Choose a file exported by JoyFox",
    "error.import.noAccountRecord": "The file is an export of one account, but it does not hold that account. Choose a file exported by JoyFox",
    "error.import.settingsInvalid": "The settings in the file are damaged. Choose a file exported by JoyFox",
    "error.import.settingsForbidden": "The settings in the file hold a name that JoyFox does not allow. Choose a file exported by JoyFox",
    "error.import.unknownSetting": "The file holds a setting that JoyFox does not use. Choose a file exported by JoyFox",
    "error.import.orphans": "Some records in the file belong to an account that the file does not hold. Choose a file exported by JoyFox",
    "error.import.sameRecordTwice": "Two records in the file would become the same record here. Choose a file exported by JoyFox"
  };

  // src/i18n/message.ts
  var MESSAGE_PARAMS = {
    "legacy.text": { text: "string" },
    "triage.reason.unknownValue": { field: "message" },
    "triage.reason.atOrAbove": {
      field: "message",
      value: "number",
      minimum: "number"
    },
    "triage.reason.belowMinimum": {
      field: "message",
      value: "number",
      minimum: "number"
    },
    "triage.reason.accountAgeRangeAbove": {
      min: "number",
      max: "number",
      minimum: "number"
    },
    "triage.reason.accountAgeRangeBelow": {
      min: "number",
      max: "number",
      minimum: "number"
    },
    "triage.reason.accountAgeRangeCoarse": {
      min: "number",
      max: "number",
      minimum: "number"
    },
    "triage.reason.phraseSeenNow": { text: "string" },
    "triage.reason.phraseSeenBefore": { text: "string" },
    "triage.reason.phraseNotInLatest": { text: "string" },
    "triage.reason.phraseNotSeen": { text: "string" },
    "triage.reason.trustAtOrAbove": { score: "number", minimum: "number" },
    "triage.reason.trustBelow": { score: "number", minimum: "number" },
    "triage.reason.negatedMet": { reason: "message", condition: "message" },
    "triage.reason.negatedNotMet": { reason: "message", condition: "message" },
    "triage.reason.unknownNeedsReview": { reason: "message" },
    "triage.reason.unknownMet": { reason: "message" },
    "triage.reason.unknownNotMet": { reason: "message" },
    "triage.reason.numbered": { number: "number", reason: "message" },
    "triage.reason.userMoved": { placement: "message" },
    "triage.headline.doesNotMeet": { placement: "message" },
    "trust.reason.positive": { count: "number" },
    "trust.reason.negative": { count: "number" },
    "trust.reason.neutral": { count: "number" },
    "spam.detail.belowMinimum": { words: "number", minimum: "number" },
    "spam.detail.duplicate": { percent: "number" },
    "spam.detail.phraseSimilar": { percent: "number" },
    "action.where.before": { step: "message" },
    "action.where.during": { step: "message" },
    "action.failure.control-missing": { step: "message" },
    "action.failure.confirmation-missing": { step: "message" },
    "action.failure.not-verified": { step: "message" },
    "action.failure.unverifiable": { step: "message", where: "message" },
    "action.failure.member-mismatch": { where: "message" },
    "action.failure.conversation-mismatch": { where: "message" },
    "action.failure.identity-unavailable": { where: "message" },
    "action.failure.account-changed": { where: "message" },
    "action.failure.turned-off": { where: "message" },
    "action.failure.superseded": { where: "message" },
    "action.failure.log-unavailable": { where: "message" },
    "action.failure.handoff-failed": { where: "message" },
    "action.failure.timeout": { step: "message" },
    "action.failure.step-error": { where: "message" },
    "triage.conditions.summary": { count: "number" },
    "triage.condition.line": { outcome: "message", condition: "message" },
    "triage.condition.lineNegated": { outcome: "message", condition: "message" },
    "triage.placementLine": { placement: "message", source: "message" },
    "triage.movedOn": { date: "string", placement: "message" },
    "mark.trustFailed": { placement: "message" },
    "triage.unknownFacts.one": { fact: "message" },
    "triage.unknownFacts.two": { first: "message", second: "message" },
    "triage.unknownFacts.three": {
      first: "message",
      second: "message",
      third: "message"
    },
    "trust.score.value": { score: "number" },
    "trust.contribution": { points: "number", reason: "message" },
    "inbox.viewCount": { view: "message", count: "number" },
    "inbox.badge": { text: "message" },
    "inbox.whyNamed": { name: "string" },
    "notes.removeTag": { label: "string" },
    "notes.summary.tags": { count: "number" },
    "notes.summary.noteAndTags": { count: "number" },
    "notes.length": { count: "number", maximum: "number" },
    "accounts.nameWithIdentifier": { label: "string", identifier: "string" },
    "accounts.useLabel": { name: "string" },
    "accounts.nowActive": { name: "string" },
    "accounts.renameLabel": { name: "string" },
    "accounts.renameField": { identifier: "string" },
    "accounts.renamed": { name: "string" },
    "accounts.removeLabel": { name: "string" },
    "accounts.confirmRemoveLabel": { name: "string" },
    "accounts.removePrompt": { name: "string" },
    "accounts.removed": { name: "string" },
    "accounts.removedNoneActive": { name: "string" },
    "accounts.removedNoneLeft": { name: "string" },
    "accounts.added": { name: "string" },
    "rule.unknownLabel": { condition: "message" },
    "rule.valueLabel": { condition: "message" },
    "rule.textLabel": { condition: "message" },
    "rule.textProblem": { maximum: "number", condition: "message" },
    "rule.numberProblem": {
      minimum: "number",
      maximum: "number",
      condition: "message"
    },
    "rule.fieldNumberProblem": { minimum: "number", maximum: "number" },
    "rule.fieldTextProblem": { maximum: "number" },
    "rule.removeConditionLabel": { condition: "message" },
    "rule.notLabel": { condition: "message" },
    "rule.ruleTitle": { number: "number" },
    "rule.ruleMatchLabel": { number: "number" },
    "rule.removeRuleLabel": { number: "number" },
    "rule.confirmRemoveGroupLabel": { number: "number" },
    "rule.removeGroupPrompt": { number: "number" },
    "rule.addConditionLabel": { number: "number" },
    "rule.ruleCount": { count: "number", maximum: "number" },
    "rule.notSaved": { problem: "message" },
    "listing.removeTag": { tag: "string" },
    "listing.summary.event": { state: "string" },
    "listing.summary.venue": { state: "string" },
    "eventFilter.tag": { tag: "string" },
    "events.count": { shown: "number", total: "number" },
    "events.untitled": { id: "string" },
    "events.past": { when: "string" },
    "events.venue": { venue: "string" },
    "eventFilter.count": { shown: "number", loaded: "number" },
    "typeFilter.count": { shown: "number", loaded: "number" },
    "typeFilter.unknownHidden": { count: "number" },
    "compat.shared": { count: "number" },
    "triage.sharedEvent.attending": { event: "string", when: "string" },
    "triage.sharedEvent.attended": { event: "string", when: "string" },
    "events.guests": { count: "number" },
    "signals.photos": { count: "number" },
    "signals.words": { count: "number" },
    "signals.tagCount": { count: "number" },
    "signals.trust": { score: "number" },
    "signals.editor.label": { member: "string" },
    "member.number": { id: "string" },
    "signals.filter.count": { hidden: "number", loaded: "number" },
    "messages.retentionHint": { default: "number" },
    "messages.retentionConfirmPrompt": { months: "number" },
    "data.retentionConfirmPrompt": { keep: "number" },
    "messages.retentionSaved": { deleted: "number" },
    "messages.retentionInvalid": { minimum: "number", maximum: "number" },
    "messages.count": { count: "number" },
    "messages.countLimited": { count: "number", shown: "number" },
    "messages.sentTo": { member: "string", when: "string" },
    "messages.receivedFrom": { member: "string", when: "string" },
    "messages.storedAt": { when: "string" },
    "compat.own": { count: "number" },
    "compat.badge": { count: "number" },
    "compat.badgeLabel": { count: "number" },
    "listing.tooManyTags.event": { maximum: "number" },
    "listing.tooManyTags.venue": { maximum: "number" },
    "searches.nameTooLong": { maximum: "number" },
    "searches.full": { maximum: "number" },
    "searches.saved": { name: "string" },
    "searches.noMatch": { name: "string" },
    "searches.deleteLabel": { name: "string" },
    "searches.confirmDelete": { name: "string" },
    "searches.deleted": { name: "string" },
    "searches.running": { name: "string" },
    "searches.shown": { name: "string" },
    "picker.result.too-long": { over: "number", limit: "number" },
    "rule.preset.describe.complete": { photos: "number", words: "number" },
    "rule.preset.describe.highTrust": {
      photos: "number",
      words: "number",
      days: "number"
    },
    "rule.preset.applied": { preset: "message" },
    "templates.inFolder": { folder: "string" },
    "templates.editLabel": { name: "string" },
    "templates.editing": { name: "string" },
    "templates.deleteLabel": { name: "string" },
    "templates.confirmDeleteLabel": { name: "string" },
    "templates.deletePrompt": { name: "string" },
    "templates.deleted": { name: "string" },
    "templates.saved": { name: "string" },
    "templates.added": { name: "string" },
    "data.showLabel": { label: "message" },
    "data.hideLabel": { label: "message" },
    "data.deleteAllLabel": { label: "message" },
    "data.deleteAllPrompt": { count: "number", label: "message" },
    "data.deletedAll": { label: "message" },
    "data.recordsTitle": { label: "message", count: "number" },
    "data.recordSummary": { id: "string", updated: "string" },
    "data.recordSummaryNamed": {
      name: "string",
      id: "string",
      updated: "string"
    },
    "data.recordNamed": { name: "string", id: "string" },
    "data.deleteRecordLabel": { record: "string" },
    "data.deleteRecordPrompt": { record: "string" },
    "data.deletedRecord": { record: "string" },
    "data.showMore": { count: "number" },
    "data.retentionHint": {
      minimum: "number",
      maximum: "number",
      default: "number"
    },
    "data.retentionSaved": { deleted: "number" },
    "data.retentionInvalid": { minimum: "number", maximum: "number" },
    "data.reminderHint": {
      minimum: "number",
      maximum: "number",
      default: "number"
    },
    "data.reminderSaved": { days: "number" },
    "data.reminderInvalid": { minimum: "number", maximum: "number" },
    "data.reminderDue": { days: "number" },
    "data.lastExport": { days: "number" },
    "data.moreValues": { count: "number" },
    "data.moreCharacters": { count: "number" },
    "data.confirmLabel": { label: "message" },
    "data.import.summary.all": {
      matched: "number",
      added: "number",
      total: "number"
    },
    "data.import.summary.account": {
      matched: "number",
      added: "number",
      total: "number"
    },
    "data.import.settingsSkipped": { keys: "string" },
    "data.import.settingsNotSaved": { keys: "string" },
    "data.import.settingsAdded": { keys: "string" },
    "data.import.complete": { added: "number", replaced: "number" },
    "data.import.completeSettingsFailed": { added: "number", replaced: "number" },
    "error.withSuffix.nothingChanged": { error: "message" },
    "error.withSuffix.nothingImported": { error: "message" },
    "error.withSuffix.nothingDeleted": { error: "message" },
    "error.withSuffix.nothingExported": { error: "message" },
    "error.withSuffix.settingNotChanged": { error: "message" },
    "error.template.nameTooLong": { maximum: "number" },
    "error.template.folderTooLong": { maximum: "number" },
    "error.template.tooLong": { maximum: "number" },
    "error.import.notList": { entity: "message" },
    "error.import.notRecord": { index: "number", entity: "message" },
    "error.import.forbiddenKey": { index: "number", entity: "message" },
    "error.import.unknownField": { index: "number", entity: "message" },
    "error.import.tooLong": {
      index: "number",
      entity: "message",
      maximum: "number"
    },
    "error.import.invalid": { index: "number", entity: "message" },
    "error.import.future": { index: "number", entity: "message" },
    "error.import.otherAccount": { index: "number", entity: "message" },
    "error.import.notOwnScope": { index: "number" },
    "error.import.twice": { index: "number", entity: "message" }
  };
  function isMessageKey(value) {
    return typeof value === "string" && Object.hasOwn(en, value);
  }
  function paramsOf(key2) {
    return Object.hasOwn(MESSAGE_PARAMS, key2) ? MESSAGE_PARAMS[key2] : null;
  }
  var isRecord = (value) => typeof value === "object" && value !== null && !Array.isArray(value);
  var MAX_DEPTH = 8;
  function isMessage(value, depth = 0) {
    if (depth > MAX_DEPTH || !isRecord(value)) return false;
    if (!isMessageKey(value.key)) return false;
    const spec = paramsOf(value.key);
    if (spec === null) return Object.keys(value).every((name) => name === "key");
    if (!Object.keys(value).every((name) => name === "key" || name === "params"))
      return false;
    const params = value.params;
    if (!isRecord(params)) return false;
    const names = Object.keys(spec);
    if (Object.keys(params).length !== names.length) return false;
    return names.every((name) => {
      if (!Object.hasOwn(params, name)) return false;
      const param = params[name];
      switch (spec[name]) {
        case "string":
          return typeof param === "string";
        case "number":
          return typeof param === "number" && Number.isFinite(param);
        case "message":
          return isMessage(param, depth + 1);
        default:
          return false;
      }
    });
  }
  function message(key2, ...params) {
    return params.length > 0 ? { key: key2, params: params[0] } : { key: key2 };
  }

  // src/storage/local-settings.ts
  function runtimeArea() {
    const area = globalThis.browser?.storage?.local;
    if (!area)
      throw new ExtensionError(
        "StorageError",
        "browser.storage.local is unavailable in this context"
      );
    return area;
  }
  var runtimeSettingsArea = {
    async get(keys) {
      return await runtimeArea().get(keys);
    },
    async set(items) {
      await runtimeArea().set(items);
    },
    async remove(keys) {
      await runtimeArea().remove(keys);
    },
    async getAll() {
      return await runtimeArea().get(null);
    },
    async clear() {
      await runtimeArea().clear();
    }
  };

  // src/storage/account-lock.ts
  var fallback = /* @__PURE__ */ new Map();
  var fallbackExclusive = Promise.resolve();
  var fallbackShared = /* @__PURE__ */ new Set();
  var DATA_LOCK_NAME = "joyfox:data";
  function accountLockName(accountId) {
    return `joyfox:account:${encodeURIComponent(accountId)}`;
  }
  function webLocks() {
    const locks = globalThis.navigator?.locks;
    return locks?.request?.bind(locks);
  }
  function withSharedDataLock(action2) {
    const request = webLocks();
    if (request)
      return request(
        DATA_LOCK_NAME,
        { mode: "shared" },
        () => action2()
      );
    const run = fallbackExclusive.then(() => action2());
    const settled = run.catch(() => void 0);
    fallbackShared.add(settled);
    void settled.then(() => fallbackShared.delete(settled));
    return run;
  }
  function accountOnly(accountId, action2) {
    const request = webLocks();
    const name = accountLockName(accountId);
    if (request) return request(name, () => action2());
    const previous = fallback.get(name) ?? Promise.resolve();
    const run = previous.then(action2, action2);
    const settled = run.catch(() => void 0);
    fallback.set(name, settled);
    void settled.then(() => {
      if (fallback.get(name) === settled) fallback.delete(name);
    });
    return run;
  }
  function withAccountLock(accountId, action2) {
    return withSharedDataLock(() => accountOnly(accountId, action2));
  }
  function withAccountLocks(accountIds, action2) {
    const ordered = [...new Set(accountIds)].sort();
    const acquire = (index) => index === ordered.length ? action2() : accountOnly(ordered[index], () => acquire(index + 1));
    return withSharedDataLock(() => acquire(0));
  }

  // src/domain/snapshot-order.ts
  var newestCaptureFirst = (a, b) => Date.parse(b.capturedAt) - Date.parse(a.capturedAt) || b.id.localeCompare(a.id);

  // src/storage/reason-migration.ts
  var USER_MOVED = {
    qualified: "You moved this sender to Qualified.",
    "needs-review": "You moved this sender to Needs Review.",
    quarantined: "You moved this sender to Quarantined."
  };
  function migrateReasons(reasons, placement) {
    if (!Array.isArray(reasons)) return reasons;
    const own = typeof placement === "string" && Object.hasOwn(USER_MOVED, placement) ? placement : void 0;
    return reasons.map((reason) => {
      if (typeof reason !== "string") return reason;
      if (own && reason === USER_MOVED[own])
        return message("triage.reason.userMoved", {
          placement: { key: `placement.${own}` }
        });
      return { key: "legacy.text", params: { text: reason } };
    });
  }

  // src/storage/database.ts
  var DATABASE_NAME = "joyfox";
  var DATABASE_VERSION = 5;
  var VERSION_1_ENTITY_NAMES = [
    "extensionAccounts",
    "joyClubMembers",
    "profileSnapshots",
    "userNotes",
    "userTags",
    "trustSignals",
    "contactRules",
    "conversationClassifications",
    "savedSearches",
    "eventMetadata",
    "spendLogEntries",
    "syncConfigs",
    "extensionPreferences",
    "messageTemplates",
    "spamPhrases",
    "actionLogs"
  ];
  var VERSION_2_ENTITY_NAMES = [
    "messageObservations",
    "senderSpamOverrides"
  ];
  var VERSION_3_ENTITY_NAMES = ["messagePhraseMatches"];
  var VERSION_5_ENTITY_NAMES = ["cachedMessages"];
  var ENTITY_NAMES = [
    ...VERSION_1_ENTITY_NAMES,
    ...VERSION_2_ENTITY_NAMES,
    ...VERSION_3_ENTITY_NAMES,
    ...VERSION_5_ENTITY_NAMES
  ];
  var connection;
  function migrateToVersion4(db, transaction) {
    const name = "conversationClassifications";
    if (!transaction || !db.objectStoreNames.contains(name)) return;
    const cursor = transaction.objectStore(name).openCursor();
    cursor.onsuccess = () => {
      const current = cursor.result;
      if (!current) return;
      const record = current.value;
      current.update({
        ...record,
        reasons: migrateReasons(record.reasons, record.placement)
      });
      current.continue();
    };
  }
  function openDatabase() {
    if (connection) return connection;
    const opening = new Promise((resolve, reject) => {
      const request = indexedDB.open(DATABASE_NAME, DATABASE_VERSION);
      request.onupgradeneeded = (event) => {
        const db = request.result;
        const createStores = (names) => {
          for (const name of names) {
            const store = db.createObjectStore(name, { keyPath: "storageKey" });
            store.createIndex("accountId", "accountId", { unique: false });
            store.createIndex("updatedAt", "updatedAt", { unique: false });
          }
        };
        if (event.oldVersion < 1) createStores(VERSION_1_ENTITY_NAMES);
        if (event.oldVersion < 2) createStores(VERSION_2_ENTITY_NAMES);
        if (event.oldVersion < 3) createStores(VERSION_3_ENTITY_NAMES);
        if (event.oldVersion < 4) migrateToVersion4(db, request.transaction);
        if (event.oldVersion < 5) createStores(VERSION_5_ENTITY_NAMES);
      };
      request.onsuccess = () => {
        const db = request.result;
        db.onversionchange = () => {
          db.close();
          if (connection === opening) connection = void 0;
        };
        resolve(db);
      };
      request.onerror = () => reject(request.error);
      request.onblocked = () => console.warn(
        "JoyFox: database upgrade is blocked by another open connection"
      );
    }).catch((error) => {
      if (connection === opening) connection = void 0;
      throw error;
    });
    connection = opening;
    return opening;
  }
  function requestResult(request) {
    return new Promise((resolve, reject) => {
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }
  function transactionDone(transaction) {
    return new Promise((resolve, reject) => {
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error);
      transaction.onabort = () => reject(transaction.error);
    });
  }
  async function commitAll(transaction, work) {
    const done = transactionDone(transaction);
    done.catch(() => void 0);
    try {
      await work();
    } catch (error) {
      try {
        transaction.abort();
      } catch {
      }
      throw error;
    }
    await done;
  }

  // src/domain/iso-date.ts
  var ISO_DATE = /^(\d{4})-(\d{2})-(\d{2})(?:T(\d{2}):(\d{2})(?::(\d{2})(?:\.\d{1,9})?)?(?:Z|[+-](\d{2}):(\d{2})))?$/;
  function isStrictIsoDate(value) {
    const match = ISO_DATE.exec(value);
    if (!match) return false;
    const [, y, m, d, hh, mm, ss, oh, om] = match;
    const year = Number(y);
    const month = Number(m);
    const day = Number(d);
    const calendar = new Date(Date.UTC(year, month - 1, day));
    if (calendar.getUTCFullYear() !== year || calendar.getUTCMonth() !== month - 1 || calendar.getUTCDate() !== day)
      return false;
    if (hh !== void 0 && (Number(hh) > 23 || Number(mm) > 59)) return false;
    if (ss !== void 0 && Number(ss) > 59) return false;
    if (oh !== void 0 && (Number(oh) > 23 || Number(om) > 59)) return false;
    return Number.isFinite(Date.parse(value));
  }

  // src/events/event-date.ts
  function validDay(year, month, day) {
    const date = new Date(Date.UTC(year, month - 1, day));
    return date.getUTCFullYear() === year && date.getUTCMonth() === month - 1 && date.getUTCDate() === day;
  }
  function isWallTime(value) {
    const match = /^(\d{4})-(\d{2})-(\d{2})(?:T(\d{2}):(\d{2}))?$/u.exec(value);
    if (!match) return false;
    if (!validDay(Number(match[1]), Number(match[2]), Number(match[3])))
      return false;
    return match[4] === void 0 || Number(match[4]) <= 23 && Number(match[5]) <= 59;
  }

  // src/notes/limits.ts
  var MAX_NOTE_LENGTH = 4e3;
  var MAX_TAG_LENGTH = 64;

  // src/events/listing.ts
  var normalizeTag = (label) => label.trim().replace(/\s+/gu, " ");
  var tagKey = (label) => normalizeTag(label).toLowerCase();
  var ATTENDANCE_VALUES = [
    "unknown",
    "interested",
    "attending",
    "not-attending",
    "attended"
  ];
  var MAX_EVENT_TAGS = 20;
  var MAX_EVENT_ATTENDEES = 2e3;
  var MAX_LISTING_TEXT_LENGTH = 300;
  var listingRecordId = (kind, id) => `${kind}:${id}`;
  var kindOf = (record) => record.kind ?? "event";
  function cleanTags(tags) {
    const seen = /* @__PURE__ */ new Set();
    const result = [];
    for (const raw of tags) {
      const label = normalizeTag(raw);
      const key2 = tagKey(label);
      if (label.length === 0 || seen.has(key2)) continue;
      seen.add(key2);
      result.push(label);
    }
    return result;
  }
  function notesProblem(notes) {
    if (notes.note.trim().length > MAX_NOTE_LENGTH) return "note";
    if (notes.tags.some((tag) => normalizeTag(tag).length > MAX_TAG_LENGTH))
      return "tag";
    if (cleanTags(notes.tags).length > MAX_EVENT_TAGS) return "tags";
    if (!ATTENDANCE_VALUES.includes(notes.attendance)) return "attendance";
    return void 0;
  }
  var cutListingText = (text) => {
    const clean = text?.replace(/\s+/gu, " ").trim();
    return clean ? clean.slice(0, MAX_LISTING_TEXT_LENGTH) : void 0;
  };
  function compareListings(a, b) {
    const aStart = a.startLocal ?? "\uFFFF";
    const bStart = b.startLocal ?? "\uFFFF";
    return aStart.localeCompare(bStart) || (a.title ?? "").localeCompare(b.title ?? "") || a.id.localeCompare(b.id);
  }

  // src/selectors/registry.ts
  var FROM_URL = "url:pathname";
  var VERIFIED_HOSTS = ["www.joyclub.de"];
  var selectorRegistry = {
    inbox: {
      status: "verified",
      evidence: "01-inbox.md",
      path: "^/clubmail/?$",
      root: ".cm-conversation-list",
      fields: {
        row: ".cm-conversation-list-item",
        // Display only (F2): kept as the member's nickname for JoyFox's own
        // texts, never an identity (resolveMemberIdentity refuses it).
        senderName: '[data-e2e="conversation-list-item-name"]',
        memberId: ".cm-conversation-list-item__avatar[href]",
        verificationCode: "j-veri-icon[verification-status]",
        genderCode: "j-gender-icon[universal-gender]",
        readStatus: ".cm-conversation-list-item__read-status",
        // Compared with the rule's phrases (ADR 0013). Never stored or logged.
        messagePreview: ".cm-conversation-list-item__text",
        // The row's second line, which holds the preview. JoyFox puts its own
        // line before it, in the same slot (owner's live check, 2026-09-27).
        descriptionLine: ".cm-conversation-list-item__line--description"
      }
    },
    conversation: {
      status: "verified",
      evidence: "02-conversation.md",
      path: "^/clubmail/conversation/conversation-wrapper-(personal-\\d+-\\d+)/?$",
      root: ".cm-conversation-header",
      fields: {
        memberId: "a.cm-conversation-header[href]",
        verificationCode: ".cm-conversation-header j-veri-icon[verification-status]",
        genderCode: ".cm-conversation-header j-gender-icon[universal-gender]",
        profileDescription: ".cm-conversation-header__description",
        messageItem: "li.cm-message-list-item",
        // V1-4, from 12-messages.md. Each item carries `data-message-id`;
        // a date separator or a system hint has no bubble and is skipped.
        sentBubble: 'div.cm-message-bubble[data-e2e="sent-message"]',
        receivedBubble: 'div.cm-message-bubble[data-e2e="received-message"]',
        messageText: "div.cm-message-bubble__content",
        messageBubble: "j-message-bubble",
        // In the bubble's shadow root.
        messageTime: ".footer time[datetime]",
        composer: "textarea.joy-input-wonder__input",
        sendButton: 'button.joy-input-wonder__button[data-e2e="button-submit"]'
      }
    },
    profile: {
      status: "verified",
      evidence: "03-profile.md",
      path: "^/profile/(\\d+)\\.[^/]+\\.html$",
      // The mobile header carries the data-e2e marker; the desktop header has
      // none, only its BEM class. JoyClub hides one of the two by screen width
      // (owner's live check, 2026-09-27), and pageMember anchors on the shown one.
      root: '[data-e2e="profile-header-base-info"], .profile-header__base-information--desktop',
      fields: {
        memberId: FROM_URL,
        verificationCode: '[data-e2e="profile-header-base-info"] j-veri-icon[verification-status]',
        genderCode: '[data-e2e="profile-header-base-info"] j-gender-icon[universal-gender]',
        photoCount: ".amount-badge[aria-label]",
        // One badge in this list reads "Angemeldet seit <n> <unit>"; the
        // extractor picks it by that text, as the badges share one structure.
        memberSinceBadge: ".profile-sidebar-container__badge-list j-list-item",
        // Another badge of the same list says whether JoyClub verified the
        // member, even under a green shield (owner's live check, 2026-09-27).
        verificationBadge: ".profile-sidebar-container__badge-list j-list-item",
        // Only the main text is counted; the motto above it is not.
        profileMainText: ".profile-description-maintext__text",
        // V1-2, from 13-preferences.md. The "Vorlieben" checklist: one level
        // group per level that has tags, each tag a `j-tag` whose label is in
        // its shadow root. Each person has a visible and a hidden copy.
        preferenceSection: "div.profile-erotic-prefs",
        preferenceLevel: "div.profile-erotic-prefs__category",
        preferenceLevelTitle: "h4.profile-erotic-prefs__category-title",
        preferenceTag: "div.profile-erotic-prefs__category-item-list > j-tag",
        preferenceTagLabel: "a.j-tag",
        // Only the viewer's own profile has the "Account" headline.
        ownProfileHeadline: "h2.profile-headline"
      }
    },
    search: {
      status: "verified",
      evidence: "11-search.md",
      // `/member/` and its filtered form `/member/<place>-as-r/is-<genders>/`.
      // Filters apply in place: the address changes without a page load.
      path: "^/member/(?:[^/]+/)*$",
      root: "div.member_search_list",
      fields: {
        resultList: "div.member_search_list",
        filterButton: '[data-e2e="search-filter-button"]',
        // "Anwenden" in the filter panel (11-search.md). V1-3 clicks it once
        // after a saved search opens, so the results follow its filters.
        applyButton: 'j-button[data-e2e="apply-filter-button"]',
        // The member ID is in the link (V1-2 reads it for the shared count).
        resultLink: 'a[data-e2e="result-item"]',
        resultCard: "j-member-card",
        // The card's nickname, in its `user-name` attribute (11-search.md).
        // Display only, never an identity.
        resultName: "j-member-card[user-name]"
      }
    },
    event: {
      status: "verified",
      evidence: "14-events.md",
      // The event ID is the number in the path; no attribute holds it.
      path: "^/event/(\\d+)\\.[^/]+\\.html$",
      root: "h1.event_name",
      fields: {
        eventId: FROM_URL,
        title: "h1.event_name",
        infoBox: ".event_info_box",
        startText: ".event_info_box .event-time",
        venueLink: ".event_location_detail a.event_club",
        // V1-2: the guest list tabs; each entry is a link to a profile.
        attendeeEntry: '.tab-pane[id^="guest_"] a.card.normal',
        attendeeName: "div.date_moreinfo",
        // The entry's text block (name, age, place). The name box inside it is
        // one clipped line, so JoyFox's line goes after it, at the end of this
        // block (owner's live check, 2026-09-27).
        attendeeInfo: "div.date_info",
        // The guest's nickname (14-events.md). Display only, never an identity.
        attendeeNickname: "div.date_moreinfo strong"
      }
    },
    // "Dates & Events" and its sub-tabs; one list holds event and date cards.
    "event-calendar": {
      status: "verified",
      evidence: "14-events.md",
      path: "^/dates_partys/",
      root: "div.card-list-ui",
      fields: {
        list: "div.card-list-ui",
        item: "div.card-list-ui-list-item",
        eventItem: "div.card-list-ui-list-item.event-card-ui[data-element-id]",
        headline: ".card-ui-detail-right-headline"
      }
    },
    // A venue ("Club") uses the profile template; its ID is a member ID.
    venue: {
      status: "verified",
      evidence: "15-venues.md",
      path: "^/club/(\\d+)\\.[^/]+\\.html$",
      root: "h1.profile_name",
      fields: {
        venueId: FROM_URL,
        name: "h1.profile_name"
      }
    },
    // V1-14, from 17-my-joy-lists.md. The five "My JOY" lists (visitors,
    // matches, liked you, you like, you visited) share one component tree, and
    // JoyClub's tabs move between them client-side. The section exists on each
    // of them; the grid is read inside it.
    "my-joy-list": {
      status: "verified",
      evidence: "17-my-joy-lists.md",
      path: "^/my_joy/(?:visitors|visits|voting/(?:match|top|fav))/?$",
      root: "section.my-joy-visits-view",
      fields: {
        // `display: grid`. It holds a summary card (`aside`) and the list.
        grid: "div.card-grid-container",
        // `display: contents`, so each `li` is a grid item: hiding one leaves no
        // gap. JoyClub appends 40 more `li` per scroll to the same list.
        slot: "ul.card-grid-container-list > li",
        // Always 4 filler cards at the list's end. Not members.
        placeholder: "li.card-grid-placeholder-card",
        card: "j-member-card",
        // The card host carries the code; it always equals the gender icon's
        // code in the card's shadow root, and the coordinator sees it change.
        genderCode: "j-member-card[universal-gender]"
      }
    }
  };

  // src/extraction/preferences.ts
  var MAX_PREFERENCE_TAGS = 500;
  var MAX_PREFERENCE_LABEL_LENGTH = 100;
  var normalizeLabel = (label) => label.replace(/\s+/gu, " ").trim();
  function sharedPreferences(own, other) {
    const mine = new Set(own);
    return [...new Set(other)].filter((label) => mine.has(label)).sort();
  }

  // src/messages/message-settings.ts
  var MESSAGE_CACHING_KEY = "joyfox.messageCaching";
  var MESSAGE_RETENTION_KEY = "joyfox.messageRetentionMonths";
  var DEFAULT_MESSAGE_RETENTION_MONTHS = 12;
  var MIN_MESSAGE_RETENTION_MONTHS = 1;
  var MAX_MESSAGE_RETENTION_MONTHS = 120;
  var MAX_MESSAGE_TEXT_LENGTH = 1e4;
  var MESSAGE_ID_PATTERN = /^cm-message-[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/u;
  var CONVERSATION_ID_PATTERN = /^personal-\d+-\d+$/u;
  var isMessageCaching = (value) => value !== false;
  function isMessageRetention(value) {
    return typeof value === "number" && Number.isInteger(value) && value >= MIN_MESSAGE_RETENTION_MONTHS && value <= MAX_MESSAGE_RETENTION_MONTHS;
  }
  async function readMessageSettings(settings) {
    try {
      const stored = await settings.get([
        MESSAGE_CACHING_KEY,
        MESSAGE_RETENTION_KEY
      ]);
      const months = stored[MESSAGE_RETENTION_KEY];
      return {
        caching: isMessageCaching(stored[MESSAGE_CACHING_KEY]),
        retentionMonths: isMessageRetention(months) ? months : DEFAULT_MESSAGE_RETENTION_MONTHS
      };
    } catch {
      return {
        caching: false,
        retentionMonths: DEFAULT_MESSAGE_RETENTION_MONTHS
      };
    }
  }
  function retentionCutoff(now, months) {
    const cutoff = new Date(now.getTime());
    cutoff.setUTCMonth(cutoff.getUTCMonth() - months);
    return cutoff.toISOString();
  }
  var messageTime = (message2) => message2.sentAt ?? message2.createdAt;

  // src/qualification/facts.ts
  var LIVE_ONLY_FACTS = /* @__PURE__ */ new Set([
    "personallyKnown"
  ]);
  var UNKNOWN_FACTS = Object.freeze({
    verification: "unknown",
    personallyKnown: "unknown",
    photoCount: "unknown",
    profileWordCount: "unknown",
    joinedAt: "unknown",
    joinedWindow: "unknown"
  });
  var isCount = (value) => typeof value === "number" && Number.isSafeInteger(value) && value >= 0;
  function isUsable(field, value) {
    switch (field) {
      case "verification":
      case "personallyKnown":
        return typeof value === "boolean";
      case "photoCount":
      case "profileWordCount":
        return isCount(value);
      case "joinedAt":
        return typeof value === "string" && isStrictIsoDate(value);
      case "joinedWindow":
        return isJoinWindow(value);
    }
  }
  function isJoinWindow(value) {
    if (!value || typeof value !== "object") return false;
    const { earliest, latest } = value;
    return typeof earliest === "string" && typeof latest === "string" && isStrictIsoDate(earliest) && isStrictIsoDate(latest) && Date.parse(earliest) <= Date.parse(latest);
  }
  function mergeProfileFacts(observed3, cached) {
    const facts = { ...UNKNOWN_FACTS };
    const sources = {
      verification: "none",
      personallyKnown: "none",
      photoCount: "none",
      profileWordCount: "none",
      joinedAt: "none",
      joinedWindow: "none"
    };
    const cachedWindow = cached?.joinedEarliest !== void 0 && cached.joinedLatest !== void 0 ? { earliest: cached.joinedEarliest, latest: cached.joinedLatest } : void 0;
    for (const field of Object.keys(UNKNOWN_FACTS)) {
      const fresh = observed3[field];
      if (isUsable(field, fresh)) {
        facts[field] = fresh;
        sources[field] = "observed";
        continue;
      }
      if (LIVE_ONLY_FACTS.has(field)) continue;
      const stored = field === "joinedWindow" ? cachedWindow : cached?.[field];
      if (isUsable(field, stored)) {
        facts[field] = stored;
        sources[field] = "cached";
      }
    }
    return { facts, sources };
  }
  function newestSnapshot(snapshots) {
    return [...snapshots].sort(newestCaptureFirst)[0];
  }

  // src/qualification/engine.ts
  function numericCriterion(name, label, value, minimum, source) {
    const field = message(label);
    if (value === "unknown")
      return {
        name,
        state: "unknown",
        reason: message("triage.reason.unknownValue", { field }),
        source
      };
    return value >= minimum ? {
      name,
      state: "pass",
      reason: message("triage.reason.atOrAbove", { field, value, minimum }),
      source
    } : {
      name,
      state: "fail",
      reason: message("triage.reason.belowMinimum", {
        field,
        value,
        minimum
      }),
      source
    };
  }
  function accountAgeDays(joinedAt, now) {
    if (joinedAt === "unknown" || !isStrictIsoDate(joinedAt)) return "unknown";
    const elapsed = now.getTime() - Date.parse(joinedAt);
    if (!Number.isFinite(elapsed) || elapsed < 0) return "unknown";
    return Math.floor(elapsed / (24 * 60 * 60 * 1e3));
  }
  var DAY_MS = 24 * 60 * 60 * 1e3;
  function accountAgeRange(window, now) {
    if (!isJoinWindow(window)) return "unknown";
    const min = Math.floor((now.getTime() - Date.parse(window.latest)) / DAY_MS);
    const max = Math.floor(
      (now.getTime() - Date.parse(window.earliest)) / DAY_MS
    );
    if (!Number.isFinite(min) || !Number.isFinite(max) || min < 0)
      return "unknown";
    return { min, max };
  }
  function accountAgeCriterion(facts, minimum, now, sourceOf) {
    const exact = accountAgeDays(facts.joinedAt, now);
    if (exact !== "unknown" || facts.joinedWindow === "unknown")
      return numericCriterion(
        "accountAge",
        "field.accountAgeDays",
        exact,
        minimum,
        sourceOf("joinedAt")
      );
    const source = sourceOf("joinedWindow");
    const range = accountAgeRange(facts.joinedWindow, now);
    if (range === "unknown")
      return numericCriterion(
        "accountAge",
        "field.accountAgeDays",
        "unknown",
        minimum,
        source
      );
    const span = { min: range.min, max: range.max, minimum };
    if (range.min >= minimum)
      return {
        name: "accountAge",
        state: "pass",
        reason: message("triage.reason.accountAgeRangeAbove", span),
        source
      };
    if (range.max < minimum)
      return {
        name: "accountAge",
        state: "fail",
        reason: message("triage.reason.accountAgeRangeBelow", span),
        source
      };
    return {
      name: "accountAge",
      state: "unknown",
      reason: message("triage.reason.accountAgeRangeCoarse", span),
      source
    };
  }
  function evaluateCriterion(criterion, facts, sources = {}, now = /* @__PURE__ */ new Date()) {
    const sourceOf = (field) => sources[field] ?? "none";
    switch (criterion.name) {
      case "verification": {
        const source = sourceOf("verification");
        if (facts.verification === "unknown")
          return {
            name: "verification",
            state: "unknown",
            reason: message("triage.reason.verificationUnknown"),
            source
          };
        return {
          name: "verification",
          state: facts.verification ? "pass" : "fail",
          reason: message(
            facts.verification ? "triage.reason.verified" : "triage.reason.notVerified"
          ),
          source
        };
      }
      case "personallyKnown": {
        const source = sourceOf("personallyKnown");
        return facts.personallyKnown === "unknown" ? {
          name: "personallyKnown",
          state: "unknown",
          reason: message("triage.reason.personallyKnownUnknown"),
          source
        } : {
          name: "personallyKnown",
          state: facts.personallyKnown ? "pass" : "fail",
          reason: message(
            facts.personallyKnown ? "triage.reason.personallyKnown" : "triage.reason.notPersonallyKnown"
          ),
          source
        };
      }
      case "photoCount":
        return numericCriterion(
          "photoCount",
          "field.photoCount",
          facts.photoCount,
          criterion.minimum,
          sourceOf("photoCount")
        );
      case "profileWordCount":
        return numericCriterion(
          "profileWordCount",
          "field.profileWordCount",
          facts.profileWordCount,
          criterion.minimum,
          sourceOf("profileWordCount")
        );
      case "accountAge":
        return accountAgeCriterion(facts, criterion.minimumDays, now, sourceOf);
    }
  }

  // src/rules/message-phrase.ts
  function normalizePhrase(text) {
    return text.normalize("NFKC").replace(/[\uFE0E\uFE0F]/gu, "").toUpperCase().toLowerCase().replace(/\u00DF/gu, "ss").replace(/\u03C2/gu, "\u03C3").replace(/\s+/gu, " ").trim();
  }
  var MAX_PHRASE_LENGTH = 100;
  var MAX_NORMALIZED_PHRASE_LENGTH = 400;
  var MAX_PREVIEW_LENGTH = 2e3;
  function phrasesIn(message2, phrases) {
    const normalized = normalizePhrase(message2);
    const found = /* @__PURE__ */ new Set();
    for (const phrase of phrases)
      if (phrase.length > 0 && normalized.includes(phrase)) found.add(phrase);
    return found;
  }

  // src/rules/contact-rule.ts
  var NUMERIC_CONDITION_KINDS = /* @__PURE__ */ new Set([
    "minimumPhotos",
    "minimumProfileWords",
    "minimumAccountAgeDays",
    "minimumTrustScore"
  ]);
  var TEXT_CONDITION_KINDS = /* @__PURE__ */ new Set([
    "firstMessageContains"
  ]);
  var CONDITION_KINDS = [
    "verified",
    "personallyKnown",
    "minimumPhotos",
    "minimumProfileWords",
    "minimumAccountAgeDays",
    "notTemplateSpam",
    "minimumTrustScore",
    "firstMessageContains"
  ];
  var CONDITION_TEXT = {
    verified: "condition.verified",
    personallyKnown: "condition.personallyKnown",
    minimumPhotos: "condition.minimumPhotos",
    minimumProfileWords: "condition.minimumProfileWords",
    minimumAccountAgeDays: "condition.minimumAccountAgeDays",
    notTemplateSpam: "condition.notTemplateSpam",
    minimumTrustScore: "condition.minimumTrustScore",
    firstMessageContains: "condition.firstMessageContains"
  };
  var RULE_LIMITS = Object.freeze({
    maxDepth: 4,
    maxChildren: 32,
    maxValue: 1e5,
    minTrustValue: -1e3,
    maxTextLength: MAX_PHRASE_LENGTH
  });
  function contactRuleProblem(value) {
    if (!value || typeof value !== "object") return "The rule must be an object";
    const rule = value;
    if (![1, 2, 3].includes(rule.schemaVersion))
      return "Unsupported rule schema version";
    if (!["all", "man", "woman", "couple"].includes(rule.audience))
      return "Unsupported rule audience";
    if (typeof rule.enabled !== "boolean") return "enabled must be a boolean";
    if (!["needs-review", "quarantined"].includes(rule.defaultPlacement))
      return "defaultPlacement must be needs-review or quarantined";
    return nodeProblem(rule.root, 1, rule.schemaVersion, true);
  }
  function rulePhrases(root) {
    const phrases = /* @__PURE__ */ new Set();
    const walk = (node) => {
      if (node.type === "group") node.children.forEach(walk);
      else if (TEXT_CONDITION_KINDS.has(node.kind) && node.text !== void 0) {
        const phrase = normalizePhrase(node.text);
        if (phrase.length > 0) phrases.add(phrase);
      }
    };
    walk(root);
    return phrases;
  }
  function nodeProblem(value, depth, version, mustBeGroup = false) {
    if (!value || typeof value !== "object")
      return "A rule node must be an object";
    const node = value;
    if (node.type === "group") {
      if (depth > RULE_LIMITS.maxDepth) return "The rule is nested too deeply";
      if (node.match !== "all" && node.match !== "any")
        return "A group must match all or any";
      if (!Array.isArray(node.children)) return "A group needs a children array";
      if (node.children.length > RULE_LIMITS.maxChildren)
        return "A group has too many conditions";
      for (const child of node.children) {
        const problem = nodeProblem(child, depth + 1, version);
        if (problem) return problem;
      }
      return void 0;
    }
    if (mustBeGroup) return "The rule root must be a group";
    if (node.type !== "condition") return "Unknown rule node type";
    if (!CONDITION_KINDS.includes(node.kind))
      return "Unknown condition kind";
    if (!["needs-review", "met", "not-met"].includes(node.whenUnknown))
      return "whenUnknown has an unsupported value";
    if (node.negate !== void 0 && (node.negate !== true || version === 1))
      return "negate must be true, and needs rule schema version 2";
    const kind = node.kind;
    if (TEXT_CONDITION_KINDS.has(kind)) {
      if (version === 1 || version === 2)
        return "This condition needs rule schema version 3";
      const text = node.text;
      const phrase = typeof text === "string" ? normalizePhrase(text) : "";
      if (typeof text !== "string" || text !== text.trim() || text.length > RULE_LIMITS.maxTextLength || phrase.length === 0 || // Every phrase a rule accepts must also fit a stored match, or an
      // export would hold a match that import refuses.
      phrase.length > MAX_NORMALIZED_PHRASE_LENGTH)
        return `A condition text must be 1 to ${RULE_LIMITS.maxTextLength} characters, with no space at either end`;
    } else if (node.text !== void 0) return "This condition takes no text";
    if (NUMERIC_CONDITION_KINDS.has(kind)) {
      const minimum = kind === "minimumTrustScore" ? RULE_LIMITS.minTrustValue : 0;
      if (typeof node.value !== "number" || !Number.isSafeInteger(node.value) || node.value < minimum || node.value > RULE_LIMITS.maxValue)
        return "A condition threshold must be a whole number in range";
    } else if (node.value !== void 0)
      return "This condition takes no threshold";
    return void 0;
  }
  var PLACEMENT_TEXT = {
    qualified: "placement.qualified",
    "needs-review": "placement.needs-review",
    quarantined: "placement.quarantined"
  };
  var CRITERION_FOR = {
    verified: () => ({ name: "verification" }),
    personallyKnown: () => ({ name: "personallyKnown" }),
    minimumPhotos: (minimum) => ({ name: "photoCount", minimum }),
    minimumProfileWords: (minimum) => ({ name: "profileWordCount", minimum }),
    minimumAccountAgeDays: (minimumDays) => ({ name: "accountAge", minimumDays })
  };
  function readCondition(condition, input, now) {
    const criterion = CRITERION_FOR[condition.kind];
    if (criterion) {
      const result = evaluateCriterion(
        criterion(condition.value ?? 0),
        input.facts,
        input.sources,
        now
      );
      return {
        state: result.state,
        reason: result.reason,
        source: result.source
      };
    }
    if (condition.kind === "notTemplateSpam")
      switch (input.spam) {
        case "flagged":
          return {
            state: "fail",
            reason: message("triage.reason.spamFlagged"),
            source: "observed"
          };
        case "not-flagged":
          return {
            state: "pass",
            reason: message("triage.reason.spamNotFlagged"),
            source: "observed"
          };
        case "overridden":
          return {
            state: "pass",
            reason: message("triage.reason.spamOverridden"),
            source: "cached"
          };
        case "unknown":
          return {
            state: "unknown",
            reason: message("triage.reason.spamUnknown"),
            source: "none"
          };
      }
    if (condition.kind === "firstMessageContains")
      return readMessagePhrase(condition.text ?? "", input.messages);
    const minimum = condition.value ?? 0;
    if (input.trust === "unknown")
      return {
        state: "unknown",
        reason: message("triage.reason.trustUnknown"),
        source: "none"
      };
    const score = { score: input.trust.score, minimum };
    return input.trust.score >= minimum ? {
      state: "pass",
      reason: message("triage.reason.trustAtOrAbove", score),
      source: "cached"
    } : {
      state: "fail",
      reason: message("triage.reason.trustBelow", score),
      source: "cached"
    };
  }
  function readMessagePhrase(text, messages) {
    const phrase = normalizePhrase(text);
    if (messages?.seenNow.has(phrase))
      return {
        state: "pass",
        reason: message("triage.reason.phraseSeenNow", { text }),
        source: "observed"
      };
    if (messages?.seenBefore.has(phrase))
      return {
        state: "pass",
        reason: message("triage.reason.phraseSeenBefore", { text }),
        source: "cached"
      };
    if (messages?.previewShown)
      return {
        state: "unknown",
        reason: message("triage.reason.phraseNotInLatest", { text }),
        source: "observed"
      };
    return {
      state: "unknown",
      reason: message("triage.reason.phraseNotSeen", { text }),
      source: "none"
    };
  }
  var UNKNOWN_SUFFIX = {
    "needs-review": "triage.reason.unknownNeedsReview",
    met: "triage.reason.unknownMet",
    "not-met": "triage.reason.unknownNotMet"
  };
  function evaluateCondition(condition, input, now) {
    const read = readCondition(condition, input, now);
    const negate = condition.negate === true;
    const base = { kind: condition.kind, ...negate ? { negate } : {} };
    if (read.state !== "unknown") {
      const met = read.state === "pass" !== negate;
      return {
        ...base,
        state: read.state,
        outcome: met ? "met" : "not-met",
        reason: negate ? message(
          met ? "triage.reason.negatedMet" : "triage.reason.negatedNotMet",
          {
            reason: read.reason,
            condition: message(CONDITION_TEXT[condition.kind])
          }
        ) : read.reason,
        source: read.source
      };
    }
    return {
      ...base,
      state: "unknown",
      outcome: condition.whenUnknown,
      reason: message(UNKNOWN_SUFFIX[condition.whenUnknown], {
        reason: read.reason
      }),
      source: read.source
    };
  }
  function evaluateGroup(group, input, now, collected, numberRules = false) {
    if (group.children.length === 0) return { outcome: "met", reasons: [] };
    const results = group.children.map((child, index) => {
      if (child.type === "group") {
        const result = evaluateGroup(child, input, now, collected);
        if (!numberRules) return result;
        return {
          ...result,
          reasons: result.reasons.map(
            (reason) => message("triage.reason.numbered", { number: index + 1, reason })
          )
        };
      }
      const evaluated = evaluateCondition(child, input, now);
      collected.push(evaluated);
      return { outcome: evaluated.outcome, reasons: [evaluated.reason] };
    });
    const having = (outcome2) => results.filter((result) => result.outcome === outcome2);
    const combine = (outcome2) => ({
      outcome: outcome2,
      reasons: having(outcome2).flatMap((result) => result.reasons)
    });
    if (group.match === "all") {
      if (having("not-met").length > 0) return combine("not-met");
      if (having("needs-review").length > 0) return combine("needs-review");
      return combine("met");
    }
    const [firstMet] = having("met");
    if (firstMet) return firstMet;
    if (having("needs-review").length > 0) return combine("needs-review");
    return combine("not-met");
  }
  function evaluateContactRule(rule, input) {
    const now = input.now ?? /* @__PURE__ */ new Date();
    const evaluatedConditions = [];
    const { children } = rule.root;
    const numberRules = children.length > 1 && children.every((child) => child.type === "group");
    const { outcome: outcome2, reasons } = evaluateGroup(
      rule.root,
      input,
      now,
      evaluatedConditions,
      numberRules
    );
    const placement = outcome2 === "met" ? "qualified" : outcome2 === "needs-review" ? "needs-review" : rule.defaultPlacement;
    const headline = outcome2 === "met" ? message(
      reasons.length === 0 ? "triage.headline.noConditions" : "triage.headline.meets"
    ) : outcome2 === "needs-review" ? message("triage.headline.undecided") : message("triage.headline.doesNotMeet", {
      placement: message(PLACEMENT_TEXT[rule.defaultPlacement])
    });
    return {
      placement,
      reasons: [headline, ...reasons],
      evaluatedConditions
    };
  }

  // src/storage/member-directory.ts
  async function registerMember(members2, accountId, memberId2, timestamp) {
    if (await members2.get(accountId, memberId2)) return;
    const member = {
      id: memberId2,
      accountId,
      joyClubMemberId: memberId2,
      createdAt: timestamp,
      updatedAt: timestamp
    };
    await members2.put(accountId, member);
  }
  var MAX_NICKNAME_LENGTH = 64;
  function cleanNickname(value) {
    if (typeof value !== "string") return void 0;
    const nickname = value.replace(/\s+/gu, " ").trim();
    if (nickname.length === 0 || nickname.length > MAX_NICKNAME_LENGTH)
      return void 0;
    return /[\u0000-\u001f\u007f]/u.test(nickname) ? void 0 : nickname;
  }
  async function rememberNicknames(members2, accountId, names, timestamp) {
    let changed = 0;
    for (const { memberId: memberId2, nickname } of names) {
      const existing = await members2.get(accountId, memberId2);
      if (existing?.nickname === nickname) continue;
      const member = existing ? { ...existing, nickname, updatedAt: timestamp } : {
        id: memberId2,
        accountId,
        joyClubMemberId: memberId2,
        nickname,
        createdAt: timestamp,
        updatedAt: timestamp
      };
      await members2.put(accountId, member);
      changed += 1;
    }
    return changed;
  }

  // src/storage/validation.ts
  var ValidationError = class extends Error {
  };
  function requireString(record, field) {
    const value = record[field];
    if (typeof value !== "string" || value.length === 0)
      throw new ValidationError(`${field} must be a non-empty string`);
    return value;
  }
  function requireNumber(record, field) {
    const value = record[field];
    if (typeof value !== "number" || !Number.isFinite(value))
      throw new ValidationError(`${field} must be a finite number`);
    return value;
  }
  function requireBoolean(record, field) {
    const value = record[field];
    if (typeof value !== "boolean")
      throw new ValidationError(`${field} must be a boolean`);
    return value;
  }
  function requireArray(record, field) {
    const value = record[field];
    if (!Array.isArray(value))
      throw new ValidationError(`${field} must be an array`);
    return value;
  }
  function requireDate(record, field) {
    const value = requireString(record, field);
    if (!Number.isFinite(Date.parse(value)))
      throw new ValidationError(`${field} must be an ISO-compatible date`);
  }
  function requireEnum(record, field, values) {
    if (!values.includes(requireString(record, field)))
      throw new ValidationError(`${field} has an unsupported value`);
  }
  function requireStringArray(record, field) {
    if (!requireArray(record, field).every((value) => typeof value === "string"))
      throw new ValidationError(`${field} must contain only strings`);
  }
  function requireMessageArray(record, field) {
    if (!requireArray(record, field).every((value) => isMessage(value)))
      throw new ValidationError(`${field} must contain only catalog messages`);
  }
  function optionalString(record, field) {
    if (record[field] !== void 0) requireString(record, field);
  }
  function allowOnly(record, fields, entityName) {
    const unexpected = Object.keys(record).find(
      (field) => !fields.includes(field)
    );
    if (unexpected)
      throw new ValidationError(
        `${entityName} contains unsupported field ${unexpected}`
      );
  }
  function validateActionSteps(record) {
    for (const value of requireArray(record, "steps")) {
      if (!value || typeof value !== "object")
        throw new ValidationError("steps must contain objects");
      const step = value;
      requireString(step, "name");
      requireBoolean(step, "ok");
      requireDate(step, "at");
      optionalString(step, "errorCode");
    }
  }
  function validateProfileSnapshot(record) {
    requireString(record, "memberId");
    requireDate(record, "capturedAt");
    if (record.verification !== "unknown" && typeof record.verification !== "boolean")
      throw new ValidationError("verification must be boolean or unknown");
    for (const field of ["photoCount", "profileWordCount"]) {
      if (record[field] !== "unknown" && (typeof record[field] !== "number" || !Number.isInteger(record[field]) || record[field] < 0))
        throw new ValidationError(
          `${field} must be a non-negative integer or unknown`
        );
    }
    if (record.joinedAt !== "unknown") requireDate(record, "joinedAt");
    const hasEarliest = record.joinedEarliest !== void 0;
    const hasLatest = record.joinedLatest !== void 0;
    if (hasEarliest !== hasLatest)
      throw new ValidationError(
        "joinedEarliest and joinedLatest must be present together"
      );
    if (hasEarliest) {
      for (const field of ["joinedEarliest", "joinedLatest"])
        if (!isStrictIsoDate(requireString(record, field)))
          throw new ValidationError(`${field} must be a strict ISO 8601 date`);
      if (Date.parse(record.joinedEarliest) > Date.parse(record.joinedLatest))
        throw new ValidationError(
          "joinedEarliest must not be after joinedLatest"
        );
    }
    if (record.positivePreferences !== void 0) {
      const labels = record.positivePreferences;
      if (!Array.isArray(labels) || labels.some(
        (label, index) => typeof label !== "string" || label.length === 0 || label !== normalizeLabel(label) || index > 0 && !(labels[index - 1] < label)
      ))
        throw new ValidationError(
          "positivePreferences must be normalized labels, sorted and unique"
        );
    }
    if (record.ownProfile !== void 0 && record.ownProfile !== true)
      throw new ValidationError("ownProfile must be true when present");
  }
  function validateSyncConfig(record) {
    allowOnly(
      record,
      [
        "id",
        "accountId",
        "createdAt",
        "updatedAt",
        "endpoint",
        "lastSyncedAt",
        "keyDerivation"
      ],
      "SyncConfig"
    );
    requireString(record, "endpoint");
    const keyDerivation = record.keyDerivation;
    if (!keyDerivation || typeof keyDerivation !== "object")
      throw new ValidationError("keyDerivation is required");
    const parameters = keyDerivation;
    allowOnly(
      parameters,
      ["algorithm", "iterations", "hash", "salt"],
      "keyDerivation"
    );
    if (parameters.algorithm !== "PBKDF2" || parameters.hash !== "SHA-256")
      throw new ValidationError("Unsupported key derivation parameters");
    if (!Number.isInteger(requireNumber(parameters, "iterations")) || requireNumber(parameters, "iterations") <= 0)
      throw new ValidationError("iterations must be a positive integer");
    requireString(parameters, "salt");
  }
  function validateEntity(entityName, entity) {
    const record = entity;
    requireString(record, "id");
    requireString(record, "accountId");
    requireDate(record, "createdAt");
    requireDate(record, "updatedAt");
    switch (entityName) {
      case "extensionAccounts":
        requireString(record, "joyClubAccountId");
        optionalString(record, "label");
        break;
      case "joyClubMembers":
        requireString(record, "joyClubMemberId");
        if (record.nickname !== void 0 && cleanNickname(record.nickname) !== record.nickname)
          throw new ValidationError("nickname must be a clean nickname");
        break;
      case "profileSnapshots":
        validateProfileSnapshot(record);
        break;
      case "userNotes":
        requireString(record, "memberId");
        requireString(record, "body");
        break;
      case "userTags":
        requireString(record, "memberId");
        requireString(record, "label");
        break;
      case "trustSignals":
        requireString(record, "memberId");
        requireEnum(record, "kind", ["positive", "negative", "neutral"]);
        requireDate(record, "occurredAt");
        break;
      case "contactRules": {
        requireString(record, "name");
        const problem = contactRuleProblem(record);
        if (problem) throw new ValidationError(problem);
        break;
      }
      case "conversationClassifications":
        requireString(record, "memberId");
        optionalString(record, "conversationId");
        requireEnum(record, "placement", [
          "qualified",
          "needs-review",
          "quarantined"
        ]);
        requireEnum(record, "source", ["user"]);
        requireDate(record, "decidedAt");
        requireMessageArray(record, "reasons");
        optionalString(record, "ruleId");
        break;
      case "savedSearches":
        requireString(record, "name");
        requireString(record, "url");
        break;
      case "eventMetadata":
        requireString(record, "eventId");
        if (record.kind !== void 0) {
          requireEnum(record, "kind", ["event", "venue"]);
          if (!/^\d{1,12}$/u.test(record.eventId))
            throw new ValidationError("eventId must be JoyClub's number");
          if (record.id !== `${record.kind}:${record.eventId}`)
            throw new ValidationError("id must be <kind>:<eventId>");
        }
        optionalString(record, "title");
        if (record.startLocal !== void 0 && !isWallTime(requireString(record, "startLocal")))
          throw new ValidationError("startLocal must be YYYY-MM-DD[THH:mm]");
        if (record.path !== void 0 && !/^\/(event|club)\/\d{1,12}\.[^/]+\.html$/u.test(
          requireString(record, "path")
        ))
          throw new ValidationError("path must be a JoyClub event or venue path");
        if (record.venueId !== void 0 && !/^\d{1,12}$/u.test(requireString(record, "venueId")))
          throw new ValidationError("venueId must be JoyClub's number");
        optionalString(record, "venueName");
        optionalString(record, "note");
        requireStringArray(record, "tags");
        requireEnum(record, "attendance", [
          "interested",
          "attending",
          "not-attending",
          "attended",
          "unknown"
        ]);
        if (record.attendees !== void 0) {
          const ids = record.attendees;
          if (!Array.isArray(ids) || ids.length > MAX_EVENT_ATTENDEES || ids.some(
            (id, index) => typeof id !== "string" || // The member-ID shape every handler accepts (triage-service).
            !/^\d{1,20}$/u.test(id) || index > 0 && !(ids[index - 1] < id)
          ))
            throw new ValidationError(
              `attendees must be up to ${MAX_EVENT_ATTENDEES} member IDs, sorted and unique`
            );
        }
        if (record.attendeesSeenAt !== void 0)
          requireDate(record, "attendeesSeenAt");
        break;
      case "spendLogEntries":
        requireDate(record, "occurredAt");
        requireNumber(record, "amountMinor");
        requireString(record, "currency");
        requireEnum(record, "category", ["coins", "membership", "other"]);
        break;
      case "syncConfigs":
        validateSyncConfig(record);
        if (record.lastSyncedAt !== void 0)
          requireDate(record, "lastSyncedAt");
        break;
      case "extensionPreferences":
        requireString(record, "key");
        break;
      case "messageTemplates":
        requireString(record, "name");
        requireString(record, "body");
        optionalString(record, "folder");
        break;
      case "spamPhrases":
        requireString(record, "phrase");
        requireBoolean(record, "enabled");
        break;
      case "messageObservations":
        allowOnly(
          record,
          [
            "id",
            "accountId",
            "createdAt",
            "updatedAt",
            "memberId",
            "conversationId",
            "observedAt",
            "normalizedText"
          ],
          "MessageObservation"
        );
        requireString(record, "memberId");
        requireDate(record, "observedAt");
        requireString(record, "normalizedText");
        optionalString(record, "conversationId");
        break;
      case "senderSpamOverrides":
        requireString(record, "memberId");
        requireEnum(record, "decision", ["not-spam"]);
        requireDate(record, "decidedAt");
        optionalString(record, "reason");
        break;
      case "cachedMessages": {
        const messageId = requireString(record, "messageId");
        if (!MESSAGE_ID_PATTERN.test(messageId))
          throw new ValidationError("messageId must be JoyClub's message ID");
        if (record.id !== `message:${messageId}`)
          throw new ValidationError("id must be message:<messageId>");
        const conversationId2 = requireString(record, "conversationId");
        if (!CONVERSATION_ID_PATTERN.test(conversationId2))
          throw new ValidationError("conversationId must be personal-<n>-<n>");
        const memberId2 = requireString(record, "memberId");
        if (!conversationId2.split("-").slice(1).includes(memberId2))
          throw new ValidationError("memberId must be in the conversation");
        requireEnum(record, "direction", ["sent", "received"]);
        if (record.sentAt !== void 0) requireDate(record, "sentAt");
        const text = requireString(record, "text");
        if (text.trim().length === 0 || text.length > MAX_MESSAGE_TEXT_LENGTH)
          throw new ValidationError(
            `text must hold 1 to ${MAX_MESSAGE_TEXT_LENGTH} characters`
          );
        break;
      }
      case "messagePhraseMatches":
        allowOnly(
          record,
          [
            "id",
            "accountId",
            "createdAt",
            "updatedAt",
            "memberId",
            "phrase",
            "matchedAt"
          ],
          "MessagePhraseMatch"
        );
        requireString(record, "memberId");
        if (requireString(record, "phrase").length > MAX_NORMALIZED_PHRASE_LENGTH)
          throw new ValidationError("phrase is too long");
        requireDate(record, "matchedAt");
        break;
      case "actionLogs":
        requireString(record, "action");
        optionalString(record, "memberId");
        optionalString(record, "conversationId");
        validateActionSteps(record);
        break;
    }
  }

  // src/storage/repository.ts
  var keyPart = (value) => encodeURIComponent(value);
  var key = (accountId, id) => `${keyPart(accountId)}:${keyPart(id)}`;
  var storageKeyFor = key;
  function withoutStorageKey(stored) {
    const copy = { ...stored };
    delete copy.storageKey;
    return copy;
  }
  var IndexedDbRepository = class {
    constructor(entityName) {
      this.entityName = entityName;
    }
    async get(accountId, id) {
      const db = await openDatabase();
      const stored = await requestResult(
        db.transaction(this.entityName).objectStore(this.entityName).get(key(accountId, id))
      );
      if (!stored) return void 0;
      return withoutStorageKey(stored);
    }
    async list(accountId) {
      const db = await openDatabase();
      const records = await requestResult(
        db.transaction(this.entityName).objectStore(this.entityName).index("accountId").getAll(accountId)
      );
      return records.map(withoutStorageKey);
    }
    /**
     * Stores one record. `retention` is passed to the store's retention policy,
     * if it has one (profile snapshots: how many to keep per member).
     */
    async put(accountId, entity, retention) {
      if (entity.accountId !== accountId)
        throw new ValidationError(
          "Entity account does not match repository scope"
        );
      validateEntity(this.entityName, entity);
      const db = await openDatabase();
      const transaction = db.transaction(this.entityName, "readwrite");
      const store = transaction.objectStore(this.entityName);
      await commitAll(transaction, async () => {
        store.put({ ...entity, storageKey: key(accountId, entity.id) });
        await this.applyRetention?.(store, accountId, entity, retention);
      });
    }
    async delete(accountId, id) {
      const db = await openDatabase();
      const transaction = db.transaction(this.entityName, "readwrite");
      transaction.objectStore(this.entityName).delete(key(accountId, id));
      await transactionDone(transaction);
    }
  };

  // src/storage/snapshot-retention.ts
  var SNAPSHOT_RETENTION_KEY = "joyfox.snapshotRetention";
  var DEFAULT_SNAPSHOT_RETENTION = 20;
  var MIN_SNAPSHOT_RETENTION = 1;
  var MAX_SNAPSHOT_RETENTION = 100;
  function isSnapshotRetention(value) {
    return typeof value === "number" && Number.isInteger(value) && value >= MIN_SNAPSHOT_RETENTION && value <= MAX_SNAPSHOT_RETENTION;
  }
  async function readSnapshotRetention(settings) {
    try {
      const value = (await settings.get([SNAPSHOT_RETENTION_KEY]))[SNAPSHOT_RETENTION_KEY];
      return isSnapshotRetention(value) ? value : DEFAULT_SNAPSHOT_RETENTION;
    } catch {
      return DEFAULT_SNAPSHOT_RETENTION;
    }
  }

  // src/storage/repositories.ts
  var PROFILE_SNAPSHOT_RETENTION = DEFAULT_SNAPSHOT_RETENTION;
  function snapshotsBeyond(snapshots, keep) {
    const byMember = /* @__PURE__ */ new Map();
    for (const snapshot of snapshots) {
      const member = `${snapshot.accountId}\0${snapshot.memberId}`;
      const list = byMember.get(member) ?? [];
      list.push(snapshot);
      byMember.set(member, list);
    }
    return [...byMember.values()].flatMap(
      (list) => list.sort(newestCaptureFirst).slice(Math.max(keep, 1))
    );
  }
  var ExtensionAccountRepository = class extends IndexedDbRepository {
    constructor() {
      super("extensionAccounts");
    }
    /**
     * The account directory is the one store that must be readable without an
     * account scope, because the scope itself is chosen from its contents. Every
     * account record is self-scoped (`accountId === id`), so this reads the
     * directory and never another account's data.
     */
    async listAllAccounts() {
      const db = await openDatabase();
      const stored = await requestResult(
        db.transaction("extensionAccounts").objectStore("extensionAccounts").getAll()
      );
      return stored.map(withoutStorageKey);
    }
    /**
     * Stores a new account only if no stored account has its JoyClub
     * identifier. The check and the write share one readwrite transaction, and
     * IndexedDB runs such transactions on this store one at a time, in every
     * extension context, so two creates can never both pass the check.
     * Returns `false`, writing nothing, for a duplicate.
     */
    async addIfIdentifierFree(account) {
      validateEntity("extensionAccounts", account);
      if (account.accountId !== account.id)
        throw new ValidationError("An account must be its own scope");
      const db = await openDatabase();
      const transaction = db.transaction("extensionAccounts", "readwrite");
      const store = transaction.objectStore("extensionAccounts");
      let added = false;
      await commitAll(transaction, async () => {
        const stored = await requestResult(
          store.getAll()
        );
        if (stored.some(
          (existing) => existing.joyClubAccountId === account.joyClubAccountId
        ))
          return;
        store.put({
          ...account,
          storageKey: storageKeyFor(account.id, account.id)
        });
        added = true;
      });
      return added;
    }
  };
  var JoyClubMemberRepository = class extends IndexedDbRepository {
    constructor() {
      super("joyClubMembers");
    }
  };
  var ProfileSnapshotRepository = class extends IndexedDbRepository {
    constructor() {
      super("profileSnapshots");
    }
    async applyRetention(store, accountId, entity, retention = PROFILE_SNAPSHOT_RETENTION) {
      const stored = await requestResult(
        store.index("accountId").getAll(accountId)
      );
      const member = stored.filter(
        (snapshot) => snapshot.memberId === entity.memberId
      );
      for (const obsolete of snapshotsBeyond(member, retention))
        store.delete(obsolete.storageKey);
    }
    /**
     * Keeps only the newest `keep` snapshots of every member in every account,
     * in one transaction: after the user lowers the setting, the snapshots
     * already stored follow it too. Returns how many were deleted.
     */
    async pruneAll(keep) {
      const db = await openDatabase();
      const transaction = db.transaction("profileSnapshots", "readwrite");
      const store = transaction.objectStore("profileSnapshots");
      let deleted = 0;
      await commitAll(transaction, async () => {
        const all = await requestResult(
          store.getAll()
        );
        for (const obsolete of snapshotsBeyond(all, keep)) {
          store.delete(obsolete.storageKey);
          deleted += 1;
        }
      });
      return deleted;
    }
  };
  var UserNoteRepository = class extends IndexedDbRepository {
    constructor() {
      super("userNotes");
    }
  };
  var UserTagRepository = class extends IndexedDbRepository {
    constructor() {
      super("userTags");
    }
  };
  var TrustSignalRepository = class extends IndexedDbRepository {
    constructor() {
      super("trustSignals");
    }
  };
  var ContactRuleRepository = class extends IndexedDbRepository {
    constructor() {
      super("contactRules");
    }
  };
  var ConversationClassificationRepository = class extends IndexedDbRepository {
    constructor() {
      super("conversationClassifications");
    }
  };
  var SavedSearchRepository = class extends IndexedDbRepository {
    constructor() {
      super("savedSearches");
    }
  };
  var EventMetadataRepository = class extends IndexedDbRepository {
    constructor() {
      super("eventMetadata");
    }
  };
  var SpendLogEntryRepository = class extends IndexedDbRepository {
    constructor() {
      super("spendLogEntries");
    }
  };
  var SyncConfigRepository = class extends IndexedDbRepository {
    constructor() {
      super("syncConfigs");
    }
  };
  var ExtensionPreferenceRepository = class extends IndexedDbRepository {
    constructor() {
      super("extensionPreferences");
    }
  };
  var MessageTemplateRepository = class extends IndexedDbRepository {
    constructor() {
      super("messageTemplates");
    }
  };
  var SpamPhraseRepository = class extends IndexedDbRepository {
    constructor() {
      super("spamPhrases");
    }
  };
  var MESSAGE_OBSERVATION_RETENTION_DAYS = 365;
  var MessageObservationRepository = class extends IndexedDbRepository {
    constructor() {
      super("messageObservations");
    }
    /**
     * The window is measured from this write, using `updatedAt`, which the
     * writer always sets to now. Measuring from the record's own `observedAt`
     * would let a caller backdate one message and drag the cutoff back with it,
     * keeping everything expired alive.
     *
     * The record being written is never purged here, so `put` cannot report
     * storing something this pass deleted in the same transaction.
     */
    async applyRetention(store, accountId, entity) {
      const cutoff = Date.parse(entity.updatedAt) - MESSAGE_OBSERVATION_RETENTION_DAYS * 24 * 60 * 60 * 1e3;
      const stored = await requestResult(
        store.index("accountId").getAll(accountId)
      );
      for (const observation of stored)
        if (observation.id !== entity.id && Date.parse(observation.observedAt) < cutoff)
          store.delete(observation.storageKey);
    }
  };
  var SenderSpamOverrideRepository = class extends IndexedDbRepository {
    constructor() {
      super("senderSpamOverrides");
    }
  };
  var ActionLogRepository = class extends IndexedDbRepository {
    constructor() {
      super("actionLogs");
    }
  };
  var MessagePhraseMatchRepository = class extends IndexedDbRepository {
    constructor() {
      super("messagePhraseMatches");
    }
  };
  var CachedMessageRepository = class extends IndexedDbRepository {
    constructor() {
      super("cachedMessages");
    }
    /**
     * Deletes every cached message, in every account, older than `cutoff`
     * (an ISO date), in one transaction. A message's age counts from when it
     * was sent, or from when it was stored when the page showed no time.
     * Returns how many were deleted.
     */
    async pruneOlderThan(cutoff) {
      const db = await openDatabase();
      const transaction = db.transaction("cachedMessages", "readwrite");
      const store = transaction.objectStore("cachedMessages");
      let deleted = 0;
      await commitAll(transaction, async () => {
        const all = await requestResult(
          store.getAll()
        );
        for (const message2 of all)
          if (Date.parse(messageTime(message2)) < Date.parse(cutoff)) {
            store.delete(message2.storageKey);
            deleted += 1;
          }
      });
      return deleted;
    }
  };
  var repositories = {
    extensionAccounts: new ExtensionAccountRepository(),
    joyClubMembers: new JoyClubMemberRepository(),
    profileSnapshots: new ProfileSnapshotRepository(),
    userNotes: new UserNoteRepository(),
    userTags: new UserTagRepository(),
    trustSignals: new TrustSignalRepository(),
    contactRules: new ContactRuleRepository(),
    conversationClassifications: new ConversationClassificationRepository(),
    savedSearches: new SavedSearchRepository(),
    eventMetadata: new EventMetadataRepository(),
    spendLogEntries: new SpendLogEntryRepository(),
    syncConfigs: new SyncConfigRepository(),
    extensionPreferences: new ExtensionPreferenceRepository(),
    messageTemplates: new MessageTemplateRepository(),
    spamPhrases: new SpamPhraseRepository(),
    messageObservations: new MessageObservationRepository(),
    senderSpamOverrides: new SenderSpamOverrideRepository(),
    actionLogs: new ActionLogRepository(),
    messagePhraseMatches: new MessagePhraseMatchRepository(),
    cachedMessages: new CachedMessageRepository()
  };
  async function deleteAccountEntities(accountId, names) {
    if (names.length === 0) return;
    const db = await openDatabase();
    const transaction = db.transaction([...names], "readwrite");
    await commitAll(transaction, async () => {
      for (const name of names) {
        const store = transaction.objectStore(name);
        const keys = await requestResult(
          store.index("accountId").getAllKeys(accountId)
        );
        for (const recordKey of keys) store.delete(recordKey);
      }
    });
  }
  async function deleteAccountData(accountId) {
    await deleteAccountEntities(accountId, ENTITY_NAMES);
  }

  // src/accounts/account-service.ts
  var ACTIVE_ACCOUNT_SETTING_KEY = "joyfox.activeAccountId";
  var AccountService = class {
    constructor(accounts2 = new ExtensionAccountRepository(), settings = runtimeSettingsArea, now = () => (/* @__PURE__ */ new Date()).toISOString(), newId = () => crypto.randomUUID()) {
      this.accounts = accounts2;
      this.settings = settings;
      this.now = now;
      this.newId = newId;
    }
    async listAccounts() {
      const accounts2 = await this.accounts.listAllAccounts();
      return accounts2.sort(
        (a, b) => a.createdAt.localeCompare(b.createdAt) || a.id.localeCompare(b.id)
      );
    }
    async createAccount(input) {
      const joyClubAccountId = input.joyClubAccountId.trim();
      if (joyClubAccountId.length === 0)
        throw new ExtensionError(
          "IdentityMismatch",
          "An account needs a non-empty identifier",
          { display: message("error.account.emptyIdentifier") }
        );
      const timestamp = this.now();
      const id = this.newId();
      const label = input.label?.trim();
      const account = {
        id,
        // An extension account is its own scope. Keeping `accountId` equal to
        // `id` means the account directory obeys the same scoping rule as every
        // other store instead of needing an exception.
        accountId: id,
        joyClubAccountId,
        ...label ? { label } : {},
        createdAt: timestamp,
        updatedAt: timestamp
      };
      await withAccountLock(id, async () => {
        if (!await this.accounts.addIfIdentifierFree(account))
          throw new ExtensionError(
            "IdentityMismatch",
            "That account identifier is already registered",
            { display: message("error.account.duplicate") }
          );
        if (await this.getActiveAccount() === void 0)
          await this.settings.set({ [ACTIVE_ACCOUNT_SETTING_KEY]: id });
      });
      return account;
    }
    /**
     * Changes only the display label. The JoyClub identifier never changes: an
     * import matches accounts by it. The label is checked as on create: it is
     * trimmed, and an empty one is dropped so the identifier shows instead.
     */
    async renameAccount(accountId, label) {
      const trimmed = label.trim();
      return withAccountLock(accountId, async () => {
        const account = await this.accounts.get(accountId, accountId);
        if (!account)
          throw new ExtensionError(
            "IdentityMismatch",
            "That account no longer exists",
            { display: message("error.account.gone") }
          );
        const renamed = { ...account, updatedAt: this.now() };
        delete renamed.label;
        if (trimmed) renamed.label = trimmed;
        await this.accounts.put(accountId, renamed);
        return renamed;
      });
    }
    async getActiveAccountId() {
      const stored = await this.settings.get([ACTIVE_ACCOUNT_SETTING_KEY]);
      const value = stored[ACTIVE_ACCOUNT_SETTING_KEY];
      return typeof value === "string" && value.length > 0 ? value : void 0;
    }
    /**
     * Returns the active account only when the pointer still resolves to a
     * stored account. A dangling pointer yields `undefined` so the caller shows
     * "no active account" rather than operating on an unknown scope.
     */
    async getActiveAccount() {
      const activeId = await this.getActiveAccountId();
      if (!activeId) return void 0;
      return this.accounts.get(activeId, activeId);
    }
    /**
     * Holds the locks of the account being left and the account being
     * activated. A write that checked, under its account's lock, that its
     * account is active therefore finishes before the switch, or sees the
     * switch and refuses.
     */
    async setActiveAccount(accountId) {
      for (; ; ) {
        const current = await this.getActiveAccountId();
        const switched = await withAccountLocks(
          current ? [current, accountId] : [accountId],
          async () => {
            if (await this.getActiveAccountId() !== current) return false;
            if (await this.accounts.get(accountId, accountId) === void 0)
              throw new ExtensionError(
                "IdentityMismatch",
                "Cannot activate an account that is not registered",
                { display: message("error.account.notRegistered") }
              );
            await this.settings.set({ [ACTIVE_ACCOUNT_SETTING_KEY]: accountId });
            return true;
          }
        );
        if (switched) return;
      }
    }
    async clearActiveAccount() {
      await this.settings.remove([ACTIVE_ACCOUNT_SETTING_KEY]);
    }
    /**
     * Removes the account and every record scoped to it. The pointer is cleared
     * first so an interrupted delete can never leave the extension active on a
     * half-removed scope. No other account becomes active. Returns whether the
     * removed account was the active one, so the caller can say so.
     */
    async deleteAccount(accountId) {
      return withAccountLock(accountId, async () => {
        const wasActive = await this.getActiveAccountId() === accountId;
        if (wasActive) await this.clearActiveAccount();
        await deleteAccountData(accountId);
        return wasActive;
      });
    }
  };

  // src/actions/ignore-delete.ts
  var QUICK_IGNORE_DELETE = "quick-ignore-delete";
  var QUICK_DELETE = "quick-delete";
  var QUICK_ACTIONS = [
    QUICK_IGNORE_DELETE,
    QUICK_DELETE
  ];
  var isQuickAction = (value) => QUICK_ACTIONS.includes(value);
  var ACTION_STATES = [
    "Started",
    "DeleteRequested",
    "DeleteConfirmed",
    "IgnoreRequested",
    "IgnoreConfirmed",
    "Completed",
    "Failed"
  ];
  var NEXT = {
    [QUICK_IGNORE_DELETE]: {
      Started: "DeleteRequested",
      DeleteRequested: "DeleteConfirmed",
      DeleteConfirmed: "IgnoreRequested",
      IgnoreRequested: "IgnoreConfirmed",
      IgnoreConfirmed: "Completed"
    },
    // Delete alone: `Started`, `DeleteRequested`, `DeleteConfirmed`,
    // `Completed`, or `Failed` from any state that is not terminal.
    [QUICK_DELETE]: {
      Started: "DeleteRequested",
      DeleteRequested: "DeleteConfirmed",
      DeleteConfirmed: "Completed"
    }
  };
  var isTerminal = (state2) => state2 === "Completed" || state2 === "Failed";
  function canTransition(from, to, action2 = QUICK_IGNORE_DELETE) {
    if (isTerminal(from)) return false;
    return to === "Failed" || NEXT[action2][from] === to;
  }
  var ACTION_FAILURES = [
    "control-missing",
    "confirmation-missing",
    "not-verified",
    "unverifiable",
    "member-mismatch",
    "conversation-mismatch",
    "identity-unavailable",
    "account-changed",
    "turned-off",
    "superseded",
    "log-unavailable",
    "handoff-failed",
    "timeout",
    "step-error"
  ];
  var STEP_ORDER = ["delete", "ignore"];
  var ACTION_STEPS = {
    [QUICK_IGNORE_DELETE]: STEP_ORDER,
    [QUICK_DELETE]: ["delete"]
  };
  var STEP_STATES = {
    ignore: { requested: "IgnoreRequested", confirmed: "IgnoreConfirmed" },
    delete: { requested: "DeleteRequested", confirmed: "DeleteConfirmed" }
  };
  var STEP_TIMEOUT_MS = 15e3;
  var STALE_AFTER_MS = 12e4;
  var STARTED_STALE_AFTER_MS = 2 * STEP_TIMEOUT_MS;
  function staleAfterMs(last) {
    return last === "Started" ? STARTED_STALE_AFTER_MS : STALE_AFTER_MS;
  }
  function outcome(steps, step) {
    const names = new Set(steps.map((item) => item.name));
    const states = STEP_STATES[step];
    if (names.has(states.confirmed)) return "done";
    if (names.has(states.requested)) return "unknown";
    return "not-done";
  }
  function failureText(failure2, step, outcome2) {
    const name = message(`action.step.${step}`);
    const where = message(
      outcome2 === "not-done" ? "action.where.before" : "action.where.during",
      { step: name }
    );
    switch (failure2) {
      case "control-missing":
      case "confirmation-missing":
      case "not-verified":
      case "timeout":
        return message(`action.failure.${failure2}`, { step: name });
      case "unverifiable":
        return message("action.failure.unverifiable", { step: name, where });
      default:
        return message(`action.failure.${failure2}`, { where });
    }
  }
  var stepText = (step, outcome2) => message(`action.stepText.${step}.${outcome2}`);
  var actionOf = (log) => log.action === QUICK_DELETE ? QUICK_DELETE : QUICK_IGNORE_DELETE;
  function reportOperation(log, now) {
    const action2 = actionOf(log);
    const steps = log.steps;
    const last = steps.at(-1);
    const lastState = last?.name;
    const ignore = outcome(steps, "ignore");
    const remove = outcome(steps, "delete");
    const failure2 = lastState === "Failed" && ACTION_FAILURES.includes(last?.errorCode) ? last?.errorCode : void 0;
    const lastAt = Date.parse(last?.at ?? log.updatedAt);
    const status = lastState === "Completed" ? "completed" : lastState === "Failed" ? "failed" : !Number.isFinite(lastAt) || now - lastAt > staleAfterMs(lastState) ? "interrupted" : "running";
    if (action2 === QUICK_DELETE)
      return deleteReport(status, remove, ignore, failure2);
    const lines = [];
    if (status === "completed") {
      lines.push(message("action.report.finished"), stepText("delete", "done"));
      lines.push(stepText("ignore", "done"), message("action.report.undo"));
      return { status, ignore, delete: remove, lines };
    }
    if (status === "running") {
      lines.push(message("action.report.running"));
      return { status, ignore, delete: remove, lines };
    }
    lines.push(
      message(
        status === "failed" ? "action.report.stopped" : "action.report.interrupted"
      )
    );
    if (failure2) {
      const step = remove === "done" ? "ignore" : "delete";
      lines.push(failureText(failure2, step, step === "ignore" ? ignore : remove));
      if (failure2 === "unverifiable" && step === "delete")
        lines.push(message("action.next.showList"));
    }
    lines.push(stepText("delete", remove), stepText("ignore", ignore));
    const untouched = ignore === "not-done" && remove === "not-done";
    lines.push(
      message(
        untouched ? "action.report.nothingChanged" : "action.report.notUndone"
      )
    );
    if (untouched) {
      lines.push(message("action.self.delete"), message("action.self.ignore"));
    } else {
      if (remove !== "done") lines.push(message("action.next.delete"));
      if (ignore !== "done") lines.push(message("action.next.ignore"));
    }
    return {
      status,
      ignore,
      delete: remove,
      ...failure2 ? { failure: failure2 } : {},
      lines
    };
  }
  function deleteReport(status, remove, ignore, failure2) {
    const lines = [];
    if (status === "completed") {
      lines.push(
        message("action.deleteReport.finished"),
        stepText("delete", "done"),
        message("action.deleteReport.undo")
      );
      return { status, ignore, delete: remove, lines };
    }
    if (status === "running") {
      lines.push(message("action.deleteReport.running"));
      return { status, ignore, delete: remove, lines };
    }
    lines.push(
      message(
        status === "failed" ? "action.deleteReport.stopped" : "action.deleteReport.interrupted"
      )
    );
    if (failure2) {
      lines.push(failureText(failure2, "delete", remove));
      if (failure2 === "unverifiable") lines.push(message("action.next.showList"));
    }
    lines.push(stepText("delete", remove));
    const untouched = remove === "not-done";
    lines.push(
      message(
        untouched ? "action.report.nothingChanged" : "action.report.notUndone"
      ),
      message(untouched ? "action.self.delete" : "action.next.delete")
    );
    return {
      status,
      ignore,
      delete: remove,
      ...failure2 ? { failure: failure2 } : {},
      lines
    };
  }

  // src/actions/action-log-service.ts
  function requireAccountId(accountId) {
    if (accountId.trim().length === 0)
      throw new ExtensionError(
        "IdentityMismatch",
        "An action needs an explicit active account"
      );
  }
  var newestFirst = (a, b) => Date.parse(b.createdAt) - Date.parse(a.createdAt) || b.id.localeCompare(a.id);
  var ActionLogService = class {
    constructor(logs = new ActionLogRepository(), members2 = new JoyClubMemberRepository(), now = () => (/* @__PURE__ */ new Date()).toISOString(), newId = () => crypto.randomUUID()) {
      this.logs = logs;
      this.members = members2;
      this.now = now;
      this.newId = newId;
    }
    #sequence = 0;
    /**
     * Start an operation, unless one for the same member is still running (in
     * another tab, for example), whichever action it is: only one trash run
     * at a time. One that stopped moving counts as interrupted and does not
     * block a new start.
     */
    async begin(accountId, target, action2 = QUICK_IGNORE_DELETE) {
      requireAccountId(accountId);
      const previous = await this.latest(accountId, target.memberId);
      const at = this.now();
      if (previous) {
        const report = reportOperation(previous, Date.parse(at));
        if (report.status === "running") return { status: "busy", report };
      }
      this.#sequence += 1;
      const operationId2 = `action:${at}:${String(this.#sequence).padStart(6, "0")}:${this.newId()}`;
      await registerMember(this.members, accountId, target.memberId, at);
      await this.logs.put(accountId, {
        id: operationId2,
        accountId,
        memberId: target.memberId,
        conversationId: target.conversationId,
        action: action2,
        steps: [{ name: "Started", ok: true, at }],
        createdAt: at,
        updatedAt: at
      });
      return { status: "started", operationId: operationId2 };
    }
    /**
     * Append one transition. `Failed` needs a reason and no other state may
     * carry one. Only the member's newest run may move: a run that read as
     * interrupted (its tab was suspended, for example) and was replaced by a
     * newer one is refused if its tab resumes, so two runs never act on one
     * member at once.
     */
    async record(accountId, operationId2, state2, failure2) {
      requireAccountId(accountId);
      const log = await this.logs.get(accountId, operationId2);
      if (!log || !isQuickAction(log.action)) return "unknown-operation";
      const last = log.steps.at(-1)?.name;
      if (!last || !canTransition(last, state2, log.action)) return "invalid";
      if (state2 === "Failed" !== (failure2 !== void 0)) return "invalid";
      if (log.memberId) {
        const newest = await this.latest(accountId, log.memberId);
        if (newest && newest.id !== log.id) return "superseded";
      }
      const at = this.now();
      await this.logs.put(accountId, {
        ...log,
        steps: [
          ...log.steps,
          {
            name: state2,
            ok: state2 !== "Failed",
            at,
            ...failure2 ? { errorCode: failure2 } : {}
          }
        ],
        updatedAt: at
      });
      return "recorded";
    }
    /** One operation by ID, or `undefined` when it is not a quick action. */
    async find(accountId, operationId2) {
      requireAccountId(accountId);
      const log = await this.logs.get(accountId, operationId2);
      return isQuickAction(log?.action) ? log : void 0;
    }
    /**
     * The newest operation for one member, Quick Ignore and Delete or Delete
     * alone: both act on the member's conversation, so a newer one of either
     * replaces an older one.
     */
    async latest(accountId, memberId2) {
      requireAccountId(accountId);
      const logs = await this.logs.list(accountId);
      return logs.filter((log) => isQuickAction(log.action) && log.memberId === memberId2).sort(newestFirst)[0];
    }
  };

  // src/compatibility/compatibility-service.ts
  var CompatibilityService = class {
    constructor(snapshots = new ProfileSnapshotRepository()) {
      this.snapshots = snapshots;
    }
    async lookup(accountId, memberIds) {
      const all = await this.snapshots.list(accountId);
      const newestOwn = newestSnapshot(
        all.filter((snapshot) => snapshot.ownProfile === true)
      );
      const ownLatest = newestOwn ? newestSnapshot(
        all.filter((snapshot) => snapshot.memberId === newestOwn.memberId)
      ) : void 0;
      const own = ownLatest?.positivePreferences ?? null;
      const byMember = /* @__PURE__ */ new Map();
      for (const snapshot of all) {
        const group = byMember.get(snapshot.memberId);
        if (group) group.push(snapshot);
        else byMember.set(snapshot.memberId, [snapshot]);
      }
      const shared = {};
      for (const memberId2 of new Set(memberIds)) {
        const theirs = newestSnapshot(
          byMember.get(memberId2) ?? []
        )?.positivePreferences;
        shared[memberId2] = own && theirs && memberId2 !== newestOwn?.memberId ? sharedPreferences(own, theirs).length : null;
      }
      return {
        accountId,
        own,
        ownMemberId: newestOwn?.memberId ?? null,
        shared
      };
    }
  };

  // src/storage/revision.ts
  async function bumpRevision(key2, settings = runtimeSettingsArea) {
    try {
      await settings.set({ [key2]: crypto.randomUUID() });
    } catch {
    }
  }

  // src/storage/message-revision.ts
  var MESSAGE_REVISION_KEY = "joyfox.messageRevision";
  var bumpMessageRevision = (settings) => bumpRevision(MESSAGE_REVISION_KEY, settings);

  // src/messages/message-cache-service.ts
  var searchable = (text) => text.replace(/\s+/gu, " ").trim().toLocaleLowerCase("de");
  var MessageCacheService = class {
    constructor(settings, messages = new CachedMessageRepository(), now = () => /* @__PURE__ */ new Date()) {
      this.settings = settings;
      this.messages = messages;
      this.now = now;
    }
    async store(accountId, conversationId2, memberId2, seen) {
      const { caching, retentionMonths } = await readMessageSettings(
        this.settings
      );
      if (!caching) return { status: "off" };
      const now = this.now();
      const timestamp = now.toISOString();
      const cutoff = Date.parse(retentionCutoff(now, retentionMonths));
      let stored = 0;
      for (const message2 of seen) {
        const id = `message:${message2.messageId}`;
        const existing = await this.messages.get(accountId, id);
        const sentAt = message2.sentAt ?? existing?.sentAt;
        if (sentAt && Date.parse(sentAt) < cutoff) continue;
        if (existing && existing.conversationId !== conversationId2) continue;
        if (existing && existing.text === message2.text && existing.sentAt === sentAt)
          continue;
        await this.messages.put(accountId, {
          id,
          accountId,
          messageId: message2.messageId,
          conversationId: conversationId2,
          memberId: memberId2,
          direction: message2.direction,
          ...sentAt ? { sentAt } : {},
          text: message2.text,
          createdAt: existing?.createdAt ?? timestamp,
          updatedAt: timestamp
        });
        stored += 1;
      }
      const deleted = await this.prune();
      return { status: "stored", stored, deleted };
    }
    /**
     * Every stored message of the account that contains the query, newest
     * first. Case and spacing do not matter. An empty query finds nothing.
     */
    async search(accountId, query) {
      const needle = searchable(query);
      if (!needle) return { messages: [] };
      const all = await this.messages.list(accountId);
      return {
        messages: all.filter((message2) => searchable(message2.text).includes(needle)).sort(
          (a, b) => Date.parse(messageTime(b)) - Date.parse(messageTime(a)) || a.id.localeCompare(b.id)
        )
      };
    }
    /**
     * Deletes every message older than the window now in effect. A deletion
     * sets the message revision, so open options pages ("Messages" and "Your
     * data") drop what is gone.
     */
    async prune() {
      const { retentionMonths } = await readMessageSettings(this.settings);
      const deleted = await this.messages.pruneOlderThan(
        retentionCutoff(this.now(), retentionMonths)
      );
      if (deleted > 0) await bumpMessageRevision(this.settings);
      return deleted;
    }
    /** Saves the window, then deletes what is older at once. */
    async setRetention(months) {
      if (!isMessageRetention(months))
        throw new RangeError("Invalid message retention");
      await this.settings.set({ [MESSAGE_RETENTION_KEY]: months });
      return this.prune();
    }
  };

  // src/messaging/router.ts
  function failureOf(error) {
    if (!(error instanceof Error)) return { name: typeof error };
    return {
      name: error.name,
      message: error.message,
      ...error.stack ? { stack: error.stack } : {}
    };
  }
  var MessageRouter = class {
    #handlers = /* @__PURE__ */ new Map();
    register(type, handler) {
      this.#handlers.set(
        type,
        handler
      );
    }
    async route(message2, context = {}) {
      if (!message2 || typeof message2.type !== "string" || typeof message2.requestId !== "string") {
        return {
          requestId: message2?.requestId ?? "invalid",
          ok: false,
          error: { code: "INVALID_MESSAGE", message: "Invalid message envelope" }
        };
      }
      const handler = this.#handlers.get(message2.type);
      if (!handler)
        return {
          requestId: message2.requestId,
          ok: false,
          error: { code: "UNKNOWN_MESSAGE", message: "Unsupported message type" }
        };
      try {
        return {
          requestId: message2.requestId,
          ok: true,
          payload: await handler(message2.payload, context)
        };
      } catch (error) {
        console.error("JoyFox: request failed", message2.type, failureOf(error));
        return {
          requestId: message2.requestId,
          ok: false,
          error: {
            code: "HANDLER_FAILED",
            message: "The request could not be completed"
          }
        };
      }
    }
  };

  // src/trust/trust-score.ts
  function computeTrustScore(input) {
    const contributions = [];
    const count = (kind) => input.signals.filter((signal) => signal.kind === kind).length;
    const positive = count("positive");
    const negative = count("negative");
    const neutral = count("neutral");
    if (positive > 0)
      contributions.push({
        points: positive,
        reason: message("trust.reason.positive", { count: positive })
      });
    if (negative > 0)
      contributions.push({
        points: -negative,
        reason: message("trust.reason.negative", { count: negative })
      });
    if (neutral > 0)
      contributions.push({
        points: 0,
        reason: message("trust.reason.neutral", { count: neutral })
      });
    if (input.personallyKnown === true)
      contributions.push({
        points: 1,
        reason: message("trust.reason.personallyKnown")
      });
    if (input.spam === "flagged")
      contributions.push({
        points: -1,
        reason: message("trust.reason.spamFlagged")
      });
    if (contributions.length === 0) return "unknown";
    return {
      score: contributions.reduce((sum, item) => sum + item.points, 0),
      contributions,
      logged: positive + negative + neutral
    };
  }

  // src/rules/presets.ts
  var COMPLETE_PROFILE = { photos: 3, words: 50 };
  var HIGH_TRUST_ACCOUNT_DAYS = 180;
  var PRESET_CONDITIONS = {
    open: [],
    complete: [
      ["minimumPhotos", COMPLETE_PROFILE.photos],
      ["minimumProfileWords", COMPLETE_PROFILE.words]
    ],
    verified: [["verified"]],
    highTrust: [
      ["verified"],
      ["minimumPhotos", COMPLETE_PROFILE.photos],
      ["minimumProfileWords", COMPLETE_PROFILE.words],
      ["minimumAccountAgeDays", HIGH_TRUST_ACCOUNT_DAYS]
    ],
    custom: []
  };

  // src/signals/completeness.ts
  function completeness(facts) {
    const { photoCount, profileWordCount, verification } = facts;
    const below = photoCount !== "unknown" && photoCount < COMPLETE_PROFILE.photos || profileWordCount !== "unknown" && profileWordCount < COMPLETE_PROFILE.words;
    const known = photoCount !== "unknown" && profileWordCount !== "unknown";
    return {
      state: below ? "incomplete" : known ? "complete" : "unknown",
      photoCount,
      profileWordCount,
      verification
    };
  }

  // src/signals/met-in-person.ts
  var MET_IN_PERSON_KEY = "metInPerson";
  var metInPersonId = (memberId2) => `met-in-person:${memberId2}`;

  // src/signals/signals-service.ts
  var MAX_SIGNAL_MEMBERS = 500;
  function groupBy(items) {
    const groups = /* @__PURE__ */ new Map();
    for (const item of items) {
      const group = groups.get(item.memberId);
      if (group) group.push(item);
      else groups.set(item.memberId, [item]);
    }
    return groups;
  }
  var SignalsService = class {
    constructor(snapshots = new ProfileSnapshotRepository(), notes = new UserNoteRepository(), tags = new UserTagRepository(), trustSignals = new TrustSignalRepository(), spamOverrides = new SenderSpamOverrideRepository(), preferences = new ExtensionPreferenceRepository()) {
      this.snapshots = snapshots;
      this.notes = notes;
      this.tags = tags;
      this.trustSignals = trustSignals;
      this.spamOverrides = spamOverrides;
      this.preferences = preferences;
    }
    async lookup(accountId, members2) {
      const [snapshots, notes, tags, signals, overrides, preferences] = await Promise.all([
        this.snapshots.list(accountId),
        this.notes.list(accountId),
        this.tags.list(accountId),
        this.trustSignals.list(accountId),
        this.spamOverrides.list(accountId),
        this.preferences.list(accountId)
      ]);
      const metInPerson = new Set(
        preferences.filter((item) => item.key === MET_IN_PERSON_KEY).map((item) => item.value)
      );
      const snapshotsBy = groupBy(snapshots);
      const signalsBy = groupBy(signals);
      const tagsBy = groupBy(tags);
      const noted = new Set(notes.map((note) => note.memberId));
      const notSpam = new Set(overrides.map((item) => item.memberId));
      const answer = {};
      for (const { memberId: memberId2, observed: observed3, noShield } of members2) {
        const { facts } = mergeProfileFacts(
          observed3,
          newestSnapshot(snapshotsBy.get(memberId2) ?? [])
        );
        if (noShield && facts.personallyKnown === "unknown")
          facts.personallyKnown = metInPerson.has(memberId2);
        answer[memberId2] = {
          completeness: completeness(facts),
          trust: computeTrustScore({
            signals: signalsBy.get(memberId2) ?? [],
            spam: notSpam.has(memberId2) ? "overridden" : "unknown",
            personallyKnown: facts.personallyKnown
          }),
          hasNote: noted.has(memberId2),
          tags: (tagsBy.get(memberId2) ?? []).map((tag) => tag.label).sort((a, b) => a.localeCompare(b))
        };
      }
      return answer;
    }
  };

  // src/storage/session-area.ts
  function sessionArea() {
    const area = globalThis.browser?.storage?.session;
    if (!area)
      throw new ExtensionError(
        "StorageError",
        "browser.storage.session is unavailable in this context"
      );
    return area;
  }
  var runtimeSessionArea = {
    async get(keys) {
      return await sessionArea().get(keys);
    },
    async set(items) {
      await sessionArea().set(items);
    },
    async remove(keys) {
      await sessionArea().remove(keys);
    },
    async getAll() {
      return await sessionArea().get(null);
    },
    async clear() {
      await sessionArea().clear();
    }
  };

  // src/events/event-service.ts
  var EventTrackerService = class {
    constructor(listings = new EventMetadataRepository(), now = () => (/* @__PURE__ */ new Date()).toISOString()) {
      this.listings = listings;
      this.now = now;
    }
    async get(accountId, kind, id) {
      return (await this.#find(accountId, kind, id))?.record;
    }
    /**
     * The stored record for one listing. A record from before V1-5 (imported,
     * with no `kind`) can have another key than `event:<id>`; it is found by
     * its event ID, and `save` moves it to the new key.
     */
    async #find(accountId, kind, id) {
      const key2 = listingRecordId(kind, id);
      const record = await this.listings.get(accountId, key2);
      if (record) return { key: key2, record };
      if (kind !== "event") return void 0;
      const legacy = (await this.listings.list(accountId)).find(
        (item) => item.kind === void 0 && item.eventId === id
      );
      return legacy ? { key: legacy.id, record: legacy } : void 0;
    }
    /**
     * The new version of a record: the time now, but always later than the
     * stored version. Two saves in one clock tick then still give two
     * versions, so a stale editor cannot match the second one.
     */
    #version(existing) {
      const now = this.now();
      const stored = existing ? Date.parse(existing.updatedAt) : Number.NaN;
      if (Number.isNaN(stored) || Date.parse(now) > stored) return now;
      return new Date(stored + 1).toISOString();
    }
    async list(accountId) {
      return (await this.listings.list(accountId)).sort(compareListings);
    }
    /**
     * Store the user's notes on one listing. `expectedUpdatedAt` is the
     * version the editor was drawn from (`null`: no record); a record changed
     * since is not overwritten. Notes left empty (no note, no tags, no
     * attendance) remove the record, so the listing is no longer tracked.
     */
    async save(accountId, kind, id, notes, facts, expectedUpdatedAt) {
      const recordId = listingRecordId(kind, id);
      const found = await this.#find(accountId, kind, id);
      const existing = found?.record;
      if ((existing?.updatedAt ?? null) !== expectedUpdatedAt)
        return { status: "conflict", record: existing };
      const note = notes.note.trim();
      const tags = cleanTags(notes.tags);
      const attendance = kind === "venue" ? "unknown" : notes.attendance;
      if (!note && tags.length === 0 && attendance === "unknown") {
        if (found) await this.listings.delete(accountId, found.key);
        return { status: "removed" };
      }
      const timestamp = this.#version(existing);
      const title = cutListingText(facts.title) ?? existing?.title;
      const startLocal = facts.startLocal ?? existing?.startLocal;
      const path = facts.path ?? existing?.path;
      const venueId = facts.venueId ?? existing?.venueId;
      const venueName = cutListingText(facts.venueName) ?? existing?.venueName;
      const record = {
        id: recordId,
        accountId,
        eventId: id,
        kind,
        ...title ? { title } : {},
        ...startLocal ? { startLocal } : {},
        ...path ? { path } : {},
        ...venueId ? { venueId } : {},
        ...venueName ? { venueName } : {},
        ...note ? { note } : {},
        tags,
        attendance,
        // The guest list read earlier stays while the event is tracked.
        ...existing?.attendees ? { attendees: existing.attendees } : {},
        ...existing?.attendeesSeenAt ? { attendeesSeenAt: existing.attendeesSeenAt } : {},
        createdAt: existing?.createdAt ?? timestamp,
        updatedAt: timestamp
      };
      await this.listings.put(accountId, record);
      if (found && found.key !== recordId)
        await this.listings.delete(accountId, found.key);
      return { status: "saved", record };
    }
    /**
     * V1-13: add the member IDs a tracked event's guest list showed to the
     * ones read before (PRD 9.3). Only a tracked event keeps them. The notes'
     * version (`updatedAt`) does not change, so an open editor is not told of a
     * conflict it could not see.
     */
    async recordAttendees(accountId, eventId, memberIds) {
      const found = await this.#find(accountId, "event", eventId);
      if (!found || kindOf(found.record) !== "event") return "untracked";
      const known = found.record.attendees ?? [];
      const merged = [.../* @__PURE__ */ new Set([...known, ...memberIds])].sort();
      const kept = merged.length > MAX_EVENT_ATTENDEES ? [
        ...known,
        ...merged.filter((id) => !known.includes(id)).slice(0, MAX_EVENT_ATTENDEES - known.length)
      ].sort() : merged;
      if (kept.length === known.length) return "unchanged";
      await this.listings.put(accountId, {
        ...found.record,
        attendees: kept,
        attendeesSeenAt: this.now()
      });
      return "stored";
    }
    /** V1-13: the tracked events whose stored guest list names a member. */
    async forMember(accountId, memberId2) {
      return (await this.list(accountId)).filter(
        (record) => kindOf(record) === "event" && (record.attendees ?? []).includes(memberId2)
      );
    }
  };

  // src/identity/member-identity.ts
  var unresolved = (reason) => ({
    status: "unresolved",
    reason
  });
  function isUsableIdentifier(value) {
    return value.length > 0 && value.length <= 128 && value === value.trim() && // eslint-disable-next-line no-control-regex
    !/[\s\u0000-\u001f\u007f]/.test(value);
  }
  function knownMemberIdentity(memberId2, source) {
    return isUsableIdentifier(memberId2) ? { status: "resolved", memberId: memberId2, source } : unresolved("invalid");
  }
  var IDENTITY_UNAVAILABLE_TEXT = {
    "not-identity-field": "Saving is off because this page field does not identify a member. Nothing was stored.",
    "selector-unverified": "Saving is off because this page has no verified member identifier yet. Nothing was stored.",
    "unstable-identifier": "Saving is off because only a display name is available, which is not a stable identity. Nothing was stored.",
    missing: "Saving is off because the member identifier was not found on this page. Nothing was stored.",
    invalid: "Saving is off because the member identifier on this page could not be read. Nothing was stored."
  };

  // src/identity/persistence-outcome.ts
  function disabled(reason) {
    return {
      status: "disabled",
      reason,
      message: IDENTITY_UNAVAILABLE_TEXT[reason]
    };
  }
  var ok = (value) => ({
    status: "ok",
    value
  });

  // src/notes/notes-service.ts
  var noteId = (memberId2) => `note:${encodeURIComponent(memberId2)}`;
  var tagId = (memberId2, tagKey2) => `tag:${encodeURIComponent(memberId2)}:${encodeURIComponent(tagKey2)}`;
  function normalizeTagLabel(label) {
    return label.trim().replace(/\s+/gu, " ");
  }
  var tagKeyFor = (label) => normalizeTagLabel(label).toLowerCase();
  function requireAccountId2(accountId) {
    if (accountId.trim().length === 0)
      throw new ExtensionError(
        "IdentityMismatch",
        "A note or tag needs an explicit active account"
      );
  }
  var NotesService = class {
    constructor(notes = new UserNoteRepository(), tags = new UserTagRepository(), members2 = new JoyClubMemberRepository(), now = () => (/* @__PURE__ */ new Date()).toISOString()) {
      this.notes = notes;
      this.tags = tags;
      this.members = members2;
      this.now = now;
    }
    /**
     * Record the member the note or tag belongs to, so an export carries the
     * member directory the notes reference rather than dangling member IDs.
     */
    async #ensureMember(accountId, memberId2) {
      const existing = await this.members.get(accountId, memberId2);
      if (existing) return;
      const timestamp = this.now();
      const member = {
        id: memberId2,
        accountId,
        joyClubMemberId: memberId2,
        createdAt: timestamp,
        updatedAt: timestamp
      };
      await this.members.put(accountId, member);
    }
    async readNote(accountId, identity) {
      requireAccountId2(accountId);
      if (identity.status === "unresolved") return disabled(identity.reason);
      return ok(await this.notes.get(accountId, noteId(identity.memberId)));
    }
    /**
     * Saves the note, or removes it when the body is empty. An empty body is a
     * deletion rather than an empty record so "cleared" and "never written" look
     * the same in the data inspector and in an export.
     */
    async saveNote(accountId, identity, body) {
      requireAccountId2(accountId);
      if (identity.status === "unresolved") return disabled(identity.reason);
      const trimmed = body.trim();
      if (trimmed.length > MAX_NOTE_LENGTH)
        throw new ExtensionError(
          "StorageError",
          `A note may not exceed ${MAX_NOTE_LENGTH} characters`
        );
      const id = noteId(identity.memberId);
      if (trimmed.length === 0) {
        await this.notes.delete(accountId, id);
        return ok(void 0);
      }
      const existing = await this.notes.get(accountId, id);
      const timestamp = this.now();
      const note = {
        id,
        accountId,
        memberId: identity.memberId,
        body: trimmed,
        createdAt: existing?.createdAt ?? timestamp,
        updatedAt: timestamp
      };
      await this.#ensureMember(accountId, identity.memberId);
      await this.notes.put(accountId, note);
      return ok(note);
    }
    /**
     * Save only if the stored note still has the text the editor was drawn
     * from (`null`: no note). A save from another tab, or a delete in the data
     * inspector, is then never overwritten unseen. Text is compared rather
     * than a timestamp, so two saves in one millisecond cannot hide a change,
     * and a save over identical text is let through. The caller holds the
     * account lock, so nothing writes between the check and the save.
     */
    async saveNoteIfUnchanged(accountId, identity, body, expectedBody2) {
      requireAccountId2(accountId);
      if (identity.status === "unresolved") return disabled(identity.reason);
      const current = (await this.notes.get(accountId, noteId(identity.memberId)))?.body ?? null;
      if (current !== expectedBody2) return ok({ status: "conflict", current });
      const saved = await this.saveNote(accountId, identity, body);
      if (saved.status === "disabled") return disabled(saved.reason);
      return ok({ status: "saved", current: saved.value?.body ?? null });
    }
    async deleteNote(accountId, identity) {
      requireAccountId2(accountId);
      if (identity.status === "unresolved") return disabled(identity.reason);
      await this.notes.delete(accountId, noteId(identity.memberId));
      return ok(void 0);
    }
    async listTags(accountId, identity) {
      requireAccountId2(accountId);
      if (identity.status === "unresolved") return disabled(identity.reason);
      const all = await this.tags.list(accountId);
      return ok(
        all.filter((tag) => tag.memberId === identity.memberId).sort((a, b) => tagKeyFor(a.label).localeCompare(tagKeyFor(b.label)))
      );
    }
    /**
     * Adding an existing tag keeps the stored label and does not duplicate it.
     * The result says so, so the editor does not report a tag as added.
     */
    async addTag(accountId, identity, label) {
      requireAccountId2(accountId);
      if (identity.status === "unresolved") return disabled(identity.reason);
      const normalized = normalizeTagLabel(label);
      if (normalized.length === 0)
        throw new ExtensionError("StorageError", "A tag needs a label");
      if (normalized.length > MAX_TAG_LENGTH)
        throw new ExtensionError(
          "StorageError",
          `A tag may not exceed ${MAX_TAG_LENGTH} characters`
        );
      const id = tagId(identity.memberId, tagKeyFor(normalized));
      const existing = await this.tags.get(accountId, id);
      if (existing) return ok({ tag: existing, added: false });
      const timestamp = this.now();
      const tag = {
        id,
        accountId,
        memberId: identity.memberId,
        label: normalized,
        createdAt: timestamp,
        updatedAt: timestamp
      };
      await this.#ensureMember(accountId, identity.memberId);
      await this.tags.put(accountId, tag);
      return ok({ tag, added: true });
    }
    async removeTag(accountId, identity, label) {
      requireAccountId2(accountId);
      if (identity.status === "unresolved") return disabled(identity.reason);
      await this.tags.delete(
        accountId,
        tagId(identity.memberId, tagKeyFor(label))
      );
      return ok(void 0);
    }
  };

  // src/search/saved-search.ts
  var MAX_SAVED_SEARCH_NAME_LENGTH = 80;
  var MAX_SAVED_SEARCHES = 50;
  var MAX_SAVED_SEARCH_URL_LENGTH = 2e3;
  var NO_MATCH = { status: "no-match" };
  function decode(segment) {
    try {
      return decodeURIComponent(segment);
    } catch {
      return segment;
    }
  }
  function readSearchAddress(url) {
    const definition = selectorRegistry.search;
    if (definition.status !== "verified" || !definition.path || url.length > MAX_SAVED_SEARCH_URL_LENGTH)
      return NO_MATCH;
    let parsed;
    try {
      parsed = new URL(url);
    } catch {
      return NO_MATCH;
    }
    if (parsed.protocol !== "https:" || parsed.username !== "" || parsed.password !== "" || parsed.port !== "" || !VERIFIED_HOSTS.includes(parsed.hostname) || !new RegExp(definition.path).test(parsed.pathname))
      return NO_MATCH;
    return {
      status: "ok",
      url: parsed.href,
      filters: {
        path: parsed.pathname.split("/").slice(2).filter((segment) => segment.length > 0).map(decode),
        query: queryPairs(parsed.searchParams)
      }
    };
  }
  function queryPairs(params) {
    const pairs = [];
    params.forEach((value, name) => pairs.push([name, value]));
    return pairs;
  }
  var normalizeSearchName = (name) => name.trim().replace(/\s+/gu, " ");

  // src/search/saved-search-service.ts
  function compareSearches(a, b) {
    return a.name.localeCompare(b.name) || a.id.localeCompare(b.id);
  }
  var SavedSearchService = class {
    constructor(searches = new SavedSearchRepository(), now = () => (/* @__PURE__ */ new Date()).toISOString(), newId = () => `search:${crypto.randomUUID()}`) {
      this.searches = searches;
      this.now = now;
      this.newId = newId;
    }
    async list(accountId) {
      return (await this.searches.list(accountId)).sort(compareSearches);
    }
    async save(accountId, input) {
      const name = normalizeSearchName(input.name);
      if (name.length === 0 || name.length > MAX_SAVED_SEARCH_NAME_LENGTH)
        return { status: "invalid-name" };
      const address = readSearchAddress(input.url);
      if (address.status !== "ok") return { status: "no-match" };
      if ((await this.searches.list(accountId)).length >= MAX_SAVED_SEARCHES)
        return { status: "full" };
      const timestamp = this.now();
      const search = {
        id: this.newId(),
        accountId,
        name,
        url: address.url,
        filters: address.filters,
        createdAt: timestamp,
        updatedAt: timestamp
      };
      await this.searches.put(accountId, search);
      return { status: "saved", search };
    }
    async delete(accountId, id) {
      await this.searches.delete(accountId, id);
    }
  };

  // src/templates/template-service.ts
  var MAX_TEMPLATE_NAME_LENGTH = 80;
  var MAX_TEMPLATE_FOLDER_LENGTH = 40;
  var MAX_TEMPLATE_BODY_LENGTH = 4e3;
  var collapse = (value) => value.trim().replace(/\s+/gu, " ");
  function normalizeTemplateBody(body) {
    return body.replace(/\r\n?/gu, "\n");
  }
  function folderOf(template, general = "") {
    return template.folder ?? general;
  }
  function compareTemplates(a, b, general = "") {
    return folderOf(a, general).localeCompare(folderOf(b, general)) || a.name.localeCompare(b.name) || a.id.localeCompare(b.id);
  }
  function invalid(text, display) {
    return new ExtensionError("ExtractionInvalid", text, { display });
  }
  var TemplateService = class {
    constructor(templates = new MessageTemplateRepository(), accounts2 = new ExtensionAccountRepository(), now = () => (/* @__PURE__ */ new Date()).toISOString(), newId = () => `template:${crypto.randomUUID()}`) {
      this.templates = templates;
      this.accounts = accounts2;
      this.now = now;
      this.newId = newId;
    }
    async list(accountId) {
      const templates = await this.templates.list(accountId);
      return templates.sort(compareTemplates);
    }
    async save(accountId, input, guard) {
      const name = collapse(input.name);
      const folder = collapse(input.folder ?? "");
      const body = normalizeTemplateBody(input.body);
      if (name.length === 0)
        throw invalid(
          "A template needs a name",
          message("error.template.noName")
        );
      if (name.length > MAX_TEMPLATE_NAME_LENGTH)
        throw invalid(
          `A template name can have at most ${MAX_TEMPLATE_NAME_LENGTH} characters`,
          message("error.template.nameTooLong", {
            maximum: MAX_TEMPLATE_NAME_LENGTH
          })
        );
      if (folder.length > MAX_TEMPLATE_FOLDER_LENGTH)
        throw invalid(
          `A folder name can have at most ${MAX_TEMPLATE_FOLDER_LENGTH} characters`,
          message("error.template.folderTooLong", {
            maximum: MAX_TEMPLATE_FOLDER_LENGTH
          })
        );
      if (body.trim().length === 0)
        throw invalid(
          "A template needs some text",
          message("error.template.noText")
        );
      if (body.length > MAX_TEMPLATE_BODY_LENGTH)
        throw invalid(
          `A template can have at most ${MAX_TEMPLATE_BODY_LENGTH} characters`,
          message("error.template.tooLong", {
            maximum: MAX_TEMPLATE_BODY_LENGTH
          })
        );
      return withAccountLock(accountId, async () => {
        await this.#requireAccount(accountId, guard);
        const existing = input.id ? await this.templates.get(accountId, input.id) : void 0;
        if (input.id && !existing)
          throw new ExtensionError(
            "StorageError",
            "That template was deleted meanwhile",
            { display: message("error.template.deleted") }
          );
        const timestamp = this.now();
        const template = {
          id: existing?.id ?? this.newId(),
          accountId,
          name,
          body,
          ...folder ? { folder } : {},
          createdAt: existing?.createdAt ?? timestamp,
          updatedAt: timestamp
        };
        await this.templates.put(accountId, template);
        return template;
      });
    }
    async delete(accountId, id, guard) {
      await withAccountLock(accountId, async () => {
        await this.#requireAccount(accountId, guard);
        await this.templates.delete(accountId, id);
      });
    }
    async #requireAccount(accountId, guard) {
      if (!await this.accounts.get(accountId, accountId))
        throw new ExtensionError(
          "IdentityMismatch",
          "That account no longer exists",
          { display: message("error.account.gone") }
        );
      if (guard && await guard.activeAccountId() !== accountId)
        throw new ExtensionError(
          "IdentityMismatch",
          "The active account changed",
          { display: message("error.account.changed") }
        );
    }
  };

  // src/storage/triage-revision.ts
  var TRIAGE_REVISION_KEY = "joyfox.triageRevision";
  async function bumpTriageRevision(settings = runtimeSettingsArea) {
    try {
      await settings.set({ [TRIAGE_REVISION_KEY]: crypto.randomUUID() });
    } catch {
    }
  }

  // src/rules/rule-service.ts
  var GLOBAL_RULE_ID = "rule:global";

  // src/triage/shared-event.ts
  var SHARED_EVENT_EXCEPTION_KEY = "joyfox.sharedEventException";
  var SHARED_EVENT_OPT_OUT_KEY = "sharedEventOptOut";
  var sharedEventOptOutId = (memberId2) => `shared-event-opt-out:${memberId2}`;
  var COUNTED = /* @__PURE__ */ new Set([
    "attending",
    "attended"
  ]);
  function latestFirst(a, b) {
    if (a.startLocal && b.startLocal)
      return b.startLocal.localeCompare(a.startLocal) || compareListings(a, b);
    if (a.startLocal) return -1;
    if (b.startLocal) return 1;
    return compareListings(a, b);
  }
  function sharedEventsByMember(records) {
    const byMember = /* @__PURE__ */ new Map();
    const counted = records.filter(
      (record) => kindOf(record) === "event" && COUNTED.has(record.attendance)
    ).sort(latestFirst);
    for (const record of counted)
      for (const memberId2 of record.attendees ?? [])
        if (!byMember.has(memberId2))
          byMember.set(memberId2, {
            eventId: record.eventId,
            ...record.title ? { title: record.title } : {},
            ...record.startLocal ? { startLocal: record.startLocal } : {},
            attendance: record.attendance
          });
    return byMember;
  }

  // src/triage/triage-service.ts
  var MEMBER_ID_PATTERN = /^\d{1,20}$/;
  var isMemberId = (value) => typeof value === "string" && MEMBER_ID_PATTERN.test(value);
  var MAX_MEMBERS_PER_REQUEST = 200;
  var classificationId = (memberId2) => `classification:${encodeURIComponent(memberId2)}`;
  var phraseMatchId = (memberId2, phrase) => `phrase-match:${encodeURIComponent(memberId2)}:${encodeURIComponent(phrase)}`;
  function requireAccountId3(accountId) {
    if (accountId.trim().length === 0)
      throw new ExtensionError(
        "IdentityMismatch",
        "Triage needs an explicit active account"
      );
  }
  function requireMemberId(memberId2) {
    if (!isMemberId(memberId2))
      throw new ExtensionError("IdentityMismatch", "Invalid member ID");
  }
  var SNAPSHOT_FIELDS = [
    "verification",
    "photoCount",
    "profileWordCount",
    "joinedAt",
    "joinedEarliest",
    "joinedLatest",
    "positivePreferences",
    "ownProfile"
  ];
  var TriageService = class {
    constructor(rules = new ContactRuleRepository(), snapshots = new ProfileSnapshotRepository(), classifications = new ConversationClassificationRepository(), spamOverrides = new SenderSpamOverrideRepository(), trustSignals = new TrustSignalRepository(), members2 = new JoyClubMemberRepository(), settings = runtimeSettingsArea, now = () => /* @__PURE__ */ new Date(), newId = () => crypto.randomUUID(), phraseMatches = new MessagePhraseMatchRepository(), listings = new EventMetadataRepository(), preferences = new ExtensionPreferenceRepository()) {
      this.rules = rules;
      this.snapshots = snapshots;
      this.classifications = classifications;
      this.spamOverrides = spamOverrides;
      this.trustSignals = trustSignals;
      this.members = members2;
      this.settings = settings;
      this.now = now;
      this.newId = newId;
      this.phraseMatches = phraseMatches;
      this.listings = listings;
      this.preferences = preferences;
    }
    #sequence = 0;
    /**
     * V1-13: who is on the guest list of a counted event, when the exception
     * is on; an empty map when it is off or cannot be read.
     */
    async #sharedEvents(accountId) {
      let on = false;
      try {
        on = (await this.settings.get([SHARED_EVENT_EXCEPTION_KEY]))[SHARED_EVENT_EXCEPTION_KEY] === true;
      } catch {
      }
      if (!on) return /* @__PURE__ */ new Map();
      const [records, preferences] = await Promise.all([
        this.listings.list(accountId),
        this.preferences.list(accountId)
      ]);
      const shared = sharedEventsByMember(records);
      for (const preference of preferences)
        if (preference.key === SHARED_EVENT_OPT_OUT_KEY && typeof preference.value === "string")
          shared.delete(preference.value);
      return shared;
    }
    /**
     * V1-13: turn the shared-event exception off for one sender, so the rule
     * decides again. The user undoes it by deleting the record under "Your
     * data".
     */
    /**
     * V1-10: keep the profile page's "met in person" mark for guest-list card
     * signals (`src/signals/met-in-person.ts`). Written only when it changes.
     * Called only after the page showed some fact, so a header whose shield has
     * not drawn yet with nothing else does not clear it.
     */
    async #recordMetInPerson(accountId, memberId2, marked) {
      const id = metInPersonId(memberId2);
      const stored = await this.preferences.get(accountId, id);
      if (marked === (stored !== void 0)) return;
      if (marked) {
        const timestamp = this.now().toISOString();
        await this.preferences.put(accountId, {
          id,
          accountId,
          key: MET_IN_PERSON_KEY,
          value: memberId2,
          createdAt: timestamp,
          updatedAt: timestamp
        });
      } else await this.preferences.delete(accountId, id);
      await bumpTriageRevision(this.settings);
    }
    async optOutSharedEvent(accountId, memberId2) {
      requireAccountId3(accountId);
      requireMemberId(memberId2);
      const timestamp = this.now().toISOString();
      await this.preferences.put(accountId, {
        id: sharedEventOptOutId(memberId2),
        accountId,
        key: SHARED_EVENT_OPT_OUT_KEY,
        value: memberId2,
        createdAt: timestamp,
        updatedAt: timestamp
      });
      await bumpTriageRevision(this.settings);
    }
    async evaluate(accountId, requested) {
      if (!accountId) return { status: "no-account" };
      requireAccountId3(accountId);
      if (requested.length > MAX_MEMBERS_PER_REQUEST)
        throw new ExtensionError("RuleEvaluationError", "Too many members");
      for (const member of requested) requireMemberId(member.memberId);
      const rule = await this.rules.get(accountId, GLOBAL_RULE_ID);
      if (!rule) return { status: "no-rule", accountId };
      if (!rule.enabled) return { status: "rule-disabled", accountId };
      const phrases = rulePhrases(rule.root);
      const [snapshots, overrides, spamOverrides, signals, matches, shared] = await Promise.all([
        this.snapshots.list(accountId),
        this.classifications.list(accountId),
        this.spamOverrides.list(accountId),
        this.trustSignals.list(accountId),
        phrases.size > 0 ? this.phraseMatches.list(accountId) : Promise.resolve([]),
        this.#sharedEvents(accountId)
      ]);
      const matchesByMember = groupBy2(matches, (item) => item.memberId);
      const snapshotsByMember = groupBy2(snapshots, (item) => item.memberId);
      const overrideByMember = new Map(
        overrides.map((item) => [item.memberId, item])
      );
      const notSpam = new Set(spamOverrides.map((item) => item.memberId));
      const signalsByMember = groupBy2(signals, (item) => item.memberId);
      const now = this.now();
      const results = requested.map((member) => {
        const cached = newestSnapshot(
          snapshotsByMember.get(member.memberId) ?? []
        );
        const { facts, sources } = mergeProfileFacts(member.observed, cached);
        const spam = notSpam.has(member.memberId) ? "overridden" : "unknown";
        const trust = computeTrustScore({
          signals: signalsByMember.get(member.memberId) ?? [],
          spam,
          personallyKnown: facts.personallyKnown
        });
        const messages = phrases.size > 0 ? {
          previewShown: member.preview !== void 0,
          seenNow: phrasesIn(member.preview ?? "", phrases),
          seenBefore: new Set(
            (matchesByMember.get(member.memberId) ?? []).map(
              (match) => match.phrase
            )
          )
        } : void 0;
        const automatic = evaluateContactRule(rule, {
          facts,
          sources,
          spam,
          trust,
          ...messages ? { messages } : {},
          now
        });
        const override = overrideByMember.get(member.memberId);
        const sharedEvent = shared.get(member.memberId);
        if (!override && sharedEvent && automatic.placement !== "qualified")
          return {
            memberId: member.memberId,
            placement: "qualified",
            source: "shared-event",
            sharedEvent,
            automatic,
            trust
          };
        return override ? {
          memberId: member.memberId,
          placement: override.placement,
          source: "override",
          override: {
            placement: override.placement,
            decidedAt: override.decidedAt
          },
          automatic,
          trust
        } : {
          memberId: member.memberId,
          placement: automatic.placement,
          source: "rule",
          automatic,
          trust
        };
      });
      return { status: "ok", accountId, results };
    }
    /**
     * The trust score for one member without a rule, so a page can show and log
     * trust (M6) even while triage is off. Uses the same inputs as `evaluate`.
     */
    async trustFor(accountId, memberId2, observed3) {
      if (!accountId) return { status: "no-account" };
      requireAccountId3(accountId);
      requireMemberId(memberId2);
      const [spamOverrides, signals] = await Promise.all([
        this.spamOverrides.list(accountId),
        this.trustSignals.list(accountId)
      ]);
      const { facts } = mergeProfileFacts(observed3);
      return {
        status: "ok",
        accountId,
        trust: computeTrustScore({
          signals: signals.filter((signal) => signal.memberId === memberId2),
          spam: spamOverrides.some((item) => item.memberId === memberId2) ? "overridden" : "unknown",
          personallyKnown: facts.personallyKnown
        })
      };
    }
    /**
     * Store which of the rule's phrases each inbox preview contains, so the
     * condition stays met after the sender's later messages hide the one that
     * held it (ADR 0013). Only the normalized phrase and the time are stored,
     * never the preview. Returns how many new matches were written.
     */
    async recordPhraseMatches(accountId, requested) {
      requireAccountId3(accountId);
      for (const member of requested) requireMemberId(member.memberId);
      const rule = await this.rules.get(accountId, GLOBAL_RULE_ID);
      if (!rule?.enabled) return 0;
      const phrases = rulePhrases(rule.root);
      if (phrases.size === 0) return 0;
      const stored = new Set(
        (await this.phraseMatches.list(accountId)).map((match) => match.id)
      );
      const timestamp = this.now().toISOString();
      let written = 0;
      for (const member of requested) {
        if (member.preview === void 0) continue;
        for (const phrase of phrasesIn(member.preview, phrases)) {
          const id = phraseMatchId(member.memberId, phrase);
          if (stored.has(id)) continue;
          stored.add(id);
          await registerMember(
            this.members,
            accountId,
            member.memberId,
            timestamp
          );
          await this.phraseMatches.put(accountId, {
            id,
            accountId,
            memberId: member.memberId,
            phrase,
            matchedAt: timestamp,
            createdAt: timestamp,
            updatedAt: timestamp
          });
          written += 1;
        }
      }
      if (written > 0) await bumpTriageRevision(this.settings);
      return written;
    }
    /** Store or clear (`null`) the user's manual placement for one sender. */
    async setOverride(accountId, memberId2, placement) {
      requireAccountId3(accountId);
      requireMemberId(memberId2);
      const id = classificationId(memberId2);
      if (placement === null) await this.classifications.delete(accountId, id);
      else {
        const timestamp = this.now().toISOString();
        const existing = await this.classifications.get(accountId, id);
        const record = {
          id,
          accountId,
          memberId: memberId2,
          placement,
          source: "user",
          decidedAt: timestamp,
          ruleId: GLOBAL_RULE_ID,
          reasons: [
            message("triage.reason.userMoved", {
              placement: message(PLACEMENT_TEXT[placement])
            })
          ],
          createdAt: existing?.createdAt ?? timestamp,
          updatedAt: timestamp
        };
        await registerMember(this.members, accountId, memberId2, timestamp);
        await this.classifications.put(accountId, record);
      }
      await bumpTriageRevision(this.settings);
    }
    /**
     * Cache the profile facts a profile page showed, so the inbox can use them
     * later without opening the profile (build plan Section 8). Only counts,
     * codes and dates are stored, never profile text; V1-2 adds the labels of
     * the tags the profile lists at a positive level. Returns whether a record
     * was written: nothing is written when no fact was seen or when the facts
     * match the newest snapshot.
     */
    async captureSnapshot(accountId, memberId2, observed3, extras = {}) {
      requireAccountId3(accountId);
      requireMemberId(memberId2);
      const { facts } = mergeProfileFacts(observed3);
      const window = facts.joinedWindow === "unknown" ? void 0 : facts.joinedWindow;
      const values = {
        verification: facts.verification,
        photoCount: facts.photoCount,
        profileWordCount: facts.profileWordCount,
        joinedAt: facts.joinedAt,
        ...window ? { joinedEarliest: window.earliest, joinedLatest: window.latest } : {},
        ...extras.preferences ? { positivePreferences: [...extras.preferences] } : {},
        ...extras.ownProfile ? { ownProfile: true } : {}
      };
      const seen = values.positivePreferences !== void 0 || values.verification !== "unknown" || values.photoCount !== "unknown" || values.profileWordCount !== "unknown" || values.joinedAt !== "unknown" || window !== void 0;
      if (!seen) return false;
      await this.#recordMetInPerson(
        accountId,
        memberId2,
        facts.personallyKnown === true
      );
      const all = await this.snapshots.list(accountId);
      const newest = newestSnapshot(
        all.filter((snapshot2) => snapshot2.memberId === memberId2)
      );
      if (newest) {
        if (values.verification === "unknown")
          values.verification = newest.verification;
        if (values.photoCount === "unknown")
          values.photoCount = newest.photoCount;
        if (values.profileWordCount === "unknown")
          values.profileWordCount = newest.profileWordCount;
        if (values.joinedAt === "unknown") values.joinedAt = newest.joinedAt;
        if (!window && newest.joinedEarliest !== void 0 && newest.joinedLatest !== void 0)
          Object.assign(values, {
            joinedEarliest: newest.joinedEarliest,
            joinedLatest: newest.joinedLatest
          });
        if (!values.positivePreferences && newest.positivePreferences)
          values.positivePreferences = newest.positivePreferences;
        if (newest.ownProfile) values.ownProfile = true;
      }
      if (newest && SNAPSHOT_FIELDS.every(
        (field) => sameSnapshotValue(
          field,
          newest[field],
          values[field]
        )
      ))
        return false;
      const timestamp = this.now().toISOString();
      const snapshot = {
        // Zero-padded sequence first, so two snapshots captured in the same
        // millisecond still sort in capture order (`newestCaptureFirst` breaks
        // ties on ID).
        id: `snapshot:${String(this.#sequence += 1).padStart(12, "0")}:${this.newId()}`,
        accountId,
        memberId: memberId2,
        capturedAt: timestamp,
        ...values,
        createdAt: timestamp,
        updatedAt: timestamp
      };
      await registerMember(this.members, accountId, memberId2, timestamp);
      await this.snapshots.put(
        accountId,
        snapshot,
        await readSnapshotRetention(this.settings)
      );
      await bumpTriageRevision(this.settings);
      return true;
    }
  };
  function sameSnapshotValue(field, stored, fresh) {
    if ((field === "joinedEarliest" || field === "joinedLatest") && typeof stored === "string" && typeof fresh === "string")
      return stored.slice(0, 10) === fresh.slice(0, 10);
    if (field === "positivePreferences")
      return JSON.stringify(stored) === JSON.stringify(fresh);
    return stored === fresh;
  }
  function groupBy2(items, key2) {
    const groups = /* @__PURE__ */ new Map();
    for (const item of items) {
      const group = groups.get(key2(item));
      if (group) group.push(item);
      else groups.set(key2(item), [item]);
    }
    return groups;
  }

  // src/trust/trust-service.ts
  function requireAccountId4(accountId) {
    if (accountId.trim().length === 0)
      throw new ExtensionError(
        "IdentityMismatch",
        "A trust outcome needs an explicit active account"
      );
  }
  var newestFirst2 = (a, b) => Date.parse(b.occurredAt) - Date.parse(a.occurredAt) || b.id.localeCompare(a.id);
  var TrustService = class {
    constructor(signals = new TrustSignalRepository(), members2 = new JoyClubMemberRepository(), settings = runtimeSettingsArea, now = () => (/* @__PURE__ */ new Date()).toISOString(), newId = () => crypto.randomUUID()) {
      this.signals = signals;
      this.members = members2;
      this.settings = settings;
      this.now = now;
      this.newId = newId;
    }
    #sequence = 0;
    /**
     * Logs and undos run one after another across all tabs: the background
     * holds one TrustService, so an undo from one tab can never read the list
     * while another tab's log is half written.
     */
    #queue = Promise.resolve();
    #serial(action2) {
      const run = this.#queue.then(action2);
      this.#queue = run.catch(() => void 0);
      return run;
    }
    async listSignals(accountId, memberId2) {
      requireAccountId4(accountId);
      const all = await this.signals.list(accountId);
      return all.filter((signal) => signal.memberId === memberId2).sort(newestFirst2);
    }
    async logOutcome(accountId, memberId2, kind) {
      return this.#serial(async () => {
        requireAccountId4(accountId);
        const timestamp = this.now();
        const signal = {
          // Zero-padded so the text order of IDs is the logging order.
          id: `trust:${String(this.#sequence += 1).padStart(12, "0")}:${this.newId()}`,
          accountId,
          memberId: memberId2,
          kind,
          occurredAt: timestamp,
          createdAt: timestamp,
          updatedAt: timestamp
        };
        await registerMember(this.members, accountId, memberId2, timestamp);
        await this.signals.put(accountId, signal);
        await bumpTriageRevision(this.settings);
        return signal;
      });
    }
    /** Removes the newest outcome for the member. Returns whether one existed. */
    async undoLastOutcome(accountId, memberId2) {
      return this.#serial(async () => {
        const [latest] = await this.listSignals(accountId, memberId2);
        if (!latest) return false;
        await this.signals.delete(accountId, latest.id);
        await bumpTriageRevision(this.settings);
        return true;
      });
    }
  };

  // src/storage/action-revision.ts
  var ACTION_REVISION_KEY = "joyfox.actionRevision";
  var bumpActionRevision = (settings) => bumpRevision(ACTION_REVISION_KEY, settings);

  // src/background/handler-guards.ts
  var invalid2 = (what) => new ExtensionError("ExtractionInvalid", `Invalid ${what}`);
  function memberId(value) {
    if (!isMemberId(value)) throw invalid2("member ID");
    return value;
  }
  async function writeAccount(deps, expected) {
    const active = await deps.activeAccountId();
    return active === expected ? active : void 0;
  }
  async function lockedWrite(deps, expected, refused, write) {
    if (typeof expected !== "string" || expected.length === 0)
      throw invalid2("account");
    return withAccountLock(expected, async () => {
      const accountId = await writeAccount(deps, expected);
      return accountId ? write(accountId) : refused;
    });
  }

  // src/background/action-handlers.ts
  var browserTabUrl = async (tabId2) => (await globalThis.browser?.tabs?.get(tabId2))?.url;
  var HANDOFF_PREFIX = "joyfox.m9.handOff.";
  var PROFILE_PATH = /^\/profile\/(\d{1,20})\.[^/]+\.html$/;
  function profilePath(value) {
    if (typeof value !== "string" || !PROFILE_PATH.test(value))
      throw invalid2("profile path");
    return value;
  }
  function isProfileOf(path, profile) {
    const member = PROFILE_PATH.exec(profile)?.[1];
    return member !== void 0 && PROFILE_PATH.exec(path ?? "")?.[1] === member;
  }
  var CONVERSATION_PATH = /^\/clubmail\/conversation\/conversation-wrapper-(personal-\d{1,20}-\d{1,20})\/?$/;
  function pathOf(url) {
    try {
      return url ? new URL(url).pathname : void 0;
    } catch {
      return void 0;
    }
  }
  var senderPath = (context) => pathOf(context.url);
  function tabId(context) {
    if (typeof context.tabId !== "number") throw invalid2("tab");
    return context.tabId;
  }
  function nextStep(value) {
    const index = STEP_ORDER.indexOf(value);
    if (index < 1) throw invalid2("step");
    return value;
  }
  function stepBefore(next) {
    const previous = STEP_ORDER[STEP_ORDER.indexOf(next) - 1];
    return STEP_STATES[previous].confirmed;
  }
  function isMarker(value) {
    const marker = value;
    return typeof marker?.accountId === "string" && typeof marker.operationId === "string" && typeof marker.at === "number" && typeof marker.profilePath === "string" && STEP_ORDER.indexOf(marker.next) > 0;
  }
  var CONVERSATION_ID_PATTERN2 = /^personal-\d{1,20}-\d{1,20}$/;
  var MAX_OPERATION_ID_LENGTH = 200;
  function conversationId(value) {
    if (typeof value !== "string" || !CONVERSATION_ID_PATTERN2.test(value))
      throw invalid2("conversation ID");
    return value;
  }
  function deadline(value) {
    if (value === void 0) return void 0;
    if (typeof value !== "number" || !Number.isFinite(value))
      throw invalid2("deadline");
    return value;
  }
  function operationId(value) {
    if (typeof value !== "string" || value.length === 0 || value.length > MAX_OPERATION_ID_LENGTH)
      throw invalid2("operation ID");
    return value;
  }
  function action(value) {
    if (value === void 0) return QUICK_IGNORE_DELETE;
    if (!isQuickAction(value)) throw invalid2("action");
    return value;
  }
  function state(value) {
    if (!ACTION_STATES.includes(value)) throw invalid2("state");
    return value;
  }
  function failure(value) {
    if (value === void 0) return void 0;
    if (!ACTION_FAILURES.includes(value))
      throw invalid2("failure");
    return value;
  }
  function registerActionHandlers(router2, deps) {
    const tabUrl = deps.tabUrl ?? browserTabUrl;
    const now = deps.now ?? (() => Date.now());
    router2.register("action.ignoreDelete.start", async (payload) => {
      const target = {
        memberId: memberId(payload?.memberId),
        conversationId: conversationId(payload?.conversationId)
      };
      const until = deadline(payload?.deadline);
      const kind = action(payload?.action);
      const answer = await lockedWrite(
        deps,
        payload?.accountId,
        { status: "refused" },
        async (accountId) => (
          // Checked under the lock, since waiting for it is what makes a start
          // late: the page has stopped waiting, so nothing is stored.
          until !== void 0 && now() > until ? { status: "expired" } : deps.actions.begin(accountId, target, kind)
        )
      );
      if (answer.status === "started") await bumpActionRevision(deps.settings);
      return answer;
    });
    router2.register("action.ignoreDelete.record", async (payload) => {
      const id = operationId(payload?.operationId);
      const next = state(payload?.state);
      const reason = failure(payload?.failure);
      const answer = await lockedWrite(deps, payload?.accountId, { status: "refused" }, async (accountId) => ({
        status: await deps.actions.record(accountId, id, next, reason)
      }));
      if (answer.status === "recorded") await bumpActionRevision(deps.settings);
      return answer;
    });
    const handOffReady = async (accountId, operationId2, next) => {
      const log = await deps.actions.find(accountId, operationId2);
      if (log?.action !== QUICK_IGNORE_DELETE || !log.memberId || !log.conversationId)
        return void 0;
      const newest = await deps.actions.latest(accountId, log.memberId);
      if (newest?.id !== log.id) return void 0;
      const last = log.steps.at(-1);
      if (last?.name !== stepBefore(next)) return void 0;
      const moved = Date.parse(last.at);
      return Number.isFinite(moved) && now() - moved <= STALE_AFTER_MS ? log : void 0;
    };
    router2.register("action.ignoreDelete.handOff", async (payload, context) => {
      const tab = tabId(context);
      const id = operationId(payload?.operationId);
      const next = nextStep(payload?.next);
      const path = profilePath(payload?.profilePath);
      const session = deps.session;
      if (!session) return { status: "refused" };
      return lockedWrite(
        deps,
        payload?.accountId,
        { status: "refused" },
        async (accountId) => {
          const log = await handOffReady(accountId, id, next);
          const current = pathOf(await tabUrl(tab).catch(() => void 0)) ?? senderPath(context);
          if (!log || PROFILE_PATH.exec(path)?.[1] !== log.memberId || CONVERSATION_PATH.exec(current ?? "")?.[1] !== log.conversationId)
            return { status: "refused" };
          const marker = {
            accountId,
            operationId: id,
            next,
            profilePath: path,
            at: now()
          };
          await session.set({ [`${HANDOFF_PREFIX}${tab}`]: marker });
          return { status: "stored" };
        }
      );
    });
    router2.register("action.ignoreDelete.withdraw", async (payload, context) => {
      const key2 = `${HANDOFF_PREFIX}${tabId(context)}`;
      const id = operationId(payload?.operationId);
      const session = deps.session;
      if (!session) return { status: "none" };
      const answer = await lockedWrite(deps, payload?.accountId, { status: "none" }, async (accountId) => {
        const stored = (await session.get([key2]))[key2];
        if (!isMarker(stored) || stored.accountId !== accountId || stored.operationId !== id)
          return { status: "none" };
        await session.remove([key2]);
        if (!await handOffReady(accountId, id, stored.next))
          return { status: "none" };
        await deps.actions.record(accountId, id, "Failed", "handoff-failed");
        const closed = await deps.actions.find(accountId, id);
        return closed ? { status: "withdrawn", lines: reportOperation(closed, now()).lines } : { status: "none" };
      });
      if (answer.status === "withdrawn") await bumpActionRevision(deps.settings);
      return answer;
    });
    router2.register(
      "action.ignoreDelete.dropStale",
      async (_payload, context) => {
        const key2 = `${HANDOFF_PREFIX}${tabId(context)}`;
        const session = deps.session;
        if (!session) return { status: "none" };
        const stored = (await session.get([key2]))[key2];
        if (stored === void 0) return { status: "none" };
        if (!isMarker(stored)) {
          await session.remove([key2]);
          return { status: "none" };
        }
        if (isProfileOf(senderPath(context), stored.profilePath))
          return { status: "none" };
        const closed = await withAccountLock(stored.accountId, async () => {
          const current = (await session.get([key2]))[key2];
          if (!isMarker(current) || current.operationId !== stored.operationId)
            return false;
          const ready = await handOffReady(
            stored.accountId,
            stored.operationId,
            stored.next
          );
          if (ready)
            await deps.actions.record(
              stored.accountId,
              stored.operationId,
              "Failed",
              "handoff-failed"
            );
          await session.remove([key2]);
          return ready !== void 0;
        });
        if (!closed) return { status: "none" };
        await bumpActionRevision(deps.settings);
        return { status: "dropped" };
      }
    );
    router2.register("action.ignoreDelete.pending", async (_payload, context) => {
      const key2 = `${HANDOFF_PREFIX}${tabId(context)}`;
      const session = deps.session;
      if (!session) return { status: "none" };
      const stored = (await session.get([key2]))[key2];
      if (stored === void 0) return { status: "none" };
      const answer = await readHandOff(stored, context);
      await session.remove([key2]);
      if (answer.status === "stopped") await bumpActionRevision(deps.settings);
      return answer;
    });
    const readHandOff = async (stored, context) => {
      if (!isMarker(stored) || now() - stored.at > STALE_AFTER_MS)
        return { status: "none" };
      if (!isProfileOf(senderPath(context), stored.profilePath))
        return { status: "none" };
      if (await deps.activeAccountId() !== stored.accountId) {
        const closed = await withAccountLock(stored.accountId, async () => {
          if (!await handOffReady(
            stored.accountId,
            stored.operationId,
            stored.next
          ))
            return void 0;
          await deps.actions.record(
            stored.accountId,
            stored.operationId,
            "Failed",
            "account-changed"
          );
          return deps.actions.find(stored.accountId, stored.operationId);
        });
        if (!closed) return { status: "none" };
        return {
          status: "stopped",
          lines: reportOperation(closed, now()).lines
        };
      }
      const log = await handOffReady(
        stored.accountId,
        stored.operationId,
        stored.next
      );
      if (!log?.memberId || !log.conversationId) return { status: "none" };
      return {
        status: "ok",
        accountId: stored.accountId,
        operationId: log.id,
        memberId: log.memberId,
        conversationId: log.conversationId,
        next: stored.next,
        steps: log.steps
      };
    };
    router2.register("action.ignoreDelete.latest", async (payload) => {
      const id = memberId(payload?.memberId);
      const accountId = await deps.activeAccountId();
      if (!accountId) return { status: "no-account" };
      const log = await deps.actions.latest(accountId, id);
      if (!log) return { status: "none", accountId };
      return {
        status: "ok",
        accountId,
        action: isQuickAction(log.action) ? log.action : QUICK_IGNORE_DELETE,
        ...log.conversationId ? { conversationId: log.conversationId } : {},
        updatedAt: log.steps.at(-1)?.at ?? log.updatedAt,
        staleAfterMs: staleAfterMs(log.steps.at(-1)?.name),
        report: reportOperation(log, now())
      };
    });
  }

  // src/background/lifecycle.ts
  var repo = new ExtensionPreferenceRepository();
  function incrementPersistentWakeCounter(accountId) {
    return withAccountLock(accountId, () => incrementUnlocked(accountId));
  }
  async function incrementUnlocked(accountId) {
    const current = await repo.get(accountId, "background-wake-count");
    const value = typeof current?.value === "number" ? current.value + 1 : 1;
    const now = (/* @__PURE__ */ new Date()).toISOString();
    const record = {
      id: "background-wake-count",
      accountId,
      key: "diagnostic.backgroundWakeCount",
      value,
      createdAt: current?.createdAt ?? now,
      updatedAt: now
    };
    await repo.put(accountId, record);
    return value;
  }

  // src/compatibility/limits.ts
  var MAX_COMPATIBILITY_MEMBERS = 500;

  // src/background/compatibility-handlers.ts
  function registerCompatibilityHandlers(router2, deps) {
    router2.register("compat.lookup", async (payload) => {
      const ids = payload?.memberIds;
      if (!Array.isArray(ids) || ids.length > MAX_COMPATIBILITY_MEMBERS)
        throw invalid2("member list");
      const requested = ids.map(memberId);
      const accountId = await deps.activeAccountId();
      if (!accountId) return { status: "no-account" };
      return {
        status: "ok",
        ...await deps.compatibility.lookup(accountId, requested)
      };
    });
  }

  // src/storage/event-revision.ts
  var EVENT_REVISION_KEY = "joyfox.eventRevision";
  var bumpEventRevision = (settings) => bumpRevision(EVENT_REVISION_KEY, settings);

  // src/background/listing-handlers.ts
  var NUMBER = /^\d{1,12}$/u;
  var PATH = /^\/(event|club)\/\d{1,12}\.[^/]+\.html$/u;
  function summarize(record) {
    return {
      kind: kindOf(record),
      eventId: record.eventId,
      ...record.title ? { title: record.title } : {},
      ...record.startLocal ? { startLocal: record.startLocal } : {},
      ...record.path ? { path: record.path } : {},
      ...record.venueId ? { venueId: record.venueId } : {},
      ...record.venueName ? { venueName: record.venueName } : {},
      ...record.note ? { note: record.note } : {},
      tags: record.tags,
      attendance: record.attendance,
      updatedAt: record.updatedAt
    };
  }
  function listingKind(value) {
    if (value !== "event" && value !== "venue") throw invalid2("listing kind");
    return value;
  }
  function listingId(value) {
    if (typeof value !== "string" || !NUMBER.test(value))
      throw invalid2("listing");
    return value;
  }
  function optionalText(value, pattern) {
    if (value === void 0) return void 0;
    if (typeof value !== "string" || pattern && !pattern.test(value))
      throw invalid2("listing fact");
    return value;
  }
  function listingFacts(value) {
    if (typeof value !== "object" || value === null)
      throw invalid2("listing facts");
    const facts = value;
    const title = optionalText(facts.title);
    const startLocal = optionalText(facts.startLocal);
    if (startLocal !== void 0 && !isWallTime(startLocal))
      throw invalid2("listing fact");
    const path = optionalText(facts.path, PATH);
    const venueId = optionalText(facts.venueId, NUMBER);
    const venueName = optionalText(facts.venueName);
    return {
      ...title !== void 0 ? { title } : {},
      ...startLocal !== void 0 ? { startLocal } : {},
      ...path !== void 0 ? { path } : {},
      ...venueId !== void 0 ? { venueId } : {},
      ...venueName !== void 0 ? { venueName } : {}
    };
  }
  function registerListingHandlers(router2, deps) {
    router2.register("listing.get", async (payload) => {
      const kind = listingKind(payload?.kind);
      const id = listingId(payload?.eventId);
      const accountId = await deps.activeAccountId();
      if (!accountId) return { status: "no-account" };
      const record = await deps.listings.get(accountId, kind, id);
      return {
        status: "ok",
        accountId,
        listing: record ? summarize(record) : null
      };
    });
    router2.register("listing.list", async () => {
      const accountId = await deps.activeAccountId();
      if (!accountId) return { listings: [] };
      const records = await deps.listings.list(accountId);
      return { accountId, listings: records.map(summarize) };
    });
    router2.register("listing.save", async (payload) => {
      const kind = listingKind(payload?.kind);
      const id = listingId(payload?.eventId);
      const note = payload?.note;
      const tags = payload?.tags;
      const attendance = payload?.attendance;
      if (typeof note !== "string" || !Array.isArray(tags) || !tags.every((tag) => typeof tag === "string") || !ATTENDANCE_VALUES.includes(attendance))
        throw invalid2("listing notes");
      const notes = { note, tags, attendance };
      if (notesProblem(notes)) throw invalid2("listing notes");
      const facts = listingFacts(payload?.facts);
      const expected = payload?.expectedUpdatedAt;
      if (expected !== null && typeof expected !== "string")
        throw invalid2("listing version");
      const answer = await lockedWrite(
        deps,
        payload?.accountId,
        { status: "refused" },
        async (accountId) => {
          const result = await deps.listings.save(
            accountId,
            kind,
            id,
            notes,
            facts,
            expected
          );
          if (result.status === "saved")
            return { status: "saved", listing: summarize(result.record) };
          if (result.status === "removed") return { status: "removed" };
          return {
            status: "conflict",
            listing: result.record ? summarize(result.record) : null
          };
        }
      );
      if (answer.status === "saved" || answer.status === "removed")
        await bumpEventRevision(deps.settings);
      return answer;
    });
    router2.register("listing.attendees", async (payload) => {
      const id = listingId(payload?.eventId);
      const ids = payload?.memberIds;
      if (!Array.isArray(ids) || ids.length > MAX_EVENT_ATTENDEES)
        throw invalid2("member list");
      const members2 = ids.map(memberId);
      const answer = await lockedWrite(deps, payload?.accountId, { status: "refused" }, async (accountId) => ({
        status: await deps.listings.recordAttendees(accountId, id, members2)
      }));
      if (answer.status === "stored") await bumpEventRevision(deps.settings);
      return answer;
    });
    router2.register("listing.forMember", async (payload) => {
      const member = memberId(payload?.memberId);
      const accountId = await deps.activeAccountId();
      if (!accountId) return { status: "no-account" };
      const records = await deps.listings.forMember(accountId, member);
      return {
        status: "ok",
        accountId,
        listings: records.map(summarize)
      };
    });
  }

  // src/storage/member-revision.ts
  var MEMBER_REVISION_KEY = "joyfox.memberRevision";
  var bumpMemberRevision = (settings) => bumpRevision(MEMBER_REVISION_KEY, settings);

  // src/background/member-handlers.ts
  var MAX_NAMES_PER_REQUEST = 200;
  function registerMemberHandlers(router2, deps) {
    const members2 = deps.members ?? new JoyClubMemberRepository();
    const now = deps.now ?? (() => (/* @__PURE__ */ new Date()).toISOString());
    router2.register("member.names", async (payload) => {
      const list = payload?.names;
      if (!Array.isArray(list) || list.length > MAX_NAMES_PER_REQUEST)
        throw invalid2("name list");
      const names = list.map((item) => {
        const entry = item ?? {};
        const nickname = cleanNickname(entry.nickname);
        if (!nickname) throw invalid2("nickname");
        return { memberId: memberId(entry.memberId), nickname };
      });
      return lockedWrite(deps, payload?.accountId, { status: "refused" }, async (accountId) => {
        const changed = await rememberNicknames(members2, accountId, names, now());
        if (changed > 0) await bumpMemberRevision(deps.settings);
        return { status: "ok", changed };
      });
    });
  }

  // src/background/message-handlers.ts
  var MAX_MESSAGES_PER_REQUEST = 100;
  function seenMessages(value) {
    if (!Array.isArray(value) || value.length > MAX_MESSAGES_PER_REQUEST)
      throw invalid2("message list");
    return value.map((item) => {
      const entry = item ?? {};
      const { messageId, direction, sentAt, text } = entry;
      if (typeof messageId !== "string" || !MESSAGE_ID_PATTERN.test(messageId))
        throw invalid2("message ID");
      if (direction !== "sent" && direction !== "received")
        throw invalid2("message direction");
      if (sentAt !== void 0 && (typeof sentAt !== "string" || !isStrictIsoDate(sentAt)))
        throw invalid2("message time");
      if (typeof text !== "string" || text.trim().length === 0 || text.length > MAX_MESSAGE_TEXT_LENGTH)
        throw invalid2("message text");
      return { messageId, direction, text, ...sentAt ? { sentAt } : {} };
    });
  }
  function registerMessageHandlers(router2, deps) {
    void deps.messages.prune().catch(() => void 0);
    router2.register("messages.cache", async (payload) => {
      const conversationId2 = payload?.conversationId;
      if (typeof conversationId2 !== "string" || !CONVERSATION_ID_PATTERN.test(conversationId2))
        throw invalid2("conversation ID");
      const member = memberId(payload?.memberId);
      if (!conversationId2.split("-").slice(1).includes(member))
        throw invalid2("member ID");
      const messages = seenMessages(payload?.messages);
      const answer = await lockedWrite(
        deps,
        payload?.accountId,
        { status: "refused" },
        (accountId) => deps.messages.store(accountId, conversationId2, member, messages)
      );
      if (answer.status === "stored" && answer.stored > 0)
        await bumpMessageRevision(deps.settings).catch(() => void 0);
      return answer;
    });
  }

  // src/background/signals-handlers.ts
  function observed(value) {
    if (value === void 0) return {};
    if (!value || typeof value !== "object" || Array.isArray(value))
      throw invalid2("observed facts");
    return value;
  }
  function registerSignalsHandlers(router2, deps) {
    router2.register("signals.lookup", async (payload) => {
      const list = payload?.members;
      if (!Array.isArray(list) || list.length > MAX_SIGNAL_MEMBERS)
        throw invalid2("member list");
      const members2 = list.map((item) => {
        const entry = item ?? {};
        if (entry.noShield !== void 0 && typeof entry.noShield !== "boolean")
          throw invalid2("shield flag");
        return {
          memberId: memberId(entry.memberId),
          observed: observed(entry.observed),
          ...entry.noShield === true ? { noShield: true } : {}
        };
      });
      const accountId = await deps.activeAccountId();
      if (!accountId) return { status: "no-account" };
      return {
        status: "ok",
        accountId,
        signals: await deps.signals.lookup(accountId, members2)
      };
    });
  }

  // src/storage/notes-revision.ts
  var NOTES_REVISION_KEY = "joyfox.notesRevision";
  var bumpNotesRevision = (settings) => bumpRevision(NOTES_REVISION_KEY, settings);

  // src/background/notes-handlers.ts
  var identityOf = (value) => knownMemberIdentity(memberId(value), "page");
  function noteBody(value) {
    if (typeof value !== "string" || value.trim().length > MAX_NOTE_LENGTH)
      throw invalid2("note");
    return value;
  }
  function expectedBody(value) {
    if (value === null) return null;
    if (typeof value !== "string") throw invalid2("expected note");
    return value;
  }
  function tagLabel(value) {
    if (typeof value !== "string") throw invalid2("tag");
    const label = normalizeTagLabel(value);
    if (label.length === 0 || label.length > MAX_TAG_LENGTH) throw invalid2("tag");
    return label;
  }
  function registerNotesHandlers(router2, deps) {
    router2.register("note.get", async (payload) => {
      const identity = identityOf(payload?.memberId);
      const accountId = await deps.activeAccountId();
      if (!accountId) return { status: "no-account" };
      const note = await deps.notes.readNote(accountId, identity);
      const tags = await deps.notes.listTags(accountId, identity);
      if (note.status !== "ok" || tags.status !== "ok")
        throw invalid2("member ID");
      return {
        status: "ok",
        accountId,
        note: note.value?.body ?? null,
        tags: tags.value.map((tag) => tag.label)
      };
    });
    const changed = () => bumpNotesRevision(deps.settings);
    router2.register("note.save", async (payload) => {
      const identity = identityOf(payload?.memberId);
      const body = noteBody(payload?.body);
      const expected = expectedBody(payload?.expectedBody);
      const answer = await lockedWrite(deps, payload?.accountId, { status: "refused" }, async (accountId) => {
        const outcome2 = await deps.notes.saveNoteIfUnchanged(
          accountId,
          identity,
          body,
          expected
        );
        if (outcome2.status !== "ok") throw invalid2("member ID");
        return outcome2.value;
      });
      if (answer.status === "saved") await changed();
      return answer;
    });
    router2.register("tag.add", async (payload) => {
      const identity = identityOf(payload?.memberId);
      const label = tagLabel(payload?.label);
      const answer = await lockedWrite(
        deps,
        payload?.accountId,
        { done: false },
        async (accountId) => {
          const outcome2 = await deps.notes.addTag(accountId, identity, label);
          if (outcome2.status !== "ok") return { done: false };
          return outcome2.value.added ? { done: true } : { done: true, existed: true };
        }
      );
      if (answer.done && !answer.existed) await changed();
      return answer;
    });
    router2.register("tag.remove", async (payload) => {
      const identity = identityOf(payload?.memberId);
      const label = tagLabel(payload?.label);
      const answer = await lockedWrite(
        deps,
        payload?.accountId,
        { done: false },
        async (accountId) => ({
          done: (await deps.notes.removeTag(accountId, identity, label)).status === "ok"
        })
      );
      if (answer.done) await changed();
      return answer;
    });
  }

  // src/background/onboarding.ts
  function registerOnboarding(runtime) {
    runtime.onInstalled.addListener(({ reason }) => {
      if (reason === "install")
        void runtime.openOptionsPage().catch(() => void 0);
    });
  }
  function registerToolbarButton(action2, openOptionsPage) {
    action2?.onClicked.addListener(() => {
      void openOptionsPage().catch(() => void 0);
    });
  }

  // src/storage/saved-search-revision.ts
  var SAVED_SEARCH_REVISION_KEY = "joyfox.savedSearchRevision";
  var bumpSavedSearchRevision = (settings) => bumpRevision(SAVED_SEARCH_REVISION_KEY, settings);

  // src/background/search-handlers.ts
  function searchName(value) {
    if (typeof value !== "string") throw invalid2("search name");
    const name = normalizeSearchName(value);
    if (name.length === 0 || name.length > MAX_SAVED_SEARCH_NAME_LENGTH)
      throw invalid2("search name");
    return name;
  }
  function searchUrl(value) {
    if (typeof value !== "string" || value.length > MAX_SAVED_SEARCH_URL_LENGTH)
      throw invalid2("search address");
    return value;
  }
  function searchId(value) {
    if (typeof value !== "string" || value.length === 0)
      throw invalid2("saved search");
    return value;
  }
  function registerSearchHandlers(router2, deps) {
    router2.register("search.list", async () => {
      const accountId = await deps.activeAccountId();
      if (!accountId) return { searches: [] };
      const searches = await deps.searches.list(accountId);
      return {
        accountId,
        searches: searches.map(({ id, name, url, filters }) => ({
          id,
          name,
          url,
          filters
        }))
      };
    });
    const changed = () => bumpSavedSearchRevision(deps.settings);
    router2.register("search.save", async (payload) => {
      const name = searchName(payload?.name);
      const url = searchUrl(payload?.url);
      const answer = await lockedWrite(
        deps,
        payload?.accountId,
        { status: "refused" },
        async (accountId) => {
          const result = await deps.searches.save(accountId, { name, url });
          if (result.status === "saved")
            return { status: "saved", id: result.search.id };
          return { status: result.status === "full" ? "full" : "no-match" };
        }
      );
      if (answer.status === "saved") await changed();
      return answer;
    });
    router2.register("search.delete", async (payload) => {
      const id = searchId(payload?.id);
      const answer = await lockedWrite(
        deps,
        payload?.accountId,
        { status: "refused" },
        async (accountId) => {
          await deps.searches.delete(accountId, id);
          return { status: "deleted" };
        }
      );
      if (answer.status === "deleted") await changed();
      return answer;
    });
  }

  // src/background/template-handlers.ts
  function registerTemplateHandlers(router2, deps) {
    router2.register("template.list", async () => {
      const accountId = await deps.activeAccountId();
      if (!accountId) return { templates: [] };
      const templates = await deps.templates.list(accountId);
      return {
        accountId,
        templates: templates.map((template) => ({
          id: template.id,
          name: template.name,
          folder: folderOf(template),
          body: template.body
        }))
      };
    });
  }

  // src/background/triage-handlers.ts
  var PLACEMENTS = [
    "qualified",
    "needs-review",
    "quarantined"
  ];
  var OUTCOMES = [
    "positive",
    "negative",
    "neutral"
  ];
  function observed2(value) {
    if (value === void 0) return {};
    if (!value || typeof value !== "object" || Array.isArray(value))
      throw invalid2("observed facts");
    return value;
  }
  function preview(value) {
    if (value === void 0) return {};
    if (typeof value !== "string" || value.length > MAX_PREVIEW_LENGTH)
      throw invalid2("message preview");
    return { preview: value };
  }
  function captureExtras(preferences, ownProfile) {
    if (ownProfile !== void 0 && typeof ownProfile !== "boolean")
      throw invalid2("own profile flag");
    const extras = ownProfile ? { ownProfile: true } : {};
    if (preferences === void 0) return extras;
    if (!Array.isArray(preferences) || preferences.length > MAX_PREFERENCE_TAGS || preferences.some(
      (label) => typeof label !== "string" || normalizeLabel(label).length === 0 || label.length > MAX_PREFERENCE_LABEL_LENGTH
    ))
      throw invalid2("preferences");
    return {
      ...extras,
      preferences: [
        ...new Set(preferences.map(normalizeLabel))
      ].sort()
    };
  }
  function members(value) {
    if (!Array.isArray(value) || value.length > MAX_MEMBERS_PER_REQUEST)
      throw invalid2("member list");
    return value.map((item) => {
      const entry = item ?? {};
      return {
        memberId: memberId(entry.memberId),
        observed: observed2(entry.observed),
        ...preview(entry.preview)
      };
    });
  }
  function registerTriageHandlers(router2, deps) {
    router2.register("triage.evaluate", async (payload) => {
      const requested = members(payload?.members);
      const accountId = await deps.activeAccountId();
      if (accountId && requested.some((member) => member.preview !== void 0))
        await lockedWrite(
          deps,
          accountId,
          0,
          (id) => deps.triage.recordPhraseMatches(id, requested)
        ).catch(() => 0);
      return deps.triage.evaluate(await deps.activeAccountId(), requested);
    });
    router2.register("triage.setOverride", async (payload) => {
      const id = memberId(payload?.memberId);
      const placement = payload?.placement;
      if (placement !== null && !PLACEMENTS.includes(placement))
        throw invalid2("placement");
      return lockedWrite(
        deps,
        payload?.accountId,
        { done: false },
        async (accountId) => {
          await deps.triage.setOverride(accountId, id, placement);
          return { done: true };
        }
      );
    });
    router2.register("triage.sharedEventOptOut", async (payload) => {
      const id = memberId(payload?.memberId);
      return lockedWrite(
        deps,
        payload?.accountId,
        { done: false },
        async (accountId) => {
          await deps.triage.optOutSharedEvent(accountId, id);
          return { done: true };
        }
      );
    });
    router2.register("trust.log", async (payload) => {
      const id = memberId(payload?.memberId);
      if (!OUTCOMES.includes(payload?.kind)) throw invalid2("outcome");
      const kind = payload.kind;
      return lockedWrite(
        deps,
        payload?.accountId,
        { done: false },
        async (accountId) => {
          await deps.trust.logOutcome(accountId, id, kind);
          return { done: true };
        }
      );
    });
    router2.register(
      "trust.get",
      async (payload) => deps.triage.trustFor(
        await deps.activeAccountId(),
        memberId(payload?.memberId),
        observed2(payload?.observed)
      )
    );
    router2.register("trust.undo", async (payload) => {
      const id = memberId(payload?.memberId);
      return lockedWrite(
        deps,
        payload?.accountId,
        { removed: false },
        async (accountId) => ({
          removed: await deps.trust.undoLastOutcome(accountId, id)
        })
      );
    });
    router2.register("snapshot.capture", async (payload) => {
      const id = memberId(payload?.memberId);
      const facts = observed2(payload?.observed);
      const extras = captureExtras(payload?.preferences, payload?.ownProfile);
      return lockedWrite(
        deps,
        payload?.accountId,
        { stored: false },
        async (accountId) => ({
          stored: await deps.triage.captureSnapshot(accountId, id, facts, extras)
        })
      );
    });
    router2.register("options.open", async () => {
      await deps.openOptions();
      return { done: true };
    });
  }

  // src/background/index.ts
  var router = new MessageRouter();
  router.register("diagnostic.ping", ({ value }) => ({ value }));
  router.register("diagnostic.wake", async ({ accountId }) => ({
    wakeCount: await incrementPersistentWakeCounter(accountId)
  }));
  var accounts = new AccountService();
  var activeAccountId = async () => (await accounts.getActiveAccount())?.id;
  registerTriageHandlers(router, {
    triage: new TriageService(),
    trust: new TrustService(),
    activeAccountId,
    openOptions: () => browser.runtime.openOptionsPage()
  });
  registerNotesHandlers(router, { notes: new NotesService(), activeAccountId });
  registerMessageHandlers(router, {
    messages: new MessageCacheService(runtimeSettingsArea),
    activeAccountId
  });
  registerSignalsHandlers(router, {
    signals: new SignalsService(),
    activeAccountId
  });
  registerMemberHandlers(router, { activeAccountId });
  registerCompatibilityHandlers(router, {
    compatibility: new CompatibilityService(),
    activeAccountId
  });
  registerActionHandlers(router, {
    actions: new ActionLogService(),
    activeAccountId,
    session: runtimeSessionArea
  });
  registerTemplateHandlers(router, {
    templates: new TemplateService(),
    activeAccountId
  });
  registerSearchHandlers(router, {
    searches: new SavedSearchService(),
    activeAccountId
  });
  registerListingHandlers(router, {
    listings: new EventTrackerService(),
    activeAccountId
  });
  registerOnboarding(browser.runtime);
  registerToolbarButton(browser.action, () => browser.runtime.openOptionsPage());
  browser.runtime.onMessage.addListener(
    (message2, sender) => router.route(message2, {
      ...typeof sender?.tab?.id === "number" ? { tabId: sender.tab.id } : {},
      ...typeof sender?.url === "string" ? { url: sender.url } : {}
    })
  );
})();
