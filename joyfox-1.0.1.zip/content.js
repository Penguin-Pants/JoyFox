"use strict";
(() => {
  // src/errors.ts
  var ExtensionError = class extends Error {
    constructor(code, message2, options) {
      super(message2, options);
      this.code = code;
      this.name = "ExtensionError";
      if (options?.display) this.display = options.display;
    }
    /**
     * What the UI shows, in the user's language. The English `message` stays
     * for logs; a panel never shows it (docs/i18n-spec.md, Section 3.10).
     */
    display;
  };

  // src/i18n/catalog/en.ts
  var en = {
    // Shared labels
    "placement.qualified": "Qualified",
    "placement.needs-review": "Needs Review",
    "placement.quarantined": "Junk",
    "condition.verified": "Verified by JoyClub",
    "condition.personallyKnown": "Personally known",
    "condition.minimumPhotos": "Minimum photos",
    "condition.minimumProfileWords": "Minimum profile words",
    "condition.minimumAccountAgeDays": "Minimum account age in days",
    "condition.notTemplateSpam": "Not flagged as template spam",
    "condition.minimumTrustScore": "Minimum local trust score",
    "condition.firstMessageContains": "First message contains",
    "field.accountAgeDays": "Account age in days",
    "field.photoCount": "Photo count",
    "field.profileWordCount": "Profile word count",
    "outcome.qualified": "Qualified",
    "outcome.partial-information": "Partial information",
    "outcome.does-not-meet-rule": "Does not meet rule",
    "common.close": "Close",
    "common.openOptions": "Open JoyFox options",
    "common.saveFailed": "JoyFox could not save that change. Nothing was changed. Try again. If it keeps failing, reload the page.",
    "legacy.text": (p) => p.text,
    // Shown in place of a damaged or unknown text reference, never its key.
    "common.textUnavailable": "(This text cannot be shown.)",
    // Triage reasons (qualification engine, contact rule, triage service)
    "triage.reason.unknownValue": (p) => `${p.field} is unknown, so it was not counted for or against.`,
    "triage.reason.atOrAbove": (p, f) => `${p.field} is ${f.number(p.value)}, at or above the required ${f.number(p.minimum)}.`,
    "triage.reason.belowMinimum": (p, f) => `${p.field} is ${f.number(p.value)}, below the required ${f.number(p.minimum)}.`,
    "triage.reason.accountAgeRangeAbove": (p, f) => `Account age is between ${f.number(p.min)} and ${f.number(p.max)} days, at or above the required ${f.number(p.minimum)}.`,
    "triage.reason.accountAgeRangeBelow": (p, f) => `Account age is between ${f.number(p.min)} and ${f.number(p.max)} days, below the required ${f.number(p.minimum)}.`,
    "triage.reason.accountAgeRangeCoarse": (p, f) => `Account age is between ${f.number(p.min)} and ${f.number(p.max)} days, which is too coarse to compare with the required ${f.number(p.minimum)}, so it was not counted for or against.`,
    "triage.reason.verificationUnknown": "Verification status is unknown, so it was not counted for or against.",
    "triage.reason.verified": "The profile is verified, as the rule requires.",
    "triage.reason.notVerified": "The profile is not verified, which the rule requires.",
    "triage.reason.personallyKnownUnknown": "Whether you know this member personally is unknown, so it was not counted for or against.",
    "triage.reason.personallyKnown": "You marked this member as personally known, as the rule requires.",
    "triage.reason.notPersonallyKnown": "You have not marked this member as personally known, which the rule requires.",
    "triage.reason.noCriteria": "No qualification criteria are configured, so every sender qualifies.",
    "triage.reason.spamFlagged": "A message from this sender looks like a copied template.",
    "triage.reason.spamNotFlagged": "No message from this sender looks like a copied template.",
    "triage.reason.spamOverridden": "You marked this sender as not spam.",
    "triage.reason.spamUnknown": "JoyFox has not checked this sender's messages for templates, so spam status is unknown.",
    "triage.reason.phraseSeenNow": (p) => `The latest message from this sender contains "${p.text}".`,
    "triage.reason.phraseSeenBefore": (p) => `An earlier message from this sender, seen in your inbox, contains "${p.text}".`,
    "triage.reason.phraseNotInLatest": (p) => `The latest message from this sender does not contain "${p.text}". The inbox shows only the latest message, so JoyFox cannot see if the first message contained it.`,
    "triage.reason.phraseNotSeen": (p) => `JoyFox has not seen a message from this sender that contains "${p.text}". Only the inbox shows messages to JoyFox.`,
    "triage.reason.trustUnknown": "You have logged nothing about this member, so the local trust score is unknown.",
    "triage.reason.trustAtOrAbove": (p, f) => `Your local trust score is ${f.number(p.score)}, at or above the required ${f.number(p.minimum)}.`,
    "triage.reason.trustBelow": (p, f) => `Your local trust score is ${f.number(p.score)}, below the required ${f.number(p.minimum)}.`,
    "triage.reason.negatedMet": (p) => `${p.reason} Your rule says "not ${p.condition}", so this counts as met.`,
    "triage.reason.negatedNotMet": (p) => `${p.reason} Your rule says "not ${p.condition}", so this counts as not met.`,
    "triage.reason.unknownNeedsReview": (p) => `${p.reason} Your rule sends unknown values to Needs Review.`,
    "triage.reason.unknownMet": (p) => `${p.reason} Your rule counts an unknown value as met.`,
    "triage.reason.unknownNotMet": (p) => `${p.reason} Your rule counts an unknown value as not met.`,
    "triage.reason.numbered": (p, f) => `Group ${f.number(p.number)}: ${p.reason}`,
    "triage.reason.userMoved": (p) => `You moved this sender to ${p.placement}.`,
    "triage.headline.noConditions": "Your contact rule has no required conditions, so every sender qualifies.",
    "triage.headline.meets": "This sender meets your contact rule.",
    "triage.headline.undecided": "JoyFox could not decide, because some information is unknown.",
    "triage.headline.doesNotMeet": (p) => `This sender does not meet your contact rule, so JoyFox places them in ${p.placement}.`,
    // Trust score
    "trust.reason.positive": (p, f) => `You logged ${f.plural(p.count, {
      one: "1 positive outcome",
      other: `${f.number(p.count)} positive outcomes`
    })}.`,
    "trust.reason.negative": (p, f) => `You logged ${f.plural(p.count, {
      one: "1 negative outcome",
      other: `${f.number(p.count)} negative outcomes`
    })}.`,
    "trust.reason.neutral": (p, f) => `You logged ${f.plural(p.count, {
      one: "1 neutral outcome",
      other: `${f.number(p.count)} neutral outcomes`
    })}, which count 0.`,
    "trust.reason.personallyKnown": "You marked this member as personally known.",
    "trust.reason.spamFlagged": "A message from this member looks like a copied template.",
    "trust.scopeNote": "Based only on what you logged and saw in this browser. It is not a JoyClub or community rating.",
    // Template spam detector
    "spam.detail.override": "You marked this sender as not spam, so their messages are never flagged.",
    "spam.detail.belowMinimum": (p, f) => `The message has ${f.plural(p.words, {
      one: "1 word",
      other: `${f.number(p.words)} words`
    })}, below the ${f.number(p.minimum)} needed before template matching runs.`,
    "spam.detail.duplicate": (p, f) => `This message closely matches an earlier message you received (${f.number(p.percent)}% similar).`,
    "spam.detail.knownPhrase": "The message contains a phrase from your known-template list.",
    "spam.detail.phraseSimilar": (p, f) => `The message closely matches a phrase from your known-template list (${f.number(p.percent)}% similar).`,
    "spam.detail.noMatch": "The message matched no earlier message and no known template phrase.",
    // Quick Ignore and Delete (M9): the report built from ActionLog steps
    "action.step.ignore": "Ignore",
    "action.step.delete": "Delete",
    "action.where.before": (p) => `before ${p.step}`,
    "action.where.during": (p) => `during ${p.step}`,
    "action.failure.control-missing": (p) => `JoyFox could not find JoyClub's ${p.step} option on this page.`,
    "action.failure.confirmation-missing": (p) => `JoyClub's confirmation for ${p.step} did not appear.`,
    "action.failure.not-verified": (p) => `JoyClub did not show that ${p.step} succeeded.`,
    "action.failure.unverifiable": (p) => `JoyFox cannot see JoyClub's result for ${p.step} on this page, so it stopped ${p.where}.`,
    "action.failure.member-mismatch": (p) => `The page showed another member, so JoyFox stopped ${p.where}.`,
    "action.failure.conversation-mismatch": (p) => `The page showed another conversation, so JoyFox stopped ${p.where}.`,
    "action.failure.identity-unavailable": (p) => `JoyFox could not confirm which member or conversation the page shows, so it stopped ${p.where}.`,
    "action.failure.account-changed": (p) => `The active JoyFox account changed, so JoyFox stopped ${p.where}.`,
    "action.failure.turned-off": (p) => `Ignore and Delete was turned off, so JoyFox stopped ${p.where}.`,
    "action.failure.superseded": (p) => `A newer JoyFox run for this member started, so JoyFox stopped ${p.where}.`,
    "action.failure.log-unavailable": (p) => `JoyFox could not write to its action log, so it stopped ${p.where}.`,
    "action.failure.handoff-failed": (p) => `JoyFox could not move on to the member's profile, so it stopped ${p.where}.`,
    "action.failure.timeout": (p) => `JoyClub did not respond in time during ${p.step}.`,
    "action.failure.step-error": (p) => `An unexpected error stopped JoyFox ${p.where}.`,
    "action.stepText.ignore.done": "Ignore: done. JoyClub ignores this member.",
    "action.stepText.ignore.not-done": "Ignore: not done.",
    "action.stepText.ignore.unknown": "Ignore: not confirmed. JoyFox started it but did not see JoyClub confirm it.",
    "action.stepText.delete.done": "Delete: done. JoyClub moved the conversation to the trash.",
    "action.stepText.delete.not-done": "Delete: not done.",
    "action.stepText.delete.unknown": "Delete: not confirmed. JoyFox started it but did not see JoyClub confirm it.",
    "action.next.ignore": "Next: open the member's profile and check whether they are ignored. If not, ignore them there yourself.",
    "action.next.delete": "Next: open the conversation and check whether it is in the trash. If not, move it there yourself with JoyClub's trash button.",
    "action.next.showList": "Delete works only while this conversation shows in the ClubMail list beside it. Widen the window, or scroll the list until the conversation shows, then try again.",
    "action.self.ignore": "You can do it yourself: open the member's profile and ignore them there.",
    "action.self.delete": "You can do it yourself: move the conversation to the trash with JoyClub's trash button.",
    "action.report.finished": "Ignore and Delete finished.",
    "action.report.undo": `To undo, restore the conversation from JoyClub's trash. Then open the member's profile and choose "Profil nicht mehr ignorieren" in its menu.`,
    "action.report.running": "Ignore and Delete is running.",
    "action.report.stopped": "Ignore and Delete stopped.",
    "action.report.interrupted": "Ignore and Delete was interrupted, for example because the tab closed.",
    "action.report.nothingChanged": "Nothing was changed on JoyClub.",
    "action.report.notUndone": "JoyFox did not undo anything.",
    "action.deleteReport.finished": "Delete finished.",
    "action.deleteReport.undo": "To undo, restore the conversation from JoyClub's trash.",
    "action.deleteReport.running": "Delete is running.",
    "action.deleteReport.stopped": "Delete stopped.",
    "action.deleteReport.interrupted": "Delete was interrupted, for example because the tab closed.",
    // Content script: the Delete and Ignore and Delete buttons and notice
    "quick.progress.Started": "Ignore and Delete is running. Checking the page.",
    "quick.delete.progress.Started": "Delete is running. Checking the page.",
    "quick.progress.DeleteRequested": "Moving the conversation to the trash.",
    "quick.progress.DeleteConfirmed": "Delete done. Opening the member's profile to ignore them there.",
    "quick.progress.IgnoreRequested": "Ignoring the member on JoyClub.",
    "quick.button": "Ignore and Delete",
    "quick.region": "JoyFox conversation actions",
    "quick.delete.button": "Delete",
    "quick.delete.scope": "One click moves this conversation to JoyClub's trash, then returns to the ClubMail list. The member is not ignored. JoyFox stops at the first problem and tells you what was done. It never sends a message.",
    "quick.scope": "Experimental. One click moves this conversation to JoyClub's trash, then opens the member's profile and ignores them there. JoyFox stops at the first problem and tells you what was done. It never sends a message.",
    "quick.needsList": "Works only while this conversation shows in the ClubMail list beside it. Widen the window, or scroll the list until the conversation shows.",
    "quick.noProfile": "JoyFox cannot find the link to this member's profile, where Ignore is, so it did nothing. You can do it yourself: move the conversation to the trash with JoyClub's trash button, then open the member's profile and ignore them there.",
    "quick.resumed": "Ignore and Delete, continued from the conversation:",
    "quick.waitingMenu": "Waiting for JoyClub's profile menu\u2026",
    "quick.previous": "Your last Ignore and Delete for this member:",
    "quick.previousOther": "Your last Ignore and Delete for this member, in another conversation:",
    "quick.otherResult": "Your last Ignore and Delete, for another conversation:",
    "quick.delete.previous": "Your last Delete for this member:",
    "quick.delete.previousOther": "Your last Delete for this member, in another conversation:",
    "quick.delete.otherResult": "Your last Delete, for another conversation:",
    "quick.otherRunning": "A JoyFox run is still going for another conversation. Wait until it ends.",
    "quick.busy": "Another JoyFox run for this member is still going, for example in another tab. Nothing was done here.",
    "quick.junk.done": "Mark as junk: the sender is in Junk, and a Negative outcome is logged.",
    "quick.junk.busy": "Another JoyFox run for this member is still going, so JoyFox did not start the trash step.",
    "quick.junk.notTrashed": "The conversation was not moved to the trash.",
    "quick.delete.unexpected": "Delete stopped because of an unexpected error. JoyFox may have moved the conversation to the trash: check JoyClub's trash yourself.",
    "quick.unexpected": "Ignore and Delete stopped because of an unexpected error. JoyFox may have completed a step: check the member's profile and the conversation yourself.",
    // Content script: triage explanation, member bar and trust controls
    "triage.outcome.met": "Met",
    "triage.outcome.not-met": "Not met",
    "triage.outcome.needs-review": "Needs Review",
    "triage.conditions.summary": (p, f) => `All checked conditions (${f.number(p.count)})`,
    "triage.condition.line": (p) => `${p.outcome}: ${p.condition}. `,
    "triage.condition.lineNegated": (p) => `${p.outcome}: not ${p.condition}. `,
    "triage.placementLine": (p) => `Placement: ${p.placement} (${p.source}).`,
    "triage.source.override": "your manual choice",
    "triage.source.rule": "your contact rule",
    "triage.source.sharedEvent": "the shared-event exception",
    "triage.sharedEvent.attending": (p) => `On the guest list of "${p.event}"${p.when ? ` (${p.when})` : ""}, which you marked Attending.`,
    "triage.sharedEvent.attended": (p) => `On the guest list of "${p.event}"${p.when ? ` (${p.when})` : ""}, which you marked Attended.`,
    "triage.sharedEvent.optOut": "Don't use the shared event for this sender",
    "triage.movedOn": (p) => `You moved this sender on ${p.date}. Your rule alone would place them in ${p.placement}.`,
    "triage.place.group": "Place this sender",
    "triage.useRule": "Use my rule again",
    "mark.group": "Mark this sender",
    "mark.qualified": "Mark qualified",
    "mark.junk": "Mark as junk",
    "mark.trustFailed": (p) => `JoyFox placed this sender in ${p.placement} but could not log the trust outcome, so it stopped there. You can log it on the member's conversation or profile page.`,
    "mark.junk.noTrash": "The sender is in Junk, and a Negative outcome is logged. JoyFox could not move this conversation to the trash here. Move it there yourself with JoyClub's trash button.",
    "triage.profileFact.minimumPhotos": "photo count",
    "triage.profileFact.minimumProfileWords": "profile word count",
    "triage.profileFact.minimumAccountAgeDays": "account age",
    "triage.unknownFacts.one": (p) => `The ${p.fact} is unknown. Open the profile and JoyFox reads it.`,
    "triage.unknownFacts.two": (p) => `The ${p.first} and ${p.second} are unknown. Open the profile and JoyFox reads them.`,
    "triage.unknownFacts.three": (p) => `The ${p.first}, ${p.second} and ${p.third} are unknown. Open the profile and JoyFox reads them.`,
    "trust.score.none": "Local trust score: no history yet.",
    "trust.score.value": (p, f) => `Local trust score: ${f.number(p.score)}.`,
    "trust.details.summary": "How the score adds up",
    "trust.contribution": (p, f) => `${p.points > 0 ? "+" : ""}${f.number(p.points)}: ${p.reason}`,
    "trust.log.group": "Log how it went with this member",
    "trust.log.positive": "Log positive",
    "trust.log.neutral": "Log neutral",
    "trust.log.negative": "Log negative",
    "trust.log.undo": "Undo last outcome",
    "bar.placementPrefix": "Placement: ",
    "bar.yourChoice": "(your choice)",
    "bar.sharedEvent": "(shared event)",
    "bar.openProfile": "Open profile",
    "bar.log": "Log:",
    "bar.positive": "Positive",
    "bar.neutral": "Neutral",
    "bar.negative": "Negative",
    "bar.undo": "Undo",
    "bar.details": "Details",
    "strip.collapse": "Collapse JoyFox",
    "strip.expand": "Expand JoyFox",
    "bar.scoreDetails": "Score details",
    "panel.ruleOff.no-rule": "No contact rule is set, so JoyFox does not place this sender.",
    "panel.ruleOff.rule-disabled": "Your contact rule is turned off, so JoyFox does not place this sender.",
    "panel.ruleOff.other": "JoyFox cannot place this sender right now. Reload the page to try again.",
    "panel.ruleOff.no-account": "No JoyFox account is active, so JoyFox shows nothing for this member.",
    // Content script: inbox triage
    "inbox.region": "JoyFox triage",
    "inbox.views": "Show messages",
    "inbox.view.default": "Inbox",
    "inbox.view.all": "Show all",
    "inbox.viewCount": (p, f) => `${p.view} (${f.number(p.count)})`,
    "inbox.about": "About these views",
    "inbox.aboutText": "Inbox hides Junk rows from this view only. Nothing is deleted, and JoyFox changes nothing on JoyClub.",
    "inbox.checking": "Checking",
    "inbox.badge": (p) => `JoyFox: ${p.text}. Details.`,
    "inbox.why": "Details",
    "inbox.whyNamed": (p) => `Details: ${p.name}`,
    "inbox.rowGone": "This row is no longer shown.",
    "inbox.unidentified": "JoyFox could not read this sender's profile number, so it could not check your rule. The row stays visible.",
    "inbox.stillChecking": "JoyFox is still checking this sender.",
    "inbox.setup.no-account": "JoyFox has no active account, so it does not sort this inbox.",
    "inbox.setup.no-rule": "No contact rule is saved, so JoyFox does not sort this inbox.",
    // Content script: notes and tags
    "notes.region": "JoyFox notes and tags",
    "notes.scope": "Private to JoyFox: stored only in this browser, under the active JoyFox account. JoyFox never sends it anywhere.",
    "notes.saved": "Note saved.",
    "notes.removed": "Note removed.",
    "notes.conflict": "This note changed in another tab or in the JoyFox data inspector, so JoyFox did not save your text. It is still in the box. Save again to replace the stored note, or discard your changes to see it.",
    "notes.refused": "The active JoyFox account changed, so nothing was stored. Text typed for the previous account was dropped.",
    "notes.emptyTag": "Type a tag first. Nothing was added.",
    "notes.emptyNote": "Type a note first. Nothing was saved.",
    "notes.tagAdded": "Tag added.",
    "notes.tagExists": "Already tagged.",
    "notes.tagRemoved": "Tag removed.",
    "notes.privateNote": "Private note",
    // Shown under a note box once the text is near its limit.
    "notes.length": (p, f) => `${f.number(p.count)} of ${f.number(p.maximum)} characters`,
    "notes.pasteCut": "Only part of the pasted text fit. The rest was not pasted.",
    "notes.discard": "Discard my changes",
    "notes.save": "Save note",
    "notes.tags": "Tags",
    "notes.noTags": "No tags yet.",
    "notes.remove": "Remove",
    "notes.removeTag": (p) => `Remove tag ${p.label}`,
    "notes.addTagLabel": "Add a tag",
    "notes.addTag": "Add tag",
    "notes.summary.none": "Your notes and tags (none yet)",
    "notes.summary.note": "Your notes and tags (a note)",
    "notes.summary.tags": (p, f) => `Your notes and tags (${f.plural(p.count, {
      one: "1 tag",
      other: `${f.number(p.count)} tags`
    })})`,
    "notes.summary.noteAndTags": (p, f) => `Your notes and tags (a note and ${f.plural(p.count, {
      one: "1 tag",
      other: `${f.number(p.count)} tags`
    })})`,
    // Content script: event and venue notes (V1-5)
    "listing.heading.event": "JoyFox: your notes on this event",
    "listing.heading.venue": "JoyFox: your notes on this venue",
    // The box's summary: what is stored, for example "Attending, 2 tags, a note".
    "listing.summary.event": (p) => `JoyFox: your notes on this event (${p.state})`,
    "listing.summary.venue": (p) => `JoyFox: your notes on this venue (${p.state})`,
    "listing.summary.none": "none yet",
    "listing.summary.note": "a note",
    "listing.loading": "Loading your notes\u2026",
    "listing.readFailed": "JoyFox could not read your notes on this page. Reload the page to try again.",
    "listing.noAccount": "Select or add an account in the JoyFox options to keep notes on events.",
    "listing.attendanceLabel": "Your attendance",
    "listing.attendance.unknown": "No status",
    "listing.attendance.interested": "Interested",
    "listing.attendance.attending": "Attending",
    "listing.attendance.not-attending": "Not attending",
    "listing.attendance.attended": "Attended",
    "listing.noteLabel": "Your note",
    "listing.saveNote": "Save note",
    "listing.tagsLabel": "Your tags",
    "listing.tagLabel": "New tag",
    "listing.addTag": "Add tag",
    "listing.removeTag": (p) => `Remove tag ${p.tag}`,
    "listing.emptyTag": "Type a tag first. Nothing was added.",
    "listing.tooManyTags.event": (p, f) => `You can add at most ${f.number(p.maximum)} tags to an event. Remove one first.`,
    "listing.tooManyTags.venue": (p, f) => `You can add at most ${f.number(p.maximum)} tags to a venue. Remove one first.`,
    "listing.privacy": "Private: stored only in this browser. JoyClub sees nothing, and your sign-up on JoyClub does not change.",
    "listing.saved": "Saved.",
    // The first save of an event or venue.
    "listing.tracked.event": "Saved. JoyFox now tracks this event.",
    "listing.tracked.venue": "Saved. JoyFox now tracks this venue.",
    "listing.removed.event": "No note, tag or attendance is left, so JoyFox no longer tracks this event.",
    "listing.removed.venue": "No note or tag is left, so JoyFox no longer tracks this venue.",
    "listing.conflict": "These notes changed in another tab, so JoyFox did not save. The stored notes are shown now; your typed note is still in the box.",
    "listing.refused": "The active JoyFox account changed, so nothing was saved.",
    // Options page: personal event calendar (V1-5)
    "events.heading": "Your events",
    "events.hint": "Every event and venue you added a note, tag or attendance to on JoyClub, in date order. JoyFox keeps them after JoyClub removes an event. To change one, open it on JoyClub.",
    "events.readFailed": "JoyFox could not read your events. Reload the page to try again.",
    "events.noAccount": "Select or add an account first. Each account has its own events.",
    "events.empty": "No tracked events yet. Open an event on JoyClub and add a note, a tag or your attendance.",
    "events.count": (p, f) => `${f.number(p.shown)} of ${f.number(p.total)} tracked events shown.`,
    "events.filterLabel": "Show",
    "events.filter.all": "All tracked events",
    "events.searchLabel": "Search my notes, tags and titles",
    "events.noDate": "No date",
    "events.untitled": (p) => `Event ${p.id}`,
    "events.past": (p) => `${p.when} (past)`,
    "events.venue": (p) => `Venue: ${p.venue}`,
    "events.venuesHeading": "Your venues",
    "events.guests": (p, f) => f.plural(p.count, {
      one: "1 guest stored",
      other: `${f.number(p.count)} guests stored`
    }),
    "events.exception.label": "Shared-event exception: place a sender in Qualified when they are on the guest list of an event I marked Attending or Attended",
    "events.exception.hint": `Off by default. JoyFox stores a tracked event's guest list when you open the event page, as far as JoyClub has loaded it, and deletes it when you stop tracking the event. A sender you marked yourself keeps your choice, and the "Details" panel can turn the exception off for one sender.`,
    "events.exception.saved": "Saved.",
    "events.exception.saveFailed": "JoyFox could not save this setting. Try again.",
    // Options page: the switch for the experimental Ignore and Delete (M9)
    "quickSetting.heading": "Ignore and Delete",
    "quickSetting.label": 'Show the "Ignore and Delete" button on ClubMail conversations',
    "quickSetting.hint": `Experimental and on by default. One click moves the conversation to JoyClub's trash, opens the member's profile in the same tab and ignores the member there. It works only while the ClubMail list shows beside the conversation. JoyFox acts only when you click. The "Action log" in "Your data" records every step. This setting controls only "Ignore and Delete": the "Delete" button and "Mark as junk" move a conversation to JoyClub's trash also when it is off.`,
    "quickSetting.risk": "If JoyClub finds a tool that clicks for you, it can restrict or close your account. Of all JoyFox features, this one has the highest risk.",
    "quickSetting.undo": `To undo, restore the conversation from JoyClub's trash. Then open the member's profile and choose "Profil nicht mehr ignorieren" in its menu.`,
    "quickSetting.saved": "Saved. Open ClubMail tabs follow at once.",
    "quickSetting.saveFailed": "JoyFox could not save this setting. Try again.",
    "sharedEvents.heading": "Shared events",
    "sharedEvents.intro": "This member is on the stored guest list of these events you track:",
    // Content script: event list filter (V1-5)
    "eventFilter.label": "JoyFox: show",
    "eventFilter.all": "All loaded events and dates",
    "eventFilter.tracked": "Only events JoyFox tracks",
    "eventFilter.note": "Only events with your note",
    "eventFilter.attending": "Only events you attend",
    "eventFilter.interested": "Only events you are interested in",
    "eventFilter.tag": (p) => `Only events with your tag: ${p.tag}`,
    "eventFilter.count": (p, f) => `${f.number(p.shown)} of ${f.number(p.loaded)} loaded events shown. Events loaded later are checked too.`,
    "eventFilter.readFailed": "JoyFox could not read your event notes. Reload the page to try again.",
    "eventFilter.noAccount": "Select or add an account in the JoyFox options to filter by your notes.",
    "eventFilter.badge": "JoyFox",
    "eventFilter.hasNote": "note",
    // Content script: profile type filter on the "My JOY" lists (V1-14)
    "typeFilter.legend": "Profile type",
    "typeFilter.man": "Man",
    "typeFilter.woman": "Woman",
    "typeFilter.couple": "Couple",
    "typeFilter.unknown": "Unknown",
    "typeFilter.count": (p, f) => `Showing ${f.number(p.shown)} of ${f.number(p.loaded)} loaded`,
    "typeFilter.unknownHidden": (p, f) => `${f.number(p.count)} with unknown type hidden`,
    "typeFilter.scrollHint": "Scroll down to load more.",
    "typeFilter.unknownMark": "Type unknown",
    // Options page: message search (V1-4)
    "messages.heading": "Message search",
    "messages.hint": "JoyFox stores the ClubMail messages you open, sent and received, so you can search them here. It stores only what a conversation shows on screen and never loads older messages. The text stays in this browser, and an export file holds it too. If you allow JoyFox in private windows, it stores the messages you open there in the same way.",
    "messages.caching": "Store the messages I open in ClubMail",
    "messages.cachingOn": "Message storing is on.",
    "messages.cachingOff": 'Message storing is off. Messages stored before stay until they are older than the time set here, or until you delete them under "Your data".',
    "messages.offHint": "Storing is off: JoyFox stores no new messages. Search still covers the messages stored before.",
    "messages.retentionLabel": "Keep messages for (months)",
    "messages.retentionSave": "Save",
    "messages.retentionHint": (p, f) => `Messages older than this are deleted automatically. Lowering the number deletes older messages at once. The default is ${f.number(p.default)}. Click "Save" to apply.`,
    // Save asks for a second click when the number goes down, as deletes do.
    "messages.retentionConfirm": "Save and delete",
    "messages.retentionConfirmPrompt": (p, f) => `Lowering the number deletes the stored messages older than ${f.plural(
      p.months,
      { one: "1 month", other: `${f.number(p.months)} months` }
    )} at once. Click "Save and delete" to confirm.`,
    "messages.retentionSaved": (p, f) => p.deleted === 0 ? "Saved. No older message needed deleting." : `Saved. ${f.plural(p.deleted, {
      one: "1 older message was",
      other: `${f.number(p.deleted)} older messages were`
    })} deleted.`,
    "messages.retentionInvalid": (p, f) => `Enter a whole number from ${f.number(p.minimum)} to ${f.number(p.maximum)}. Nothing was changed.`,
    "messages.noAccount": "Select or add an account first.",
    "messages.readFailed": "JoyFox could not read your stored messages. Reload the page to try again.",
    "messages.searchLabel": "Search my messages",
    "messages.count": (p, f) => p.count === 0 ? "No stored message contains this." : `${f.plural(p.count, {
      one: "1 message",
      other: `${f.number(p.count)} messages`
    })} found.`,
    "messages.countLimited": (p, f) => `${f.number(p.count)} messages found. The newest ${f.number(p.shown)} are shown.`,
    // `member` is the member's nickname, or `member.number` when JoyFox has
    // never seen it.
    "messages.sentTo": (p) => `You to ${p.member} \xB7 ${p.when}`,
    "messages.receivedFrom": (p) => `${p.member} to you \xB7 ${p.when}`,
    "messages.storedAt": (p) => `stored ${p.when}`,
    // Content script: profile signals on cards (V1-10)
    "signals.state.complete": "Complete",
    "signals.state.incomplete": "Incomplete",
    "signals.state.unknown": "Completeness unknown",
    // The inbox row's compact line: the full text is in the tooltip.
    "signals.state.unknownShort": "Unknown",
    "signals.photos": (p, f) => f.plural(p.count, {
      one: "1 photo",
      other: `${f.number(p.count)} photos`
    }),
    "signals.photosUnknown": "photos unknown",
    "signals.words": (p, f) => f.plural(p.count, {
      one: "1 word",
      other: `${f.number(p.count)} words`
    }),
    "signals.wordsUnknown": "words unknown",
    "signals.verified": "verified",
    "signals.notVerified": "not verified",
    "signals.verificationUnknown": "verification unknown",
    "signals.heading": "Profile completeness",
    "signals.trust": (p, f) => `Trust ${p.score > 0 ? "+" : ""}${f.number(p.score)}`,
    "signals.trustNoneShort": "Trust \u2013",
    "signals.noteAdd": "Add note",
    "signals.noteEdit": "Note",
    "signals.tagsLabel": "Your tags",
    "signals.tagCount": (p, f) => f.plural(p.count, {
      one: "1 tag",
      other: `${f.number(p.count)} tags`
    }),
    "signals.editor.label": (p) => `JoyFox: note and tags for ${p.member}`,
    // A member whose nickname JoyFox has never seen.
    "member.number": (p) => `Member ${p.id}`,
    "signals.editor.loading": "Loading\u2026",
    "signals.editor.close": "Close",
    "signals.editor.noAccount": "Select or add an account in the JoyFox options to keep notes.",
    "signals.editor.readFailed": "JoyFox could not read this member's notes. Close and try again.",
    "signals.filter.label": "JoyFox: hide incomplete profiles",
    "signals.filter.count": (p, f) => `${f.number(p.hidden)} of ${f.number(p.loaded)} loaded profiles hidden. Profiles JoyFox knows nothing about stay visible.`,
    // Content script: compatibility overlay (V1-2)
    "compat.heading": "Shared preferences",
    "compat.shared": (p, f) => `You share ${f.plural(p.count, {
      one: "1 preference",
      other: `${f.number(p.count)} preferences`
    })} with this member:`,
    "compat.none": "You share no preferences with this member.",
    "compat.listToggle": "Show the shared preferences",
    "compat.own": (p, f) => `This is your profile. JoyFox compares other profiles with your ${f.plural(
      p.count,
      {
        one: "1 positive preference",
        other: `${f.number(p.count)} positive preferences`
      }
    )}.`,
    "compat.ownUnknown": "Open your own JoyClub profile once, so JoyFox knows your preferences.",
    "compat.unreadable": "JoyFox could not read this profile's preferences yet.",
    "compat.missing": "This profile shows no preferences to compare.",
    "compat.readFailed": "JoyFox could not load your preferences. Reload the page to try again.",
    "compat.noAccount": "Select or add an account in the JoyFox options to compare preferences.",
    "compat.badge": (p, f) => `${f.number(p.count)} shared`,
    "compat.badgeLabel": (p, f) => `JoyFox: ${f.plural(p.count, {
      one: "1 shared preference",
      other: `${f.number(p.count)} shared preferences`
    })}`,
    "compat.sort.button": "Sort by shared preferences",
    "compat.sort.on": "Sorted by shared preferences. Members whose profile you have not opened come last.",
    "compat.sort.unavailable": "JoyFox cannot sort the results as JoyClub shows them now. Their order has not changed.",
    // Content script: saved searches (V1-3)
    "searches.heading": "JoyFox saved searches",
    "searches.loading": "Loading saved searches\u2026",
    "searches.readFailed": "JoyFox could not read your saved searches. Reload the page to try again.",
    "searches.empty": "No saved searches yet.",
    "searches.noAccount": "Select or add an account in the JoyFox options to save searches.",
    "searches.save": "Save this search",
    "searches.nameLabel": "Name for this search",
    "searches.confirmSave": "Save",
    "searches.cancel": "Cancel",
    "searches.noName": "Type a name first. Nothing was saved.",
    "searches.nameTooLong": (p, f) => `A name can have at most ${f.number(p.maximum)} characters. Nothing was saved.`,
    "searches.notSearchAddress": "This page's address is not a search JoyFox can save. Nothing was saved.",
    "searches.full": (p, f) => `You have ${f.number(p.maximum)} saved searches, the most JoyFox keeps. Delete one first.`,
    "searches.refused": "The active JoyFox account changed, so nothing was changed.",
    "searches.saved": (p) => `Saved "${p.name}".`,
    "searches.noMatch": (p) => `"${p.name}" no longer matches JoyClub's search address, so JoyFox did not open it. Run the search again and save it again.`,
    "searches.running": (p) => `Running "${p.name}"\u2026`,
    "searches.runningUnnamed": "Running the saved search\u2026",
    "searches.shown": (p) => `Showing "${p.name}".`,
    "searches.shownUnnamed": "Showing the saved search.",
    "searches.runFailed": `JoyFox could not run the saved search. Open JoyClub's filter and click "Anwenden".`,
    "searches.deleteLabel": (p) => `Delete saved search ${p.name}`,
    "searches.confirmDelete": (p) => `Click \u2715 again to delete "${p.name}".`,
    "searches.deleted": (p) => `Deleted "${p.name}".`,
    // Content script: template picker
    "picker.toggle": "JoyFox templates",
    "picker.loading": "Loading templates\u2026",
    "picker.readFailed": 'JoyFox could not load your templates. Nothing was inserted. Click "JoyFox templates" again to try again.',
    "picker.empty": "No templates yet. Add them on the JoyFox options page.",
    "picker.noAccount": "No JoyFox account is active. Choose one on the JoyFox options page.",
    "picker.result.inserted": "Template inserted. Check the text, then click JoyClub's Send button yourself.",
    "picker.result.not-editable": "The message field cannot be edited right now. Nothing was inserted. Wait until you can type in the message field, then try again.",
    "picker.result.too-long": (p, f) => `With the template, the message would be ${f.plural(p.over, {
      one: "1 character",
      other: `${f.number(p.over)} characters`
    })} too long. The message field takes at most ${f.number(p.limit)} characters. Nothing was inserted. Shorten your text or the template.`,
    "picker.result.altered": "JoyClub changed the text after insertion. Check the message field before you send.",
    "templates.folder.general": "General",
    "templates.folder.eventConfirmation": "Event confirmation",
    "templates.folder.eventCancellation": "Event cancellation",
    // Options page: shell and tabs
    "options.title": "JoyFox options",
    "options.intro": "JoyFox stores everything locally in this browser profile. Inbox sorting stays off until you save a contact rule.",
    "options.tabs.start": "Get started",
    "options.tabs.accounts": "Accounts",
    "options.tabs.rule": "Contact rule",
    "options.tabs.templates": "Templates",
    "options.tabs.events": "Events",
    "options.tabs.messages": "Messages",
    "options.tabs.data": "Your data",
    "options.importRegion": "Import JoyFox data",
    "options.languageSaveFailed": "JoyFox could not save the language. Try again.",
    // Options page: Get started
    "start.state.done": "Done",
    "start.state.off": "Saved, but turned off",
    "start.state.todo": "Not done yet",
    "start.state.doneOpen": "Done: no conditions, so every sender qualifies",
    "start.ready": "JoyFox is set up. Open your JoyClub inbox to see it sorted.",
    "start.intro": "Three steps, a few minutes. Everything stays in this browser.",
    "start.introAccess": "Four steps, a few minutes. Everything stays in this browser.",
    "start.readFailed": "JoyFox could not read its setup. Reload the page to try again.",
    "start.step.access": "Allow JoyFox to access joyclub.de. Access is off now, so JoyFox cannot work on JoyClub.",
    "start.step.account": "Add your JoyClub account under [Accounts](#accounts). JoyFox makes the first one active.",
    "start.step.chooseAccount": "Choose the active account under [Accounts](#accounts).",
    "start.step.rule": "Save a contact rule under [Contact rule](#rule). Inbox sorting stays off until a rule is saved and turned on.",
    "start.step.inbox": "Open your JoyClub inbox (www.joyclub.de, ClubMail). JoyFox adds its tabs above the list.",
    // Options page: site access (Get started)
    "access.allow": "Allow access to joyclub.de",
    "access.granted": "Access to joyclub.de is on. Reload any JoyClub tab that is open, so JoyFox can work there.",
    "access.refused": "Access to joyclub.de is still off. JoyFox cannot work on JoyClub until you allow access here or in about:addons.",
    // Options page: accounts
    "accounts.readFailed": "JoyFox could not read its stored accounts. No account was changed. Reload the page to try again.",
    "accounts.hint": "JoyFox cannot read which JoyClub login a tab uses. The active account is the one selected here. JoyFox stores your notes, tags, rules, templates and other data under it.",
    "accounts.activeLabel": "Active account:",
    "accounts.noneSelected": "None selected",
    "accounts.empty": "No accounts yet. Add one below to use JoyFox.",
    "accounts.list": "Stored accounts",
    // An account's label with its JoyClub identifier, so two accounts with
    // similar labels can be told apart.
    "accounts.nameWithIdentifier": (p) => `${p.label} (${p.identifier})`,
    "accounts.active": "Active",
    "accounts.inactive": "Not active",
    "accounts.use": "Use this account",
    "accounts.useLabel": (p) => `Use this account: ${p.name}`,
    "accounts.nowActive": (p) => `Active account is now ${p.name}.`,
    "accounts.rename": "Rename",
    "accounts.renameLabel": (p) => `Rename account ${p.name}`,
    "accounts.renameField": (p) => `New display label for ${p.identifier}`,
    "accounts.renameSave": "Save",
    "accounts.renameCancel": "Cancel",
    "accounts.renamed": (p) => `Label saved. JoyFox now shows this account as ${p.name}.`,
    "accounts.remove": "Remove",
    "accounts.confirmRemove": "Confirm removal",
    "accounts.removeLabel": (p) => `Remove account ${p.name}`,
    "accounts.confirmRemoveLabel": (p) => `Confirm removal of account ${p.name} and all of its data`,
    "accounts.removePrompt": (p) => `Removing ${p.name} deletes everything JoyFox stored for this account, for example notes, tags, rules, templates, messages, event notes and saved searches. Click again to confirm.`,
    "accounts.removed": (p) => `Removed ${p.name} and its stored data.`,
    "accounts.removedNoneActive": (p) => `Removed ${p.name} and its stored data. No account is active now. Choose one with "Use this account".`,
    "accounts.removedNoneLeft": (p) => `Removed ${p.name} and its stored data. No accounts are left. Add one to use JoyFox.`,
    "accounts.addForm": "Add an account",
    "accounts.identifier": "JoyClub account identifier",
    "accounts.identifierHint": "Your JoyClub nickname works well. JoyFox uses it only to tell your accounts apart and to match imports. JoyFox does not check it. You cannot change it later.",
    "accounts.label": "Display label (optional)",
    "accounts.labelHint": "Only JoyFox shows this label. If you leave it empty, JoyFox shows the identifier.",
    "accounts.add": "Add account",
    "accounts.added": (p) => `Added ${p.name}.`,
    // Options page: contact rule
    "rule.readFailed": "JoyFox could not read the contact rule. No rule was changed. Reload the page to try again.",
    "rule.hint": "The rule only changes how JoyFox groups your own inbox into Qualified, Needs Review and Junk. It never stops a message, never deletes anything, and the sender sees nothing.",
    "rule.noAccount": "Select or add an account first. Each account has its own rule.",
    "rule.newer": "This rule was made in a newer version of JoyFox and cannot be edited here. Delete it to start a new one.",
    "rule.note.saved": "A rule is saved for the active account.",
    "rule.note.none": "No rule is saved for the active account, so JoyFox does not sort the inbox.",
    "rule.enabled": "Sort my JoyClub inbox with this rule",
    "rule.placementLabel": "A sender who does not meet the rule goes to",
    "rule.spamHint": 'Spam status is unknown for now: JoyFox does not check messages for templates yet. Only your own "not spam" corrections count. The inbox shows only the verification shield; photos, profile words and account age come from profiles you opened before.',
    "rule.autosaveHint": "Changes are saved automatically: a box or choice at once, a number or text when you leave its field.",
    "rule.firstMessageHint": '"First message contains" reads the message preview in your inbox, ignoring upper and lower case. The inbox shows only the latest message, so when a sender sent more than one, the preview may not be the first. If the preview does not contain your text, the condition counts as your "If JoyFox cannot see this" choice. Once JoyFox sees your text, it stays met.',
    "rule.preset.label": "Start from a preset",
    "rule.preset.choose": "Choose a preset\u2026",
    "rule.preset.apply": "Apply preset",
    "rule.preset.confirm": "Replace conditions",
    "rule.preset.confirmPrompt": 'The preset replaces every condition below. Click "Replace conditions" to confirm.',
    "rule.preset.hint": "A preset fills in the conditions below and saves them. You can then change them like any other rule.",
    "rule.preset.open": "Open",
    "rule.preset.complete": "Complete profiles only",
    "rule.preset.verified": "Verified members",
    "rule.preset.highTrust": "High-trust members",
    "rule.preset.custom": "Custom",
    "rule.preset.describe.open": "No conditions: every sender qualifies.",
    "rule.preset.describe.complete": (p, f) => `A sender needs at least ${f.number(p.photos)} photos and at least ${f.number(p.words)} words of profile text.`,
    "rule.preset.describe.verified": "A sender needs to be verified by JoyClub.",
    "rule.preset.describe.highTrust": (p, f) => `A sender needs to be verified by JoyClub, with at least ${f.number(p.photos)} photos, at least ${f.number(p.words)} words of profile text and an account at least ${f.number(p.days)} days old.`,
    "rule.preset.describe.custom": "Clears all conditions, so you can tick the ones you want.",
    "rule.preset.applied": (p) => `Preset "${p.preset}" applied and saved. You can change its conditions below.`,
    "rule.preset.appliedOpen": 'Preset "Open" applied and saved. The rule has no conditions, so every sender qualifies.',
    "rule.preset.appliedCustom": "All conditions cleared and saved. Tick the conditions you want. Until you do, every sender qualifies.",
    "rule.editor": "Editor:",
    "rule.simple": "Simple",
    "rule.advanced": "Advanced",
    "rule.match.all": "ALL",
    "rule.match.any": "ANY",
    "rule.box.all": "A sender qualifies when ALL of these are met",
    "rule.box.any": "Or a sender qualifies when ANY of these is met",
    "rule.unknown.needs-review": "Send to Needs Review",
    "rule.unknown.met": "Count as met",
    "rule.unknown.not-met": "Count as not met",
    "rule.unknownPrompt": "If JoyFox cannot see this:",
    "rule.unknownLabel": (p) => `${p.condition}: if JoyFox cannot see this`,
    "rule.valueLabel": (p) => `${p.condition} value`,
    "rule.numberProblem": (p, f) => `Enter a whole number from ${f.number(p.minimum)} to ${f.number(p.maximum)} for "${p.condition}".`,
    "rule.textPlaceholder": "Word, phrase or emoji",
    "rule.textLabel": (p) => `${p.condition}: word, phrase or emoji`,
    "rule.textProblem": (p, f) => `Enter a word, phrase or emoji of up to ${f.number(p.maximum)} characters for "${p.condition}".`,
    "rule.fieldNumberProblem": (p, f) => `Enter a whole number from ${f.number(p.minimum)} to ${f.number(p.maximum)}.`,
    "rule.fieldTextProblem": (p, f) => `Enter a word, phrase or emoji of up to ${f.number(p.maximum)} characters.`,
    "rule.textHint": "Type a word, phrase or emoji to use this condition.",
    "rule.spamNote": "(not checked yet: always unknown)",
    "rule.combine.label": "How the groups combine",
    "rule.combine.prefix": "A sender is qualified if ",
    "rule.combine.suffix": " of these groups match.",
    "rule.advancedHint": 'Each group is met when ALL or ANY of its conditions are met, as you choose. Tick "not" to turn a condition around: "not Minimum photos 3" means fewer than 3 photos. A group without conditions is not saved.',
    "rule.addRule": "+ Add group",
    "rule.removeRule": "Remove group",
    "rule.confirmRemoveGroup": "Confirm removal",
    "rule.confirmRemoveGroupLabel": (p, f) => `Confirm removal of group ${f.number(p.number)}`,
    "rule.removeGroupPrompt": (p, f) => `Click again to remove group ${f.number(p.number)} and its conditions.`,
    "rule.ruleSuffix": " of these are met",
    "rule.noConditions": "No conditions yet. Add one below.",
    "rule.removeCondition": "Remove condition",
    "rule.removeConditionLabel": (p) => `Remove ${p.condition}`,
    "rule.not": "not",
    "rule.notTitle": "Turn this condition around",
    "rule.notLabel": (p) => `not: turn "${p.condition}" around`,
    "rule.joiner.all": "AND",
    "rule.joiner.any": "OR",
    "rule.ruleTitle": (p, f) => `Group ${f.number(p.number)}: met if `,
    "rule.ruleMatchLabel": (p, f) => `How group ${f.number(p.number)} combines its conditions`,
    "rule.removeRuleLabel": (p, f) => `Remove group ${f.number(p.number)}`,
    "rule.addConditionLabel": (p, f) => `Add a condition to group ${f.number(p.number)}`,
    "rule.addCondition": "+ Add condition\u2026",
    "rule.ruleCount": (p, f) => `${f.number(p.count)} of ${f.number(p.maximum)} groups`,
    "rule.simpleUnavailable.all": "Simple view is not available: the groups combine with ALL.",
    "rule.simpleUnavailable.not": 'Simple view is not available: the rule uses "not".',
    "rule.simpleUnavailable.severalAll": "Simple view is not available: more than one group needs ALL of several conditions.",
    "rule.simpleUnavailable.duplicate": "Simple view is not available: a condition appears in more than one group.",
    "rule.savedNoConditions": "Rule saved. It has no conditions yet, so every sender qualifies.",
    "rule.savedVacuous": "Rule saved. With nothing in the ALL box, every sender qualifies, so the ANY box has no effect.",
    "rule.saved": "Rule saved. Open JoyClub tabs update at once.",
    "rule.notSaved": (p) => `${p.problem} The rule was not saved.`,
    "rule.saveFailed": "JoyFox could not save the rule. Nothing was changed. Change the field again, or reload the page to see the saved rule.",
    "rule.deleteAll": "Delete whole contact rule",
    "rule.confirmDeleteAll": "Confirm delete",
    "rule.deletePrompt": "Click again to delete the whole contact rule. JoyFox then stops sorting the inbox for this account.",
    "rule.removed": "Contact rule deleted. JoyFox no longer sorts the inbox for this account.",
    "rule.removeFailed": "JoyFox could not delete the rule. Nothing was changed. Try again. If it keeps failing, reload the page.",
    "rule.stale.account.saved": "The active account changed, so the rule was not saved. Check the active account on the Accounts tab before you change the rule again.",
    "rule.stale.account.removed": "The active account changed, so the rule was not deleted. Check the active account on the Accounts tab before you delete a rule again.",
    "rule.stale.rule.saved": "The rule was changed in another tab. It was not saved. The form now shows the saved rule.",
    "rule.stale.rule.removed": "The rule was changed in another tab. It was not deleted. The form now shows the saved rule.",
    "rule.changedElsewhere": "The rule was changed in another tab. The form now shows the saved rule.",
    // Options page: templates
    "templates.readFailed": "JoyFox could not read your templates. No template was changed. Reload the page to try again.",
    "templates.heading": "Message templates",
    "templates.hint": `On a JoyClub conversation, the "JoyFox templates" button below the message field inserts a template at the cursor. You can still edit the text, and you always click JoyClub's Send button yourself. JoyFox never sends a message.`,
    // `[Accounts](#accounts)` is drawn as a link to the Accounts tab.
    "templates.noAccount": "Choose an active account on the [Accounts](#accounts) tab to store templates.",
    "templates.empty": "No templates yet. Add one below.",
    "templates.inFolder": (p) => `Templates in ${p.folder}`,
    "templates.edit": "Edit",
    "templates.editLabel": (p) => `Edit template ${p.name}`,
    "templates.editing": (p) => `Editing ${p.name}.`,
    "templates.delete": "Delete",
    "templates.confirmDelete": "Confirm delete",
    "templates.deleteLabel": (p) => `Delete template ${p.name}`,
    "templates.confirmDeleteLabel": (p) => `Confirm delete: template ${p.name}`,
    "templates.deletePrompt": (p) => `Click "Confirm delete" to delete ${p.name}.`,
    "templates.deleted": (p) => `Deleted ${p.name}.`,
    "templates.addForm": "Add a template",
    "templates.name": "Name",
    "templates.folder": "Folder (optional, General if empty)",
    "templates.text": "Text",
    "templates.saveChanges": "Save changes",
    "templates.add": "Add template",
    "templates.cancel": "Cancel editing",
    "templates.saved": (p) => `Saved ${p.name}.`,
    "templates.added": (p) => `Added ${p.name}.`,
    "templates.accountChanged": "The active account changed, so nothing was changed. Check the active account on the Accounts tab before you try again.",
    // Options page: your data
    "entity.extensionAccounts": "Account record",
    "entity.joyClubMembers": "Members",
    "entity.profileSnapshots": "Profile snapshots",
    "entity.userNotes": "Notes",
    "entity.userTags": "Tags",
    "entity.trustSignals": "Trust outcomes",
    "entity.contactRules": "Contact rules",
    "entity.conversationClassifications": "Manual placements",
    "entity.savedSearches": "Saved searches",
    "entity.eventMetadata": "Event notes",
    "entity.spendLogEntries": "Spending log",
    "entity.syncConfigs": "Sync settings",
    "entity.extensionPreferences": "Preferences",
    "entity.messageTemplates": "Message templates",
    "entity.spamPhrases": "Spam phrases",
    "entity.messageObservations": "Cached message text (normalized)",
    "entity.senderSpamOverrides": "Not-spam corrections",
    "entity.actionLogs": "Action log",
    "entity.messagePhraseMatches": "Message phrase matches",
    "entity.cachedMessages": "Stored messages (for search)",
    "data.readFailed": "JoyFox could not read its stored data. Nothing was changed. Reload the page to try again.",
    "data.hint": "Everything JoyFox stores stays in this browser profile. You can inspect it, save it as a JSON file and delete it here. Deleting here never changes anything on JoyClub.",
    // Import is on the Accounts tab (owner decision); this line points there.
    "data.importPointer": "To import a file, go to [Accounts](#accounts).",
    "data.noAccounts": "No accounts yet.",
    "data.accountPicker": "Account to inspect (does not change the active account)",
    "data.caption": "Stored records for this account",
    "data.col.type": "Data type",
    "data.col.records": "Records",
    "data.col.actions": "Actions",
    "data.show": "Show",
    "data.hide": "Hide",
    "data.showLabel": (p) => `Show ${p.label}`,
    "data.hideLabel": (p) => `Hide ${p.label}`,
    "data.deleteAll": "Delete all",
    "data.deleteAllLabel": (p) => `Delete all ${p.label}`,
    "data.deleteAllPrompt": (p, f) => `Click "Confirm" to delete all ${f.number(p.count)} ${p.label} records of this account.`,
    "data.deletedAll": (p) => `Deleted all ${p.label} of this account.`,
    "data.recordsTitle": (p, f) => `${p.label} (${f.number(p.count)})`,
    "data.accountRecordHint": "The account record is removed only with the whole account, on the [Accounts](#accounts) tab.",
    "data.recordSummary": (p) => `${p.id} (updated ${p.updated})`,
    // A record with a name a person knows: a member's nickname, a template's
    // or saved search's name, an event's title or an account's label.
    "data.recordSummaryNamed": (p) => `${p.name}: ${p.id} (updated ${p.updated})`,
    // A record with a name a person reads, in delete labels and messages.
    "data.recordNamed": (p) => `${p.name} (${p.id})`,
    "data.valueYes": "yes",
    "data.valueNo": "no",
    "data.valueEmpty": "(empty)",
    "data.rawJson": "Stored JSON",
    "data.moreCharacters": (p, f) => `\u2026and ${f.number(p.count)} more characters (see "Stored JSON")`,
    "data.moreValues": (p, f) => `\u2026and ${f.number(p.count)} more (see "Stored JSON")`,
    "data.delete": "Delete",
    "data.deleteRecordLabel": (p) => `Delete record ${p.record}`,
    "data.deleteRecordPrompt": (p) => `Click "Confirm" to delete record ${p.record}.`,
    "data.deletedRecord": (p) => `Deleted record ${p.record}.`,
    "data.showMore": (p, f) => `Show ${f.number(p.count)} more`,
    "data.exportAccount": "Export this account (JSON)",
    "data.exportedAccount": "Export of this account created.",
    "data.deleteAccountData": "Delete this account's data",
    "data.deleteAccountDataLabel": "Delete this account's data (every record)",
    "data.deleteAccountDataPrompt": 'Click "Confirm" to delete every record of this account. The account itself stays in Accounts.',
    "data.deletedAccountData": "Deleted all data of this account. The account itself is kept.",
    "data.allAccounts": "All accounts",
    "data.retentionLabel": "Profile snapshots kept per member",
    "data.retentionHint": (p, f) => `JoyFox keeps the newest snapshots of each member's profile facts, always at least the latest one. Lowering the number deletes older snapshots at once, in every account. From ${f.number(p.minimum)} to ${f.number(p.maximum)}; the default is ${f.number(p.default)}. Click "Save" to apply.`,
    "data.retentionSave": "Save",
    "data.retentionConfirm": "Save and delete",
    "data.retentionConfirmPrompt": (p, f) => `Lowering the number deletes older snapshots at once, in every account: each member keeps only ${f.plural(
      p.keep,
      {
        one: "the newest snapshot",
        other: `the newest ${f.number(p.keep)} snapshots`
      }
    )}. Click "Save and delete" to confirm.`,
    "data.retentionSaved": (p, f) => p.deleted === 0 ? "Saved. No snapshot needed deleting." : `Saved. ${f.plural(p.deleted, {
      one: "1 older snapshot was",
      other: `${f.number(p.deleted)} older snapshots were`
    })} deleted.`,
    "data.retentionInvalid": (p, f) => `Enter a whole number from ${f.number(p.minimum)} to ${f.number(p.maximum)}. Nothing was changed.`,
    "data.retentionFailed": "JoyFox could not save the setting. The field shows the number in use now. Try again.",
    "data.reminderLabel": "Remind me to export all data after (days)",
    "data.reminderHint": (p, f) => `JoyFox data stays in this browser profile, also when you close the browser. If you remove JoyFox or lose the profile, the data is gone, so a full export is your backup. This page asks for one when the last full export is older than this number of days. 0 turns the reminder off. From ${f.number(p.minimum)} to ${f.number(p.maximum)}; the default is ${f.number(p.default)}. Click "Save" to apply.`,
    "data.reminderSave": "Save",
    "data.reminderSaved": (p, f) => p.days === 0 ? "Saved. The export reminder is off." : `Saved. JoyFox reminds you ${f.plural(p.days, {
      one: "1 day",
      other: `${f.number(p.days)} days`
    })} after the last full export.`,
    "data.reminderInvalid": (p, f) => `Enter a whole number from ${f.number(p.minimum)} to ${f.number(p.maximum)}. Nothing was changed.`,
    "data.reminderNever": 'You have not exported all JoyFox data yet. If you remove JoyFox or lose this browser profile, the data is gone. Click "Export all JoyFox data (JSON)" to save a backup.',
    "data.reminderDue": (p, f) => `Your last full export was ${f.plural(p.days, {
      one: "1 day ago",
      other: `${f.number(p.days)} days ago`
    })}. If you remove JoyFox or lose this browser profile, newer data is gone. Click "Export all JoyFox data (JSON)" to save a backup.`,
    "data.lastExport": (p, f) => p.days === 0 ? "Last full export: today." : `Last full export: ${f.plural(p.days, {
      one: "1 day ago",
      other: `${f.number(p.days)} days ago`
    })}.`,
    "data.exportAll": "Export all JoyFox data (JSON)",
    "data.exportedAll": "Export of all JoyFox data created.",
    "data.deleteEverything": "Delete all JoyFox data",
    "data.deleteEverythingLabel": "Delete all JoyFox data in this browser",
    "data.deleteEverythingPrompt": 'Click "Confirm" to delete every account, every record and every JoyFox setting in this browser. This cannot be undone.',
    "data.deletedEverything": "Deleted all JoyFox data in this browser.",
    "data.confirm": "Confirm",
    "data.confirmLabel": (p) => `Confirm: ${p.label}`,
    "data.actionFailed": "JoyFox could not finish the delete. Some records may be deleted already: the counts shown now are what is still stored. Try again.",
    "data.exportFailed": "JoyFox could not create the export. Nothing was exported. Try again.",
    "data.import.title": "Import",
    "data.import.hint": "Import a JoyFox export file: everything, or one account. It is merged into what is stored here. An account with the same JoyClub identifier is merged into the existing one. For the same note, rule or placement the newer version wins; existing tags and corrections are kept. The import starts when you choose the file, and you then see what changed.",
    "data.import.fileLabel": "JoyFox export file (JSON)",
    "data.import.summary.all": (p, f) => `This full export holds ${f.number(p.total)} account(s): ${f.number(p.matched)} merged into an existing account, ${f.number(p.added)} added as new.`,
    "data.import.summary.account": (p, f) => `This single-account export holds ${f.number(p.total)} account(s): ${f.number(p.matched)} merged into an existing account, ${f.number(p.added)} added as new.`,
    "data.import.caption": "What the import changed",
    "data.import.col.added": "Added",
    "data.import.col.replaced": "Replaced (newer)",
    "data.import.col.kept": "Kept",
    "data.import.col.duplicates": "Skipped duplicates",
    "data.import.noRecords": "The file holds no records.",
    // Setting names in the import result. A setting JoyFox does not name is
    // shown by its stored key.
    "data.setting.activeAccount": "active account",
    "data.setting.language": "language",
    "data.setting.messageCaching": "store messages",
    "data.setting.messageRetention": "keep messages for",
    "data.setting.quickIgnoreDelete": "Ignore and Delete button",
    "data.setting.stripCollapsed": "JoyFox bar collapsed",
    "data.setting.templatePicker": "template picker",
    "data.setting.sharedEventException": "shared-event exception",
    "data.setting.snapshotRetention": "snapshots kept per member",
    "data.setting.exportReminder": "export reminder",
    "data.setting.diagnostics": "diagnostics",
    "data.import.settingsUnknown": "The file also holds settings that this version of JoyFox does not know. They were not imported.",
    "data.import.settingsSkipped": (p) => `Settings in the file that are never imported (they switch features on): ${p.keys}.`,
    "data.import.settingsNotSaved": (p) => `Settings that could not be saved: ${p.keys}.`,
    "data.import.settingsAdded": (p) => `Settings added (only those not set here): ${p.keys}.`,
    "data.import.running": "Importing the file.",
    "data.import.nothing": "Everything in this file is already stored. Nothing was changed.",
    "data.import.complete": (p, f) => `Import complete: ${f.number(p.added)} record(s) added, ${f.number(p.replaced)} replaced by a newer version.`,
    "data.import.completeSettingsFailed": (p, f) => `Import complete: ${f.number(p.added)} record(s) added, ${f.number(p.replaced)} replaced by a newer version. Some settings could not be saved (listed above). Set them again yourself.`,
    "data.import.incomplete": "JoyFox could not finish the import. Choose the file again to try again: records already stored are not added twice.",
    "data.import.unreadable": "JoyFox could not check that file. Nothing was imported. Choose the file again. If it still fails, reload the page, or export the file from JoyFox again.",
    // Errors the UI shows (ExtensionError.display). No final full stop: the
    // panels add a suffix such as "Nothing was changed." An error without a
    // display message gets the panel's own failure text instead, which says
    // what to do next.
    "error.withSuffix.nothingChanged": (p) => `${p.error}. Nothing was changed.`,
    "error.withSuffix.nothingImported": (p) => `${p.error}. Nothing was imported.`,
    "error.withSuffix.nothingDeleted": (p) => `${p.error}. Nothing was deleted.`,
    "error.withSuffix.nothingExported": (p) => `${p.error}. Nothing was exported. Try again.`,
    "error.withSuffix.settingNotChanged": (p) => `${p.error}. The setting was not changed. Try again.`,
    "error.account.emptyIdentifier": "Enter your JoyClub account identifier first",
    "error.account.duplicate": "An account with this identifier is already in the list. Use that account, or enter another identifier",
    "error.account.notRegistered": "That account is no longer in the list, for example because it was removed in another tab",
    "error.account.gone": "That account no longer exists",
    "error.account.changed": "The active account changed",
    "error.template.noName": "A template needs a name",
    "error.template.nameTooLong": (p, f) => `A template name can have at most ${f.number(p.maximum)} characters`,
    "error.template.folderTooLong": (p, f) => `A folder name can have at most ${f.number(p.maximum)} characters`,
    "error.template.noText": "A template needs some text",
    "error.template.tooLong": (p, f) => `A template can have at most ${f.number(p.maximum)} characters`,
    "error.template.deleted": "That template was deleted meanwhile",
    "error.data.changedDuringCheck": "Stored data changed while the file was checked. Choose the file again",
    "error.data.unknownType": "Unknown data type",
    "error.data.accountRecord": "The account record is removed only with the whole account",
    // The next step ends each refusal that a correct export file fixes.
    "error.import.tooLarge": "The file is too large to be a JoyFox export. Choose a file exported by JoyFox",
    "error.import.notJson": "The file is not a JoyFox export. Choose a file exported by JoyFox",
    "error.import.notExport": "The file is not a JoyFox export. Choose a file exported by JoyFox",
    "error.import.noVersion": "The file does not say which JoyFox version made it. Choose a file exported by JoyFox",
    "error.import.newerVersion": "The file comes from a newer JoyFox version. Update JoyFox first",
    "error.import.noScope": "The file does not say if it holds one account or all data. Choose a file exported by JoyFox",
    "error.import.noAccountNamed": "The file is an export of one account, but it does not name the account. Choose a file exported by JoyFox",
    "error.import.unknownType": "The file holds a type of data that JoyFox does not know. Choose a file exported by JoyFox",
    "error.import.notList": (p) => `The ${p.entity} part of the file is damaged. Choose a file exported by JoyFox`,
    "error.import.notRecord": (p, f) => `Record ${f.number(p.index)} in ${p.entity} is damaged. Choose a file exported by JoyFox`,
    "error.import.forbiddenKey": (p, f) => `Record ${f.number(p.index)} in ${p.entity} holds a field name that JoyFox does not allow. Choose a file exported by JoyFox`,
    "error.import.unknownField": (p, f) => `Record ${f.number(p.index)} in ${p.entity} holds a field that JoyFox does not know. Choose a file exported by JoyFox`,
    "error.import.tooLong": (p, f) => `Record ${f.number(p.index)} in ${p.entity} holds a text longer than ${f.number(p.maximum)} characters. Choose a file exported by JoyFox`,
    "error.import.invalid": (p, f) => `Record ${f.number(p.index)} in ${p.entity} is damaged. Choose a file exported by JoyFox`,
    "error.import.future": (p, f) => `Record ${f.number(p.index)} in ${p.entity} has a date in the future. Check the clock of the computer that made the file`,
    "error.import.otherAccount": (p, f) => `Record ${f.number(p.index)} in ${p.entity} belongs to another account. Choose a file exported by JoyFox`,
    "error.import.notOwnScope": (p, f) => `Account record ${f.number(p.index)} is damaged. Choose a file exported by JoyFox`,
    "error.import.twice": (p, f) => `Record ${f.number(p.index)} in ${p.entity} is in the file twice. Choose a file exported by JoyFox`,
    "error.import.sameIdentifier": "Two accounts in the file have the same identifier. Choose a file exported by JoyFox",
    "error.import.noAccountRecord": "The file is an export of one account, but it does not hold that account. Choose a file exported by JoyFox",
    "error.import.settingsInvalid": "The settings in the file are damaged. Choose a file exported by JoyFox",
    "error.import.settingsForbidden": "The settings in the file hold a name that JoyFox does not allow. Choose a file exported by JoyFox",
    "error.import.unknownSetting": "The file holds a setting that JoyFox does not use. Choose a file exported by JoyFox",
    "error.import.orphans": "Some records in the file belong to an account that the file does not hold. Choose a file exported by JoyFox",
    "error.import.sameRecordTwice": "Two records in the file would become the same record here. Choose a file exported by JoyFox"
  };

  // src/i18n/message.ts
  var MESSAGE_PARAMS = {
    "legacy.text": { text: "string" },
    "triage.reason.unknownValue": { field: "message" },
    "triage.reason.atOrAbove": {
      field: "message",
      value: "number",
      minimum: "number"
    },
    "triage.reason.belowMinimum": {
      field: "message",
      value: "number",
      minimum: "number"
    },
    "triage.reason.accountAgeRangeAbove": {
      min: "number",
      max: "number",
      minimum: "number"
    },
    "triage.reason.accountAgeRangeBelow": {
      min: "number",
      max: "number",
      minimum: "number"
    },
    "triage.reason.accountAgeRangeCoarse": {
      min: "number",
      max: "number",
      minimum: "number"
    },
    "triage.reason.phraseSeenNow": { text: "string" },
    "triage.reason.phraseSeenBefore": { text: "string" },
    "triage.reason.phraseNotInLatest": { text: "string" },
    "triage.reason.phraseNotSeen": { text: "string" },
    "triage.reason.trustAtOrAbove": { score: "number", minimum: "number" },
    "triage.reason.trustBelow": { score: "number", minimum: "number" },
    "triage.reason.negatedMet": { reason: "message", condition: "message" },
    "triage.reason.negatedNotMet": { reason: "message", condition: "message" },
    "triage.reason.unknownNeedsReview": { reason: "message" },
    "triage.reason.unknownMet": { reason: "message" },
    "triage.reason.unknownNotMet": { reason: "message" },
    "triage.reason.numbered": { number: "number", reason: "message" },
    "triage.reason.userMoved": { placement: "message" },
    "triage.headline.doesNotMeet": { placement: "message" },
    "trust.reason.positive": { count: "number" },
    "trust.reason.negative": { count: "number" },
    "trust.reason.neutral": { count: "number" },
    "spam.detail.belowMinimum": { words: "number", minimum: "number" },
    "spam.detail.duplicate": { percent: "number" },
    "spam.detail.phraseSimilar": { percent: "number" },
    "action.where.before": { step: "message" },
    "action.where.during": { step: "message" },
    "action.failure.control-missing": { step: "message" },
    "action.failure.confirmation-missing": { step: "message" },
    "action.failure.not-verified": { step: "message" },
    "action.failure.unverifiable": { step: "message", where: "message" },
    "action.failure.member-mismatch": { where: "message" },
    "action.failure.conversation-mismatch": { where: "message" },
    "action.failure.identity-unavailable": { where: "message" },
    "action.failure.account-changed": { where: "message" },
    "action.failure.turned-off": { where: "message" },
    "action.failure.superseded": { where: "message" },
    "action.failure.log-unavailable": { where: "message" },
    "action.failure.handoff-failed": { where: "message" },
    "action.failure.timeout": { step: "message" },
    "action.failure.step-error": { where: "message" },
    "triage.conditions.summary": { count: "number" },
    "triage.condition.line": { outcome: "message", condition: "message" },
    "triage.condition.lineNegated": { outcome: "message", condition: "message" },
    "triage.placementLine": { placement: "message", source: "message" },
    "triage.movedOn": { date: "string", placement: "message" },
    "mark.trustFailed": { placement: "message" },
    "triage.unknownFacts.one": { fact: "message" },
    "triage.unknownFacts.two": { first: "message", second: "message" },
    "triage.unknownFacts.three": {
      first: "message",
      second: "message",
      third: "message"
    },
    "trust.score.value": { score: "number" },
    "trust.contribution": { points: "number", reason: "message" },
    "inbox.viewCount": { view: "message", count: "number" },
    "inbox.badge": { text: "message" },
    "inbox.whyNamed": { name: "string" },
    "notes.removeTag": { label: "string" },
    "notes.summary.tags": { count: "number" },
    "notes.summary.noteAndTags": { count: "number" },
    "notes.length": { count: "number", maximum: "number" },
    "accounts.nameWithIdentifier": { label: "string", identifier: "string" },
    "accounts.useLabel": { name: "string" },
    "accounts.nowActive": { name: "string" },
    "accounts.renameLabel": { name: "string" },
    "accounts.renameField": { identifier: "string" },
    "accounts.renamed": { name: "string" },
    "accounts.removeLabel": { name: "string" },
    "accounts.confirmRemoveLabel": { name: "string" },
    "accounts.removePrompt": { name: "string" },
    "accounts.removed": { name: "string" },
    "accounts.removedNoneActive": { name: "string" },
    "accounts.removedNoneLeft": { name: "string" },
    "accounts.added": { name: "string" },
    "rule.unknownLabel": { condition: "message" },
    "rule.valueLabel": { condition: "message" },
    "rule.textLabel": { condition: "message" },
    "rule.textProblem": { maximum: "number", condition: "message" },
    "rule.numberProblem": {
      minimum: "number",
      maximum: "number",
      condition: "message"
    },
    "rule.fieldNumberProblem": { minimum: "number", maximum: "number" },
    "rule.fieldTextProblem": { maximum: "number" },
    "rule.removeConditionLabel": { condition: "message" },
    "rule.notLabel": { condition: "message" },
    "rule.ruleTitle": { number: "number" },
    "rule.ruleMatchLabel": { number: "number" },
    "rule.removeRuleLabel": { number: "number" },
    "rule.confirmRemoveGroupLabel": { number: "number" },
    "rule.removeGroupPrompt": { number: "number" },
    "rule.addConditionLabel": { number: "number" },
    "rule.ruleCount": { count: "number", maximum: "number" },
    "rule.notSaved": { problem: "message" },
    "listing.removeTag": { tag: "string" },
    "listing.summary.event": { state: "string" },
    "listing.summary.venue": { state: "string" },
    "eventFilter.tag": { tag: "string" },
    "events.count": { shown: "number", total: "number" },
    "events.untitled": { id: "string" },
    "events.past": { when: "string" },
    "events.venue": { venue: "string" },
    "eventFilter.count": { shown: "number", loaded: "number" },
    "typeFilter.count": { shown: "number", loaded: "number" },
    "typeFilter.unknownHidden": { count: "number" },
    "compat.shared": { count: "number" },
    "triage.sharedEvent.attending": { event: "string", when: "string" },
    "triage.sharedEvent.attended": { event: "string", when: "string" },
    "events.guests": { count: "number" },
    "signals.photos": { count: "number" },
    "signals.words": { count: "number" },
    "signals.tagCount": { count: "number" },
    "signals.trust": { score: "number" },
    "signals.editor.label": { member: "string" },
    "member.number": { id: "string" },
    "signals.filter.count": { hidden: "number", loaded: "number" },
    "messages.retentionHint": { default: "number" },
    "messages.retentionConfirmPrompt": { months: "number" },
    "data.retentionConfirmPrompt": { keep: "number" },
    "messages.retentionSaved": { deleted: "number" },
    "messages.retentionInvalid": { minimum: "number", maximum: "number" },
    "messages.count": { count: "number" },
    "messages.countLimited": { count: "number", shown: "number" },
    "messages.sentTo": { member: "string", when: "string" },
    "messages.receivedFrom": { member: "string", when: "string" },
    "messages.storedAt": { when: "string" },
    "compat.own": { count: "number" },
    "compat.badge": { count: "number" },
    "compat.badgeLabel": { count: "number" },
    "listing.tooManyTags.event": { maximum: "number" },
    "listing.tooManyTags.venue": { maximum: "number" },
    "searches.nameTooLong": { maximum: "number" },
    "searches.full": { maximum: "number" },
    "searches.saved": { name: "string" },
    "searches.noMatch": { name: "string" },
    "searches.deleteLabel": { name: "string" },
    "searches.confirmDelete": { name: "string" },
    "searches.deleted": { name: "string" },
    "searches.running": { name: "string" },
    "searches.shown": { name: "string" },
    "picker.result.too-long": { over: "number", limit: "number" },
    "rule.preset.describe.complete": { photos: "number", words: "number" },
    "rule.preset.describe.highTrust": {
      photos: "number",
      words: "number",
      days: "number"
    },
    "rule.preset.applied": { preset: "message" },
    "templates.inFolder": { folder: "string" },
    "templates.editLabel": { name: "string" },
    "templates.editing": { name: "string" },
    "templates.deleteLabel": { name: "string" },
    "templates.confirmDeleteLabel": { name: "string" },
    "templates.deletePrompt": { name: "string" },
    "templates.deleted": { name: "string" },
    "templates.saved": { name: "string" },
    "templates.added": { name: "string" },
    "data.showLabel": { label: "message" },
    "data.hideLabel": { label: "message" },
    "data.deleteAllLabel": { label: "message" },
    "data.deleteAllPrompt": { count: "number", label: "message" },
    "data.deletedAll": { label: "message" },
    "data.recordsTitle": { label: "message", count: "number" },
    "data.recordSummary": { id: "string", updated: "string" },
    "data.recordSummaryNamed": {
      name: "string",
      id: "string",
      updated: "string"
    },
    "data.recordNamed": { name: "string", id: "string" },
    "data.deleteRecordLabel": { record: "string" },
    "data.deleteRecordPrompt": { record: "string" },
    "data.deletedRecord": { record: "string" },
    "data.showMore": { count: "number" },
    "data.retentionHint": {
      minimum: "number",
      maximum: "number",
      default: "number"
    },
    "data.retentionSaved": { deleted: "number" },
    "data.retentionInvalid": { minimum: "number", maximum: "number" },
    "data.reminderHint": {
      minimum: "number",
      maximum: "number",
      default: "number"
    },
    "data.reminderSaved": { days: "number" },
    "data.reminderInvalid": { minimum: "number", maximum: "number" },
    "data.reminderDue": { days: "number" },
    "data.lastExport": { days: "number" },
    "data.moreValues": { count: "number" },
    "data.moreCharacters": { count: "number" },
    "data.confirmLabel": { label: "message" },
    "data.import.summary.all": {
      matched: "number",
      added: "number",
      total: "number"
    },
    "data.import.summary.account": {
      matched: "number",
      added: "number",
      total: "number"
    },
    "data.import.settingsSkipped": { keys: "string" },
    "data.import.settingsNotSaved": { keys: "string" },
    "data.import.settingsAdded": { keys: "string" },
    "data.import.complete": { added: "number", replaced: "number" },
    "data.import.completeSettingsFailed": { added: "number", replaced: "number" },
    "error.withSuffix.nothingChanged": { error: "message" },
    "error.withSuffix.nothingImported": { error: "message" },
    "error.withSuffix.nothingDeleted": { error: "message" },
    "error.withSuffix.nothingExported": { error: "message" },
    "error.withSuffix.settingNotChanged": { error: "message" },
    "error.template.nameTooLong": { maximum: "number" },
    "error.template.folderTooLong": { maximum: "number" },
    "error.template.tooLong": { maximum: "number" },
    "error.import.notList": { entity: "message" },
    "error.import.notRecord": { index: "number", entity: "message" },
    "error.import.forbiddenKey": { index: "number", entity: "message" },
    "error.import.unknownField": { index: "number", entity: "message" },
    "error.import.tooLong": {
      index: "number",
      entity: "message",
      maximum: "number"
    },
    "error.import.invalid": { index: "number", entity: "message" },
    "error.import.future": { index: "number", entity: "message" },
    "error.import.otherAccount": { index: "number", entity: "message" },
    "error.import.notOwnScope": { index: "number" },
    "error.import.twice": { index: "number", entity: "message" }
  };
  function isMessageKey(value) {
    return typeof value === "string" && Object.hasOwn(en, value);
  }
  function paramsOf(key2) {
    return Object.hasOwn(MESSAGE_PARAMS, key2) ? MESSAGE_PARAMS[key2] : null;
  }
  var isRecord = (value) => typeof value === "object" && value !== null && !Array.isArray(value);
  var MAX_DEPTH = 8;
  function isMessage(value, depth = 0) {
    if (depth > MAX_DEPTH || !isRecord(value)) return false;
    if (!isMessageKey(value.key)) return false;
    const spec = paramsOf(value.key);
    if (spec === null) return Object.keys(value).every((name) => name === "key");
    if (!Object.keys(value).every((name) => name === "key" || name === "params"))
      return false;
    const params = value.params;
    if (!isRecord(params)) return false;
    const names = Object.keys(spec);
    if (Object.keys(params).length !== names.length) return false;
    return names.every((name) => {
      if (!Object.hasOwn(params, name)) return false;
      const param = params[name];
      switch (spec[name]) {
        case "string":
          return typeof param === "string";
        case "number":
          return typeof param === "number" && Number.isFinite(param);
        case "message":
          return isMessage(param, depth + 1);
        default:
          return false;
      }
    });
  }
  function message(key2, ...params) {
    return params.length > 0 ? { key: key2, params: params[0] } : { key: key2 };
  }

  // src/storage/local-settings.ts
  function runtimeArea() {
    const area = globalThis.browser?.storage?.local;
    if (!area)
      throw new ExtensionError(
        "StorageError",
        "browser.storage.local is unavailable in this context"
      );
    return area;
  }
  var runtimeSettingsArea = {
    async get(keys) {
      return await runtimeArea().get(keys);
    },
    async set(items) {
      await runtimeArea().set(items);
    },
    async remove(keys) {
      await runtimeArea().remove(keys);
    },
    async getAll() {
      return await runtimeArea().get(null);
    },
    async clear() {
      await runtimeArea().clear();
    }
  };

  // src/storage/account-lock.ts
  var fallbackExclusive = Promise.resolve();

  // src/domain/snapshot-order.ts
  var newestCaptureFirst = (a, b) => Date.parse(b.capturedAt) - Date.parse(a.capturedAt) || b.id.localeCompare(a.id);

  // src/storage/reason-migration.ts
  var USER_MOVED = {
    qualified: "You moved this sender to Qualified.",
    "needs-review": "You moved this sender to Needs Review.",
    quarantined: "You moved this sender to Quarantined."
  };
  function migrateReasons(reasons, placement) {
    if (!Array.isArray(reasons)) return reasons;
    const own = typeof placement === "string" && Object.hasOwn(USER_MOVED, placement) ? placement : void 0;
    return reasons.map((reason) => {
      if (typeof reason !== "string") return reason;
      if (own && reason === USER_MOVED[own])
        return message("triage.reason.userMoved", {
          placement: { key: `placement.${own}` }
        });
      return { key: "legacy.text", params: { text: reason } };
    });
  }

  // src/storage/database.ts
  var DATABASE_NAME = "joyfox";
  var DATABASE_VERSION = 5;
  var VERSION_1_ENTITY_NAMES = [
    "extensionAccounts",
    "joyClubMembers",
    "profileSnapshots",
    "userNotes",
    "userTags",
    "trustSignals",
    "contactRules",
    "conversationClassifications",
    "savedSearches",
    "eventMetadata",
    "spendLogEntries",
    "syncConfigs",
    "extensionPreferences",
    "messageTemplates",
    "spamPhrases",
    "actionLogs"
  ];
  var VERSION_2_ENTITY_NAMES = [
    "messageObservations",
    "senderSpamOverrides"
  ];
  var VERSION_3_ENTITY_NAMES = ["messagePhraseMatches"];
  var VERSION_5_ENTITY_NAMES = ["cachedMessages"];
  var ENTITY_NAMES = [
    ...VERSION_1_ENTITY_NAMES,
    ...VERSION_2_ENTITY_NAMES,
    ...VERSION_3_ENTITY_NAMES,
    ...VERSION_5_ENTITY_NAMES
  ];
  var connection;
  function migrateToVersion4(db, transaction) {
    const name = "conversationClassifications";
    if (!transaction || !db.objectStoreNames.contains(name)) return;
    const cursor = transaction.objectStore(name).openCursor();
    cursor.onsuccess = () => {
      const current = cursor.result;
      if (!current) return;
      const record = current.value;
      current.update({
        ...record,
        reasons: migrateReasons(record.reasons, record.placement)
      });
      current.continue();
    };
  }
  function openDatabase() {
    if (connection) return connection;
    const opening = new Promise((resolve, reject) => {
      const request2 = indexedDB.open(DATABASE_NAME, DATABASE_VERSION);
      request2.onupgradeneeded = (event) => {
        const db = request2.result;
        const createStores = (names) => {
          for (const name of names) {
            const store = db.createObjectStore(name, { keyPath: "storageKey" });
            store.createIndex("accountId", "accountId", { unique: false });
            store.createIndex("updatedAt", "updatedAt", { unique: false });
          }
        };
        if (event.oldVersion < 1) createStores(VERSION_1_ENTITY_NAMES);
        if (event.oldVersion < 2) createStores(VERSION_2_ENTITY_NAMES);
        if (event.oldVersion < 3) createStores(VERSION_3_ENTITY_NAMES);
        if (event.oldVersion < 4) migrateToVersion4(db, request2.transaction);
        if (event.oldVersion < 5) createStores(VERSION_5_ENTITY_NAMES);
      };
      request2.onsuccess = () => {
        const db = request2.result;
        db.onversionchange = () => {
          db.close();
          if (connection === opening) connection = void 0;
        };
        resolve(db);
      };
      request2.onerror = () => reject(request2.error);
      request2.onblocked = () => console.warn(
        "JoyFox: database upgrade is blocked by another open connection"
      );
    }).catch((error) => {
      if (connection === opening) connection = void 0;
      throw error;
    });
    connection = opening;
    return opening;
  }
  function requestResult(request2) {
    return new Promise((resolve, reject) => {
      request2.onsuccess = () => resolve(request2.result);
      request2.onerror = () => reject(request2.error);
    });
  }
  function transactionDone(transaction) {
    return new Promise((resolve, reject) => {
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error);
      transaction.onabort = () => reject(transaction.error);
    });
  }
  async function commitAll(transaction, work) {
    const done = transactionDone(transaction);
    done.catch(() => void 0);
    try {
      await work();
    } catch (error) {
      try {
        transaction.abort();
      } catch {
      }
      throw error;
    }
    await done;
  }

  // src/domain/iso-date.ts
  var ISO_DATE = /^(\d{4})-(\d{2})-(\d{2})(?:T(\d{2}):(\d{2})(?::(\d{2})(?:\.\d{1,9})?)?(?:Z|[+-](\d{2}):(\d{2})))?$/;
  function isStrictIsoDate(value) {
    const match = ISO_DATE.exec(value);
    if (!match) return false;
    const [, y, m, d, hh, mm, ss, oh, om] = match;
    const year = Number(y);
    const month = Number(m);
    const day = Number(d);
    const calendar = new Date(Date.UTC(year, month - 1, day));
    if (calendar.getUTCFullYear() !== year || calendar.getUTCMonth() !== month - 1 || calendar.getUTCDate() !== day)
      return false;
    if (hh !== void 0 && (Number(hh) > 23 || Number(mm) > 59)) return false;
    if (ss !== void 0 && Number(ss) > 59) return false;
    if (oh !== void 0 && (Number(oh) > 23 || Number(om) > 59)) return false;
    return Number.isFinite(Date.parse(value));
  }

  // src/events/event-date.ts
  var MONTHS = {
    januar: 1,
    j\u00E4nner: 1,
    februar: 2,
    m\u00E4rz: 3,
    maerz: 3,
    april: 4,
    mai: 5,
    juni: 6,
    juli: 7,
    august: 8,
    september: 9,
    oktober: 10,
    november: 11,
    dezember: 12
  };
  var pad = (value) => String(value).padStart(2, "0");
  function validDay(year, month, day) {
    const date = new Date(Date.UTC(year, month - 1, day));
    return date.getUTCFullYear() === year && date.getUTCMonth() === month - 1 && date.getUTCDate() === day;
  }
  function parseEventStart(text2) {
    const clean = text2.replace(/\s+/gu, " ").trim();
    let year;
    let month;
    let day;
    const named = /(\d{1,2})\.\s*([A-Za-zÄÖÜäöü]+)\s+(\d{4})/u.exec(clean);
    const numeric = /\b(\d{1,2})\.(\d{1,2})\.(\d{4})\b/u.exec(clean);
    if (named) {
      const found2 = MONTHS[named[2].toLowerCase()];
      if (!found2) return void 0;
      day = Number(named[1]);
      month = found2;
      year = Number(named[3]);
    } else if (numeric) {
      day = Number(numeric[1]);
      month = Number(numeric[2]);
      year = Number(numeric[3]);
    } else return void 0;
    if (!validDay(year, month, day)) return void 0;
    const date = `${year}-${pad(month)}-${pad(day)}`;
    const time = /\b(\d{1,2}):(\d{2})\b/u.exec(clean);
    if (!time) return date;
    const hour = Number(time[1]);
    const minute = Number(time[2]);
    if (hour > 23 || minute > 59) return date;
    return `${date}T${pad(hour)}:${pad(minute)}`;
  }
  function isWallTime(value) {
    const match = /^(\d{4})-(\d{2})-(\d{2})(?:T(\d{2}):(\d{2}))?$/u.exec(value);
    if (!match) return false;
    if (!validDay(Number(match[1]), Number(match[2]), Number(match[3])))
      return false;
    return match[4] === void 0 || Number(match[4]) <= 23 && Number(match[5]) <= 59;
  }

  // src/notes/limits.ts
  var MAX_NOTE_LENGTH = 4e3;
  var MAX_TAG_LENGTH = 64;

  // src/events/listing.ts
  var normalizeTag = (label) => label.trim().replace(/\s+/gu, " ");
  var tagKey = (label) => normalizeTag(label).toLowerCase();
  var ATTENDANCE_VALUES = [
    "unknown",
    "interested",
    "attending",
    "not-attending",
    "attended"
  ];
  var MAX_EVENT_TAGS = 20;
  var MAX_EVENT_ATTENDEES = 2e3;
  function cleanTags(tags) {
    const seen = /* @__PURE__ */ new Set();
    const result = [];
    for (const raw of tags) {
      const label = normalizeTag(raw);
      const key2 = tagKey(label);
      if (label.length === 0 || seen.has(key2)) continue;
      seen.add(key2);
      result.push(label);
    }
    return result;
  }

  // src/selectors/registry.ts
  var FROM_URL = "url:pathname";
  var VERIFIED_HOSTS = ["www.joyclub.de"];
  var selectorRegistry = {
    inbox: {
      status: "verified",
      evidence: "01-inbox.md",
      path: "^/clubmail/?$",
      root: ".cm-conversation-list",
      fields: {
        row: ".cm-conversation-list-item",
        // Display only (F2): kept as the member's nickname for JoyFox's own
        // texts, never an identity (resolveMemberIdentity refuses it).
        senderName: '[data-e2e="conversation-list-item-name"]',
        memberId: ".cm-conversation-list-item__avatar[href]",
        verificationCode: "j-veri-icon[verification-status]",
        genderCode: "j-gender-icon[universal-gender]",
        readStatus: ".cm-conversation-list-item__read-status",
        // Compared with the rule's phrases (ADR 0013). Never stored or logged.
        messagePreview: ".cm-conversation-list-item__text",
        // The row's second line, which holds the preview. JoyFox puts its own
        // line before it, in the same slot (owner's live check, 2026-09-27).
        descriptionLine: ".cm-conversation-list-item__line--description"
      }
    },
    conversation: {
      status: "verified",
      evidence: "02-conversation.md",
      path: "^/clubmail/conversation/conversation-wrapper-(personal-\\d+-\\d+)/?$",
      root: ".cm-conversation-header",
      fields: {
        memberId: "a.cm-conversation-header[href]",
        verificationCode: ".cm-conversation-header j-veri-icon[verification-status]",
        genderCode: ".cm-conversation-header j-gender-icon[universal-gender]",
        profileDescription: ".cm-conversation-header__description",
        messageItem: "li.cm-message-list-item",
        // V1-4, from 12-messages.md. Each item carries `data-message-id`;
        // a date separator or a system hint has no bubble and is skipped.
        sentBubble: 'div.cm-message-bubble[data-e2e="sent-message"]',
        receivedBubble: 'div.cm-message-bubble[data-e2e="received-message"]',
        messageText: "div.cm-message-bubble__content",
        messageBubble: "j-message-bubble",
        // In the bubble's shadow root.
        messageTime: ".footer time[datetime]",
        composer: "textarea.joy-input-wonder__input",
        sendButton: 'button.joy-input-wonder__button[data-e2e="button-submit"]'
      }
    },
    profile: {
      status: "verified",
      evidence: "03-profile.md",
      path: "^/profile/(\\d+)\\.[^/]+\\.html$",
      // The mobile header carries the data-e2e marker; the desktop header has
      // none, only its BEM class. JoyClub hides one of the two by screen width
      // (owner's live check, 2026-09-27), and pageMember anchors on the shown one.
      root: '[data-e2e="profile-header-base-info"], .profile-header__base-information--desktop',
      fields: {
        memberId: FROM_URL,
        verificationCode: '[data-e2e="profile-header-base-info"] j-veri-icon[verification-status]',
        genderCode: '[data-e2e="profile-header-base-info"] j-gender-icon[universal-gender]',
        photoCount: ".amount-badge[aria-label]",
        // One badge in this list reads "Angemeldet seit <n> <unit>"; the
        // extractor picks it by that text, as the badges share one structure.
        memberSinceBadge: ".profile-sidebar-container__badge-list j-list-item",
        // Another badge of the same list says whether JoyClub verified the
        // member, even under a green shield (owner's live check, 2026-09-27).
        verificationBadge: ".profile-sidebar-container__badge-list j-list-item",
        // Only the main text is counted; the motto above it is not.
        profileMainText: ".profile-description-maintext__text",
        // V1-2, from 13-preferences.md. The "Vorlieben" checklist: one level
        // group per level that has tags, each tag a `j-tag` whose label is in
        // its shadow root. Each person has a visible and a hidden copy.
        preferenceSection: "div.profile-erotic-prefs",
        preferenceLevel: "div.profile-erotic-prefs__category",
        preferenceLevelTitle: "h4.profile-erotic-prefs__category-title",
        preferenceTag: "div.profile-erotic-prefs__category-item-list > j-tag",
        preferenceTagLabel: "a.j-tag",
        // Only the viewer's own profile has the "Account" headline.
        ownProfileHeadline: "h2.profile-headline"
      }
    },
    search: {
      status: "verified",
      evidence: "11-search.md",
      // `/member/` and its filtered form `/member/<place>-as-r/is-<genders>/`.
      // Filters apply in place: the address changes without a page load.
      path: "^/member/(?:[^/]+/)*$",
      root: "div.member_search_list",
      fields: {
        resultList: "div.member_search_list",
        filterButton: '[data-e2e="search-filter-button"]',
        // "Anwenden" in the filter panel (11-search.md). V1-3 clicks it once
        // after a saved search opens, so the results follow its filters.
        applyButton: 'j-button[data-e2e="apply-filter-button"]',
        // The member ID is in the link (V1-2 reads it for the shared count).
        resultLink: 'a[data-e2e="result-item"]',
        resultCard: "j-member-card",
        // The card's nickname, in its `user-name` attribute (11-search.md).
        // Display only, never an identity.
        resultName: "j-member-card[user-name]"
      }
    },
    event: {
      status: "verified",
      evidence: "14-events.md",
      // The event ID is the number in the path; no attribute holds it.
      path: "^/event/(\\d+)\\.[^/]+\\.html$",
      root: "h1.event_name",
      fields: {
        eventId: FROM_URL,
        title: "h1.event_name",
        infoBox: ".event_info_box",
        startText: ".event_info_box .event-time",
        venueLink: ".event_location_detail a.event_club",
        // V1-2: the guest list tabs; each entry is a link to a profile.
        attendeeEntry: '.tab-pane[id^="guest_"] a.card.normal',
        attendeeName: "div.date_moreinfo",
        // The entry's text block (name, age, place). The name box inside it is
        // one clipped line, so JoyFox's line goes after it, at the end of this
        // block (owner's live check, 2026-09-27).
        attendeeInfo: "div.date_info",
        // The guest's nickname (14-events.md). Display only, never an identity.
        attendeeNickname: "div.date_moreinfo strong"
      }
    },
    // "Dates & Events" and its sub-tabs; one list holds event and date cards.
    "event-calendar": {
      status: "verified",
      evidence: "14-events.md",
      path: "^/dates_partys/",
      root: "div.card-list-ui",
      fields: {
        list: "div.card-list-ui",
        item: "div.card-list-ui-list-item",
        eventItem: "div.card-list-ui-list-item.event-card-ui[data-element-id]",
        headline: ".card-ui-detail-right-headline"
      }
    },
    // A venue ("Club") uses the profile template; its ID is a member ID.
    venue: {
      status: "verified",
      evidence: "15-venues.md",
      path: "^/club/(\\d+)\\.[^/]+\\.html$",
      root: "h1.profile_name",
      fields: {
        venueId: FROM_URL,
        name: "h1.profile_name"
      }
    },
    // V1-14, from 17-my-joy-lists.md. The five "My JOY" lists (visitors,
    // matches, liked you, you like, you visited) share one component tree, and
    // JoyClub's tabs move between them client-side. The section exists on each
    // of them; the grid is read inside it.
    "my-joy-list": {
      status: "verified",
      evidence: "17-my-joy-lists.md",
      path: "^/my_joy/(?:visitors|visits|voting/(?:match|top|fav))/?$",
      root: "section.my-joy-visits-view",
      fields: {
        // `display: grid`. It holds a summary card (`aside`) and the list.
        grid: "div.card-grid-container",
        // `display: contents`, so each `li` is a grid item: hiding one leaves no
        // gap. JoyClub appends 40 more `li` per scroll to the same list.
        slot: "ul.card-grid-container-list > li",
        // Always 4 filler cards at the list's end. Not members.
        placeholder: "li.card-grid-placeholder-card",
        card: "j-member-card",
        // The card host carries the code; it always equals the gender icon's
        // code in the card's shadow root, and the coordinator sees it change.
        genderCode: "j-member-card[universal-gender]"
      }
    }
  };
  function verifiedSelector(page, field) {
    const definition = selectorRegistry[page];
    return definition.status === "verified" ? definition.fields[field] : void 0;
  }
  function hasVerifiedSelectors() {
    return Object.values(selectorRegistry).some(
      (definition) => definition.status === "verified"
    );
  }

  // src/extraction/preferences.ts
  var PREFERENCE_LEVELS = [
    "Unbedingt",
    "Steh ich drauf",
    "Situationsabh\xE4ngig",
    "Mag ich nicht so",
    "Geht gar nicht",
    "M\xF6chte ich gerne ausprobieren"
  ];
  var POSITIVE_LEVELS = /* @__PURE__ */ new Set([
    "Unbedingt",
    "Steh ich drauf",
    "Situationsabh\xE4ngig",
    "M\xF6chte ich gerne ausprobieren"
  ]);
  var MAX_PREFERENCE_TAGS = 500;
  var MAX_PREFERENCE_LABEL_LENGTH = 100;
  var normalizeLabel = (label) => label.replace(/\s+/gu, " ").trim();
  function tagLabel(tag, labelSelector) {
    const host = tag;
    const shadow = host.openOrClosedShadowRoot ?? tag.shadowRoot;
    const text2 = shadow?.querySelector(labelSelector)?.textContent;
    const label = text2 === void 0 || text2 === null ? "" : normalizeLabel(text2);
    return label.length > 0 && label.length <= MAX_PREFERENCE_LABEL_LENGTH ? label : void 0;
  }
  function readPreferences(root) {
    const sectionSelector = verifiedSelector("profile", "preferenceSection");
    const levelSelector = verifiedSelector("profile", "preferenceLevel");
    const titleSelector = verifiedSelector("profile", "preferenceLevelTitle");
    const tagSelector = verifiedSelector("profile", "preferenceTag");
    const labelSelector = verifiedSelector("profile", "preferenceTagLabel");
    if (!sectionSelector || !levelSelector || !titleSelector || !tagSelector || !labelSelector)
      return { status: "missing" };
    const sections = Array.from(root.querySelectorAll(sectionSelector));
    if (sections.length === 0) return { status: "missing" };
    const entries = [];
    for (const section of sections)
      for (const group of Array.from(section.querySelectorAll(levelSelector))) {
        const title = normalizeLabel(
          group.querySelector(titleSelector)?.textContent ?? ""
        );
        const level = PREFERENCE_LEVELS.find((name) => name === title);
        if (!level) return { status: "unreadable" };
        for (const tag of Array.from(group.querySelectorAll(tagSelector))) {
          const label = tagLabel(tag, labelSelector);
          if (label === void 0) return { status: "unreadable" };
          entries.push({ tag, label, level });
        }
      }
    const positive = [
      ...new Set(
        entries.filter((entry) => POSITIVE_LEVELS.has(entry.level)).map((entry) => entry.label)
      )
    ].sort();
    if (positive.length > MAX_PREFERENCE_TAGS) return { status: "unreadable" };
    return { status: "found", entries, positive };
  }
  function isOwnProfile(root) {
    const selector = verifiedSelector("profile", "ownProfileHeadline");
    if (!selector) return false;
    return Array.from(root.querySelectorAll(selector)).some(
      (headline) => normalizeLabel(headline.textContent ?? "") === "Account"
    );
  }
  function sharedPreferences(own, other) {
    const mine = new Set(own);
    return [...new Set(other)].filter((label) => mine.has(label)).sort();
  }

  // src/messages/message-settings.ts
  var MESSAGE_CACHING_KEY = "joyfox.messageCaching";
  var MAX_MESSAGE_TEXT_LENGTH = 1e4;
  var MESSAGE_ID_PATTERN = /^cm-message-[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/u;
  var CONVERSATION_ID_PATTERN = /^personal-\d+-\d+$/u;
  var messageTime = (message2) => message2.sentAt ?? message2.createdAt;

  // src/qualification/facts.ts
  var UNKNOWN_FACTS = Object.freeze({
    verification: "unknown",
    personallyKnown: "unknown",
    photoCount: "unknown",
    profileWordCount: "unknown",
    joinedAt: "unknown",
    joinedWindow: "unknown"
  });

  // src/qualification/engine.ts
  var DAY_MS = 24 * 60 * 60 * 1e3;

  // src/rules/message-phrase.ts
  function normalizePhrase(text2) {
    return text2.normalize("NFKC").replace(/[\uFE0E\uFE0F]/gu, "").toUpperCase().toLowerCase().replace(/\u00DF/gu, "ss").replace(/\u03C2/gu, "\u03C3").replace(/\s+/gu, " ").trim();
  }
  var MAX_PHRASE_LENGTH = 100;
  var MAX_NORMALIZED_PHRASE_LENGTH = 400;
  var MAX_PREVIEW_LENGTH = 2e3;

  // src/rules/contact-rule.ts
  var NUMERIC_CONDITION_KINDS = /* @__PURE__ */ new Set([
    "minimumPhotos",
    "minimumProfileWords",
    "minimumAccountAgeDays",
    "minimumTrustScore"
  ]);
  var TEXT_CONDITION_KINDS = /* @__PURE__ */ new Set([
    "firstMessageContains"
  ]);
  var CONDITION_KINDS = [
    "verified",
    "personallyKnown",
    "minimumPhotos",
    "minimumProfileWords",
    "minimumAccountAgeDays",
    "notTemplateSpam",
    "minimumTrustScore",
    "firstMessageContains"
  ];
  var CONDITION_TEXT = {
    verified: "condition.verified",
    personallyKnown: "condition.personallyKnown",
    minimumPhotos: "condition.minimumPhotos",
    minimumProfileWords: "condition.minimumProfileWords",
    minimumAccountAgeDays: "condition.minimumAccountAgeDays",
    notTemplateSpam: "condition.notTemplateSpam",
    minimumTrustScore: "condition.minimumTrustScore",
    firstMessageContains: "condition.firstMessageContains"
  };
  var RULE_LIMITS = Object.freeze({
    maxDepth: 4,
    maxChildren: 32,
    maxValue: 1e5,
    minTrustValue: -1e3,
    maxTextLength: MAX_PHRASE_LENGTH
  });
  function contactRuleProblem(value) {
    if (!value || typeof value !== "object") return "The rule must be an object";
    const rule = value;
    if (![1, 2, 3].includes(rule.schemaVersion))
      return "Unsupported rule schema version";
    if (!["all", "man", "woman", "couple"].includes(rule.audience))
      return "Unsupported rule audience";
    if (typeof rule.enabled !== "boolean") return "enabled must be a boolean";
    if (!["needs-review", "quarantined"].includes(rule.defaultPlacement))
      return "defaultPlacement must be needs-review or quarantined";
    return nodeProblem(rule.root, 1, rule.schemaVersion, true);
  }
  function nodeProblem(value, depth, version2, mustBeGroup = false) {
    if (!value || typeof value !== "object")
      return "A rule node must be an object";
    const node = value;
    if (node.type === "group") {
      if (depth > RULE_LIMITS.maxDepth) return "The rule is nested too deeply";
      if (node.match !== "all" && node.match !== "any")
        return "A group must match all or any";
      if (!Array.isArray(node.children)) return "A group needs a children array";
      if (node.children.length > RULE_LIMITS.maxChildren)
        return "A group has too many conditions";
      for (const child of node.children) {
        const problem = nodeProblem(child, depth + 1, version2);
        if (problem) return problem;
      }
      return void 0;
    }
    if (mustBeGroup) return "The rule root must be a group";
    if (node.type !== "condition") return "Unknown rule node type";
    if (!CONDITION_KINDS.includes(node.kind))
      return "Unknown condition kind";
    if (!["needs-review", "met", "not-met"].includes(node.whenUnknown))
      return "whenUnknown has an unsupported value";
    if (node.negate !== void 0 && (node.negate !== true || version2 === 1))
      return "negate must be true, and needs rule schema version 2";
    const kind = node.kind;
    if (TEXT_CONDITION_KINDS.has(kind)) {
      if (version2 === 1 || version2 === 2)
        return "This condition needs rule schema version 3";
      const text2 = node.text;
      const phrase = typeof text2 === "string" ? normalizePhrase(text2) : "";
      if (typeof text2 !== "string" || text2 !== text2.trim() || text2.length > RULE_LIMITS.maxTextLength || phrase.length === 0 || // Every phrase a rule accepts must also fit a stored match, or an
      // export would hold a match that import refuses.
      phrase.length > MAX_NORMALIZED_PHRASE_LENGTH)
        return `A condition text must be 1 to ${RULE_LIMITS.maxTextLength} characters, with no space at either end`;
    } else if (node.text !== void 0) return "This condition takes no text";
    if (NUMERIC_CONDITION_KINDS.has(kind)) {
      const minimum = kind === "minimumTrustScore" ? RULE_LIMITS.minTrustValue : 0;
      if (typeof node.value !== "number" || !Number.isSafeInteger(node.value) || node.value < minimum || node.value > RULE_LIMITS.maxValue)
        return "A condition threshold must be a whole number in range";
    } else if (node.value !== void 0)
      return "This condition takes no threshold";
    return void 0;
  }
  var PLACEMENT_TEXT = {
    qualified: "placement.qualified",
    "needs-review": "placement.needs-review",
    quarantined: "placement.quarantined"
  };

  // src/storage/member-directory.ts
  var MAX_NICKNAME_LENGTH = 64;
  function cleanNickname(value) {
    if (typeof value !== "string") return void 0;
    const nickname = value.replace(/\s+/gu, " ").trim();
    if (nickname.length === 0 || nickname.length > MAX_NICKNAME_LENGTH)
      return void 0;
    return /[\u0000-\u001f\u007f]/u.test(nickname) ? void 0 : nickname;
  }

  // src/storage/validation.ts
  var ValidationError = class extends Error {
  };
  function requireString(record, field) {
    const value = record[field];
    if (typeof value !== "string" || value.length === 0)
      throw new ValidationError(`${field} must be a non-empty string`);
    return value;
  }
  function requireNumber(record, field) {
    const value = record[field];
    if (typeof value !== "number" || !Number.isFinite(value))
      throw new ValidationError(`${field} must be a finite number`);
    return value;
  }
  function requireBoolean(record, field) {
    const value = record[field];
    if (typeof value !== "boolean")
      throw new ValidationError(`${field} must be a boolean`);
    return value;
  }
  function requireArray(record, field) {
    const value = record[field];
    if (!Array.isArray(value))
      throw new ValidationError(`${field} must be an array`);
    return value;
  }
  function requireDate(record, field) {
    const value = requireString(record, field);
    if (!Number.isFinite(Date.parse(value)))
      throw new ValidationError(`${field} must be an ISO-compatible date`);
  }
  function requireEnum(record, field, values) {
    if (!values.includes(requireString(record, field)))
      throw new ValidationError(`${field} has an unsupported value`);
  }
  function requireStringArray(record, field) {
    if (!requireArray(record, field).every((value) => typeof value === "string"))
      throw new ValidationError(`${field} must contain only strings`);
  }
  function requireMessageArray(record, field) {
    if (!requireArray(record, field).every((value) => isMessage(value)))
      throw new ValidationError(`${field} must contain only catalog messages`);
  }
  function optionalString(record, field) {
    if (record[field] !== void 0) requireString(record, field);
  }
  function allowOnly(record, fields, entityName) {
    const unexpected = Object.keys(record).find(
      (field) => !fields.includes(field)
    );
    if (unexpected)
      throw new ValidationError(
        `${entityName} contains unsupported field ${unexpected}`
      );
  }
  function validateActionSteps(record) {
    for (const value of requireArray(record, "steps")) {
      if (!value || typeof value !== "object")
        throw new ValidationError("steps must contain objects");
      const step = value;
      requireString(step, "name");
      requireBoolean(step, "ok");
      requireDate(step, "at");
      optionalString(step, "errorCode");
    }
  }
  function validateProfileSnapshot(record) {
    requireString(record, "memberId");
    requireDate(record, "capturedAt");
    if (record.verification !== "unknown" && typeof record.verification !== "boolean")
      throw new ValidationError("verification must be boolean or unknown");
    for (const field of ["photoCount", "profileWordCount"]) {
      if (record[field] !== "unknown" && (typeof record[field] !== "number" || !Number.isInteger(record[field]) || record[field] < 0))
        throw new ValidationError(
          `${field} must be a non-negative integer or unknown`
        );
    }
    if (record.joinedAt !== "unknown") requireDate(record, "joinedAt");
    const hasEarliest = record.joinedEarliest !== void 0;
    const hasLatest = record.joinedLatest !== void 0;
    if (hasEarliest !== hasLatest)
      throw new ValidationError(
        "joinedEarliest and joinedLatest must be present together"
      );
    if (hasEarliest) {
      for (const field of ["joinedEarliest", "joinedLatest"])
        if (!isStrictIsoDate(requireString(record, field)))
          throw new ValidationError(`${field} must be a strict ISO 8601 date`);
      if (Date.parse(record.joinedEarliest) > Date.parse(record.joinedLatest))
        throw new ValidationError(
          "joinedEarliest must not be after joinedLatest"
        );
    }
    if (record.positivePreferences !== void 0) {
      const labels = record.positivePreferences;
      if (!Array.isArray(labels) || labels.some(
        (label, index) => typeof label !== "string" || label.length === 0 || label !== normalizeLabel(label) || index > 0 && !(labels[index - 1] < label)
      ))
        throw new ValidationError(
          "positivePreferences must be normalized labels, sorted and unique"
        );
    }
    if (record.ownProfile !== void 0 && record.ownProfile !== true)
      throw new ValidationError("ownProfile must be true when present");
  }
  function validateSyncConfig(record) {
    allowOnly(
      record,
      [
        "id",
        "accountId",
        "createdAt",
        "updatedAt",
        "endpoint",
        "lastSyncedAt",
        "keyDerivation"
      ],
      "SyncConfig"
    );
    requireString(record, "endpoint");
    const keyDerivation = record.keyDerivation;
    if (!keyDerivation || typeof keyDerivation !== "object")
      throw new ValidationError("keyDerivation is required");
    const parameters = keyDerivation;
    allowOnly(
      parameters,
      ["algorithm", "iterations", "hash", "salt"],
      "keyDerivation"
    );
    if (parameters.algorithm !== "PBKDF2" || parameters.hash !== "SHA-256")
      throw new ValidationError("Unsupported key derivation parameters");
    if (!Number.isInteger(requireNumber(parameters, "iterations")) || requireNumber(parameters, "iterations") <= 0)
      throw new ValidationError("iterations must be a positive integer");
    requireString(parameters, "salt");
  }
  function validateEntity(entityName, entity) {
    const record = entity;
    requireString(record, "id");
    requireString(record, "accountId");
    requireDate(record, "createdAt");
    requireDate(record, "updatedAt");
    switch (entityName) {
      case "extensionAccounts":
        requireString(record, "joyClubAccountId");
        optionalString(record, "label");
        break;
      case "joyClubMembers":
        requireString(record, "joyClubMemberId");
        if (record.nickname !== void 0 && cleanNickname(record.nickname) !== record.nickname)
          throw new ValidationError("nickname must be a clean nickname");
        break;
      case "profileSnapshots":
        validateProfileSnapshot(record);
        break;
      case "userNotes":
        requireString(record, "memberId");
        requireString(record, "body");
        break;
      case "userTags":
        requireString(record, "memberId");
        requireString(record, "label");
        break;
      case "trustSignals":
        requireString(record, "memberId");
        requireEnum(record, "kind", ["positive", "negative", "neutral"]);
        requireDate(record, "occurredAt");
        break;
      case "contactRules": {
        requireString(record, "name");
        const problem = contactRuleProblem(record);
        if (problem) throw new ValidationError(problem);
        break;
      }
      case "conversationClassifications":
        requireString(record, "memberId");
        optionalString(record, "conversationId");
        requireEnum(record, "placement", [
          "qualified",
          "needs-review",
          "quarantined"
        ]);
        requireEnum(record, "source", ["user"]);
        requireDate(record, "decidedAt");
        requireMessageArray(record, "reasons");
        optionalString(record, "ruleId");
        break;
      case "savedSearches":
        requireString(record, "name");
        requireString(record, "url");
        break;
      case "eventMetadata":
        requireString(record, "eventId");
        if (record.kind !== void 0) {
          requireEnum(record, "kind", ["event", "venue"]);
          if (!/^\d{1,12}$/u.test(record.eventId))
            throw new ValidationError("eventId must be JoyClub's number");
          if (record.id !== `${record.kind}:${record.eventId}`)
            throw new ValidationError("id must be <kind>:<eventId>");
        }
        optionalString(record, "title");
        if (record.startLocal !== void 0 && !isWallTime(requireString(record, "startLocal")))
          throw new ValidationError("startLocal must be YYYY-MM-DD[THH:mm]");
        if (record.path !== void 0 && !/^\/(event|club)\/\d{1,12}\.[^/]+\.html$/u.test(
          requireString(record, "path")
        ))
          throw new ValidationError("path must be a JoyClub event or venue path");
        if (record.venueId !== void 0 && !/^\d{1,12}$/u.test(requireString(record, "venueId")))
          throw new ValidationError("venueId must be JoyClub's number");
        optionalString(record, "venueName");
        optionalString(record, "note");
        requireStringArray(record, "tags");
        requireEnum(record, "attendance", [
          "interested",
          "attending",
          "not-attending",
          "attended",
          "unknown"
        ]);
        if (record.attendees !== void 0) {
          const ids = record.attendees;
          if (!Array.isArray(ids) || ids.length > MAX_EVENT_ATTENDEES || ids.some(
            (id, index) => typeof id !== "string" || // The member-ID shape every handler accepts (triage-service).
            !/^\d{1,20}$/u.test(id) || index > 0 && !(ids[index - 1] < id)
          ))
            throw new ValidationError(
              `attendees must be up to ${MAX_EVENT_ATTENDEES} member IDs, sorted and unique`
            );
        }
        if (record.attendeesSeenAt !== void 0)
          requireDate(record, "attendeesSeenAt");
        break;
      case "spendLogEntries":
        requireDate(record, "occurredAt");
        requireNumber(record, "amountMinor");
        requireString(record, "currency");
        requireEnum(record, "category", ["coins", "membership", "other"]);
        break;
      case "syncConfigs":
        validateSyncConfig(record);
        if (record.lastSyncedAt !== void 0)
          requireDate(record, "lastSyncedAt");
        break;
      case "extensionPreferences":
        requireString(record, "key");
        break;
      case "messageTemplates":
        requireString(record, "name");
        requireString(record, "body");
        optionalString(record, "folder");
        break;
      case "spamPhrases":
        requireString(record, "phrase");
        requireBoolean(record, "enabled");
        break;
      case "messageObservations":
        allowOnly(
          record,
          [
            "id",
            "accountId",
            "createdAt",
            "updatedAt",
            "memberId",
            "conversationId",
            "observedAt",
            "normalizedText"
          ],
          "MessageObservation"
        );
        requireString(record, "memberId");
        requireDate(record, "observedAt");
        requireString(record, "normalizedText");
        optionalString(record, "conversationId");
        break;
      case "senderSpamOverrides":
        requireString(record, "memberId");
        requireEnum(record, "decision", ["not-spam"]);
        requireDate(record, "decidedAt");
        optionalString(record, "reason");
        break;
      case "cachedMessages": {
        const messageId = requireString(record, "messageId");
        if (!MESSAGE_ID_PATTERN.test(messageId))
          throw new ValidationError("messageId must be JoyClub's message ID");
        if (record.id !== `message:${messageId}`)
          throw new ValidationError("id must be message:<messageId>");
        const conversationId = requireString(record, "conversationId");
        if (!CONVERSATION_ID_PATTERN.test(conversationId))
          throw new ValidationError("conversationId must be personal-<n>-<n>");
        const memberId = requireString(record, "memberId");
        if (!conversationId.split("-").slice(1).includes(memberId))
          throw new ValidationError("memberId must be in the conversation");
        requireEnum(record, "direction", ["sent", "received"]);
        if (record.sentAt !== void 0) requireDate(record, "sentAt");
        const text2 = requireString(record, "text");
        if (text2.trim().length === 0 || text2.length > MAX_MESSAGE_TEXT_LENGTH)
          throw new ValidationError(
            `text must hold 1 to ${MAX_MESSAGE_TEXT_LENGTH} characters`
          );
        break;
      }
      case "messagePhraseMatches":
        allowOnly(
          record,
          [
            "id",
            "accountId",
            "createdAt",
            "updatedAt",
            "memberId",
            "phrase",
            "matchedAt"
          ],
          "MessagePhraseMatch"
        );
        requireString(record, "memberId");
        if (requireString(record, "phrase").length > MAX_NORMALIZED_PHRASE_LENGTH)
          throw new ValidationError("phrase is too long");
        requireDate(record, "matchedAt");
        break;
      case "actionLogs":
        requireString(record, "action");
        optionalString(record, "memberId");
        optionalString(record, "conversationId");
        validateActionSteps(record);
        break;
    }
  }

  // src/storage/repository.ts
  var keyPart = (value) => encodeURIComponent(value);
  var key = (accountId, id) => `${keyPart(accountId)}:${keyPart(id)}`;
  var storageKeyFor = key;
  function withoutStorageKey(stored) {
    const copy = { ...stored };
    delete copy.storageKey;
    return copy;
  }
  var IndexedDbRepository = class {
    constructor(entityName) {
      this.entityName = entityName;
    }
    async get(accountId, id) {
      const db = await openDatabase();
      const stored = await requestResult(
        db.transaction(this.entityName).objectStore(this.entityName).get(key(accountId, id))
      );
      if (!stored) return void 0;
      return withoutStorageKey(stored);
    }
    async list(accountId) {
      const db = await openDatabase();
      const records = await requestResult(
        db.transaction(this.entityName).objectStore(this.entityName).index("accountId").getAll(accountId)
      );
      return records.map(withoutStorageKey);
    }
    /**
     * Stores one record. `retention` is passed to the store's retention policy,
     * if it has one (profile snapshots: how many to keep per member).
     */
    async put(accountId, entity, retention) {
      if (entity.accountId !== accountId)
        throw new ValidationError(
          "Entity account does not match repository scope"
        );
      validateEntity(this.entityName, entity);
      const db = await openDatabase();
      const transaction = db.transaction(this.entityName, "readwrite");
      const store = transaction.objectStore(this.entityName);
      await commitAll(transaction, async () => {
        store.put({ ...entity, storageKey: key(accountId, entity.id) });
        await this.applyRetention?.(store, accountId, entity, retention);
      });
    }
    async delete(accountId, id) {
      const db = await openDatabase();
      const transaction = db.transaction(this.entityName, "readwrite");
      transaction.objectStore(this.entityName).delete(key(accountId, id));
      await transactionDone(transaction);
    }
  };

  // src/storage/snapshot-retention.ts
  var DEFAULT_SNAPSHOT_RETENTION = 20;

  // src/storage/repositories.ts
  var PROFILE_SNAPSHOT_RETENTION = DEFAULT_SNAPSHOT_RETENTION;
  function snapshotsBeyond(snapshots, keep) {
    const byMember = /* @__PURE__ */ new Map();
    for (const snapshot of snapshots) {
      const member = `${snapshot.accountId}\0${snapshot.memberId}`;
      const list = byMember.get(member) ?? [];
      list.push(snapshot);
      byMember.set(member, list);
    }
    return [...byMember.values()].flatMap(
      (list) => list.sort(newestCaptureFirst).slice(Math.max(keep, 1))
    );
  }
  var ExtensionAccountRepository = class extends IndexedDbRepository {
    constructor() {
      super("extensionAccounts");
    }
    /**
     * The account directory is the one store that must be readable without an
     * account scope, because the scope itself is chosen from its contents. Every
     * account record is self-scoped (`accountId === id`), so this reads the
     * directory and never another account's data.
     */
    async listAllAccounts() {
      const db = await openDatabase();
      const stored = await requestResult(
        db.transaction("extensionAccounts").objectStore("extensionAccounts").getAll()
      );
      return stored.map(withoutStorageKey);
    }
    /**
     * Stores a new account only if no stored account has its JoyClub
     * identifier. The check and the write share one readwrite transaction, and
     * IndexedDB runs such transactions on this store one at a time, in every
     * extension context, so two creates can never both pass the check.
     * Returns `false`, writing nothing, for a duplicate.
     */
    async addIfIdentifierFree(account) {
      validateEntity("extensionAccounts", account);
      if (account.accountId !== account.id)
        throw new ValidationError("An account must be its own scope");
      const db = await openDatabase();
      const transaction = db.transaction("extensionAccounts", "readwrite");
      const store = transaction.objectStore("extensionAccounts");
      let added = false;
      await commitAll(transaction, async () => {
        const stored = await requestResult(
          store.getAll()
        );
        if (stored.some(
          (existing) => existing.joyClubAccountId === account.joyClubAccountId
        ))
          return;
        store.put({
          ...account,
          storageKey: storageKeyFor(account.id, account.id)
        });
        added = true;
      });
      return added;
    }
  };
  var JoyClubMemberRepository = class extends IndexedDbRepository {
    constructor() {
      super("joyClubMembers");
    }
  };
  var ProfileSnapshotRepository = class extends IndexedDbRepository {
    constructor() {
      super("profileSnapshots");
    }
    async applyRetention(store, accountId, entity, retention = PROFILE_SNAPSHOT_RETENTION) {
      const stored = await requestResult(
        store.index("accountId").getAll(accountId)
      );
      const member = stored.filter(
        (snapshot) => snapshot.memberId === entity.memberId
      );
      for (const obsolete of snapshotsBeyond(member, retention))
        store.delete(obsolete.storageKey);
    }
    /**
     * Keeps only the newest `keep` snapshots of every member in every account,
     * in one transaction: after the user lowers the setting, the snapshots
     * already stored follow it too. Returns how many were deleted.
     */
    async pruneAll(keep) {
      const db = await openDatabase();
      const transaction = db.transaction("profileSnapshots", "readwrite");
      const store = transaction.objectStore("profileSnapshots");
      let deleted = 0;
      await commitAll(transaction, async () => {
        const all = await requestResult(
          store.getAll()
        );
        for (const obsolete of snapshotsBeyond(all, keep)) {
          store.delete(obsolete.storageKey);
          deleted += 1;
        }
      });
      return deleted;
    }
  };
  var UserNoteRepository = class extends IndexedDbRepository {
    constructor() {
      super("userNotes");
    }
  };
  var UserTagRepository = class extends IndexedDbRepository {
    constructor() {
      super("userTags");
    }
  };
  var TrustSignalRepository = class extends IndexedDbRepository {
    constructor() {
      super("trustSignals");
    }
  };
  var ContactRuleRepository = class extends IndexedDbRepository {
    constructor() {
      super("contactRules");
    }
  };
  var ConversationClassificationRepository = class extends IndexedDbRepository {
    constructor() {
      super("conversationClassifications");
    }
  };
  var SavedSearchRepository = class extends IndexedDbRepository {
    constructor() {
      super("savedSearches");
    }
  };
  var EventMetadataRepository = class extends IndexedDbRepository {
    constructor() {
      super("eventMetadata");
    }
  };
  var SpendLogEntryRepository = class extends IndexedDbRepository {
    constructor() {
      super("spendLogEntries");
    }
  };
  var SyncConfigRepository = class extends IndexedDbRepository {
    constructor() {
      super("syncConfigs");
    }
  };
  var ExtensionPreferenceRepository = class extends IndexedDbRepository {
    constructor() {
      super("extensionPreferences");
    }
  };
  var MessageTemplateRepository = class extends IndexedDbRepository {
    constructor() {
      super("messageTemplates");
    }
  };
  var SpamPhraseRepository = class extends IndexedDbRepository {
    constructor() {
      super("spamPhrases");
    }
  };
  var MESSAGE_OBSERVATION_RETENTION_DAYS = 365;
  var MessageObservationRepository = class extends IndexedDbRepository {
    constructor() {
      super("messageObservations");
    }
    /**
     * The window is measured from this write, using `updatedAt`, which the
     * writer always sets to now. Measuring from the record's own `observedAt`
     * would let a caller backdate one message and drag the cutoff back with it,
     * keeping everything expired alive.
     *
     * The record being written is never purged here, so `put` cannot report
     * storing something this pass deleted in the same transaction.
     */
    async applyRetention(store, accountId, entity) {
      const cutoff = Date.parse(entity.updatedAt) - MESSAGE_OBSERVATION_RETENTION_DAYS * 24 * 60 * 60 * 1e3;
      const stored = await requestResult(
        store.index("accountId").getAll(accountId)
      );
      for (const observation of stored)
        if (observation.id !== entity.id && Date.parse(observation.observedAt) < cutoff)
          store.delete(observation.storageKey);
    }
  };
  var SenderSpamOverrideRepository = class extends IndexedDbRepository {
    constructor() {
      super("senderSpamOverrides");
    }
  };
  var ActionLogRepository = class extends IndexedDbRepository {
    constructor() {
      super("actionLogs");
    }
  };
  var MessagePhraseMatchRepository = class extends IndexedDbRepository {
    constructor() {
      super("messagePhraseMatches");
    }
  };
  var CachedMessageRepository = class extends IndexedDbRepository {
    constructor() {
      super("cachedMessages");
    }
    /**
     * Deletes every cached message, in every account, older than `cutoff`
     * (an ISO date), in one transaction. A message's age counts from when it
     * was sent, or from when it was stored when the page showed no time.
     * Returns how many were deleted.
     */
    async pruneOlderThan(cutoff) {
      const db = await openDatabase();
      const transaction = db.transaction("cachedMessages", "readwrite");
      const store = transaction.objectStore("cachedMessages");
      let deleted = 0;
      await commitAll(transaction, async () => {
        const all = await requestResult(
          store.getAll()
        );
        for (const message2 of all)
          if (Date.parse(messageTime(message2)) < Date.parse(cutoff)) {
            store.delete(message2.storageKey);
            deleted += 1;
          }
      });
      return deleted;
    }
  };
  var repositories = {
    extensionAccounts: new ExtensionAccountRepository(),
    joyClubMembers: new JoyClubMemberRepository(),
    profileSnapshots: new ProfileSnapshotRepository(),
    userNotes: new UserNoteRepository(),
    userTags: new UserTagRepository(),
    trustSignals: new TrustSignalRepository(),
    contactRules: new ContactRuleRepository(),
    conversationClassifications: new ConversationClassificationRepository(),
    savedSearches: new SavedSearchRepository(),
    eventMetadata: new EventMetadataRepository(),
    spendLogEntries: new SpendLogEntryRepository(),
    syncConfigs: new SyncConfigRepository(),
    extensionPreferences: new ExtensionPreferenceRepository(),
    messageTemplates: new MessageTemplateRepository(),
    spamPhrases: new SpamPhraseRepository(),
    messageObservations: new MessageObservationRepository(),
    senderSpamOverrides: new SenderSpamOverrideRepository(),
    actionLogs: new ActionLogRepository(),
    messagePhraseMatches: new MessagePhraseMatchRepository(),
    cachedMessages: new CachedMessageRepository()
  };

  // src/accounts/account-service.ts
  var ACTIVE_ACCOUNT_SETTING_KEY = "joyfox.activeAccountId";

  // src/extraction/joyclub.ts
  var found = (value, source) => ({
    status: "found",
    value,
    source
  });
  var missing = (source) => ({
    status: "missing",
    source
  });
  var invalid = (source, reason) => ({
    status: "invalid",
    source,
    reason
  });
  function pagePath(page) {
    const definition = selectorRegistry[page];
    return definition.status === "verified" && definition.path ? new RegExp(definition.path) : void 0;
  }
  function memberIdFromProfileHref(href, base, source) {
    if (href === null || href.trim() === "") return missing(source);
    let path;
    try {
      path = new URL(href, base).pathname;
    } catch {
      return invalid(source, "Unparseable profile link");
    }
    const match = pagePath("profile")?.exec(path);
    return match?.[1] ? found(match[1], source) : invalid(source, "Profile link has an unexpected shape");
  }
  function codeAttribute(scope, selector, attribute, source) {
    if (!selector) return missing(source);
    const element2 = scope.querySelector(selector);
    const raw = element2?.getAttribute(attribute);
    if (raw === null || raw === void 0) return missing(source);
    return /^\d+$/.test(raw.trim()) ? found(Number(raw.trim()), source) : invalid(source, `${attribute} is not a numeric code`);
  }
  var VERIFICATION_CODE_MEANING = Object.freeze({ 0: false, 1: true });
  var PERSONALLY_KNOWN_CODE = 3;
  function verificationFromCode(code) {
    if (code.status !== "found") return "unknown";
    return VERIFICATION_CODE_MEANING[code.value] ?? "unknown";
  }
  function personallyKnownFromCode(code) {
    if (code.status !== "found") return "unknown";
    if (code.value === PERSONALLY_KNOWN_CODE) return true;
    if (code.value in VERIFICATION_CODE_MEANING) return false;
    return "unknown";
  }
  function verificationFromBadge(text2) {
    const normalized = text2.replace(/\s+/gu, " ").trim();
    if (/^Verifiziertes Mitglied$/u.test(normalized)) return true;
    if (/\bnoch nicht verifiziert\b/u.test(normalized)) return false;
    return void 0;
  }
  var PROFILE_TYPE_CODE_MEANING = Object.freeze({ 1: "man", 2: "woman", 3: "couple" });
  function profileTypeFromCode(code) {
    if (code.status !== "found") return "unknown";
    return PROFILE_TYPE_CODE_MEANING[code.value] ?? "unknown";
  }
  function cardProfileType(card) {
    const source = "my-joy-list.genderCode";
    const selector = verifiedSelector("my-joy-list", "genderCode");
    const raw = selector && card.matches(selector) ? card.getAttribute("universal-gender")?.trim() : void 0;
    return profileTypeFromCode(
      raw && /^\d+$/.test(raw) ? found(Number(raw), source) : missing(source)
    );
  }
  var countWords = (text2) => text2.trim() === "" ? 0 : text2.trim().split(/\s+/u).length;
  function extractInboxRows(root, base) {
    const rowSelector = verifiedSelector("inbox", "row");
    if (!rowSelector) return [];
    const linkSelector = verifiedSelector("inbox", "memberId");
    const readSelector = verifiedSelector("inbox", "readStatus");
    const nameSelector = verifiedSelector("inbox", "senderName");
    const previewSelector = verifiedSelector("inbox", "messagePreview");
    return Array.from(root.querySelectorAll(rowSelector)).map((row) => {
      const readIcon = readSelector ? row.querySelector(readSelector) : null;
      const modifier = Array.from(readIcon?.classList ?? []).map((name2) => /__read-status--([a-z-]+)$/.exec(name2)?.[1]).find((value) => value !== void 0);
      const name = nameSelector ? row.querySelector(nameSelector)?.textContent?.trim() : void 0;
      const preview = previewSelector ? row.querySelector(previewSelector)?.textContent?.trim() : void 0;
      return {
        row,
        senderName: name ? found(name, "inbox.senderName") : missing("inbox.senderName"),
        memberId: memberIdFromProfileHref(
          linkSelector ? row.querySelector(linkSelector)?.getAttribute("href") ?? null : null,
          base,
          "inbox.memberId"
        ),
        verificationCode: codeAttribute(
          row,
          verifiedSelector("inbox", "verificationCode"),
          "verification-status",
          "inbox.verificationCode"
        ),
        genderCode: codeAttribute(
          row,
          verifiedSelector("inbox", "genderCode"),
          "universal-gender",
          "inbox.genderCode"
        ),
        readState: modifier ? found(modifier, "inbox.readStatus") : missing("inbox.readStatus"),
        // An empty preview (an attachment only, for example) holds no phrase,
        // so it counts as a preview without it.
        messagePreview: preview !== void 0 ? found(preview, "inbox.messagePreview") : missing("inbox.messagePreview")
      };
    });
  }
  function sameOriginProfileUrl(href, base) {
    if (href === null) return void 0;
    try {
      const page = new URL(base);
      const link = new URL(href, base);
      if (link.origin !== page.origin) return void 0;
      return pagePath("profile")?.test(link.pathname) ? `${link.origin}${link.pathname}` : void 0;
    } catch {
      return void 0;
    }
  }
  function extractConversation(root, url) {
    let path = "";
    try {
      path = new URL(url).pathname;
    } catch {
    }
    const conversationMatch = pagePath("conversation")?.exec(path);
    const conversationId = conversationMatch?.[1];
    const headerLink = verifiedSelector("conversation", "memberId");
    const descriptionSelector = verifiedSelector(
      "conversation",
      "profileDescription"
    );
    const description = descriptionSelector ? root.querySelector(descriptionSelector) : null;
    const conversation = conversationId ? found(conversationId, "conversation.url") : missing("conversation.url");
    const headerHref = headerLink ? root.querySelector(headerLink)?.getAttribute("href") ?? null : null;
    const memberId = memberIdFromProfileHref(
      headerHref,
      url,
      "conversation.memberId"
    );
    const headerMatchesUrl = conversationId !== void 0 && memberId.status === "found" && conversationId.split("-").includes(memberId.value);
    if (!headerMatchesUrl) {
      const stale = (field) => missing(`conversation.${field}:header-not-matched-to-url`);
      return {
        conversationId: conversation,
        memberId: memberId.status === "found" ? stale("memberId") : memberId,
        verificationCode: stale("verificationCode"),
        genderCode: stale("genderCode"),
        descriptionWordCount: stale("profileDescription"),
        profileUrl: stale("profileUrl")
      };
    }
    const profileUrl2 = sameOriginProfileUrl(headerHref, url);
    return {
      conversationId: conversation,
      memberId,
      verificationCode: codeAttribute(
        root,
        verifiedSelector("conversation", "verificationCode"),
        "verification-status",
        "conversation.verificationCode"
      ),
      genderCode: codeAttribute(
        root,
        verifiedSelector("conversation", "genderCode"),
        "universal-gender",
        "conversation.genderCode"
      ),
      descriptionWordCount: description ? found(
        countWords(description.textContent ?? ""),
        "conversation.profileDescription"
      ) : missing("conversation.profileDescription"),
      profileUrl: profileUrl2 ? found(profileUrl2, "conversation.profileUrl") : invalid("conversation.profileUrl", "Profile link is not on this site")
    };
  }
  var UNIT_WORDS = {
    tag: "day",
    tagen: "day",
    woche: "week",
    wochen: "week",
    monat: "month",
    monaten: "month",
    jahr: "year",
    jahren: "year"
  };
  var MEMBER_SINCE = /^Angemeldet seit (\d+|einem|einer) (Tag|Tagen|Woche|Wochen|Monat|Monaten|Jahr|Jahren)$/u;
  function parseMemberSince(text2) {
    const match = MEMBER_SINCE.exec(text2.replace(/\s+/gu, " ").trim());
    if (!match?.[1] || !match[2]) return void 0;
    const count = /^\d+$/.test(match[1]) ? Number(match[1]) : 1;
    const unit = UNIT_WORDS[match[2].toLowerCase()];
    return unit && Number.isSafeInteger(count) ? { count, unit } : void 0;
  }
  function subtractUnits(from, unit, count) {
    const date = new Date(from.getTime());
    if (unit === "day") date.setUTCDate(date.getUTCDate() - count);
    else if (unit === "week") date.setUTCDate(date.getUTCDate() - 7 * count);
    else {
      const months = unit === "month" ? count : 12 * count;
      const total = date.getUTCFullYear() * 12 + date.getUTCMonth() - months;
      const year = Math.floor(total / 12);
      const month = total - year * 12;
      const lastDay = new Date(Date.UTC(year, month + 1, 0)).getUTCDate();
      date.setUTCFullYear(year, month, Math.min(date.getUTCDate(), lastDay));
    }
    return date;
  }
  function joinWindowFromDuration(duration, now) {
    return {
      earliest: subtractUnits(
        now,
        duration.unit,
        duration.count + 1
      ).toISOString(),
      latest: subtractUnits(
        now,
        duration.unit,
        Math.max(duration.count - 1, 0)
      ).toISOString()
    };
  }
  var PHOTO_LABEL = /^\s*(\d+)\s+Fotos?\s*$/u;
  function extractProfile(root, url, now = /* @__PURE__ */ new Date()) {
    let pathname = "";
    try {
      pathname = new URL(url).pathname;
    } catch {
    }
    const memberField = verifiedSelector("profile", "memberId");
    const photoSelector = verifiedSelector("profile", "photoCount");
    const photoLabel = photoSelector ? root.querySelector(photoSelector)?.getAttribute("aria-label") ?? null : null;
    const photoMatch = photoLabel === null ? null : PHOTO_LABEL.exec(photoLabel);
    const mainTextSelector = verifiedSelector("profile", "profileMainText");
    const mainText = mainTextSelector ? root.querySelector(mainTextSelector) : null;
    return {
      memberId: memberField === FROM_URL ? memberIdFromProfileHref(pathname || null, url, "profile.url") : missing("profile.url"),
      verificationCode: codeAttribute(
        root,
        verifiedSelector("profile", "verificationCode"),
        "verification-status",
        "profile.verificationCode"
      ),
      verificationBadge: verificationBadge(root),
      genderCode: codeAttribute(
        root,
        verifiedSelector("profile", "genderCode"),
        "universal-gender",
        "profile.genderCode"
      ),
      photoCount: photoLabel === null ? missing("profile.photoCount") : photoMatch?.[1] ? found(Number(photoMatch[1]), "profile.photoCount") : invalid("profile.photoCount", "Unexpected photo badge label"),
      // No main text block is "not rendered", which is not the same as a
      // profile with zero words, so it stays missing.
      profileWordCount: mainText ? found(countWords(mainText.textContent ?? ""), "profile.mainText") : missing("profile.mainText"),
      joinedAt: missing("profile.joinedAt:no-exact-date-on-site"),
      joinedWindow: memberSinceWindow(root, now)
    };
  }
  function badgeLabel(item) {
    return Array.from(item.childNodes).filter(
      (node) => node.nodeType === node.TEXT_NODE || node.nodeType === node.ELEMENT_NODE && !node.hasAttribute("slot")
    ).map((node) => node.textContent ?? "").join(" ").replace(/\s+/gu, " ").trim();
  }
  function verificationBadge(root) {
    const selector = verifiedSelector("profile", "verificationBadge");
    if (!selector) return missing("profile.verificationBadge");
    for (const element2 of Array.from(root.querySelectorAll(selector))) {
      const label = badgeLabel(element2);
      const value = verificationFromBadge(label || (element2.textContent ?? ""));
      if (value !== void 0) return found(value, "profile.verificationBadge");
    }
    return missing("profile.verificationBadge");
  }
  function memberSinceWindow(root, now) {
    const selector = verifiedSelector("profile", "memberSinceBadge");
    if (!selector) return missing("profile.memberSince");
    const badge = Array.from(root.querySelectorAll(selector)).map(badgeLabel).find((text2) => text2.startsWith("Angemeldet seit"));
    if (badge === void 0) return missing("profile.memberSince");
    const duration = parseMemberSince(badge);
    return duration ? found(joinWindowFromDuration(duration, now), "profile.memberSince") : invalid("profile.memberSince", "Unexpected membership duration text");
  }

  // src/i18n/locale.ts
  var LOCALE_KEY = "joyfox.locale";
  var isLocale = (value) => value === "en" || value === "de";
  function resolveDefaultLocale(uiLanguage) {
    return /^de(?:[-_]|$)/iu.test(uiLanguage.trim()) ? "de" : "en";
  }
  function firefoxLanguage() {
    try {
      const api = globalThis.browser?.i18n;
      return api?.getUILanguage?.() ?? "";
    } catch {
      return "";
    }
  }
  function localeFromSetting(value, uiLanguage = firefoxLanguage) {
    return isLocale(value) ? value : resolveDefaultLocale(uiLanguage());
  }
  async function readLocale(area, uiLanguage = firefoxLanguage) {
    let stored;
    try {
      stored = (await area.get([LOCALE_KEY]))[LOCALE_KEY];
    } catch {
      stored = void 0;
    }
    return localeFromSetting(stored, uiLanguage);
  }

  // src/i18n/catalog/de.ts
  var de = {
    // Shared labels
    "placement.qualified": "Qualifiziert",
    "placement.needs-review": "Zu pr\xFCfen",
    "placement.quarantined": "Junk",
    "condition.verified": "Verifiziert",
    "condition.personallyKnown": "Pers\xF6nlich bekannt",
    "condition.minimumPhotos": "Mindestanzahl Fotos",
    "condition.minimumProfileWords": "Mindestanzahl W\xF6rter im Profil",
    "condition.minimumAccountAgeDays": "Mindestalter des Kontos in Tagen",
    "condition.notTemplateSpam": "Nicht als Vorlagen-Spam markiert",
    "condition.minimumTrustScore": "Mindest-Vertrauenswert (lokal)",
    "condition.firstMessageContains": "Erste Nachricht enth\xE4lt",
    "field.accountAgeDays": "Kontoalter in Tagen",
    "field.photoCount": "Anzahl der Fotos",
    "field.profileWordCount": "W\xF6rter im Profil",
    "outcome.qualified": "Qualifiziert",
    "outcome.partial-information": "Unvollst\xE4ndige Angaben",
    "outcome.does-not-meet-rule": "Erf\xFCllt die Regel nicht",
    "common.close": "Schlie\xDFen",
    "common.openOptions": "JoyFox-Einstellungen \xF6ffnen",
    "common.saveFailed": "JoyFox konnte diese \xC4nderung nicht speichern. Es wurde nichts ge\xE4ndert. Versuche es noch einmal. Wenn es weiter nicht klappt, lade die Seite neu.",
    "legacy.text": (p) => p.text,
    "common.textUnavailable": "(Dieser Text kann nicht angezeigt werden.)",
    // Triage reasons
    "triage.reason.unknownValue": (p) => `${p.field}: unbekannt. Der Wert wurde weder daf\xFCr noch dagegen gez\xE4hlt.`,
    "triage.reason.atOrAbove": (p, f) => `${p.field}: ${f.number(p.value)}. Das erreicht den geforderten Mindestwert ${f.number(p.minimum)}.`,
    "triage.reason.belowMinimum": (p, f) => `${p.field}: ${f.number(p.value)}. Das liegt unter dem geforderten Mindestwert ${f.number(p.minimum)}.`,
    "triage.reason.accountAgeRangeAbove": (p, f) => `Kontoalter: zwischen ${f.number(p.min)} und ${f.number(p.max)} Tagen. Das erreicht den geforderten Mindestwert ${f.number(p.minimum)}.`,
    "triage.reason.accountAgeRangeBelow": (p, f) => `Kontoalter: zwischen ${f.number(p.min)} und ${f.number(p.max)} Tagen. Das liegt unter dem geforderten Mindestwert ${f.number(p.minimum)}.`,
    "triage.reason.accountAgeRangeCoarse": (p, f) => `Kontoalter: zwischen ${f.number(p.min)} und ${f.number(p.max)} Tagen. Das ist zu ungenau f\xFCr einen Vergleich mit dem geforderten Mindestwert ${f.number(p.minimum)}, deshalb wurde es weder daf\xFCr noch dagegen gez\xE4hlt.`,
    "triage.reason.verificationUnknown": "Der Verifizierungsstatus ist unbekannt. Er wurde weder daf\xFCr noch dagegen gez\xE4hlt.",
    "triage.reason.verified": "Das Profil ist verifiziert, wie deine Regel es verlangt.",
    "triage.reason.notVerified": "Das Profil ist nicht verifiziert. Deine Regel verlangt das aber.",
    "triage.reason.personallyKnownUnknown": "Ob du dieses Mitglied pers\xF6nlich kennst, ist unbekannt. Das wurde weder daf\xFCr noch dagegen gez\xE4hlt.",
    "triage.reason.personallyKnown": "Du hast dieses Mitglied als pers\xF6nlich bekannt markiert, wie deine Regel es verlangt.",
    "triage.reason.notPersonallyKnown": "Du hast dieses Mitglied nicht als pers\xF6nlich bekannt markiert. Deine Regel verlangt das aber.",
    "triage.reason.noCriteria": "Es sind keine Kriterien eingestellt, deshalb ist jede Person qualifiziert.",
    "triage.reason.spamFlagged": "Eine Nachricht dieser Person sieht wie eine kopierte Vorlage aus.",
    "triage.reason.spamNotFlagged": "Keine Nachricht dieser Person sieht wie eine kopierte Vorlage aus.",
    "triage.reason.spamOverridden": "Du hast diese Person als \u201Ekein Spam\u201C markiert.",
    "triage.reason.spamUnknown": "JoyFox hat die Nachrichten dieser Person nicht auf Vorlagen gepr\xFCft. Der Spam-Status ist deshalb unbekannt.",
    "triage.reason.phraseSeenNow": (p) => `Die neueste Nachricht dieser Person enth\xE4lt \u201E${p.text}\u201C.`,
    "triage.reason.phraseSeenBefore": (p) => `Eine fr\xFChere Nachricht dieser Person aus deinem Posteingang enth\xE4lt \u201E${p.text}\u201C.`,
    "triage.reason.phraseNotInLatest": (p) => `Die neueste Nachricht dieser Person enth\xE4lt \u201E${p.text}\u201C nicht. Der Posteingang zeigt nur die neueste Nachricht, deshalb kann JoyFox nicht sehen, ob die erste Nachricht es enthielt.`,
    "triage.reason.phraseNotSeen": (p) => `JoyFox hat keine Nachricht dieser Person gesehen, die \u201E${p.text}\u201C enth\xE4lt. Nur der Posteingang zeigt JoyFox Nachrichten.`,
    "triage.reason.trustUnknown": "Du hast zu diesem Mitglied nichts erfasst. Der lokale Vertrauenswert ist deshalb unbekannt.",
    "triage.reason.trustAtOrAbove": (p, f) => `Dein lokaler Vertrauenswert: ${f.number(p.score)}. Das erreicht den geforderten Mindestwert ${f.number(p.minimum)}.`,
    "triage.reason.trustBelow": (p, f) => `Dein lokaler Vertrauenswert: ${f.number(p.score)}. Das liegt unter dem geforderten Mindestwert ${f.number(p.minimum)}.`,
    "triage.reason.negatedMet": (p) => `${p.reason} Deine Regel sagt \u201Enicht ${p.condition}\u201C, deshalb z\xE4hlt das als erf\xFCllt.`,
    "triage.reason.negatedNotMet": (p) => `${p.reason} Deine Regel sagt \u201Enicht ${p.condition}\u201C, deshalb z\xE4hlt das als nicht erf\xFCllt.`,
    "triage.reason.unknownNeedsReview": (p) => `${p.reason} Deine Regel ordnet unbekannte Werte in \u201EZu pr\xFCfen\u201C ein.`,
    "triage.reason.unknownMet": (p) => `${p.reason} Deine Regel z\xE4hlt einen unbekannten Wert als erf\xFCllt.`,
    "triage.reason.unknownNotMet": (p) => `${p.reason} Deine Regel z\xE4hlt einen unbekannten Wert als nicht erf\xFCllt.`,
    "triage.reason.numbered": (p, f) => `Gruppe ${f.number(p.number)}: ${p.reason}`,
    "triage.reason.userMoved": (p) => `Du hast diese Person nach \u201E${p.placement}\u201C verschoben.`,
    "triage.headline.noConditions": "Deine Kontaktregel hat keine Pflichtbedingungen, deshalb ist jede Person qualifiziert.",
    "triage.headline.meets": "Diese Person erf\xFCllt deine Kontaktregel.",
    "triage.headline.undecided": "JoyFox konnte nicht entscheiden, weil einige Angaben unbekannt sind.",
    "triage.headline.doesNotMeet": (p) => `Diese Person erf\xFCllt deine Kontaktregel nicht und kommt deshalb nach \u201E${p.placement}\u201C.`,
    // Trust score
    "trust.reason.positive": (p, f) => `Du hast ${f.plural(p.count, {
      one: "1 positive Erfahrung",
      other: `${f.number(p.count)} positive Erfahrungen`
    })} erfasst.`,
    "trust.reason.negative": (p, f) => `Du hast ${f.plural(p.count, {
      one: "1 negative Erfahrung",
      other: `${f.number(p.count)} negative Erfahrungen`
    })} erfasst.`,
    "trust.reason.neutral": (p, f) => `Du hast ${f.plural(p.count, {
      one: "1 neutrale Erfahrung",
      other: `${f.number(p.count)} neutrale Erfahrungen`
    })} erfasst. Neutrale Erfahrungen z\xE4hlen 0.`,
    "trust.reason.personallyKnown": "Du hast dieses Mitglied als pers\xF6nlich bekannt markiert.",
    "trust.reason.spamFlagged": "Eine Nachricht dieses Mitglieds sieht wie eine kopierte Vorlage aus.",
    "trust.scopeNote": "Beruht nur auf dem, was du in diesem Browser erfasst und gesehen hast. Es ist keine Bewertung von JoyClub oder der Community.",
    // Template spam detector
    "spam.detail.override": "Du hast diese Person als \u201Ekein Spam\u201C markiert. Ihre Nachrichten werden deshalb nie markiert.",
    "spam.detail.belowMinimum": (p, f) => `Die Nachricht hat ${f.plural(p.words, {
      one: "1 Wort",
      other: `${f.number(p.words)} W\xF6rter`
    })}. F\xFCr den Vorlagenvergleich sind mindestens ${f.number(p.minimum)} n\xF6tig.`,
    "spam.detail.duplicate": (p, f) => `Diese Nachricht gleicht stark einer fr\xFCheren Nachricht an dich (${f.number(p.percent)} % \xE4hnlich).`,
    "spam.detail.knownPhrase": "Die Nachricht enth\xE4lt eine Formulierung aus deiner Liste bekannter Vorlagen.",
    "spam.detail.phraseSimilar": (p, f) => `Die Nachricht gleicht stark einer Formulierung aus deiner Liste bekannter Vorlagen (${f.number(p.percent)} % \xE4hnlich).`,
    "spam.detail.noMatch": "Die Nachricht gleicht keiner fr\xFCheren Nachricht und keiner bekannten Vorlagen-Formulierung.",
    // Quick Ignore and Delete (M9). JoyClub's own German labels name its
    // controls (live-evidence/10-ignore.md).
    "action.step.ignore": "Profil ignorieren",
    "action.step.delete": "In den Papierkorb schieben",
    "action.where.before": (p) => `vor \u201E${p.step}\u201C`,
    "action.where.during": (p) => `w\xE4hrend \u201E${p.step}\u201C`,
    "action.failure.control-missing": (p) => `JoyFox hat auf dieser Seite JoyClubs Option \u201E${p.step}\u201C nicht gefunden.`,
    "action.failure.confirmation-missing": (p) => `JoyClubs Best\xE4tigung f\xFCr \u201E${p.step}\u201C ist nicht erschienen.`,
    "action.failure.not-verified": (p) => `JoyClub hat nicht angezeigt, dass \u201E${p.step}\u201C geklappt hat.`,
    "action.failure.unverifiable": (p) => `JoyFox kann JoyClubs Ergebnis f\xFCr \u201E${p.step}\u201C auf dieser Seite nicht sehen und hat deshalb ${p.where} angehalten.`,
    "action.failure.member-mismatch": (p) => `Die Seite hat ein anderes Mitglied gezeigt. JoyFox hat deshalb ${p.where} angehalten.`,
    "action.failure.conversation-mismatch": (p) => `Die Seite hat eine andere Unterhaltung gezeigt. JoyFox hat deshalb ${p.where} angehalten.`,
    "action.failure.identity-unavailable": (p) => `JoyFox konnte nicht best\xE4tigen, welches Mitglied oder welche Unterhaltung die Seite zeigt, und hat deshalb ${p.where} angehalten.`,
    "action.failure.account-changed": (p) => `Das aktive JoyFox-Konto hat sich ge\xE4ndert. JoyFox hat deshalb ${p.where} angehalten.`,
    "action.failure.turned-off": (p) => `\u201EIgnorieren und l\xF6schen\u201C wurde ausgeschaltet. JoyFox hat deshalb ${p.where} angehalten.`,
    "action.failure.superseded": (p) => `Ein neuerer JoyFox-Vorgang f\xFCr dieses Mitglied hat begonnen. JoyFox hat deshalb ${p.where} angehalten.`,
    "action.failure.log-unavailable": (p) => `JoyFox konnte nicht in sein Aktionsprotokoll schreiben und hat deshalb ${p.where} angehalten.`,
    "action.failure.handoff-failed": (p) => `JoyFox konnte nicht zum Profil des Mitglieds wechseln und hat deshalb ${p.where} angehalten.`,
    "action.failure.timeout": (p) => `JoyClub hat w\xE4hrend \u201E${p.step}\u201C nicht rechtzeitig reagiert.`,
    "action.failure.step-error": (p) => `Ein unerwarteter Fehler hat JoyFox ${p.where} angehalten.`,
    "action.stepText.ignore.done": "Profil ignorieren: erledigt. JoyClub ignoriert dieses Mitglied.",
    "action.stepText.ignore.not-done": "Profil ignorieren: nicht erledigt.",
    "action.stepText.ignore.unknown": "Profil ignorieren: nicht best\xE4tigt. JoyFox hat den Schritt begonnen, aber keine Best\xE4tigung von JoyClub gesehen.",
    "action.stepText.delete.done": "In den Papierkorb schieben: erledigt. JoyClub hat die Unterhaltung in den Papierkorb verschoben.",
    "action.stepText.delete.not-done": "In den Papierkorb schieben: nicht erledigt.",
    "action.stepText.delete.unknown": "In den Papierkorb schieben: nicht best\xE4tigt. JoyFox hat den Schritt begonnen, aber keine Best\xE4tigung von JoyClub gesehen.",
    "action.next.ignore": "N\xE4chster Schritt: \xD6ffne das Profil des Mitglieds und pr\xFCfe, ob es ignoriert wird. Wenn nicht, ignoriere es dort selbst.",
    "action.next.delete": "N\xE4chster Schritt: \xD6ffne die Unterhaltung und pr\xFCfe, ob sie im Papierkorb ist. Wenn nicht, verschiebe sie selbst mit \u201EIn den Papierkorb schieben\u201C.",
    "action.next.showList": "\u201EIn den Papierkorb schieben\u201C klappt nur, w\xE4hrend diese Unterhaltung in der ClubMail-Liste daneben zu sehen ist. Mach das Fenster breiter oder scrolle die Liste, bis die Unterhaltung erscheint, und versuche es dann noch einmal.",
    "action.self.ignore": "Du kannst es selbst tun: \xD6ffne das Profil des Mitglieds und ignoriere es dort mit \u201EProfil ignorieren\u201C.",
    "action.self.delete": "Du kannst es selbst tun: Verschiebe die Unterhaltung mit \u201EIn den Papierkorb schieben\u201C in den Papierkorb.",
    "action.report.finished": "\u201EIgnorieren und l\xF6schen\u201C ist fertig.",
    "action.report.undo": "R\xFCckg\xE4ngig machen: Hol die Unterhaltung aus JoyClubs Papierkorb zur\xFCck. \xD6ffne dann das Profil des Mitglieds und w\xE4hle im Men\xFC \u201EProfil nicht mehr ignorieren\u201C.",
    "action.report.running": "\u201EIgnorieren und l\xF6schen\u201C l\xE4uft.",
    "action.report.stopped": "\u201EIgnorieren und l\xF6schen\u201C wurde angehalten.",
    "action.report.interrupted": "\u201EIgnorieren und l\xF6schen\u201C wurde unterbrochen, zum Beispiel weil der Tab geschlossen wurde.",
    "action.report.nothingChanged": "Auf JoyClub wurde nichts ge\xE4ndert.",
    "action.report.notUndone": "JoyFox hat nichts r\xFCckg\xE4ngig gemacht.",
    "action.deleteReport.finished": "\u201EL\xF6schen\u201C ist fertig.",
    "action.deleteReport.undo": "R\xFCckg\xE4ngig machen: Hol die Unterhaltung aus JoyClubs Papierkorb zur\xFCck.",
    "action.deleteReport.running": "\u201EL\xF6schen\u201C l\xE4uft.",
    "action.deleteReport.stopped": "\u201EL\xF6schen\u201C wurde angehalten.",
    "action.deleteReport.interrupted": "\u201EL\xF6schen\u201C wurde unterbrochen, zum Beispiel weil der Tab geschlossen wurde.",
    // Content script: the Delete and Ignore and Delete buttons and notice
    "quick.progress.Started": "\u201EIgnorieren und l\xF6schen\u201C l\xE4uft. JoyFox pr\xFCft die Seite.",
    "quick.delete.progress.Started": "\u201EL\xF6schen\u201C l\xE4uft. JoyFox pr\xFCft die Seite.",
    "quick.progress.DeleteRequested": "Die Unterhaltung wird in den Papierkorb verschoben.",
    "quick.progress.DeleteConfirmed": "Papierkorb erledigt. JoyFox \xF6ffnet das Profil des Mitglieds, um es dort zu ignorieren.",
    "quick.progress.IgnoreRequested": "Das Mitglied wird auf JoyClub ignoriert.",
    "quick.button": "Ignorieren und l\xF6schen",
    "quick.region": "JoyFox: Aktionen f\xFCr die Unterhaltung",
    "quick.delete.button": "L\xF6schen",
    "quick.delete.scope": "Ein Klick verschiebt diese Unterhaltung in JoyClubs Papierkorb und kehrt dann zur ClubMail-Liste zur\xFCck. Das Mitglied wird nicht ignoriert. JoyFox h\xE4lt beim ersten Problem an und sagt dir, was erledigt wurde. JoyFox sendet nie eine Nachricht.",
    "quick.scope": "Experimentell. Ein Klick verschiebt diese Unterhaltung in JoyClubs Papierkorb, \xF6ffnet dann das Profil des Mitglieds und ignoriert es dort. JoyFox h\xE4lt beim ersten Problem an und sagt dir, was erledigt wurde. JoyFox sendet nie eine Nachricht.",
    "quick.needsList": "Klappt nur, w\xE4hrend diese Unterhaltung in der ClubMail-Liste daneben zu sehen ist. Mach das Fenster breiter oder scrolle die Liste, bis die Unterhaltung erscheint.",
    "quick.noProfile": "JoyFox findet den Link zum Profil dieses Mitglieds nicht. Dort ist \u201EProfil ignorieren\u201C. JoyFox hat deshalb nichts getan. Du kannst es selbst tun: Verschiebe die Unterhaltung mit \u201EIn den Papierkorb schieben\u201C in den Papierkorb. \xD6ffne dann das Profil des Mitglieds und ignoriere es dort mit \u201EProfil ignorieren\u201C.",
    "quick.resumed": "\u201EIgnorieren und l\xF6schen\u201C, fortgesetzt aus der Unterhaltung:",
    "quick.waitingMenu": "JoyFox wartet auf JoyClubs Profilmen\xFC \u2026",
    "quick.previous": "Dein letztes \u201EIgnorieren und l\xF6schen\u201C f\xFCr dieses Mitglied:",
    "quick.previousOther": "Dein letztes \u201EIgnorieren und l\xF6schen\u201C f\xFCr dieses Mitglied, in einer anderen Unterhaltung:",
    "quick.otherResult": "Dein letztes \u201EIgnorieren und l\xF6schen\u201C, f\xFCr eine andere Unterhaltung:",
    "quick.delete.previous": "Dein letztes \u201EL\xF6schen\u201C f\xFCr dieses Mitglied:",
    "quick.delete.previousOther": "Dein letztes \u201EL\xF6schen\u201C f\xFCr dieses Mitglied, in einer anderen Unterhaltung:",
    "quick.delete.otherResult": "Dein letztes \u201EL\xF6schen\u201C, f\xFCr eine andere Unterhaltung:",
    "quick.otherRunning": "Ein JoyFox-Vorgang l\xE4uft noch f\xFCr eine andere Unterhaltung. Warte, bis er fertig ist.",
    "quick.busy": "Ein anderer JoyFox-Vorgang f\xFCr dieses Mitglied l\xE4uft noch, zum Beispiel in einem anderen Tab. Hier wurde nichts getan.",
    "quick.junk.done": "Als Junk markiert: Die Person ist in \u201EJunk\u201C, und ein negatives Ergebnis ist festgehalten.",
    "quick.junk.busy": "Ein anderer JoyFox-Vorgang f\xFCr dieses Mitglied l\xE4uft noch. JoyFox hat den Papierkorb-Schritt deshalb nicht begonnen.",
    "quick.junk.notTrashed": "Die Unterhaltung wurde nicht in den Papierkorb verschoben.",
    "quick.delete.unexpected": "\u201EL\xF6schen\u201C wurde durch einen unerwarteten Fehler angehalten. Vielleicht hat JoyFox die Unterhaltung in den Papierkorb verschoben: Pr\xFCfe selbst JoyClubs Papierkorb.",
    "quick.unexpected": "\u201EIgnorieren und l\xF6schen\u201C wurde durch einen unerwarteten Fehler angehalten. Vielleicht hat JoyFox einen Schritt erledigt: Pr\xFCfe selbst das Profil des Mitglieds und die Unterhaltung.",
    // Content script: triage explanation, member bar and trust controls
    "triage.outcome.met": "Erf\xFCllt",
    "triage.outcome.not-met": "Nicht erf\xFCllt",
    "triage.outcome.needs-review": "Zu pr\xFCfen",
    "triage.conditions.summary": (p, f) => `Alle gepr\xFCften Bedingungen (${f.number(p.count)})`,
    "triage.condition.line": (p) => `${p.outcome}: ${p.condition}. `,
    "triage.condition.lineNegated": (p) => `${p.outcome}: nicht ${p.condition}. `,
    "triage.placementLine": (p) => `Einordnung: ${p.placement} (${p.source}).`,
    "triage.source.override": "deine eigene Wahl",
    "triage.source.rule": "deine Kontaktregel",
    "triage.source.sharedEvent": "die Ausnahme f\xFCr gemeinsame Events",
    "triage.sharedEvent.attending": (p) => `Auf der G\xE4steliste von \u201E${p.event}\u201C${p.when ? ` (${p.when})` : ""}, das du mit \u201EIch gehe hin\u201C markiert hast.`,
    "triage.sharedEvent.attended": (p) => `Auf der G\xE4steliste von \u201E${p.event}\u201C${p.when ? ` (${p.when})` : ""}, das du mit \u201EIch war dort\u201C markiert hast.`,
    "triage.sharedEvent.optOut": "Das gemeinsame Event f\xFCr diese Person nicht verwenden",
    "triage.movedOn": (p) => `Du hast diese Person am ${p.date} verschoben. Deine Regel allein w\xFCrde sie in \u201E${p.placement}\u201C einordnen.`,
    "triage.place.group": "Diese Person einordnen",
    "triage.useRule": "Wieder meine Regel verwenden",
    "mark.group": "Diese Person markieren",
    "mark.qualified": "Als qualifiziert markieren",
    "mark.junk": "Als Junk markieren",
    "mark.trustFailed": (p) => `JoyFox hat diese Person in \u201E${p.placement}\u201C eingeordnet, konnte das Vertrauensergebnis aber nicht festhalten und hat deshalb dort angehalten. Du kannst es auf der Unterhaltung oder dem Profil des Mitglieds festhalten.`,
    "mark.junk.noTrash": "Die Person ist in \u201EJunk\u201C, und ein negatives Ergebnis ist festgehalten. JoyFox konnte diese Unterhaltung hier nicht in den Papierkorb verschieben. Verschiebe sie selbst mit \u201EIn den Papierkorb schieben\u201C.",
    "triage.profileFact.minimumPhotos": "Anzahl der Fotos",
    "triage.profileFact.minimumProfileWords": "W\xF6rter im Profil",
    "triage.profileFact.minimumAccountAgeDays": "Kontoalter",
    "triage.unknownFacts.one": (p) => `${p.fact}: unbekannt. \xD6ffne das Profil, dann liest JoyFox den Wert.`,
    "triage.unknownFacts.two": (p) => `${p.first} und ${p.second}: unbekannt. \xD6ffne das Profil, dann liest JoyFox die Werte.`,
    "triage.unknownFacts.three": (p) => `${p.first}, ${p.second} und ${p.third}: unbekannt. \xD6ffne das Profil, dann liest JoyFox die Werte.`,
    "trust.score.none": "Lokaler Vertrauenswert: noch keine Eintr\xE4ge.",
    "trust.score.value": (p, f) => `Lokaler Vertrauenswert: ${f.number(p.score)}.`,
    "trust.details.summary": "So setzt sich der Wert zusammen",
    "trust.contribution": (p, f) => `${p.points > 0 ? "+" : ""}${f.number(p.points)}: ${p.reason}`,
    "trust.log.group": "Erfahrung mit diesem Mitglied erfassen",
    "trust.log.positive": "Positive Erfahrung erfassen",
    "trust.log.neutral": "Neutrale Erfahrung erfassen",
    "trust.log.negative": "Negative Erfahrung erfassen",
    "trust.log.undo": "Letzte Erfahrung zur\xFCcknehmen",
    "bar.placementPrefix": "Einordnung: ",
    "bar.yourChoice": "(deine Wahl)",
    "bar.sharedEvent": "(gemeinsames Event)",
    "bar.openProfile": "Profil \xF6ffnen",
    "bar.log": "Erfassen:",
    "bar.positive": "Positiv",
    "bar.neutral": "Neutral",
    "bar.negative": "Negativ",
    "bar.undo": "Zur\xFCcknehmen",
    "bar.details": "Details",
    "strip.collapse": "JoyFox einklappen",
    "strip.expand": "JoyFox ausklappen",
    "bar.scoreDetails": "Details zum Wert",
    "panel.ruleOff.no-rule": "Es ist keine Kontaktregel gespeichert, deshalb ordnet JoyFox diese Person nicht ein.",
    "panel.ruleOff.rule-disabled": "Deine Kontaktregel ist ausgeschaltet, deshalb ordnet JoyFox diese Person nicht ein.",
    "panel.ruleOff.other": "JoyFox kann diese Person gerade nicht einordnen. Lade die Seite neu, um es noch einmal zu versuchen.",
    "panel.ruleOff.no-account": "Es ist kein JoyFox-Konto aktiv, deshalb zeigt JoyFox zu diesem Mitglied nichts an.",
    // Content script: inbox triage
    "inbox.region": "JoyFox-Sortierung",
    "inbox.views": "Nachrichten zeigen",
    "inbox.view.default": "Posteingang",
    "inbox.view.all": "Alle zeigen",
    "inbox.viewCount": (p, f) => `${p.view} (${f.number(p.count)})`,
    "inbox.about": "\xDCber diese Ansichten",
    "inbox.aboutText": "\u201EPosteingang\u201C blendet Zeilen aus \u201EJunk\u201C nur in dieser Ansicht aus. Nichts wird gel\xF6scht, und JoyFox \xE4ndert nichts auf JoyClub.",
    "inbox.checking": "Wird eingeordnet \u2026",
    "inbox.badge": (p) => `JoyFox: ${p.text}. Details.`,
    "inbox.why": "Details",
    "inbox.whyNamed": (p) => `Details: ${p.name}`,
    "inbox.rowGone": "Diese Zeile wird nicht mehr angezeigt.",
    "inbox.unidentified": "JoyFox konnte die Profilnummer dieser Person nicht lesen und deine Regel deshalb nicht pr\xFCfen. Die Zeile bleibt sichtbar.",
    "inbox.stillChecking": "JoyFox pr\xFCft diese Person noch.",
    "inbox.setup.no-account": "Es ist kein JoyFox-Konto aktiv, deshalb sortiert JoyFox diesen Posteingang nicht.",
    "inbox.setup.no-rule": "Es ist keine Kontaktregel gespeichert, deshalb sortiert JoyFox diesen Posteingang nicht.",
    // Content script: notes and tags
    "notes.region": "JoyFox-Notizen und -Tags",
    "notes.scope": "Nur f\xFCr dich in JoyFox: gespeichert nur in diesem Browser, unter dem aktiven JoyFox-Konto. JoyFox sendet sie nie irgendwohin.",
    "notes.saved": "Notiz gespeichert.",
    "notes.removed": "Notiz entfernt.",
    "notes.conflict": "Diese Notiz wurde in einem anderen Tab oder in der JoyFox-Datenansicht ge\xE4ndert. JoyFox hat deinen Text deshalb nicht gespeichert. Er steht noch im Feld. Speichere noch einmal, um die gespeicherte Notiz zu ersetzen, oder verwirf deine \xC4nderungen, um sie zu sehen.",
    "notes.refused": "Das aktive JoyFox-Konto hat sich ge\xE4ndert, deshalb wurde nichts gespeichert. Text, den du f\xFCr das vorherige Konto eingegeben hast, wurde verworfen.",
    "notes.emptyTag": "Gib zuerst einen Tag ein. Es wurde nichts hinzugef\xFCgt.",
    "notes.emptyNote": "Gib zuerst eine Notiz ein. Es wurde nichts gespeichert.",
    "notes.tagAdded": "Tag hinzugef\xFCgt.",
    "notes.tagExists": "Diesen Tag hat das Mitglied schon.",
    "notes.tagRemoved": "Tag entfernt.",
    "notes.privateNote": "Private Notiz",
    "notes.length": (p, f) => `${f.number(p.count)} von ${f.number(p.maximum)} Zeichen`,
    "notes.pasteCut": "Nur ein Teil des eingef\xFCgten Texts hat gepasst. Der Rest wurde nicht eingef\xFCgt.",
    "notes.discard": "Meine \xC4nderungen verwerfen",
    "notes.save": "Notiz speichern",
    "notes.tags": "Tags",
    "notes.noTags": "Noch keine Tags.",
    "notes.remove": "Entfernen",
    "notes.removeTag": (p) => `Tag ${p.label} entfernen`,
    "notes.addTagLabel": "Tag hinzuf\xFCgen",
    "notes.addTag": "Hinzuf\xFCgen",
    "notes.summary.none": "Deine Notizen und Tags (noch keine)",
    "notes.summary.note": "Deine Notizen und Tags (eine Notiz)",
    "notes.summary.tags": (p, f) => `Deine Notizen und Tags (${f.plural(p.count, {
      one: "1 Tag",
      other: `${f.number(p.count)} Tags`
    })})`,
    "notes.summary.noteAndTags": (p, f) => `Deine Notizen und Tags (eine Notiz und ${f.plural(p.count, {
      one: "1 Tag",
      other: `${f.number(p.count)} Tags`
    })})`,
    // Content script: template picker
    "listing.heading.event": "JoyFox: deine Notizen zu diesem Event",
    "listing.heading.venue": "JoyFox: deine Notizen zu diesem Club",
    "listing.summary.event": (p) => `JoyFox: deine Notizen zu diesem Event (${p.state})`,
    "listing.summary.venue": (p) => `JoyFox: deine Notizen zu diesem Club (${p.state})`,
    "listing.summary.none": "noch keine",
    "listing.summary.note": "eine Notiz",
    "listing.loading": "Deine Notizen werden geladen \u2026",
    "listing.readFailed": "JoyFox konnte deine Notizen zu dieser Seite nicht lesen. Lade die Seite neu, um es noch einmal zu versuchen.",
    "listing.noAccount": "W\xE4hle in den JoyFox-Einstellungen ein Konto aus oder f\xFCge eines hinzu, um Notizen zu Events zu speichern.",
    "listing.attendanceLabel": "Deine Teilnahme",
    "listing.attendance.unknown": "Kein Status",
    "listing.attendance.interested": "Interessiert",
    "listing.attendance.attending": "Ich gehe hin",
    "listing.attendance.not-attending": "Ich gehe nicht hin",
    "listing.attendance.attended": "Ich war dort",
    "listing.noteLabel": "Deine Notiz",
    "listing.saveNote": "Notiz speichern",
    "listing.tagsLabel": "Deine Tags",
    "listing.tagLabel": "Neuer Tag",
    "listing.addTag": "Tag hinzuf\xFCgen",
    "listing.removeTag": (p) => `Tag ${p.tag} entfernen`,
    "listing.emptyTag": "Gib zuerst einen Tag ein. Es wurde nichts hinzugef\xFCgt.",
    "listing.tooManyTags.event": (p, f) => `Du kannst einem Event h\xF6chstens ${f.number(p.maximum)} Tags geben. Entferne zuerst einen.`,
    "listing.tooManyTags.venue": (p, f) => `Du kannst einem Club h\xF6chstens ${f.number(p.maximum)} Tags geben. Entferne zuerst einen.`,
    "listing.privacy": "Privat: nur in diesem Browser gespeichert. JoyClub sieht nichts, und deine Anmeldung bei JoyClub \xE4ndert sich nicht.",
    "listing.saved": "Gespeichert.",
    "listing.tracked.event": "Gespeichert. JoyFox verfolgt dieses Event jetzt.",
    "listing.tracked.venue": "Gespeichert. JoyFox verfolgt diesen Club jetzt.",
    "listing.removed.event": "Es ist keine Notiz, kein Tag und keine Teilnahme mehr eingetragen, deshalb verfolgt JoyFox dieses Event nicht mehr.",
    "listing.removed.venue": "Es ist keine Notiz und kein Tag mehr eingetragen, deshalb verfolgt JoyFox diesen Club nicht mehr.",
    "listing.conflict": "Diese Notizen wurden in einem anderen Tab ge\xE4ndert, deshalb hat JoyFox nicht gespeichert. Jetzt werden die gespeicherten Notizen angezeigt; deine eingegebene Notiz steht noch im Feld.",
    "listing.refused": "Das aktive JoyFox-Konto hat sich ge\xE4ndert, deshalb wurde nichts gespeichert.",
    "events.heading": "Deine Events",
    "events.hint": "Alle Events und Clubs, zu denen du auf JoyClub eine Notiz, einen Tag oder deine Teilnahme eingetragen hast, nach Datum. JoyFox beh\xE4lt sie, auch wenn JoyClub ein Event entfernt. Um einen Eintrag zu \xE4ndern, \xF6ffne ihn auf JoyClub.",
    "events.readFailed": "JoyFox konnte deine Events nicht lesen. Lade die Seite neu, um es noch einmal zu versuchen.",
    "events.noAccount": "W\xE4hle zuerst ein Konto aus oder f\xFCge eines hinzu. Jedes Konto hat eigene Events.",
    "events.empty": "Noch keine verfolgten Events. \xD6ffne ein Event auf JoyClub und trage eine Notiz, einen Tag oder deine Teilnahme ein.",
    "events.count": (p, f) => `${f.number(p.shown)} von ${f.number(p.total)} verfolgten Events angezeigt.`,
    "events.filterLabel": "Zeigen",
    "events.filter.all": "Alle verfolgten Events",
    "events.searchLabel": "In meinen Notizen, Tags und Titeln suchen",
    "events.noDate": "Kein Datum",
    "events.untitled": (p) => `Event ${p.id}`,
    "events.past": (p) => `${p.when} (vorbei)`,
    "events.venue": (p) => `Club: ${p.venue}`,
    "events.venuesHeading": "Deine Clubs",
    "events.guests": (p, f) => f.plural(p.count, {
      one: "1 Gast gespeichert",
      other: `${f.number(p.count)} G\xE4ste gespeichert`
    }),
    "events.exception.label": "Ausnahme f\xFCr gemeinsame Events: eine Person als \u201EQualifiziert\u201C einordnen, wenn sie auf der G\xE4steliste eines Events steht, das ich mit \u201EIch gehe hin\u201C oder \u201EIch war dort\u201C markiert habe",
    "events.exception.hint": "Standardm\xE4\xDFig aus. JoyFox speichert die G\xE4steliste eines verfolgten Events, wenn du die Event-Seite \xF6ffnest, so weit JoyClub sie geladen hat, und l\xF6scht sie, wenn du das Event nicht mehr verfolgst. Eine Person, die du selbst markiert hast, beh\xE4lt deine Wahl, und im Bereich \u201EDetails\u201C kannst du die Ausnahme f\xFCr eine Person abschalten.",
    "events.exception.saved": "Gespeichert.",
    "events.exception.saveFailed": "JoyFox konnte diese Einstellung nicht speichern. Versuche es noch einmal.",
    "quickSetting.heading": "Ignorieren und l\xF6schen",
    "quickSetting.label": "Die Schaltfl\xE4che \u201EIgnorieren und l\xF6schen\u201C in ClubMail-Unterhaltungen zeigen",
    "quickSetting.hint": "Experimentell und standardm\xE4\xDFig an. Ein Klick schiebt die Unterhaltung in JoyClubs Papierkorb, \xF6ffnet das Profil des Mitglieds im selben Tab und ignoriert das Mitglied dort. Das funktioniert nur, solange die ClubMail-Liste neben der Unterhaltung zu sehen ist. JoyFox handelt nur, wenn du klickst. Das \u201EAktionsprotokoll\u201C unter \u201EDeine Daten\u201C h\xE4lt jeden Schritt fest. Diese Einstellung steuert nur \u201EIgnorieren und l\xF6schen\u201C: Die Schaltfl\xE4che \u201EL\xF6schen\u201C und \u201EAls Junk markieren\u201C verschieben eine Unterhaltung auch dann in JoyClubs Papierkorb, wenn sie aus ist.",
    "quickSetting.risk": "Bemerkt JoyClub ein Werkzeug, das f\xFCr dich klickt, kann dein Konto eingeschr\xE4nkt oder geschlossen werden. Von allen JoyFox-Funktionen hat diese das h\xF6chste Risiko.",
    "quickSetting.undo": "Um es r\xFCckg\xE4ngig zu machen, stelle die Unterhaltung aus JoyClubs Papierkorb wieder her. \xD6ffne dann das Profil des Mitglieds und w\xE4hle im Men\xFC \u201EProfil nicht mehr ignorieren\u201C.",
    "quickSetting.saved": "Gespeichert. Offene ClubMail-Tabs folgen sofort.",
    "quickSetting.saveFailed": "JoyFox konnte diese Einstellung nicht speichern. Versuche es noch einmal.",
    "sharedEvents.heading": "Gemeinsame Events",
    "sharedEvents.intro": "Dieses Mitglied steht auf der gespeicherten G\xE4steliste dieser Events, die du verfolgst:",
    "eventFilter.label": "JoyFox: zeigen",
    "eventFilter.all": "Alle geladenen Events und Dates",
    "eventFilter.tracked": "Nur Events, die JoyFox verfolgt",
    "eventFilter.note": "Nur Events mit deiner Notiz",
    "eventFilter.attending": "Nur Events, zu denen du gehst",
    "eventFilter.interested": "Nur Events, die dich interessieren",
    "eventFilter.tag": (p) => `Nur Events mit deinem Tag: ${p.tag}`,
    "eventFilter.count": (p, f) => `${f.number(p.shown)} von ${f.number(p.loaded)} geladenen Events angezeigt. Sp\xE4ter geladene Events werden auch gepr\xFCft.`,
    "eventFilter.readFailed": "JoyFox konnte deine Event-Notizen nicht lesen. Lade die Seite neu, um es noch einmal zu versuchen.",
    "eventFilter.noAccount": "W\xE4hle in den JoyFox-Einstellungen ein Konto aus oder f\xFCge eines hinzu, um nach deinen Notizen zu filtern.",
    "eventFilter.badge": "JoyFox",
    "eventFilter.hasNote": "Notiz",
    "typeFilter.legend": "Profiltyp",
    "typeFilter.man": "Mann",
    "typeFilter.woman": "Frau",
    "typeFilter.couple": "Paar",
    "typeFilter.unknown": "Unbekannt",
    "typeFilter.count": (p, f) => `${f.number(p.shown)} von ${f.number(p.loaded)} geladenen angezeigt`,
    "typeFilter.unknownHidden": (p, f) => `${f.number(p.count)} mit unbekanntem Typ ausgeblendet`,
    "typeFilter.scrollHint": "Nach unten scrollen, um mehr zu laden.",
    "typeFilter.unknownMark": "Typ unbekannt",
    "messages.heading": "Nachrichtensuche",
    "messages.hint": "JoyFox speichert die ClubMail-Nachrichten, die du \xF6ffnest, gesendete und empfangene, damit du sie hier durchsuchen kannst. Es speichert nur, was eine Unterhaltung auf dem Bildschirm zeigt, und l\xE4dt nie \xE4ltere Nachrichten. Der Text bleibt in diesem Browser, und eine Exportdatei enth\xE4lt ihn auch. Wenn du JoyFox in privaten Fenstern erlaubst, speichert es die Nachrichten, die du dort \xF6ffnest, genauso.",
    "messages.caching": "Die Nachrichten speichern, die ich in ClubMail \xF6ffne",
    "messages.cachingOn": "Das Speichern von Nachrichten ist an.",
    "messages.cachingOff": "Das Speichern von Nachrichten ist aus. Schon gespeicherte Nachrichten bleiben, bis sie \xE4lter als die hier eingestellte Zeit sind oder bis du sie unter \u201EDeine Daten\u201C l\xF6schst.",
    "messages.offHint": "Das Speichern ist aus: JoyFox speichert keine neuen Nachrichten. Die Suche umfasst weiter die schon gespeicherten Nachrichten.",
    "messages.retentionLabel": "Nachrichten behalten f\xFCr (Monate)",
    "messages.retentionSave": "Speichern",
    "messages.retentionHint": (p, f) => `\xC4ltere Nachrichten werden automatisch gel\xF6scht. Eine kleinere Zahl l\xF6scht \xE4ltere Nachrichten sofort. Standard ist ${f.number(p.default)}. Klicke zum \xDCbernehmen auf \u201ESpeichern\u201C.`,
    "messages.retentionConfirm": "Speichern und l\xF6schen",
    "messages.retentionConfirmPrompt": (p, f) => `Eine kleinere Zahl l\xF6scht die gespeicherten Nachrichten, die \xE4lter als ${f.plural(
      p.months,
      { one: "1 Monat", other: `${f.number(p.months)} Monate` }
    )} sind, sofort. Klicke zum Best\xE4tigen auf \u201ESpeichern und l\xF6schen\u201C.`,
    "messages.retentionSaved": (p, f) => p.deleted === 0 ? "Gespeichert. Keine \xE4ltere Nachricht musste gel\xF6scht werden." : `Gespeichert. ${f.plural(p.deleted, {
      one: "1 \xE4ltere Nachricht wurde",
      other: `${f.number(p.deleted)} \xE4ltere Nachrichten wurden`
    })} gel\xF6scht.`,
    "messages.retentionInvalid": (p, f) => `Gib eine ganze Zahl von ${f.number(p.minimum)} bis ${f.number(p.maximum)} ein. Es wurde nichts ge\xE4ndert.`,
    "messages.noAccount": "W\xE4hle zuerst ein Konto aus oder f\xFCge eines hinzu.",
    "messages.readFailed": "JoyFox konnte deine gespeicherten Nachrichten nicht lesen. Lade die Seite neu, um es noch einmal zu versuchen.",
    "messages.searchLabel": "Meine Nachrichten durchsuchen",
    "messages.count": (p, f) => p.count === 0 ? "Keine gespeicherte Nachricht enth\xE4lt das." : `${f.plural(p.count, {
      one: "1 Nachricht",
      other: `${f.number(p.count)} Nachrichten`
    })} gefunden.`,
    "messages.countLimited": (p, f) => `${f.number(p.count)} Nachrichten gefunden. Die neuesten ${f.number(p.shown)} werden angezeigt.`,
    "messages.sentTo": (p) => `Du an ${p.member} \xB7 ${p.when}`,
    "messages.receivedFrom": (p) => `${p.member} an dich \xB7 ${p.when}`,
    "messages.storedAt": (p) => `gespeichert ${p.when}`,
    "signals.state.complete": "Vollst\xE4ndig",
    "signals.state.incomplete": "Unvollst\xE4ndig",
    "signals.state.unknown": "Vollst\xE4ndigkeit unbekannt",
    "signals.state.unknownShort": "Unbekannt",
    "signals.photos": (p, f) => f.plural(p.count, {
      one: "1 Foto",
      other: `${f.number(p.count)} Fotos`
    }),
    "signals.photosUnknown": "Fotos unbekannt",
    "signals.words": (p, f) => f.plural(p.count, {
      one: "1 Wort",
      other: `${f.number(p.count)} W\xF6rter`
    }),
    "signals.wordsUnknown": "W\xF6rter unbekannt",
    "signals.verified": "verifiziert",
    "signals.notVerified": "nicht verifiziert",
    "signals.verificationUnknown": "Verifizierung unbekannt",
    "signals.heading": "Vollst\xE4ndigkeit des Profils",
    "signals.trust": (p, f) => `Vertrauen ${p.score > 0 ? "+" : ""}${f.number(p.score)}`,
    "signals.trustNoneShort": "Vertrauen \u2013",
    "signals.noteAdd": "Notiz hinzuf\xFCgen",
    "signals.noteEdit": "Notiz",
    "signals.tagsLabel": "Deine Tags",
    "signals.tagCount": (p, f) => f.plural(p.count, {
      one: "1 Tag",
      other: `${f.number(p.count)} Tags`
    }),
    "signals.editor.label": (p) => `JoyFox: Notiz und Tags f\xFCr ${p.member}`,
    "member.number": (p) => `Mitglied ${p.id}`,
    "signals.editor.loading": "Wird geladen \u2026",
    "signals.editor.close": "Schlie\xDFen",
    "signals.editor.noAccount": "W\xE4hle in den JoyFox-Einstellungen ein Konto aus oder f\xFCge eines hinzu, um Notizen zu f\xFChren.",
    "signals.editor.readFailed": "JoyFox konnte die Notizen zu diesem Mitglied nicht lesen. Schlie\xDFe die Notiz und \xF6ffne sie erneut.",
    "signals.filter.label": "JoyFox: unvollst\xE4ndige Profile ausblenden",
    "signals.filter.count": (p, f) => `${f.number(p.hidden)} von ${f.number(p.loaded)} geladenen Profilen ausgeblendet. Profile, \xFCber die JoyFox nichts wei\xDF, bleiben sichtbar.`,
    "compat.heading": "Gemeinsame Vorlieben",
    "compat.shared": (p, f) => `Du teilst ${f.plural(p.count, {
      one: "1 Vorliebe",
      other: `${f.number(p.count)} Vorlieben`
    })} mit diesem Mitglied:`,
    "compat.none": "Du teilst keine Vorlieben mit diesem Mitglied.",
    "compat.listToggle": "Gemeinsame Vorlieben anzeigen",
    "compat.own": (p, f) => `Das ist dein Profil. JoyFox vergleicht andere Profile mit ${f.plural(
      p.count,
      {
        one: "deiner 1 positiven Vorliebe",
        other: `deinen ${f.number(p.count)} positiven Vorlieben`
      }
    )}.`,
    "compat.ownUnknown": "\xD6ffne einmal dein eigenes JoyClub-Profil, damit JoyFox deine Vorlieben kennt.",
    "compat.unreadable": "JoyFox konnte die Vorlieben dieses Profils noch nicht lesen.",
    "compat.missing": "Dieses Profil zeigt keine Vorlieben zum Vergleichen.",
    "compat.readFailed": "JoyFox konnte deine Vorlieben nicht laden. Lade die Seite neu, um es noch einmal zu versuchen.",
    "compat.noAccount": "W\xE4hle in den JoyFox-Einstellungen ein Konto aus oder f\xFCge eines hinzu, um Vorlieben zu vergleichen.",
    "compat.badge": (p, f) => `${f.number(p.count)} gemeinsam`,
    "compat.badgeLabel": (p, f) => `JoyFox: ${f.plural(p.count, {
      one: "1 gemeinsame Vorliebe",
      other: `${f.number(p.count)} gemeinsame Vorlieben`
    })}`,
    "compat.sort.button": "Nach gemeinsamen Vorlieben sortieren",
    "compat.sort.on": "Nach gemeinsamen Vorlieben sortiert. Mitglieder, deren Profil du noch nicht ge\xF6ffnet hast, stehen am Ende.",
    "compat.sort.unavailable": "JoyFox kann die Ergebnisse so, wie JoyClub sie gerade zeigt, nicht sortieren. Ihre Reihenfolge ist unver\xE4ndert.",
    "searches.heading": "Gespeicherte JoyFox-Suchen",
    "searches.loading": "Gespeicherte Suchen werden geladen \u2026",
    "searches.readFailed": "JoyFox konnte deine gespeicherten Suchen nicht lesen. Lade die Seite neu, um es noch einmal zu versuchen.",
    "searches.empty": "Noch keine gespeicherten Suchen.",
    "searches.noAccount": "W\xE4hle in den JoyFox-Einstellungen ein Konto aus oder f\xFCge eines hinzu, um Suchen zu speichern.",
    "searches.save": "Diese Suche speichern",
    "searches.nameLabel": "Name f\xFCr diese Suche",
    "searches.confirmSave": "Speichern",
    "searches.cancel": "Abbrechen",
    "searches.noName": "Gib zuerst einen Namen ein. Es wurde nichts gespeichert.",
    "searches.nameTooLong": (p, f) => `Ein Name darf h\xF6chstens ${f.number(p.maximum)} Zeichen haben. Es wurde nichts gespeichert.`,
    "searches.notSearchAddress": "Die Adresse dieser Seite ist keine Suche, die JoyFox speichern kann. Es wurde nichts gespeichert.",
    "searches.full": (p, f) => `Du hast ${f.number(p.maximum)} gespeicherte Suchen, mehr beh\xE4lt JoyFox nicht. L\xF6sche zuerst eine.`,
    "searches.refused": "Das aktive JoyFox-Konto hat sich ge\xE4ndert, deshalb wurde nichts ge\xE4ndert.",
    "searches.saved": (p) => `\u201E${p.name}\u201C gespeichert.`,
    "searches.noMatch": (p) => `\u201E${p.name}\u201C passt nicht mehr zur Suchadresse von JoyClub, deshalb hat JoyFox die Suche nicht ge\xF6ffnet. F\xFChre die Suche noch einmal aus und speichere sie neu.`,
    "searches.running": (p) => `\u201E${p.name}\u201C wird ausgef\xFChrt \u2026`,
    "searches.runningUnnamed": "Die gespeicherte Suche wird ausgef\xFChrt \u2026",
    "searches.shown": (p) => `\u201E${p.name}\u201C wird angezeigt.`,
    "searches.shownUnnamed": "Die gespeicherte Suche wird angezeigt.",
    "searches.runFailed": "JoyFox konnte die gespeicherte Suche nicht ausf\xFChren. \xD6ffne den Filter von JoyClub und klicke auf \u201EAnwenden\u201C.",
    "searches.deleteLabel": (p) => `Gespeicherte Suche ${p.name} l\xF6schen`,
    "searches.confirmDelete": (p) => `Klicke noch einmal auf \u2715, um \u201E${p.name}\u201C zu l\xF6schen.`,
    "searches.deleted": (p) => `\u201E${p.name}\u201C gel\xF6scht.`,
    "picker.toggle": "JoyFox-Vorlagen",
    "picker.loading": "Vorlagen werden geladen \u2026",
    "picker.readFailed": "JoyFox konnte deine Vorlagen nicht laden. Es wurde nichts eingef\xFCgt. Klicke noch einmal auf \u201EJoyFox-Vorlagen\u201C, um es erneut zu versuchen.",
    "picker.empty": "Noch keine Vorlagen. Lege sie in den JoyFox-Einstellungen an.",
    "picker.noAccount": "Kein JoyFox-Konto ist aktiv. W\xE4hle eines in den JoyFox-Einstellungen.",
    "picker.result.inserted": "Vorlage eingef\xFCgt. Pr\xFCfe den Text und klicke dann selbst auf JoyClubs \u201ESenden\u201C.",
    "picker.result.not-editable": "Das Nachrichtenfeld kann gerade nicht bearbeitet werden. Es wurde nichts eingef\xFCgt. Warte, bis du in das Nachrichtenfeld tippen kannst, und versuche es dann noch einmal.",
    "picker.result.too-long": (p, f) => `Mit der Vorlage w\xE4re die Nachricht ${f.plural(p.over, {
      one: "1 Zeichen",
      other: `${f.number(p.over)} Zeichen`
    })} zu lang. Das Nachrichtenfeld fasst h\xF6chstens ${f.number(p.limit)} Zeichen. Es wurde nichts eingef\xFCgt. K\xFCrze deinen Text oder die Vorlage.`,
    "picker.result.altered": "JoyClub hat den Text nach dem Einf\xFCgen ge\xE4ndert. Pr\xFCfe das Nachrichtenfeld, bevor du sendest.",
    "templates.folder.general": "Allgemein",
    "templates.folder.eventConfirmation": "Event-Zusage",
    "templates.folder.eventCancellation": "Event-Absage",
    // Options page: shell and tabs
    "options.title": "JoyFox-Einstellungen",
    "options.intro": "JoyFox speichert alles lokal in diesem Browserprofil. Die Sortierung des Posteingangs bleibt aus, bis du eine Kontaktregel speicherst.",
    "options.tabs.start": "Erste Schritte",
    "options.tabs.accounts": "Konten",
    "options.tabs.rule": "Kontaktregel",
    "options.tabs.templates": "Vorlagen",
    "options.tabs.events": "Events",
    "options.tabs.messages": "Nachrichten",
    "options.tabs.data": "Deine Daten",
    "options.importRegion": "JoyFox-Daten importieren",
    "options.languageSaveFailed": "JoyFox konnte die Sprache nicht speichern. Versuche es noch einmal.",
    // Options page: Get started
    "start.state.done": "Erledigt",
    "start.state.off": "Gespeichert, aber ausgeschaltet",
    "start.state.todo": "Noch nicht erledigt",
    "start.state.doneOpen": "Erledigt: keine Bedingungen, deshalb ist jede Person qualifiziert",
    "start.ready": "JoyFox ist eingerichtet. \xD6ffne deinen JoyClub-Posteingang, um ihn sortiert zu sehen.",
    "start.intro": "Drei Schritte, ein paar Minuten. Alles bleibt in diesem Browser.",
    "start.introAccess": "Vier Schritte, ein paar Minuten. Alles bleibt in diesem Browser.",
    "start.readFailed": "JoyFox konnte seine Einrichtung nicht lesen. Lade die Seite neu, um es noch einmal zu versuchen.",
    "start.step.access": "Erlaube JoyFox den Zugriff auf joyclub.de. Der Zugriff ist gerade aus, deshalb kann JoyFox auf JoyClub nicht arbeiten.",
    "start.step.account": "F\xFCge dein JoyClub-Konto unter [Konten](#accounts) hinzu. JoyFox macht das erste Konto aktiv.",
    "start.step.chooseAccount": "W\xE4hle das aktive Konto unter [Konten](#accounts) aus.",
    "start.step.rule": "Speichere eine Kontaktregel unter [Kontaktregel](#rule). Die Sortierung des Posteingangs bleibt aus, bis eine Regel gespeichert und eingeschaltet ist.",
    "start.step.inbox": "\xD6ffne deinen JoyClub-Posteingang (www.joyclub.de, ClubMail). JoyFox zeigt seine Tabs \xFCber der Liste.",
    // Options page: site access (Get started)
    "access.allow": "Zugriff auf joyclub.de erlauben",
    "access.granted": "Der Zugriff auf joyclub.de ist an. Lade offene JoyClub-Tabs neu, damit JoyFox dort arbeiten kann.",
    "access.refused": "Der Zugriff auf joyclub.de ist weiterhin aus. JoyFox kann auf JoyClub erst arbeiten, wenn du den Zugriff hier oder unter about:addons erlaubst.",
    // Options page: accounts
    "accounts.readFailed": "JoyFox konnte die gespeicherten Konten nicht lesen. Es wurde kein Konto ge\xE4ndert. Lade die Seite neu, um es noch einmal zu versuchen.",
    "accounts.hint": "JoyFox kann nicht lesen, mit welchem JoyClub-Login ein Tab arbeitet. Aktiv ist das Konto, das du hier ausw\xE4hlst. JoyFox speichert deine Notizen, Tags, Regeln, Vorlagen und andere Daten unter diesem Konto.",
    "accounts.activeLabel": "Aktives Konto:",
    "accounts.noneSelected": "Keines ausgew\xE4hlt",
    "accounts.empty": "Noch keine Konten. F\xFCge unten ein Konto hinzu, um JoyFox zu verwenden.",
    "accounts.list": "Gespeicherte Konten",
    "accounts.nameWithIdentifier": (p) => `${p.label} (${p.identifier})`,
    "accounts.active": "Aktiv",
    "accounts.inactive": "Nicht aktiv",
    "accounts.use": "Dieses Konto verwenden",
    "accounts.useLabel": (p) => `Dieses Konto verwenden: ${p.name}`,
    "accounts.nowActive": (p) => `Aktives Konto ist jetzt ${p.name}.`,
    "accounts.rename": "Umbenennen",
    "accounts.renameLabel": (p) => `Umbenennen: Konto ${p.name}`,
    "accounts.renameField": (p) => `Neuer Anzeigename f\xFCr ${p.identifier}`,
    "accounts.renameSave": "Speichern",
    "accounts.renameCancel": "Abbrechen",
    "accounts.renamed": (p) => `Anzeigename gespeichert. JoyFox zeigt dieses Konto jetzt als ${p.name}.`,
    "accounts.remove": "Entfernen",
    "accounts.confirmRemove": "Entfernen best\xE4tigen",
    "accounts.removeLabel": (p) => `Entfernen: Konto ${p.name}`,
    "accounts.confirmRemoveLabel": (p) => `Entfernen best\xE4tigen: Konto ${p.name} und alle seine Daten`,
    "accounts.removePrompt": (p) => `Wenn du ${p.name} entfernst, l\xF6scht JoyFox alles, was es f\xFCr dieses Konto gespeichert hat, zum Beispiel Notizen, Tags, Regeln, Vorlagen, Nachrichten, Event-Notizen und gespeicherte Suchen. Klicke zum Best\xE4tigen noch einmal.`,
    "accounts.removed": (p) => `${p.name} und die gespeicherten Daten wurden entfernt.`,
    "accounts.removedNoneActive": (p) => `${p.name} und die gespeicherten Daten wurden entfernt. Jetzt ist kein Konto aktiv. W\xE4hle eines mit \u201EDieses Konto verwenden\u201C.`,
    "accounts.removedNoneLeft": (p) => `${p.name} und die gespeicherten Daten wurden entfernt. Es gibt keine Konten mehr. F\xFCge ein Konto hinzu, um JoyFox zu verwenden.`,
    "accounts.addForm": "Konto hinzuf\xFCgen",
    "accounts.identifier": "JoyClub-Kontokennung",
    "accounts.identifierHint": "Dein JoyClub-Nickname eignet sich gut. JoyFox verwendet ihn nur, um deine Konten zu unterscheiden und Importe zuzuordnen. JoyFox pr\xFCft ihn nicht. Du kannst ihn sp\xE4ter nicht \xE4ndern.",
    "accounts.label": "Anzeigename (optional)",
    "accounts.labelHint": "Nur JoyFox zeigt diesen Namen. Wenn du ihn leer l\xE4sst, zeigt JoyFox die Kennung.",
    "accounts.add": "Konto hinzuf\xFCgen",
    "accounts.added": (p) => `${p.name} wurde hinzugef\xFCgt.`,
    // Options page: contact rule
    "rule.readFailed": "JoyFox konnte die Kontaktregel nicht lesen. Es wurde keine Regel ge\xE4ndert. Lade die Seite neu, um es noch einmal zu versuchen.",
    "rule.hint": "Die Regel \xE4ndert nur, wie JoyFox deinen eigenen Posteingang in \u201EQualifiziert\u201C, \u201EZu pr\xFCfen\u201C und \u201EJunk\u201C gruppiert. Sie h\xE4lt keine Nachricht auf, l\xF6scht nichts, und die sendende Person sieht nichts davon.",
    "rule.noAccount": "W\xE4hle zuerst ein Konto aus oder f\xFCge eines hinzu. Jedes Konto hat seine eigene Regel.",
    "rule.newer": "Diese Regel wurde mit einer neueren JoyFox-Version erstellt und kann hier nicht bearbeitet werden. L\xF6sche sie, um eine neue anzulegen.",
    "rule.note.saved": "F\xFCr das aktive Konto ist eine Regel gespeichert.",
    "rule.note.none": "F\xFCr das aktive Konto ist keine Regel gespeichert, deshalb sortiert JoyFox den Posteingang nicht.",
    "rule.enabled": "Meinen JoyClub-Posteingang mit dieser Regel sortieren",
    "rule.placementLabel": "Einordnung, wenn die Regel nicht erf\xFCllt ist:",
    "rule.spamHint": "Der Spam-Status ist vorerst unbekannt: JoyFox pr\xFCft Nachrichten noch nicht auf Vorlagen. Nur deine eigenen Korrekturen \u201Ekein Spam\u201C z\xE4hlen. Der Posteingang zeigt nur das Verifizierungssymbol. Fotos, W\xF6rter im Profil und Kontoalter stammen aus Profilen, die du vorher ge\xF6ffnet hast.",
    "rule.autosaveHint": "\xC4nderungen werden automatisch gespeichert: ein K\xE4stchen oder eine Auswahl sofort, eine Zahl oder ein Text, sobald du das Feld verl\xE4sst.",
    "rule.firstMessageHint": "\u201EErste Nachricht enth\xE4lt\u201C liest die Nachrichtenvorschau in deinem Posteingang und beachtet keine Gro\xDF- und Kleinschreibung. Der Posteingang zeigt nur die neueste Nachricht. Wenn eine Person mehr als eine Nachricht gesendet hat, ist die Vorschau deshalb vielleicht nicht die erste. Wenn die Vorschau deinen Text nicht enth\xE4lt, z\xE4hlt die Bedingung nach deiner Wahl unter \u201EWenn JoyFox das nicht sehen kann\u201C. Sobald JoyFox deinen Text sieht, bleibt die Bedingung erf\xFCllt.",
    "rule.preset.label": "Mit einer Vorgabe beginnen",
    "rule.preset.choose": "Vorgabe w\xE4hlen \u2026",
    "rule.preset.apply": "Vorgabe \xFCbernehmen",
    "rule.preset.confirm": "Bedingungen ersetzen",
    "rule.preset.confirmPrompt": "Die Vorgabe ersetzt alle Bedingungen unten. Klicke zur Best\xE4tigung auf \u201EBedingungen ersetzen\u201C.",
    "rule.preset.hint": "Eine Vorgabe setzt die Bedingungen unten und speichert sie. Danach kannst du sie wie jede andere Regel \xE4ndern.",
    "rule.preset.open": "Offen",
    "rule.preset.complete": "Nur vollst\xE4ndige Profile",
    "rule.preset.verified": "Verifizierte Mitglieder",
    "rule.preset.highTrust": "Mitglieder mit hohem Vertrauen",
    "rule.preset.custom": "Eigene",
    "rule.preset.describe.open": "Keine Bedingungen: Jede Person ist qualifiziert.",
    "rule.preset.describe.complete": (p, f) => `Eine Person braucht mindestens ${f.number(p.photos)} Fotos und mindestens ${f.number(p.words)} W\xF6rter im Profil.`,
    "rule.preset.describe.verified": "Eine Person muss von JoyClub verifiziert sein.",
    "rule.preset.describe.highTrust": (p, f) => `Eine Person muss von JoyClub verifiziert sein und braucht mindestens ${f.number(p.photos)} Fotos, mindestens ${f.number(p.words)} W\xF6rter im Profil und ein Konto, das mindestens ${f.number(p.days)} Tage alt ist.`,
    "rule.preset.describe.custom": "Entfernt alle Bedingungen, damit du die gew\xFCnschten ankreuzen kannst.",
    "rule.preset.applied": (p) => `Vorgabe \u201E${p.preset}\u201C \xFCbernommen und gespeichert. Du kannst ihre Bedingungen unten \xE4ndern.`,
    "rule.preset.appliedOpen": "Vorgabe \u201EOffen\u201C \xFCbernommen und gespeichert. Die Regel hat keine Bedingungen, deshalb ist jede Person qualifiziert.",
    "rule.preset.appliedCustom": "Alle Bedingungen entfernt und gespeichert. Kreuze die gew\xFCnschten Bedingungen an. Bis dahin ist jede Person qualifiziert.",
    "rule.editor": "Editor:",
    "rule.simple": "Einfach",
    "rule.advanced": "Erweitert",
    "rule.match.all": "ALLEN",
    "rule.match.any": "MINDESTENS EINER",
    "rule.box.all": "Eine Person ist qualifiziert, wenn ALLE diese Bedingungen erf\xFCllt sind",
    "rule.box.any": "Oder eine Person ist qualifiziert, wenn MINDESTENS EINE dieser Bedingungen erf\xFCllt ist",
    "rule.unknown.needs-review": "In \u201EZu pr\xFCfen\u201C einordnen",
    "rule.unknown.met": "Als erf\xFCllt z\xE4hlen",
    "rule.unknown.not-met": "Als nicht erf\xFCllt z\xE4hlen",
    "rule.unknownPrompt": "Wenn JoyFox das nicht sehen kann:",
    "rule.unknownLabel": (p) => `${p.condition}: wenn JoyFox das nicht sehen kann`,
    "rule.valueLabel": (p) => `${p.condition}: Wert`,
    "rule.numberProblem": (p, f) => `Gib f\xFCr \u201E${p.condition}\u201C eine ganze Zahl von ${f.number(p.minimum)} bis ${f.number(p.maximum)} ein.`,
    "rule.textPlaceholder": "Wort, Formulierung oder Emoji",
    "rule.textLabel": (p) => `${p.condition}: Wort, Formulierung oder Emoji`,
    "rule.textProblem": (p, f) => `Gib f\xFCr \u201E${p.condition}\u201C ein Wort, eine Formulierung oder ein Emoji mit h\xF6chstens ${f.number(p.maximum)} Zeichen ein.`,
    "rule.fieldNumberProblem": (p, f) => `Gib eine ganze Zahl von ${f.number(p.minimum)} bis ${f.number(p.maximum)} ein.`,
    "rule.fieldTextProblem": (p, f) => `Gib ein Wort, eine Formulierung oder ein Emoji mit h\xF6chstens ${f.number(p.maximum)} Zeichen ein.`,
    "rule.textHint": "Gib ein Wort, eine Formulierung oder ein Emoji ein, um diese Bedingung zu verwenden.",
    "rule.spamNote": "(noch nicht gepr\xFCft: immer unbekannt)",
    "rule.combine.label": "Wie die Gruppen verkn\xFCpft werden",
    "rule.combine.prefix": "Eine Person ist qualifiziert bei ",
    "rule.combine.suffix": " dieser Gruppen.",
    "rule.advancedHint": "Jede Gruppe ist erf\xFCllt bei ALLEN oder MINDESTENS EINER ihrer Bedingungen, wie du es w\xE4hlst. Setze ein H\xE4kchen bei \u201Enicht\u201C, um eine Bedingung umzukehren: \u201Enicht Mindestanzahl Fotos 3\u201C bedeutet weniger als 3 Fotos. Eine Gruppe ohne Bedingungen wird nicht gespeichert.",
    "rule.addRule": "+ Gruppe hinzuf\xFCgen",
    "rule.removeRule": "Gruppe entfernen",
    "rule.confirmRemoveGroup": "Entfernen best\xE4tigen",
    "rule.confirmRemoveGroupLabel": (p, f) => `Entfernen best\xE4tigen: Gruppe ${f.number(p.number)}`,
    "rule.removeGroupPrompt": (p, f) => `Klicke noch einmal, um Gruppe ${f.number(p.number)} und ihre Bedingungen zu entfernen.`,
    "rule.ruleSuffix": " dieser Bedingungen",
    "rule.noConditions": "Noch keine Bedingungen. F\xFCge unten eine hinzu.",
    "rule.removeCondition": "Bedingung entfernen",
    "rule.removeConditionLabel": (p) => `${p.condition} entfernen`,
    "rule.not": "nicht",
    "rule.notTitle": "Diese Bedingung umkehren",
    "rule.notLabel": (p) => `nicht: \u201E${p.condition}\u201C umkehren`,
    "rule.joiner.all": "UND",
    "rule.joiner.any": "ODER",
    "rule.ruleTitle": (p, f) => `Gruppe ${f.number(p.number)}: erf\xFCllt bei `,
    "rule.ruleMatchLabel": (p, f) => `Wie Gruppe ${f.number(p.number)} ihre Bedingungen verkn\xFCpft`,
    "rule.removeRuleLabel": (p, f) => `Gruppe entfernen: Nr. ${f.number(p.number)}`,
    "rule.addConditionLabel": (p, f) => `Bedingung zu Gruppe ${f.number(p.number)} hinzuf\xFCgen`,
    "rule.addCondition": "+ Bedingung hinzuf\xFCgen \u2026",
    "rule.ruleCount": (p, f) => `${f.number(p.count)} von ${f.number(p.maximum)} Gruppen`,
    "rule.simpleUnavailable.all": "Die einfache Ansicht ist nicht verf\xFCgbar: Die Gruppen sind mit ALLEN verkn\xFCpft.",
    "rule.simpleUnavailable.not": "Die einfache Ansicht ist nicht verf\xFCgbar: Die Regel verwendet \u201Enicht\u201C.",
    "rule.simpleUnavailable.severalAll": "Die einfache Ansicht ist nicht verf\xFCgbar: Mehr als eine Gruppe verlangt ALLE von mehreren Bedingungen.",
    "rule.simpleUnavailable.duplicate": "Die einfache Ansicht ist nicht verf\xFCgbar: Eine Bedingung steht in mehr als einer Gruppe.",
    "rule.savedNoConditions": "Regel gespeichert. Sie hat noch keine Bedingungen, deshalb ist jede Person qualifiziert.",
    "rule.savedVacuous": "Regel gespeichert. Ohne Eintr\xE4ge im ALLE-Kasten ist jede Person qualifiziert, deshalb wirkt der MINDESTENS-EINE-Kasten nicht.",
    "rule.saved": "Regel gespeichert. Offene JoyClub-Tabs werden sofort aktualisiert.",
    "rule.notSaved": (p) => `${p.problem} Die Regel wurde nicht gespeichert.`,
    "rule.saveFailed": "JoyFox konnte die Regel nicht speichern. Es wurde nichts ge\xE4ndert. \xC4ndere das Feld noch einmal, oder lade die Seite neu, um die gespeicherte Regel zu sehen.",
    "rule.deleteAll": "Ganze Kontaktregel l\xF6schen",
    "rule.confirmDeleteAll": "L\xF6schen best\xE4tigen",
    "rule.deletePrompt": "Klicke noch einmal, um die ganze Kontaktregel zu l\xF6schen. JoyFox sortiert den Posteingang f\xFCr dieses Konto dann nicht mehr.",
    "rule.removed": "Kontaktregel gel\xF6scht. JoyFox sortiert den Posteingang f\xFCr dieses Konto nicht mehr.",
    "rule.removeFailed": "JoyFox konnte die Regel nicht l\xF6schen. Es wurde nichts ge\xE4ndert. Versuche es noch einmal. Wenn es weiter nicht klappt, lade die Seite neu.",
    "rule.stale.account.saved": "Das aktive Konto hat sich ge\xE4ndert, deshalb wurde die Regel nicht gespeichert. Pr\xFCfe im Tab \u201EKonten\u201C das aktive Konto, bevor du die Regel noch einmal \xE4nderst.",
    "rule.stale.account.removed": "Das aktive Konto hat sich ge\xE4ndert, deshalb wurde die Regel nicht gel\xF6scht. Pr\xFCfe im Tab \u201EKonten\u201C das aktive Konto, bevor du noch einmal eine Regel l\xF6schst.",
    "rule.stale.rule.saved": "Die Regel wurde in einem anderen Tab ge\xE4ndert. Sie wurde nicht gespeichert. Das Formular zeigt jetzt die gespeicherte Regel.",
    "rule.stale.rule.removed": "Die Regel wurde in einem anderen Tab ge\xE4ndert. Sie wurde nicht gel\xF6scht. Das Formular zeigt jetzt die gespeicherte Regel.",
    "rule.changedElsewhere": "Die Regel wurde in einem anderen Tab ge\xE4ndert. Das Formular zeigt jetzt die gespeicherte Regel.",
    // Options page: templates
    "templates.readFailed": "JoyFox konnte deine Vorlagen nicht lesen. Es wurde keine Vorlage ge\xE4ndert. Lade die Seite neu, um es noch einmal zu versuchen.",
    "templates.heading": "Nachrichtenvorlagen",
    "templates.hint": "In einer JoyClub-Unterhaltung f\xFCgt die Schaltfl\xE4che \u201EJoyFox-Vorlagen\u201C unter dem Nachrichtenfeld eine Vorlage an der Cursorposition ein. Du kannst den Text danach noch \xE4ndern, und du klickst JoyClubs \u201ESenden\u201C immer selbst. JoyFox sendet nie eine Nachricht.",
    "templates.noAccount": "W\xE4hle unter [Konten](#accounts) ein aktives Konto, um Vorlagen zu speichern.",
    "templates.empty": "Noch keine Vorlagen. F\xFCge unten eine hinzu.",
    "templates.inFolder": (p) => `Vorlagen in ${p.folder}`,
    "templates.edit": "Bearbeiten",
    "templates.editLabel": (p) => `Bearbeiten: Vorlage ${p.name}`,
    "templates.editing": (p) => `Du bearbeitest ${p.name}.`,
    "templates.delete": "L\xF6schen",
    "templates.confirmDelete": "L\xF6schen best\xE4tigen",
    "templates.deleteLabel": (p) => `L\xF6schen: Vorlage ${p.name}`,
    "templates.confirmDeleteLabel": (p) => `L\xF6schen best\xE4tigen: Vorlage ${p.name}`,
    "templates.deletePrompt": (p) => `Klicke auf \u201EL\xF6schen best\xE4tigen\u201C, um ${p.name} zu l\xF6schen.`,
    "templates.deleted": (p) => `${p.name} wurde gel\xF6scht.`,
    "templates.addForm": "Vorlage hinzuf\xFCgen",
    "templates.name": "Name",
    "templates.folder": "Ordner (optional, leer bedeutet Allgemein)",
    "templates.text": "Text",
    "templates.saveChanges": "\xC4nderungen speichern",
    "templates.add": "Vorlage hinzuf\xFCgen",
    "templates.cancel": "Bearbeiten abbrechen",
    "templates.saved": (p) => `${p.name} wurde gespeichert.`,
    "templates.added": (p) => `${p.name} wurde hinzugef\xFCgt.`,
    "templates.accountChanged": "Das aktive Konto hat sich ge\xE4ndert, deshalb wurde nichts ge\xE4ndert. Pr\xFCfe im Tab \u201EKonten\u201C das aktive Konto, bevor du es noch einmal versuchst.",
    // Options page: your data
    "entity.extensionAccounts": "Kontodatensatz",
    "entity.joyClubMembers": "Mitglieder",
    "entity.profileSnapshots": "Profil-Momentaufnahmen",
    "entity.userNotes": "Notizen",
    "entity.userTags": "Tags",
    "entity.trustSignals": "Erfasste Erfahrungen",
    "entity.contactRules": "Kontaktregeln",
    "entity.conversationClassifications": "Eigene Einordnungen",
    "entity.savedSearches": "Gespeicherte Suchen",
    "entity.eventMetadata": "Event-Notizen",
    "entity.spendLogEntries": "Ausgabenprotokoll",
    "entity.syncConfigs": "Sync-Einstellungen",
    "entity.extensionPreferences": "Einstellungen",
    "entity.messageTemplates": "Nachrichtenvorlagen",
    "entity.spamPhrases": "Spam-Formulierungen",
    "entity.messageObservations": "Zwischengespeicherte Nachrichtentexte (normalisiert)",
    "entity.senderSpamOverrides": "Korrekturen \u201Ekein Spam\u201C",
    "entity.actionLogs": "Aktionsprotokoll",
    "entity.messagePhraseMatches": "Gefundene Formulierungen in Nachrichten",
    "entity.cachedMessages": "Gespeicherte Nachrichten (f\xFCr die Suche)",
    "data.readFailed": "JoyFox konnte die gespeicherten Daten nicht lesen. Es wurde nichts ge\xE4ndert. Lade die Seite neu, um es noch einmal zu versuchen.",
    "data.hint": "Alles, was JoyFox speichert, bleibt in diesem Browserprofil. Hier kannst du es ansehen, als JSON-Datei speichern und l\xF6schen. L\xF6schen hier \xE4ndert nie etwas auf JoyClub.",
    "data.importPointer": "Eine Datei importierst du unter [Konten](#accounts).",
    "data.noAccounts": "Noch keine Konten.",
    "data.accountPicker": "Konto zum Ansehen (\xE4ndert das aktive Konto nicht)",
    "data.caption": "Gespeicherte Datens\xE4tze dieses Kontos",
    "data.col.type": "Datentyp",
    "data.col.records": "Datens\xE4tze",
    "data.col.actions": "Aktionen",
    "data.show": "Zeigen",
    "data.hide": "Ausblenden",
    "data.showLabel": (p) => `Zeigen: ${p.label}`,
    "data.hideLabel": (p) => `Ausblenden: ${p.label}`,
    "data.deleteAll": "Alle l\xF6schen",
    "data.deleteAllLabel": (p) => `Alle l\xF6schen: ${p.label}`,
    "data.deleteAllPrompt": (p, f) => `Klicke auf \u201EBest\xE4tigen\u201C, um alle ${f.number(p.count)} Datens\xE4tze \u201E${p.label}\u201C dieses Kontos zu l\xF6schen.`,
    "data.deletedAll": (p) => `Alle Datens\xE4tze \u201E${p.label}\u201C dieses Kontos wurden gel\xF6scht.`,
    "data.recordsTitle": (p, f) => `${p.label} (${f.number(p.count)})`,
    "data.accountRecordHint": "Der Kontodatensatz wird nur mit dem ganzen Konto entfernt, unter [Konten](#accounts).",
    "data.recordSummary": (p) => `${p.id} (ge\xE4ndert: ${p.updated})`,
    "data.recordSummaryNamed": (p) => `${p.name}: ${p.id} (ge\xE4ndert: ${p.updated})`,
    "data.recordNamed": (p) => `${p.name} (${p.id})`,
    "data.valueYes": "ja",
    "data.valueNo": "nein",
    "data.valueEmpty": "(leer)",
    "data.rawJson": "Gespeichertes JSON",
    "data.moreCharacters": (p, f) => `\u2026und ${f.number(p.count)} weitere Zeichen (siehe \u201EGespeichertes JSON\u201C)`,
    "data.moreValues": (p, f) => `\u2026und ${f.number(p.count)} weitere (siehe \u201EGespeichertes JSON\u201C)`,
    "data.delete": "L\xF6schen",
    "data.deleteRecordLabel": (p) => `L\xF6schen: Datensatz ${p.record}`,
    "data.deleteRecordPrompt": (p) => `Klicke auf \u201EBest\xE4tigen\u201C, um den Datensatz ${p.record} zu l\xF6schen.`,
    "data.deletedRecord": (p) => `Datensatz ${p.record} wurde gel\xF6scht.`,
    "data.showMore": (p, f) => `${f.number(p.count)} weitere zeigen`,
    "data.exportAccount": "Dieses Konto exportieren (JSON)",
    "data.exportedAccount": "Der Export dieses Kontos wurde erstellt.",
    "data.deleteAccountData": "Daten dieses Kontos l\xF6schen",
    "data.deleteAccountDataLabel": "Daten dieses Kontos l\xF6schen (alle Datens\xE4tze)",
    "data.deleteAccountDataPrompt": "Klicke auf \u201EBest\xE4tigen\u201C, um alle Datens\xE4tze dieses Kontos zu l\xF6schen. Das Konto selbst bleibt unter \u201EKonten\u201C.",
    "data.deletedAccountData": "Alle Daten dieses Kontos wurden gel\xF6scht. Das Konto selbst bleibt erhalten.",
    "data.allAccounts": "Alle Konten",
    "data.retentionLabel": "Gespeicherte Profil-Momentaufnahmen je Mitglied",
    "data.retentionHint": (p, f) => `JoyFox beh\xE4lt die neuesten Momentaufnahmen der Profilangaben jedes Mitglieds, immer mindestens die letzte. Eine kleinere Zahl l\xF6scht \xE4ltere Momentaufnahmen sofort, in allen Konten. Von ${f.number(p.minimum)} bis ${f.number(p.maximum)}; Standard ist ${f.number(p.default)}. Klicke auf \u201ESpeichern\u201C, um die Zahl zu \xFCbernehmen.`,
    "data.retentionSave": "Speichern",
    "data.retentionConfirm": "Speichern und l\xF6schen",
    "data.retentionConfirmPrompt": (p, f) => `Eine kleinere Zahl l\xF6scht \xE4ltere Momentaufnahmen sofort, in allen Konten: F\xFCr jedes Mitglied bleibt nur ${f.plural(
      p.keep,
      {
        one: "die neueste Momentaufnahme",
        other: `die neuesten ${f.number(p.keep)} Momentaufnahmen`
      }
    )}. Klicke zum Best\xE4tigen auf \u201ESpeichern und l\xF6schen\u201C.`,
    "data.retentionSaved": (p, f) => p.deleted === 0 ? "Gespeichert. Keine Momentaufnahme musste gel\xF6scht werden." : `Gespeichert. ${f.plural(p.deleted, {
      one: "1 \xE4ltere Momentaufnahme wurde",
      other: `${f.number(p.deleted)} \xE4ltere Momentaufnahmen wurden`
    })} gel\xF6scht.`,
    "data.retentionInvalid": (p, f) => `Gib eine ganze Zahl von ${f.number(p.minimum)} bis ${f.number(p.maximum)} ein. Es wurde nichts ge\xE4ndert.`,
    "data.retentionFailed": "JoyFox konnte die Einstellung nicht speichern. Das Feld zeigt die Zahl, die jetzt gilt. Versuche es noch einmal.",
    "data.reminderLabel": "An den Export aller Daten erinnern nach (Tagen)",
    "data.reminderHint": (p, f) => `JoyFox-Daten bleiben in diesem Browserprofil, auch wenn du den Browser schlie\xDFt. Wenn du JoyFox entfernst oder das Profil verlierst, sind die Daten weg. Ein vollst\xE4ndiger Export ist deine Sicherung. Diese Seite bittet um einen, wenn der letzte vollst\xE4ndige Export \xE4lter als diese Zahl von Tagen ist. 0 schaltet die Erinnerung aus. Von ${f.number(p.minimum)} bis ${f.number(p.maximum)}; Standard ist ${f.number(p.default)}. Klicke auf \u201ESpeichern\u201C, um die Zahl zu \xFCbernehmen.`,
    "data.reminderSave": "Speichern",
    "data.reminderSaved": (p, f) => p.days === 0 ? "Gespeichert. Die Export-Erinnerung ist aus." : `Gespeichert. JoyFox erinnert dich ${f.plural(p.days, {
      one: "1 Tag",
      other: `${f.number(p.days)} Tage`
    })} nach dem letzten vollst\xE4ndigen Export.`,
    "data.reminderInvalid": (p, f) => `Gib eine ganze Zahl von ${f.number(p.minimum)} bis ${f.number(p.maximum)} ein. Es wurde nichts ge\xE4ndert.`,
    "data.reminderNever": "Du hast noch nicht alle JoyFox-Daten exportiert. Wenn du JoyFox entfernst oder dieses Browserprofil verlierst, sind die Daten weg. Klicke auf \u201EAlle JoyFox-Daten exportieren (JSON)\u201C, um eine Sicherung zu speichern.",
    "data.reminderDue": (p, f) => `Dein letzter vollst\xE4ndiger Export war ${f.plural(p.days, {
      one: "vor 1 Tag",
      other: `vor ${f.number(p.days)} Tagen`
    })}. Wenn du JoyFox entfernst oder dieses Browserprofil verlierst, sind neuere Daten weg. Klicke auf \u201EAlle JoyFox-Daten exportieren (JSON)\u201C, um eine Sicherung zu speichern.`,
    "data.lastExport": (p, f) => p.days === 0 ? "Letzter vollst\xE4ndiger Export: heute." : `Letzter vollst\xE4ndiger Export: ${f.plural(p.days, {
      one: "vor 1 Tag",
      other: `vor ${f.number(p.days)} Tagen`
    })}.`,
    "data.exportAll": "Alle JoyFox-Daten exportieren (JSON)",
    "data.exportedAll": "Der Export aller JoyFox-Daten wurde erstellt.",
    "data.deleteEverything": "Alle JoyFox-Daten l\xF6schen",
    "data.deleteEverythingLabel": "Alle JoyFox-Daten l\xF6schen (in diesem Browser)",
    "data.deleteEverythingPrompt": "Klicke auf \u201EBest\xE4tigen\u201C, um alle Konten, alle Datens\xE4tze und alle JoyFox-Einstellungen in diesem Browser zu l\xF6schen. Das kann nicht r\xFCckg\xE4ngig gemacht werden.",
    "data.deletedEverything": "Alle JoyFox-Daten in diesem Browser wurden gel\xF6scht.",
    "data.confirm": "Best\xE4tigen",
    "data.confirmLabel": (p) => `Best\xE4tigen: ${p.label}`,
    "data.actionFailed": "JoyFox konnte das L\xF6schen nicht abschlie\xDFen. Einige Datens\xE4tze sind vielleicht schon gel\xF6scht: Die angezeigten Zahlen zeigen, was noch gespeichert ist. Versuche es noch einmal.",
    "data.exportFailed": "JoyFox konnte den Export nicht erstellen. Es wurde nichts exportiert. Versuche es noch einmal.",
    "data.import.title": "Importieren",
    "data.import.hint": "Importiere eine JoyFox-Exportdatei: alles oder ein Konto. Sie wird mit dem zusammengef\xFChrt, was hier gespeichert ist. Ein Konto mit derselben JoyClub-Kennung wird mit dem vorhandenen Konto zusammengef\xFChrt. Bei derselben Notiz, Regel oder Einordnung gewinnt die neuere Version. Vorhandene Tags und Korrekturen bleiben erhalten. Der Import beginnt, sobald du die Datei w\xE4hlst, und danach siehst du, was sich ge\xE4ndert hat.",
    "data.import.fileLabel": "JoyFox-Exportdatei (JSON)",
    "data.import.summary.all": (p, f) => `Dieser vollst\xE4ndige Export enth\xE4lt ${f.plural(p.total, {
      one: "1 Konto",
      other: `${f.number(p.total)} Konten`
    })}: ${f.number(p.matched)} mit einem vorhandenen Konto zusammengef\xFChrt, ${f.number(p.added)} neu hinzugef\xFCgt.`,
    "data.import.summary.account": (p, f) => `Dieser Export eines einzelnen Kontos enth\xE4lt ${f.plural(p.total, {
      one: "1 Konto",
      other: `${f.number(p.total)} Konten`
    })}: ${f.number(p.matched)} mit einem vorhandenen Konto zusammengef\xFChrt, ${f.number(p.added)} neu hinzugef\xFCgt.`,
    "data.import.caption": "Was der Import ge\xE4ndert hat",
    "data.import.col.added": "Hinzugef\xFCgt",
    "data.import.col.replaced": "Ersetzt (neuer)",
    "data.import.col.kept": "Behalten",
    "data.import.col.duplicates": "\xDCbersprungene Duplikate",
    "data.import.noRecords": "Die Datei enth\xE4lt keine Datens\xE4tze.",
    "data.setting.activeAccount": "aktives Konto",
    "data.setting.language": "Sprache",
    "data.setting.messageCaching": "Nachrichten speichern",
    "data.setting.messageRetention": "Nachrichten behalten f\xFCr",
    "data.setting.quickIgnoreDelete": "Schaltfl\xE4che \u201EIgnorieren und l\xF6schen\u201C",
    "data.setting.stripCollapsed": "JoyFox-Leiste eingeklappt",
    "data.setting.templatePicker": "Vorlagenauswahl",
    "data.setting.sharedEventException": "Ausnahme f\xFCr gemeinsame Events",
    "data.setting.snapshotRetention": "Momentaufnahmen je Mitglied",
    "data.setting.exportReminder": "Export-Erinnerung",
    "data.setting.diagnostics": "Diagnose",
    "data.import.settingsUnknown": "Die Datei enth\xE4lt au\xDFerdem Einstellungen, die diese JoyFox-Version nicht kennt. Sie wurden nicht importiert.",
    "data.import.settingsSkipped": (p) => `Einstellungen in der Datei, die nie importiert werden (sie schalten Funktionen ein): ${p.keys}.`,
    "data.import.settingsNotSaved": (p) => `Einstellungen, die nicht gespeichert werden konnten: ${p.keys}.`,
    "data.import.settingsAdded": (p) => `Hinzugef\xFCgte Einstellungen (nur solche, die hier nicht gesetzt waren): ${p.keys}.`,
    "data.import.running": "Die Datei wird importiert.",
    "data.import.nothing": "Alles in dieser Datei ist schon gespeichert. Es wurde nichts ge\xE4ndert.",
    "data.import.complete": (p, f) => `Import abgeschlossen: ${f.number(p.added)} Datens\xE4tze hinzugef\xFCgt, ${f.number(p.replaced)} durch eine neuere Version ersetzt.`,
    "data.import.completeSettingsFailed": (p, f) => `Import abgeschlossen: ${f.number(p.added)} Datens\xE4tze hinzugef\xFCgt, ${f.number(p.replaced)} durch eine neuere Version ersetzt. Einige Einstellungen konnten nicht gespeichert werden (siehe oben). Stelle sie selbst noch einmal ein.`,
    "data.import.incomplete": "JoyFox konnte den Import nicht abschlie\xDFen. W\xE4hle die Datei noch einmal, um es erneut zu versuchen: Bereits gespeicherte Datens\xE4tze werden nicht doppelt hinzugef\xFCgt.",
    "data.import.unreadable": "JoyFox konnte diese Datei nicht pr\xFCfen. Es wurde nichts importiert. W\xE4hle die Datei noch einmal. Wenn es weiter nicht klappt, lade die Seite neu oder exportiere die Datei noch einmal aus JoyFox.",
    // Errors the UI shows
    "error.withSuffix.nothingChanged": (p) => `${p.error}. Es wurde nichts ge\xE4ndert.`,
    "error.withSuffix.nothingImported": (p) => `${p.error}. Es wurde nichts importiert.`,
    "error.withSuffix.nothingDeleted": (p) => `${p.error}. Es wurde nichts gel\xF6scht.`,
    "error.withSuffix.nothingExported": (p) => `${p.error}. Es wurde nichts exportiert. Versuche es noch einmal.`,
    "error.withSuffix.settingNotChanged": (p) => `${p.error}. Die Einstellung wurde nicht ge\xE4ndert. Versuche es noch einmal.`,
    "error.account.emptyIdentifier": "Gib zuerst die Kennung deines JoyClub-Kontos ein",
    "error.account.duplicate": "Ein Konto mit dieser Kennung ist schon in der Liste. Verwende dieses Konto oder gib eine andere Kennung ein",
    "error.account.notRegistered": "Dieses Konto ist nicht mehr in der Liste, zum Beispiel weil es in einem anderen Tab entfernt wurde",
    "error.account.gone": "Dieses Konto gibt es nicht mehr",
    "error.account.changed": "Das aktive Konto hat sich ge\xE4ndert",
    "error.template.noName": "Eine Vorlage braucht einen Namen",
    "error.template.nameTooLong": (p, f) => `Der Name einer Vorlage darf h\xF6chstens ${f.number(p.maximum)} Zeichen haben`,
    "error.template.folderTooLong": (p, f) => `Der Name eines Ordners darf h\xF6chstens ${f.number(p.maximum)} Zeichen haben`,
    "error.template.noText": "Eine Vorlage braucht Text",
    "error.template.tooLong": (p, f) => `Eine Vorlage darf h\xF6chstens ${f.number(p.maximum)} Zeichen haben`,
    "error.template.deleted": "Diese Vorlage wurde inzwischen gel\xF6scht",
    "error.data.changedDuringCheck": "Die gespeicherten Daten haben sich ge\xE4ndert, w\xE4hrend JoyFox die Datei gepr\xFCft hat. W\xE4hle die Datei noch einmal",
    "error.data.unknownType": "Unbekannter Datentyp",
    "error.data.accountRecord": "Der Kontodatensatz wird nur mit dem ganzen Konto entfernt",
    "error.import.tooLarge": "Die Datei ist zu gro\xDF f\xFCr einen JoyFox-Export. W\xE4hle eine Datei, die JoyFox exportiert hat",
    "error.import.notJson": "Die Datei ist kein JoyFox-Export. W\xE4hle eine Datei, die JoyFox exportiert hat",
    "error.import.notExport": "Die Datei ist kein JoyFox-Export. W\xE4hle eine Datei, die JoyFox exportiert hat",
    "error.import.noVersion": "Die Datei sagt nicht, welche JoyFox-Version sie erstellt hat. W\xE4hle eine Datei, die JoyFox exportiert hat",
    "error.import.newerVersion": "Die Datei stammt aus einer neueren JoyFox-Version. Aktualisiere zuerst JoyFox",
    "error.import.noScope": "Die Datei sagt nicht, ob sie ein Konto oder alle Daten enth\xE4lt. W\xE4hle eine Datei, die JoyFox exportiert hat",
    "error.import.noAccountNamed": "Die Datei ist der Export eines Kontos, nennt das Konto aber nicht. W\xE4hle eine Datei, die JoyFox exportiert hat",
    "error.import.unknownType": "Die Datei enth\xE4lt eine Art von Daten, die JoyFox nicht kennt. W\xE4hle eine Datei, die JoyFox exportiert hat",
    "error.import.notList": (p) => `Der Teil \u201E${p.entity}\u201C der Datei ist besch\xE4digt. W\xE4hle eine Datei, die JoyFox exportiert hat`,
    "error.import.notRecord": (p, f) => `Eintrag ${f.number(p.index)} in \u201E${p.entity}\u201C ist besch\xE4digt. W\xE4hle eine Datei, die JoyFox exportiert hat`,
    "error.import.forbiddenKey": (p, f) => `Eintrag ${f.number(p.index)} in \u201E${p.entity}\u201C enth\xE4lt einen Feldnamen, den JoyFox nicht erlaubt. W\xE4hle eine Datei, die JoyFox exportiert hat`,
    "error.import.unknownField": (p, f) => `Eintrag ${f.number(p.index)} in \u201E${p.entity}\u201C enth\xE4lt ein Feld, das JoyFox nicht kennt. W\xE4hle eine Datei, die JoyFox exportiert hat`,
    "error.import.tooLong": (p, f) => `Eintrag ${f.number(p.index)} in \u201E${p.entity}\u201C enth\xE4lt einen Text mit mehr als ${f.number(p.maximum)} Zeichen. W\xE4hle eine Datei, die JoyFox exportiert hat`,
    "error.import.invalid": (p, f) => `Eintrag ${f.number(p.index)} in \u201E${p.entity}\u201C ist besch\xE4digt. W\xE4hle eine Datei, die JoyFox exportiert hat`,
    "error.import.future": (p, f) => `Eintrag ${f.number(p.index)} in \u201E${p.entity}\u201C hat ein Datum in der Zukunft. Pr\xFCfe die Uhr des Computers, der die Datei erstellt hat`,
    "error.import.otherAccount": (p, f) => `Eintrag ${f.number(p.index)} in \u201E${p.entity}\u201C geh\xF6rt zu einem anderen Konto. W\xE4hle eine Datei, die JoyFox exportiert hat`,
    "error.import.notOwnScope": (p, f) => `Kontodatensatz ${f.number(p.index)} ist besch\xE4digt. W\xE4hle eine Datei, die JoyFox exportiert hat`,
    "error.import.twice": (p, f) => `Eintrag ${f.number(p.index)} in \u201E${p.entity}\u201C kommt in der Datei zweimal vor. W\xE4hle eine Datei, die JoyFox exportiert hat`,
    "error.import.sameIdentifier": "Zwei Konten in der Datei haben dieselbe Kennung. W\xE4hle eine Datei, die JoyFox exportiert hat",
    "error.import.noAccountRecord": "Die Datei ist der Export eines Kontos, enth\xE4lt dieses Konto aber nicht. W\xE4hle eine Datei, die JoyFox exportiert hat",
    "error.import.settingsInvalid": "Die Einstellungen in der Datei sind besch\xE4digt. W\xE4hle eine Datei, die JoyFox exportiert hat",
    "error.import.settingsForbidden": "Die Einstellungen in der Datei enthalten einen Namen, den JoyFox nicht erlaubt. W\xE4hle eine Datei, die JoyFox exportiert hat",
    "error.import.unknownSetting": "Die Datei enth\xE4lt eine Einstellung, die JoyFox nicht verwendet. W\xE4hle eine Datei, die JoyFox exportiert hat",
    "error.import.orphans": "Einige Datens\xE4tze in der Datei geh\xF6ren zu einem Konto, das die Datei nicht enth\xE4lt. W\xE4hle eine Datei, die JoyFox exportiert hat",
    "error.import.sameRecordTwice": "Zwei Datens\xE4tze in der Datei w\xFCrden hier zum selben Datensatz. W\xE4hle eine Datei, die JoyFox exportiert hat"
  };

  // src/i18n/translator.ts
  var CATALOGS = { en, de };
  var TAGS = { en: "en-US", de: "de-DE" };
  var locale = "en";
  var listeners = /* @__PURE__ */ new Set();
  function setLocale(next) {
    if (next === locale) return;
    locale = next;
    for (const listener of Array.from(listeners)) listener(next);
  }
  function onLocaleChange(listener) {
    listeners.add(listener);
    return () => listeners.delete(listener);
  }
  var numberFormats = /* @__PURE__ */ new Map();
  var dateFormats = /* @__PURE__ */ new Map();
  var pluralRules = /* @__PURE__ */ new Map();
  var wallDateFormats = /* @__PURE__ */ new Map();
  var wallDateTimeFormats = /* @__PURE__ */ new Map();
  function cached(map, make) {
    let value = map.get(locale);
    if (!value) {
      value = make(TAGS[locale]);
      map.set(locale, value);
    }
    return value;
  }
  function formatNumber(value) {
    return cached(numberFormats, (tag) => new Intl.NumberFormat(tag)).format(
      value
    );
  }
  function formatDate(iso) {
    const time = Date.parse(iso);
    if (!Number.isFinite(time)) return iso;
    return cached(
      dateFormats,
      (tag) => new Intl.DateTimeFormat(tag, { dateStyle: "medium", timeZone: "UTC" })
    ).format(time);
  }
  function formatWallTime(local) {
    const parts = /^(\d{4})-(\d{2})-(\d{2})(?:T(\d{2}):(\d{2}))?$/u.exec(local);
    if (!parts) return local;
    const [, year, month, day, hour, minute] = parts;
    const time = Date.UTC(
      Number(year),
      Number(month) - 1,
      Number(day),
      Number(hour ?? 0),
      Number(minute ?? 0)
    );
    const withTime = hour !== void 0;
    return cached(
      withTime ? wallDateTimeFormats : wallDateFormats,
      (tag) => withTime ? new Intl.DateTimeFormat(tag, {
        weekday: "short",
        year: "numeric",
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        timeZone: "UTC"
      }) : new Intl.DateTimeFormat(tag, {
        weekday: "short",
        year: "numeric",
        month: "short",
        day: "numeric",
        timeZone: "UTC"
      })
    ).format(time);
  }
  var format = {
    number: formatNumber,
    plural(value, forms) {
      return cached(pluralRules, (tag) => new Intl.PluralRules(tag)).select(
        value
      ) === "one" ? forms.one : forms.other;
    }
  };
  var reported = /* @__PURE__ */ new Set();
  function fallback(value) {
    const key2 = typeof value === "object" && value !== null && typeof value.key === "string" ? value.key : "?";
    if (!reported.has(key2)) {
      reported.add(key2);
      console.warn(`JoyFox: cannot show message "${key2}"`);
    }
    return CATALOGS[locale]["common.textUnavailable"];
  }
  function render(message2) {
    const entry = CATALOGS[locale][message2.key];
    if (typeof entry === "string") return entry;
    const spec = paramsOf(message2.key) ?? {};
    const given = message2.params;
    const params = {};
    for (const [name, kind] of Object.entries(spec))
      params[name] = kind === "message" ? render(given[name]) : given[name];
    return entry(params, format);
  }
  function t(first, ...rest) {
    const value = typeof first === "string" ? rest.length > 0 ? { key: first, params: rest[0] } : { key: first } : first;
    if (!isMessage(value)) return fallback(value);
    return render(value);
  }

  // src/storage/action-revision.ts
  var ACTION_REVISION_KEY = "joyfox.actionRevision";

  // src/storage/event-revision.ts
  var EVENT_REVISION_KEY = "joyfox.eventRevision";

  // src/storage/notes-revision.ts
  var NOTES_REVISION_KEY = "joyfox.notesRevision";

  // src/storage/saved-search-revision.ts
  var SAVED_SEARCH_REVISION_KEY = "joyfox.savedSearchRevision";

  // src/storage/triage-revision.ts
  var TRIAGE_REVISION_KEY = "joyfox.triageRevision";

  // src/content/diagnostics.ts
  var DIAGNOSTICS_KEY = "joyfox.diagnostics";
  var foundCount = (results) => results.filter((result) => result.status === "found").length;
  function summarizeInbox(rows) {
    return [
      "inbox.extracted",
      `rows=${rows.length}`,
      `senderName=${foundCount(rows.map((row) => row.senderName))}`,
      `memberId=${foundCount(rows.map((row) => row.memberId))}`,
      `verificationCode=${foundCount(rows.map((row) => row.verificationCode))}`,
      `readState=${foundCount(rows.map((row) => row.readState))}`
    ].join(" ");
  }
  function logDiagnostic(line) {
    console.debug(`JoyFox ${line}`);
  }
  var DiagnosticsFlag = class {
    #enabled = false;
    /** A change seen before the initial read settles is newer than that read. */
    #changed = false;
    constructor(read, onChanged, key2 = DIAGNOSTICS_KEY, defaultEnabled = false) {
      const enabledBy = (value) => defaultEnabled ? value !== false : value === true;
      this.#enabled = defaultEnabled;
      onChanged?.addListener((changes, areaName) => {
        if (areaName !== "local" || !(key2 in changes)) return;
        this.#changed = true;
        this.#enabled = enabledBy(changes[key2]?.newValue);
      });
      this.ready = read().then((settings) => {
        if (!this.#changed) this.#enabled = enabledBy(settings[key2]);
      }).catch(() => {
        if (!this.#changed) this.#enabled = defaultEnabled;
      });
    }
    /** Settles once the initial value is known. */
    ready;
    get enabled() {
      return this.#enabled;
    }
  };

  // src/identity/member-identity.ts
  var UNSTABLE_IDENTITY_FIELDS = [
    "displayname",
    "handle",
    "membername",
    "nickname",
    "profilename",
    "sendername",
    "username"
  ];
  var IDENTITY_FIELDS = ["memberId"];
  var unresolved = (reason) => ({
    status: "unresolved",
    reason
  });
  function isUsableIdentifier(value) {
    return value.length > 0 && value.length <= 128 && value === value.trim() && // eslint-disable-next-line no-control-regex
    !/[\s\u0000-\u001f\u007f]/.test(value);
  }
  function resolveMemberIdentity(input, lookup = verifiedSelector) {
    if (UNSTABLE_IDENTITY_FIELDS.includes(input.field.toLowerCase()))
      return unresolved("unstable-identifier");
    if (!IDENTITY_FIELDS.includes(input.field))
      return unresolved("not-identity-field");
    if (lookup(input.page, input.field) === void 0)
      return unresolved("selector-unverified");
    if (input.extraction.status === "missing") return unresolved("missing");
    if (input.extraction.status === "invalid") return unresolved("invalid");
    return isUsableIdentifier(input.extraction.value) ? {
      status: "resolved",
      memberId: input.extraction.value,
      source: input.extraction.source
    } : unresolved("invalid");
  }

  // src/trust/trust-score.ts
  var TRUST_SCOPE_NOTE = "trust.scopeNote";

  // src/triage/triage-service.ts
  var MAX_MEMBERS_PER_REQUEST = 200;

  // src/ui/focus.ts
  var FOCUS_KEY = "data-joyfox-focus";
  function rememberFocus(root) {
    const active = root?.ownerDocument.activeElement;
    if (!root || !active || !root.contains(active)) return void 0;
    const key2 = active.getAttribute(FOCUS_KEY);
    if (!key2) return void 0;
    if (active.tagName === "INPUT" || active.tagName === "TEXTAREA") {
      const field = active;
      try {
        return { key: key2, start: field.selectionStart, end: field.selectionEnd };
      } catch {
        return { key: key2 };
      }
    }
    return { key: key2 };
  }
  var usable = (node) => node && !node.disabled && !node.closest("[hidden]") && !(node.closest("details:not([open])") && node.tagName !== "SUMMARY") ? node : void 0;
  function findKey(root, key2) {
    for (const node of Array.from(
      root.querySelectorAll(`[${FOCUS_KEY}]`)
    ))
      if (node.getAttribute(FOCUS_KEY) === key2) return node;
    return void 0;
  }
  function restoreFocus(root, memo, fallbacks3 = []) {
    if (!memo) return false;
    const target = [memo.key, ...fallbacks3].map((key2) => usable(findKey(root, key2))).find((node) => node !== void 0);
    if (!target) return false;
    const same = target.getAttribute(FOCUS_KEY) === memo.key;
    target.focus({ preventScroll: same && !memo.scroll });
    if (target.getAttribute(FOCUS_KEY) === memo.key && memo.start !== void 0 && memo.start !== null && "setSelectionRange" in target) {
      try {
        target.setSelectionRange(
          memo.start,
          memo.end ?? memo.start
        );
      } catch {
      }
    }
    return true;
  }

  // src/content/triage-ui.ts
  var UI_ATTRIBUTE = "data-joyfox-ui";
  var OUTCOME_TEXT = {
    met: "triage.outcome.met",
    "not-met": "triage.outcome.not-met",
    "needs-review": "triage.outcome.needs-review"
  };
  var MARK_PLACEMENTS = [
    "qualified",
    "quarantined"
  ];
  var MARK_TEXT = {
    qualified: "mark.qualified",
    quarantined: "mark.junk"
  };
  var placementText = (placement) => t(PLACEMENT_TEXT[placement]);
  var FOCUS = {
    toggle: "why",
    conditions: "conditions",
    trustDetails: "trust-details",
    openOptions: "open-options",
    openProfile: "open-profile",
    sharedEventOptOut: "shared-event-opt-out",
    useRule: "use-rule",
    mark: (placement) => `mark:${placement}`,
    trust: (kind) => `trust:${kind}`
  };
  function focusFallbacks(key2) {
    if (key2?.startsWith("trust:")) return [FOCUS.trust("positive"), FOCUS.toggle];
    if (key2?.startsWith("mark:") || key2 === FOCUS.useRule || key2 === FOCUS.sharedEventOptOut)
      return [
        FOCUS.mark("qualified"),
        FOCUS.mark("quarantined"),
        FOCUS.useRule,
        FOCUS.toggle
      ];
    return [FOCUS.toggle];
  }
  var keyed = (node, key2) => {
    node.setAttribute(FOCUS_KEY, key2);
    return node;
  };
  function element(document2, tag, className, text2) {
    const node = document2.createElement(tag);
    node.className = className;
    if (text2 !== void 0) node.textContent = text2;
    return node;
  }
  function button(document2, className, text2, onClick) {
    const node = element(document2, "button", className, text2);
    node.type = "button";
    node.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      if (node.getAttribute("aria-disabled") === "true") return;
      onClick();
    });
    return node;
  }
  function openSections(root) {
    return new Set(
      Array.from(root?.querySelectorAll("details") ?? []).filter((node) => node.open && node.className).map((node) => node.className)
    );
  }
  function reopenSections(root, open) {
    for (const node of Array.from(
      root.querySelectorAll("details")
    ))
      if (open.has(node.className)) node.open = true;
  }
  function conditionList(document2, conditions) {
    const details = element(document2, "details", "joyfox-explain__conditions");
    details.append(
      keyed(
        element(
          document2,
          "summary",
          "",
          t("triage.conditions.summary", { count: conditions.length })
        ),
        FOCUS.conditions
      )
    );
    const list = element(document2, "ul", "joyfox-explain__list");
    for (const condition of conditions) {
      const item = element(document2, "li", "joyfox-explain__condition");
      item.dataset.outcome = condition.outcome;
      item.append(
        element(
          document2,
          "strong",
          "",
          t(
            condition.negate ? "triage.condition.lineNegated" : "triage.condition.line",
            {
              outcome: message(OUTCOME_TEXT[condition.outcome]),
              condition: message(CONDITION_TEXT[condition.kind])
            }
          )
        ),
        document2.createTextNode(t(condition.reason))
      );
      list.append(item);
    }
    details.append(list);
    return details;
  }
  function trustSection(document2, trust, actions) {
    const section = element(document2, "div", "joyfox-trust");
    section.append(
      element(document2, "p", "joyfox-trust__score", trustScoreText(trust))
    );
    if (trust !== "unknown") {
      const details = element(document2, "details", "joyfox-trust__details");
      details.append(
        keyed(
          element(document2, "summary", "", t("trust.details.summary")),
          FOCUS.trustDetails
        )
      );
      const list = element(document2, "ul", "joyfox-explain__list");
      for (const item of trust.contributions)
        list.append(
          element(
            document2,
            "li",
            "",
            t("trust.contribution", {
              points: item.points,
              reason: item.reason
            })
          )
        );
      details.append(list);
      section.append(details);
    }
    section.append(element(document2, "p", "joyfox-note", t(TRUST_SCOPE_NOTE)));
    const { onTrust, onUndoTrust } = actions;
    if (onTrust) {
      const row = element(document2, "div", "joyfox-actions");
      row.setAttribute("role", "group");
      row.setAttribute("aria-label", t("trust.log.group"));
      row.append(
        button(
          document2,
          "joyfox-button",
          t("trust.log.positive"),
          () => onTrust("positive")
        ),
        button(
          document2,
          "joyfox-button",
          t("trust.log.neutral"),
          () => onTrust("neutral")
        ),
        button(
          document2,
          "joyfox-button",
          t("trust.log.negative"),
          () => onTrust("negative")
        )
      );
      if (onUndoTrust && trust !== "unknown" && trust.logged > 0)
        row.append(
          button(document2, "joyfox-button", t("trust.log.undo"), onUndoTrust)
        );
      section.append(row);
    }
    return section;
  }
  function explanation(document2, result, actions) {
    const root = element(document2, "div", "joyfox-explain");
    root.append(
      element(
        document2,
        "p",
        "joyfox-explain__placement",
        t("triage.placementLine", {
          placement: message(PLACEMENT_TEXT[result.placement]),
          source: message(
            result.source === "override" ? "triage.source.override" : result.source === "shared-event" ? "triage.source.sharedEvent" : "triage.source.rule"
          )
        })
      )
    );
    if (result.sharedEvent) {
      const event = result.sharedEvent;
      root.append(
        element(
          document2,
          "p",
          "joyfox-explain__shared-event",
          t(
            message(
              event.attendance === "attended" ? "triage.sharedEvent.attended" : "triage.sharedEvent.attending",
              {
                event: event.title ?? t(message("events.untitled", { id: event.eventId })),
                when: event.startLocal ? formatWallTime(event.startLocal) : ""
              }
            )
          )
        )
      );
      if (actions.onSharedEventOptOut)
        root.append(
          keyed(
            button(
              document2,
              "joyfox-button",
              t("triage.sharedEvent.optOut"),
              actions.onSharedEventOptOut
            ),
            FOCUS.sharedEventOptOut
          )
        );
    }
    if (result.override)
      root.append(
        element(
          document2,
          "p",
          "",
          t("triage.movedOn", {
            date: formatDate(result.override.decidedAt),
            placement: message(PLACEMENT_TEXT[result.automatic.placement])
          })
        )
      );
    const reasons = element(document2, "ul", "joyfox-explain__list");
    for (const reason of result.automatic.reasons)
      reasons.append(element(document2, "li", "", t(reason)));
    root.append(reasons);
    if (result.automatic.evaluatedConditions.length > 0)
      root.append(conditionList(document2, result.automatic.evaluatedConditions));
    const controls = element(document2, "div", "joyfox-actions");
    controls.setAttribute("role", "group");
    controls.setAttribute("aria-label", t("triage.place.group"));
    if (actions.onMark)
      controls.append(
        ...markButtons(document2, result, actions.onMark, actions.markBusy)
      );
    if (result.source === "override")
      controls.append(
        keyed(
          button(
            document2,
            "joyfox-button",
            t("triage.useRule"),
            actions.onUseRule
          ),
          FOCUS.useRule
        )
      );
    if (controls.hasChildNodes()) root.append(controls);
    root.append(trustSection(document2, result.trust, actions));
    return root;
  }
  function markButtons(document2, result, onMark, busy = false) {
    return MARK_PLACEMENTS.map((placement) => {
      const control = keyed(
        button(
          document2,
          "joyfox-button",
          t(MARK_TEXT[placement]),
          () => onMark(placement)
        ),
        FOCUS.mark(placement)
      );
      control.dataset.mark = placement;
      control.disabled = result.source === "override" && result.placement === placement;
      if (busy) control.setAttribute("aria-disabled", "true");
      return control;
    });
  }
  var PROFILE_FACT_TEXT = {
    minimumPhotos: "triage.profileFact.minimumPhotos",
    minimumProfileWords: "triage.profileFact.minimumProfileWords",
    minimumAccountAgeDays: "triage.profileFact.minimumAccountAgeDays"
  };
  function unknownProfileFactsText(conditions) {
    const [first, second, third] = [
      ...new Set(
        conditions.filter((condition) => condition.state === "unknown").map((condition) => PROFILE_FACT_TEXT[condition.kind]).filter((name) => name !== void 0)
      )
    ].map((key2) => message(key2));
    if (!first) return void 0;
    if (!second) return message("triage.unknownFacts.one", { fact: first });
    if (!third) return message("triage.unknownFacts.two", { first, second });
    return message("triage.unknownFacts.three", { first, second, third });
  }
  function trustScoreText(trust) {
    return trust === "unknown" ? t("trust.score.none") : t("trust.score.value", { score: trust.score });
  }
  var drawerIds = 0;
  function memberBar(document2, input) {
    const { result, trust, actions } = input;
    const bar = element(document2, "div", "joyfox-bar");
    const brand = element(document2, "strong", "joyfox-bar__brand", "Joy");
    brand.append(element(document2, "span", "joyfox-bar__brand-accent", "Fox"));
    bar.append(brand);
    if (result) {
      const pill = element(document2, "span", "joyfox-pill");
      pill.dataset.placement = result.placement;
      pill.append(
        element(
          document2,
          "span",
          "joyfox-visually-hidden",
          t("bar.placementPrefix")
        ),
        document2.createTextNode(placementText(result.placement))
      );
      bar.append(pill);
      if (result.source === "override")
        bar.append(element(document2, "span", "joyfox-note", t("bar.yourChoice")));
      if (result.source === "shared-event")
        bar.append(
          element(document2, "span", "joyfox-note", t("bar.sharedEvent"))
        );
      if (actions.onMark) {
        const group = element(document2, "span", "joyfox-bar__group");
        group.setAttribute("role", "group");
        group.setAttribute("aria-label", t("mark.group"));
        group.append(
          ...markButtons(
            document2,
            result,
            actions.onMark,
            // A trust write from the bar also holds Mark, so one click never
            // adds a second outcome while the first is being stored.
            Boolean(input.markBusy || input.trustBusy || input.undoBusy)
          )
        );
        bar.append(group);
      }
      if (input.openProfile) {
        const group = element(document2, "span", "joyfox-bar__group");
        const link = keyed(
          element(
            document2,
            "a",
            "joyfox-button joyfox-bar__profile",
            t("bar.openProfile")
          ),
          FOCUS.openProfile
        );
        link.href = input.openProfile.href;
        group.append(
          element(document2, "span", "joyfox-note", t(input.openProfile.text)),
          link
        );
        bar.append(group);
      }
    } else if (input.ruleOff) {
      bar.append(element(document2, "span", "joyfox-note", t(input.ruleOff)));
      if (actions.onOpenOptions)
        bar.append(
          keyed(
            button(
              document2,
              "joyfox-button",
              t("common.openOptions"),
              actions.onOpenOptions
            ),
            FOCUS.openOptions
          )
        );
    }
    if (trust !== void 0)
      bar.append(
        element(document2, "span", "joyfox-bar__trust", trustScoreText(trust))
      );
    if (actions.onTrust) {
      const onTrust = actions.onTrust;
      const labelled = (text2, name, key2, onClick) => {
        const node = keyed(
          button(document2, "joyfox-button", text2, onClick),
          FOCUS.trust(key2)
        );
        node.setAttribute("aria-label", name);
        return node;
      };
      const log = (text2, name, kind) => {
        const node = labelled(text2, name, kind, () => onTrust(kind));
        if (input.trustBusy) node.setAttribute("aria-disabled", "true");
        return node;
      };
      const row = element(document2, "span", "joyfox-bar__group");
      row.setAttribute("role", "group");
      row.setAttribute("aria-label", t("trust.log.group"));
      row.append(
        element(document2, "span", "joyfox-note", t("bar.log")),
        log(t("bar.positive"), t("trust.log.positive"), "positive"),
        log(t("bar.neutral"), t("trust.log.neutral"), "neutral"),
        log(t("bar.negative"), t("trust.log.negative"), "negative")
      );
      if (actions.onUndoTrust && trust && trust !== "unknown" && trust.logged > 0) {
        const undo = labelled(
          t("bar.undo"),
          t("trust.log.undo"),
          "undo",
          actions.onUndoTrust
        );
        if (input.undoBusy) undo.setAttribute("aria-disabled", "true");
        row.append(undo);
      }
      bar.append(row);
    }
    const drawer = element(document2, "div", "joyfox-drawer");
    drawer.id = `joyfox-drawer-${drawerIds += 1}`;
    drawer.hidden = !input.drawerOpen;
    if (result && actions.onUseRule) {
      drawer.append(
        explanation(document2, result, {
          onUseRule: actions.onUseRule,
          ...actions.onSharedEventOptOut ? { onSharedEventOptOut: actions.onSharedEventOptOut } : {}
        })
      );
    } else if (trust !== void 0) {
      drawer.append(trustSection(document2, trust, {}));
    }
    if (!drawer.hasChildNodes()) return [bar];
    const toggle = keyed(
      button(
        document2,
        "joyfox-button joyfox-bar__toggle",
        t(result ? "bar.details" : "bar.scoreDetails"),
        () => {
          const open = drawer.hidden;
          drawer.hidden = !open;
          toggle.setAttribute("aria-expanded", String(open));
          input.onToggle(open);
        }
      ),
      FOCUS.toggle
    );
    toggle.setAttribute("aria-expanded", String(input.drawerOpen));
    toggle.setAttribute("aria-controls", drawer.id);
    bar.append(toggle);
    return [bar, drawer];
  }

  // src/content/card-line.ts
  var CARD_LINE = "card-line";
  var ORDER = ["badge", "compat-badge", "card-signals"];
  function cardLine(host, place) {
    const existing = host.querySelector(
      `:scope > [${UI_ATTRIBUTE}="${CARD_LINE}"]`
    );
    if (existing) return existing;
    const line = host.ownerDocument.createElement("div");
    line.className = "joyfox-card-line";
    line.setAttribute(UI_ATTRIBUTE, CARD_LINE);
    if (place.slot) line.setAttribute("slot", place.slot);
    if (place.before) place.before.before(line);
    else host.append(line);
    return line;
  }
  function placeInCardLine(host, part, place = {}) {
    const line = cardLine(host, place);
    const rank = ORDER.indexOf(part.getAttribute(UI_ATTRIBUTE) ?? "");
    const next = Array.from(line.children).find(
      (child) => child !== part && ORDER.indexOf(child.getAttribute(UI_ATTRIBUTE) ?? "") > rank
    );
    if (next) next.before(part);
    else line.append(part);
  }
  function placeInInboxLine(row, part) {
    const selector = verifiedSelector("inbox", "descriptionLine");
    const before = selector ? Array.from(row.children).find((child) => child.matches(selector)) : void 0;
    placeInCardLine(row, part, { before, slot: "description" });
  }
  function removeEmptyCardLines(document2) {
    for (const line of Array.from(
      document2.querySelectorAll(`[${UI_ATTRIBUTE}="${CARD_LINE}"]`)
    ))
      if (line.children.length === 0) line.remove();
  }

  // src/content/observed-facts.ts
  function shieldFacts(code) {
    const facts = {};
    const verification = verificationFromCode(code);
    const personallyKnown = personallyKnownFromCode(code);
    if (verification !== "unknown") facts.verification = verification;
    if (personallyKnown !== "unknown") facts.personallyKnown = personallyKnown;
    return facts;
  }
  var observedFromShield = (code) => shieldFacts(code);
  var observedFromInboxRow = (row) => shieldFacts(row.verificationCode);
  var observedFromConversation = (page) => shieldFacts(page.verificationCode);
  function observedFromProfile(page) {
    const facts = shieldFacts(page.verificationCode);
    if (page.verificationBadge.status === "found")
      facts.verification = page.verificationBadge.value;
    if (page.photoCount.status === "found")
      facts.photoCount = page.photoCount.value;
    if (page.profileWordCount.status === "found")
      facts.profileWordCount = page.profileWordCount.value;
    if (page.joinedAt.status === "found") facts.joinedAt = page.joinedAt.value;
    if (page.joinedWindow.status === "found")
      facts.joinedWindow = page.joinedWindow.value;
    return facts;
  }
  function factsKey(facts) {
    const window = facts.joinedWindow && facts.joinedWindow !== "unknown" ? `${facts.joinedWindow.earliest.slice(0, 10)}/${facts.joinedWindow.latest.slice(0, 10)}` : "";
    return JSON.stringify([
      facts.verification,
      facts.personallyKnown,
      facts.photoCount,
      facts.profileWordCount,
      facts.joinedAt,
      window
    ]);
  }

  // src/content/inbox-triage.ts
  var INBOX_UI = ["triage-bar", "triage-setup", "badge"];
  var SETUP_TEXT = {
    "no-account": "inbox.setup.no-account",
    "no-rule": "inbox.setup.no-rule"
  };
  var CLOSE_KEY = "close";
  var VIEW_STORAGE_KEY = "joyfox.inboxView";
  function inboxListState(document2) {
    const root = selectorRegistry.inbox.root;
    if (!root || selectorRegistry.inbox.status !== "verified") return "missing";
    const list = document2.querySelector(root);
    if (!list) return "missing";
    const check = list.checkVisibility;
    const visible = typeof check === "function" ? check.call(list) : list.ownerDocument.defaultView?.getComputedStyle(list).display !== "none";
    return visible ? "shown" : "hidden";
  }
  function inboxListShown(document2) {
    return inboxListState(document2) === "shown";
  }
  var VIEW_ATTRIBUTE = "data-joyfox-view";
  var ROW_ATTRIBUTE = "data-joyfox-row";
  var PLACEMENT_ATTRIBUTE = "data-joyfox-placement";
  var SLOT_ATTRIBUTE = "data-joyfox-slot";
  function rowSlot(row, list) {
    let slot = row;
    for (let parent = slot.parentElement; parent && parent !== list && parent.children.length === 1; parent = slot.parentElement)
      slot = parent;
    return slot;
  }
  var VIEW_TEXT = {
    default: "inbox.view.default",
    qualified: PLACEMENT_TEXT.qualified,
    "needs-review": PLACEMENT_TEXT["needs-review"],
    quarantined: PLACEMENT_TEXT.quarantined,
    all: "inbox.view.all"
  };
  function storedView(document2) {
    try {
      const value = document2.defaultView?.sessionStorage.getItem(VIEW_STORAGE_KEY);
      return value && Object.hasOwn(VIEW_TEXT, value) ? value : "default";
    } catch {
      return "default";
    }
  }
  function storeView(document2, view) {
    try {
      document2.defaultView?.sessionStorage.setItem(VIEW_STORAGE_KEY, view);
    } catch {
    }
  }
  function shownInView(placement, view) {
    if (view === "all") return true;
    if (view === "default") return placement !== "quarantined";
    return placement === view;
  }
  var InboxTriage = class {
    constructor(document2, client, now = () => /* @__PURE__ */ new Date()) {
      this.document = document2;
      this.client = client;
      this.now = now;
      this.#view = storedView(document2);
    }
    #results = /* @__PURE__ */ new Map();
    #status = "pending";
    #inFlight = false;
    #generation = 0;
    #view;
    #selected;
    #detailsKey = "";
    /**
     * The member whose last move failed. The notice stays when the details
     * redraw (for example after a language change) until another choice.
     */
    #failedFor;
    /**
     * The member a Mark sequence runs for. Set at the click, before any
     * request, and kept until the sequence ends, so a double click runs it
     * once (C9).
     */
    #markPending;
    /** What a Mark sequence did and did not do, when it stopped early. */
    #notice;
    #writeQueue = Promise.resolve();
    #active = false;
    #day;
    /** The account the current answers were computed for; writes name it. */
    #accountId;
    get view() {
      return this.#view;
    }
    /**
     * The page is the inbox: re-read it and apply placements. Safe to call on
     * every mutation.
     */
    update() {
      if (!this.#active) this.#forget();
      this.#active = true;
      this.#refresh();
    }
    /**
     * The page is no longer the inbox. JoyClub may keep the inbox list in the
     * page on other routes, so nothing may re-apply triage until `update` is
     * called again, not even a late answer or a change in another tab.
     */
    leave() {
      this.#active = false;
      this.teardown();
    }
    /** Drop every answer so the next refresh asks again. */
    #forget() {
      this.#generation += 1;
      this.#results.clear();
      this.#status = "pending";
      this.#inFlight = false;
      this.#detailsKey = "";
    }
    #refresh() {
      if (!this.#active) return;
      const day = this.now().toISOString().slice(0, 10);
      if (day !== this.#day) {
        if (this.#day !== void 0) this.#forget();
        this.#day = day;
      }
      const list = this.#list();
      if (!list || this.#status === "off") {
        this.teardown();
        return;
      }
      if (this.#status === "no-account" || this.#status === "no-rule") {
        this.#ensureSetup(list, this.#status);
        return;
      }
      const rows = this.#rows();
      this.#requestMissing(rows);
      if (this.#status !== "ok") return;
      this.document.querySelector(`[${UI_ATTRIBUTE}="triage-setup"]`)?.remove();
      this.#ensureBar(list);
      setAttribute(list, VIEW_ATTRIBUTE, this.#view);
      const counts = {
        qualified: 0,
        "needs-review": 0,
        quarantined: 0
      };
      const slots = /* @__PURE__ */ new Set();
      for (const state of rows) {
        const placement = this.#placementFor(state);
        setAttribute(state.row, ROW_ATTRIBUTE, "");
        if (placement) {
          setAttribute(state.row, PLACEMENT_ATTRIBUTE, placement);
          counts[placement] += 1;
        } else state.row.removeAttribute(PLACEMENT_ATTRIBUTE);
        const slot = rowSlot(state.row, list);
        slots.add(slot);
        setAttribute(slot, SLOT_ATTRIBUTE, placement ?? "");
        this.#ensureBadge(state, placement);
      }
      for (const node of Array.from(
        this.document.querySelectorAll(`[${SLOT_ATTRIBUTE}]`)
      ))
        if (!slots.has(node)) node.removeAttribute(SLOT_ATTRIBUTE);
      this.#renderCounts(counts);
      this.#renderDetails(rows);
    }
    /** Forget every result, for example after the rule or a placement changed. */
    invalidate() {
      this.#forget();
      this.#refresh();
    }
    /**
     * The active account changed. Everything shown belongs to the previous
     * account, so it is removed at once, before the new account's answer
     * arrives: no stale control can send a write under the new account.
     */
    accountChanged() {
      this.teardown();
      this.invalidate();
    }
    /**
     * Remove every trace of the inbox triage (`INBOX_UI`). UI that other
     * features own stays in place.
     */
    teardown() {
      for (const node of Array.from(
        this.document.querySelectorAll(`[${UI_ATTRIBUTE}]`)
      ))
        if (INBOX_UI.includes(node.getAttribute(UI_ATTRIBUTE) ?? ""))
          node.remove();
      removeEmptyCardLines(this.document);
      for (const node of Array.from(
        this.document.querySelectorAll(`[${ROW_ATTRIBUTE}]`)
      )) {
        node.removeAttribute(ROW_ATTRIBUTE);
        node.removeAttribute(PLACEMENT_ATTRIBUTE);
      }
      for (const node of Array.from(
        this.document.querySelectorAll(`[${SLOT_ATTRIBUTE}]`)
      ))
        node.removeAttribute(SLOT_ATTRIBUTE);
      for (const node of Array.from(
        this.document.querySelectorAll(`[${VIEW_ATTRIBUTE}]`)
      ))
        node.removeAttribute(VIEW_ATTRIBUTE);
      this.#detailsKey = "";
      this.#selected = void 0;
      this.#failedFor = void 0;
      this.#notice = void 0;
    }
    /**
     * The language changed: the bar is drawn again and every badge and the
     * details panel take the new text on the next refresh. The chosen view
     * and the open details stay.
     */
    localeChanged() {
      const bar = () => this.document.querySelector(
        `[${UI_ATTRIBUTE}="triage-bar"], [${UI_ATTRIBUTE}="triage-setup"]`
      );
      const open = openSections(bar());
      const focus = rememberFocus(bar());
      bar()?.remove();
      this.#detailsKey = "";
      this.#refresh();
      const redrawn = bar();
      if (!redrawn) return;
      reopenSections(redrawn, open);
      restoreFocus(redrawn, focus, [...focusFallbacks(focus?.key), CLOSE_KEY]);
    }
    setView(view) {
      this.#view = view;
      storeView(this.document, view);
      this.#refresh();
    }
    #list() {
      const root = selectorRegistry.inbox.root;
      return root && selectorRegistry.inbox.status === "verified" ? this.document.querySelector(root) : null;
    }
    #rows() {
      return extractInboxRows(this.document, this.document.URL).map(
        (row) => {
          const identity = resolveMemberIdentity({
            page: "inbox",
            field: "memberId",
            extraction: row.memberId
          });
          const name = row.senderName.status === "found" ? row.senderName.value : void 0;
          if (identity.status !== "resolved") return { row: row.row, name };
          const memberId = identity.memberId;
          const observed = observedFromInboxRow(row);
          const preview = row.messagePreview.status === "found" ? row.messagePreview.value.slice(0, MAX_PREVIEW_LENGTH) : void 0;
          return {
            row: row.row,
            memberId,
            observed,
            ...preview !== void 0 ? { preview } : {},
            name,
            // A new message changes the preview, so the row is asked about
            // again.
            key: JSON.stringify([memberId, factsKey(observed), preview ?? null])
          };
        }
      );
    }
    #requestMissing(rows) {
      if (this.#inFlight) return;
      const pending = /* @__PURE__ */ new Map();
      for (const state of rows)
        if (state.key && state.memberId && !this.#results.has(state.key))
          pending.set(state.key, {
            memberId: state.memberId,
            observed: state.observed ?? {},
            ...state.preview !== void 0 ? { preview: state.preview } : {}
          });
      if (pending.size === 0) {
        if (this.#status === "pending") this.#probe();
        return;
      }
      const batch = Array.from(pending.entries()).slice(
        0,
        MAX_MEMBERS_PER_REQUEST
      );
      this.#send(
        batch.map(([, value]) => value),
        batch.map(([key2]) => key2)
      );
    }
    /** Ask with an empty list, only to learn whether a rule is on. */
    #probe() {
      this.#send([], []);
    }
    #send(members, keys) {
      const generation = this.#generation;
      this.#inFlight = true;
      this.client.evaluate(members).then((response) => {
        if (generation !== this.#generation) return;
        this.#inFlight = false;
        if (response.status !== "ok") {
          this.teardown();
          if (response.status === "no-account" || response.status === "no-rule") {
            this.#status = response.status;
            this.#refresh();
          } else this.#status = "off";
          return;
        }
        this.#accountId = response.accountId;
        response.results.forEach((result, index) => {
          const key2 = keys[index];
          if (key2) this.#results.set(key2, result);
        });
        this.#status = "ok";
        this.#refresh();
      }).catch(() => {
        if (generation !== this.#generation) return;
        this.#inFlight = false;
        this.#status = "off";
        this.teardown();
      });
    }
    #placementFor(state) {
      if (!state.memberId) return "needs-review";
      return state.key ? this.#results.get(state.key)?.placement : void 0;
    }
    #ensureBar(list) {
      const existing = this.document.querySelector(
        `[${UI_ATTRIBUTE}="triage-bar"]`
      );
      if (existing && existing.nextElementSibling === list) return;
      existing?.remove();
      const bar = element(this.document, "div", "joyfox-triage");
      bar.setAttribute(UI_ATTRIBUTE, "triage-bar");
      bar.setAttribute("role", "region");
      bar.setAttribute("aria-label", t("inbox.region"));
      const group = element(this.document, "div", "joyfox-triage__views");
      group.setAttribute("role", "group");
      group.setAttribute("aria-label", t("inbox.views"));
      for (const view of Object.keys(VIEW_TEXT)) {
        const tab = keyed(
          button(
            this.document,
            "joyfox-button joyfox-triage__view",
            t(VIEW_TEXT[view]),
            () => this.setView(view)
          ),
          `view:${view}`
        );
        tab.dataset.view = view;
        group.append(tab);
      }
      const about = element(this.document, "details", "joyfox-triage__about");
      const summary = element(this.document, "summary", "joyfox-button", "?");
      summary.setAttribute("aria-label", t("inbox.about"));
      summary.title = t("inbox.about");
      about.append(
        summary,
        element(this.document, "p", "joyfox-note", t("inbox.aboutText"))
      );
      group.append(about);
      bar.append(group);
      const details = element(this.document, "div", "joyfox-triage__details");
      details.hidden = true;
      bar.append(details);
      list.before(bar);
    }
    /**
     * One line where the tab bar goes, when there is no account or no saved
     * rule, with the way to the options. Written only when it changes.
     */
    #ensureSetup(list, reason) {
      const existing = this.document.querySelector(
        `[${UI_ATTRIBUTE}="triage-setup"]`
      );
      if (existing && existing.nextElementSibling === list && existing.dataset.reason === reason)
        return;
      const focus = rememberFocus(existing);
      existing?.remove();
      const bar = element(
        this.document,
        "div",
        "joyfox-triage joyfox-triage--setup"
      );
      bar.setAttribute(UI_ATTRIBUTE, "triage-setup");
      bar.dataset.reason = reason;
      bar.setAttribute("role", "region");
      bar.setAttribute("aria-label", t("inbox.region"));
      bar.append(
        element(this.document, "p", "joyfox-note", t(SETUP_TEXT[reason])),
        keyed(
          button(this.document, "joyfox-button", t("common.openOptions"), () => {
            void this.client.openOptions().catch(() => void 0);
          }),
          FOCUS.openOptions
        )
      );
      list.before(bar);
      restoreFocus(bar, focus);
    }
    #renderCounts(counts) {
      for (const tab of Array.from(
        this.document.querySelectorAll(
          `[${UI_ATTRIBUTE}="triage-bar"] .joyfox-triage__view`
        )
      )) {
        const view = tab.dataset.view;
        const label = view === "default" || view === "all" ? t(VIEW_TEXT[view]) : t("inbox.viewCount", {
          view: message(VIEW_TEXT[view]),
          count: counts[view]
        });
        setText(tab, label);
        setAttribute(tab, "aria-pressed", String(view === this.#view));
      }
    }
    #ensureBadge(state, placement) {
      const key2 = placement ? PLACEMENT_TEXT[placement] : "inbox.checking";
      const text2 = t(key2);
      let badge = state.row.querySelector(
        `[${UI_ATTRIBUTE}="badge"]`
      );
      if (!badge) {
        const created = button(
          this.document,
          "joyfox-badge",
          text2,
          () => {
            this.#selected = created.dataset.member ?? "";
            this.#failedFor = void 0;
            this.#detailsKey = "";
            this.#refresh();
            const details = this.document.querySelector(
              `[${UI_ATTRIBUTE}="triage-bar"] .joyfox-triage__details`
            );
            details?.scrollIntoView?.({ block: "nearest" });
            details?.focus();
          }
        );
        badge = created;
        badge.setAttribute(UI_ATTRIBUTE, "badge");
        placeInInboxLine(state.row, badge);
      }
      setText(badge, text2);
      setAttribute(badge, "data-placement", placement ?? "pending");
      setAttribute(badge, "aria-label", t("inbox.badge", { text: message(key2) }));
      setAttribute(badge, "data-member", state.memberId ?? "");
    }
    #renderDetails(rows) {
      const details = this.document.querySelector(
        `[${UI_ATTRIBUTE}="triage-bar"] .joyfox-triage__details`
      );
      if (!details || this.#selected === void 0) return;
      const state = rows.find((row) => (row.memberId ?? "") === this.#selected);
      const result = state?.key ? this.#results.get(state.key) : void 0;
      const markBusy = this.#markPending !== void 0;
      const key2 = JSON.stringify([
        this.#selected,
        state?.name,
        result,
        markBusy,
        this.#notice
      ]);
      if (key2 === this.#detailsKey) return;
      this.#detailsKey = key2;
      details.hidden = false;
      details.tabIndex = -1;
      const heading = element(
        this.document,
        "h2",
        "joyfox-triage__heading",
        // The name is shown as JoyClub shows it, never logged.
        state?.name ? t("inbox.whyNamed", { name: state.name }) : t("inbox.why")
      );
      const close = keyed(
        button(this.document, "joyfox-button", t("common.close"), () => {
          const member = this.#selected;
          this.#selected = void 0;
          this.#failedFor = void 0;
          this.#detailsKey = "";
          details.hidden = true;
          details.replaceChildren();
          this.#focusAfterClose(member);
        }),
        CLOSE_KEY
      );
      const focus = rememberFocus(details);
      const redraw = (...body) => {
        details.replaceChildren(heading, ...body, close);
        restoreFocus(details, focus, [...focusFallbacks(focus?.key), CLOSE_KEY]);
      };
      if (!state) {
        redraw(element(this.document, "p", "", t("inbox.rowGone")));
        return;
      }
      if (!state.memberId) {
        redraw(element(this.document, "p", "", t("inbox.unidentified")));
        return;
      }
      if (!result) {
        redraw(element(this.document, "p", "", t("inbox.stillChecking")));
        return;
      }
      const memberId = state.memberId;
      const accountId = this.#accountId;
      redraw(
        explanation(this.document, result, {
          onMark: (placement) => this.#mark(memberId, placement),
          markBusy,
          onUseRule: () => {
            if (!accountId) return;
            this.#writeQueue = this.#writeQueue.then(
              () => this.client.setOverride(accountId, memberId, null).then(() => {
                this.#failedFor = void 0;
                this.invalidate();
              }).catch(() => {
                this.#failedFor = memberId;
                this.#showError();
              })
            );
          },
          onSharedEventOptOut: () => {
            if (!accountId) return;
            this.#writeQueue = this.#writeQueue.then(
              () => this.client.optOutSharedEvent(accountId, memberId).then(() => {
                this.#failedFor = void 0;
                this.invalidate();
              }).catch(() => {
                this.#failedFor = memberId;
                this.#showError();
              })
            );
          }
        })
      );
      if (this.#failedFor === memberId) this.#showError();
      if (this.#notice?.memberId === memberId)
        this.#showNotice(this.#notice.text);
    }
    /**
     * "Mark qualified" or "Mark as junk" in the row panel (C2, C4, C6): the
     * user's own placement, then one trust outcome, Positive or Negative. No
     * trash: the inbox list opens no conversation (D10). It stops at the
     * first step that fails or is refused.
     */
    #mark(memberId, placement) {
      const accountId = this.#accountId;
      if (!accountId || this.#markPending !== void 0) return;
      this.#markPending = memberId;
      this.#failedFor = void 0;
      this.#notice = void 0;
      this.#detailsKey = "";
      this.#refresh();
      this.#writeQueue = this.#writeQueue.then(async () => {
        try {
          await this.client.setOverride(accountId, memberId, placement);
        } catch {
          this.#failedFor = memberId;
          return;
        }
        try {
          await this.client.logTrust(
            accountId,
            memberId,
            placement === "qualified" ? "positive" : "negative"
          );
        } catch {
          this.#notice = {
            memberId,
            text: message("mark.trustFailed", {
              placement: message(PLACEMENT_TEXT[placement])
            })
          };
        }
      }).finally(() => {
        if (this.#markPending === memberId) this.#markPending = void 0;
        this.invalidate();
      });
    }
    /** A Mark sequence's notice, in the details shown now. */
    #showNotice(text2) {
      const details = this.document.querySelector(
        `[${UI_ATTRIBUTE}="triage-bar"] .joyfox-triage__details`
      );
      if (!details || details.querySelector(".joyfox-mark-notice")) return;
      details.append(
        element(this.document, "p", "joyfox-error joyfox-mark-notice", t(text2))
      );
    }
    /**
     * After Close, focus goes back to the badge of the row the panel was
     * about, scrolled into view. When the current view hides that row, or it
     * is gone, focus goes to the current view's button.
     */
    #focusAfterClose(member) {
      const badge = Array.from(
        this.document.querySelectorAll(`[${UI_ATTRIBUTE}="badge"]`)
      ).find((node) => member !== void 0 && node.dataset.member === member);
      if (badge && shownInView(badge.dataset.placement, this.#view)) {
        badge.scrollIntoView?.({ block: "nearest" });
        badge.focus({ preventScroll: true });
        return;
      }
      this.document.querySelector(
        `[${UI_ATTRIBUTE}="triage-bar"] .joyfox-triage__view[aria-pressed="true"]`
      )?.focus();
    }
    /** The failure notice, in the details shown now (a redraw replaces them). */
    #showError() {
      const details = this.document.querySelector(
        `[${UI_ATTRIBUTE}="triage-bar"] .joyfox-triage__details`
      );
      if (!details || details.querySelector(".joyfox-error")) return;
      details.append(
        element(this.document, "p", "joyfox-error", t("common.saveFailed"))
      );
    }
  };
  function setAttribute(node, name, value) {
    if (node.getAttribute(name) !== value) node.setAttribute(name, value);
  }
  function setText(node, text2) {
    if (node.textContent !== text2) node.textContent = text2;
  }

  // src/messaging/protocol.ts
  function createRequestId() {
    return crypto.randomUUID();
  }

  // src/messaging/request.ts
  async function request(sender, type, payload) {
    const message2 = { type, requestId: createRequestId(), payload };
    const response = await sender(message2);
    if (response.requestId !== message2.requestId)
      throw new Error("Mismatched response requestId");
    if (!response.ok)
      throw new Error(`${response.error.code}: ${response.error.message}`);
    return response.payload;
  }

  // src/rules/presets.ts
  var COMPLETE_PROFILE = { photos: 3, words: 50 };
  var HIGH_TRUST_ACCOUNT_DAYS = 180;
  var PRESET_CONDITIONS = {
    open: [],
    complete: [
      ["minimumPhotos", COMPLETE_PROFILE.photos],
      ["minimumProfileWords", COMPLETE_PROFILE.words]
    ],
    verified: [["verified"]],
    highTrust: [
      ["verified"],
      ["minimumPhotos", COMPLETE_PROFILE.photos],
      ["minimumProfileWords", COMPLETE_PROFILE.words],
      ["minimumAccountAgeDays", HIGH_TRUST_ACCOUNT_DAYS]
    ],
    custom: []
  };

  // src/signals/signals-service.ts
  var MAX_SIGNAL_MEMBERS = 500;

  // src/content/member-strip.ts
  var MEMBER_STRIP = "member-strip";
  var STRIP_TOGGLE = "strip-toggle";
  var STRIP_COLLAPSED_KEY = "joyfox.stripCollapsed";
  var SECTION_ORDER = [
    STRIP_TOGGLE,
    "member-panel",
    "completeness",
    "compatibility",
    "shared-events",
    "member-notes",
    "quick-action"
  ];
  function shownElement(document2, selector) {
    const matches2 = Array.from(document2.querySelectorAll(selector));
    return matches2.find((element2) => element2.getClientRects().length > 0) ?? matches2[0] ?? null;
  }
  function isHorizontalFlex(element2) {
    const view = element2.ownerDocument.defaultView;
    if (!view) return false;
    const style = view.getComputedStyle(element2);
    return (style.display === "flex" || style.display === "inline-flex") && !style.flexDirection.startsWith("column");
  }
  function stripAnchor(anchor) {
    const parent = anchor.parentElement;
    if (!parent || parent === anchor.ownerDocument.body) return anchor;
    return isHorizontalFlex(parent) ? parent : anchor;
  }
  var collapsed = false;
  var storeCollapsed;
  function setStripCollapsed(document2, value, store) {
    collapsed = value;
    if (store) storeCollapsed = store;
    const strip = findStrip(document2);
    if (strip) applyCollapsed(strip);
  }
  function applyCollapsed(strip) {
    const value = String(collapsed);
    if (strip.dataset.collapsed !== value) strip.dataset.collapsed = value;
    const toggle = strip.querySelector(
      `:scope > [${UI_ATTRIBUTE}="${STRIP_TOGGLE}"]`
    );
    if (!toggle) return;
    const expanded = String(!collapsed);
    if (toggle.getAttribute("aria-expanded") !== expanded)
      toggle.setAttribute("aria-expanded", expanded);
    const label = t(collapsed ? "strip.expand" : "strip.collapse");
    if (toggle.getAttribute("aria-label") !== label) {
      toggle.setAttribute("aria-label", label);
      toggle.title = label;
    }
  }
  function stripToggle(document2, strip) {
    const toggle = button(
      document2,
      "joyfox-button joyfox-strip__toggle",
      "",
      () => {
        collapsed = !collapsed;
        applyCollapsed(strip);
        storeCollapsed?.(collapsed);
      }
    );
    toggle.setAttribute(UI_ATTRIBUTE, STRIP_TOGGLE);
    toggle.append(element(document2, "span", "joyfox-strip__chevron"));
    return toggle;
  }
  function findStrip(document2) {
    return document2.querySelector(
      `[${UI_ATTRIBUTE}="${MEMBER_STRIP}"]`
    );
  }
  function isPlaced(section, anchor) {
    const strip = section.parentElement;
    return strip?.getAttribute(UI_ATTRIBUTE) === MEMBER_STRIP && strip.previousElementSibling === stripAnchor(anchor);
  }
  function placeInStrip(document2, anchor, section) {
    const after = stripAnchor(anchor);
    let strip = findStrip(document2);
    if (!strip) {
      strip = document2.createElement("div");
      strip.className = "joyfox-strip";
      strip.setAttribute(UI_ATTRIBUTE, MEMBER_STRIP);
      strip.setAttribute("role", "region");
      strip.setAttribute("aria-label", "JoyFox");
      strip.append(stripToggle(document2, strip));
    }
    applyCollapsed(strip);
    if (strip.previousElementSibling !== after) {
      const active = document2.activeElement;
      const focused = active instanceof HTMLElement && strip.contains(active) ? active : null;
      after.after(strip);
      if (focused && document2.activeElement !== focused)
        focused.focus({ preventScroll: true });
    }
    const rank = SECTION_ORDER.indexOf(section.getAttribute(UI_ATTRIBUTE) ?? "");
    const next = Array.from(strip.children).find(
      (child) => child !== section && SECTION_ORDER.indexOf(child.getAttribute(UI_ATTRIBUTE) ?? "") > rank
    );
    if (next) next.before(section);
    else strip.append(section);
  }
  function removeEmptyStrip(document2) {
    const strip = findStrip(document2);
    if (strip && Array.from(strip.children).every(
      (child) => child.getAttribute(UI_ATTRIBUTE) === STRIP_TOGGLE
    ))
      strip.remove();
  }

  // src/content/member-panel.ts
  var MEMBER_PANEL = "member-panel";
  function pageMember(document2, page) {
    const root = selectorRegistry[page].root;
    const anchor = root ? shownElement(document2, root) : null;
    if (!anchor) return void 0;
    const url = document2.URL;
    const member = page === "conversation" ? { page, extraction: extractConversation(document2, url) } : { page, extraction: extractProfile(document2, url) };
    const identity = resolveMemberIdentity({
      page,
      field: "memberId",
      extraction: member.extraction.memberId
    });
    if (identity.status !== "resolved") return void 0;
    return { ...member, anchor, memberId: identity.memberId };
  }
  var RULE_OFF_TEXT = {
    "no-account": "panel.ruleOff.no-account",
    "no-rule": "panel.ruleOff.no-rule",
    "rule-disabled": "panel.ruleOff.rule-disabled"
  };
  var MemberPanel = class {
    constructor(document2, client, trash) {
      this.document = document2;
      this.client = client;
      this.trash = trash;
    }
    #data = /* @__PURE__ */ new Map();
    #inFlight;
    #generation = 0;
    #rendered = "";
    #captured = "";
    /**
     * Captures run one after another. The background stamps a snapshot when it
     * writes, so two captures in flight at once could finish out of order and
     * leave an older, partial reading as the newest snapshot.
     */
    #captureQueue = Promise.resolve();
    #writeQueue = Promise.resolve();
    /**
     * The member whose last write failed. The notice shows only on that
     * member's panel, drawn in the language shown, until the next write, the
     * page is left or the account changes.
     */
    #errorFor;
    /**
     * The member an outcome is being logged for. Until it is stored, further
     * Log clicks are ignored, so a double click logs one outcome.
     */
    #trustPending;
    /** The member whose Undo is being stored; a second click waits for it. */
    #undoPending;
    /**
     * The member a Mark sequence runs for, set at the click, before any
     * request: until the whole sequence (placement, outcome, trash) ends, the
     * Mark buttons are unavailable, so a double click runs it once (C9).
     */
    #markPending;
    /** What a Mark sequence did and did not do, when it stopped early. */
    #notice;
    #page;
    /** Whether "Details" is open; kept across redraws of the bar. */
    #drawerOpen = false;
    /** The member the drawer state belongs to. */
    #drawerMember;
    update(page) {
      this.#page = page;
      const target = this.#target(page);
      if (!target) {
        this.teardown();
        return;
      }
      const shown = this.document.querySelector(
        `[${UI_ATTRIBUTE}="${MEMBER_PANEL}"]`
      );
      if (shown && shown.getAttribute("data-member") !== target.memberId) {
        this.teardown();
        this.#drawerOpen = false;
      }
      const data = this.#data.get(target.key);
      if (!data) {
        this.#load(target);
        return;
      }
      if (page === "profile" && data.accountId)
        this.#capture(target, data.accountId);
      this.#render(target, data);
    }
    /** Forget every answer and reload the current page's panel. */
    invalidate() {
      this.#generation += 1;
      this.#data.clear();
      this.#inFlight = void 0;
      this.#rendered = "";
      if (this.#page) this.update(this.#page);
    }
    /**
     * The active account changed. The panel shows the previous account's data,
     * so it goes at once, and the profile is captured again for the new
     * account on the next update.
     */
    accountChanged() {
      this.teardown();
      this.#drawerOpen = false;
      this.#captured = "";
      this.#errorFor = void 0;
      this.#notice = void 0;
      this.invalidate();
    }
    /** Called when the page is no longer a conversation or profile. */
    leave() {
      this.#page = void 0;
      this.#generation += 1;
      this.#inFlight = void 0;
      this.teardown();
      this.#drawerOpen = false;
      this.#errorFor = void 0;
      this.#notice = void 0;
    }
    teardown() {
      for (const node of Array.from(
        this.document.querySelectorAll(`[${UI_ATTRIBUTE}="${MEMBER_PANEL}"]`)
      ))
        node.remove();
      removeEmptyStrip(this.document);
      this.#rendered = "";
    }
    #target(page) {
      const member = pageMember(this.document, page);
      if (!member) return void 0;
      const observed = member.page === "conversation" ? observedFromConversation(member.extraction) : observedFromProfile(member.extraction);
      const extras = {};
      if (member.page === "profile") {
        const preferences = readPreferences(this.document);
        if (preferences.status === "found")
          extras.preferences = preferences.positive;
        if (isOwnProfile(this.document)) extras.ownProfile = true;
      }
      const profileUrl2 = member.page === "conversation" && member.extraction.profileUrl.status === "found" ? member.extraction.profileUrl.value : void 0;
      return {
        page,
        memberId: member.memberId,
        observed,
        extras,
        anchor: member.anchor,
        key: `${page}|${member.memberId}|${factsKey(observed)}|${JSON.stringify(extras)}`,
        ...profileUrl2 ? { profileUrl: profileUrl2 } : {}
      };
    }
    /** Once per distinct set of facts, so a re-render does not re-store. */
    #capture(target, accountId) {
      const key2 = `${accountId}|${target.key}`;
      if (this.#captured === key2) return;
      this.#captured = key2;
      const { memberId, observed, extras } = target;
      this.#captureQueue = this.#captureQueue.then(
        () => this.client.captureSnapshot(accountId, memberId, observed, extras).catch(() => {
          if (this.#captured === key2) this.#captured = "";
        })
      );
    }
    #load(target) {
      if (this.#inFlight === target.key) return;
      this.#inFlight = target.key;
      const generation = this.#generation;
      const done = (data) => {
        if (generation !== this.#generation) return;
        if (this.#inFlight === target.key) this.#inFlight = void 0;
        this.#data.set(target.key, data);
        this.update(target.page);
      };
      this.client.evaluate([{ memberId: target.memberId, observed: target.observed }]).then(async (response) => {
        const result = response.status === "ok" ? response.results[0] : void 0;
        if (response.status === "ok" && result)
          return done({
            kind: "triage",
            accountId: response.accountId,
            result
          });
        const trust = await this.client.getTrust(
          target.memberId,
          target.observed
        );
        done({
          kind: "trust-only",
          ...trust.status === "ok" ? { accountId: trust.accountId } : {},
          rule: response.status,
          trust
        });
      }).catch(() => {
        if (generation !== this.#generation || this.#inFlight !== target.key)
          return;
        this.#inFlight = void 0;
        this.teardown();
      });
    }
    /** The language changed: draw the panel again, in place. */
    localeChanged() {
      this.#rendered = "";
      if (this.#page) this.update(this.#page);
    }
    #render(target, data) {
      if (target.extras.ownProfile) {
        this.teardown();
        return;
      }
      const failed = this.#errorFor === target.memberId;
      const busy = this.#trustPending === target.memberId;
      const undoBusy = this.#undoPending === target.memberId;
      const markBusy = this.#markPending === target.memberId;
      const notice = this.#notice?.memberId === target.memberId ? this.#notice.text : void 0;
      const key2 = JSON.stringify([
        target.key,
        data,
        failed,
        busy,
        undoBusy,
        markBusy,
        notice
      ]);
      const existing = this.document.querySelector(
        `[${UI_ATTRIBUTE}="${MEMBER_PANEL}"]`
      );
      if (existing && key2 === this.#rendered && isPlaced(existing, target.anchor))
        return;
      const same = existing?.getAttribute("data-member") === target.memberId;
      const open = same ? openSections(existing) : /* @__PURE__ */ new Set();
      const focus = same ? rememberFocus(existing) : void 0;
      existing?.remove();
      this.#rendered = key2;
      if (this.#drawerMember !== target.memberId) {
        this.#drawerMember = target.memberId;
        this.#drawerOpen = false;
      }
      const panel = element(
        this.document,
        "section",
        "joyfox-panel joyfox-member"
      );
      panel.setAttribute(UI_ATTRIBUTE, MEMBER_PANEL);
      panel.setAttribute("data-member", target.memberId);
      panel.setAttribute("role", "group");
      panel.setAttribute("aria-label", "JoyFox");
      const memberId = target.memberId;
      const accountId = data.accountId;
      const trustActions = accountId ? {
        onTrust: (kind) => {
          if (this.#trustPending === memberId) return;
          this.#trustPending = memberId;
          this.#write(
            memberId,
            () => this.client.logTrust(accountId, memberId, kind),
            () => {
              if (this.#trustPending === memberId)
                this.#trustPending = void 0;
            }
          );
          if (this.#page) this.update(this.#page);
        },
        // A double click on Undo removes one outcome. An Undo right after
        // a Log still runs, after it, and removes that outcome.
        onUndoTrust: () => {
          if (this.#undoPending === memberId) return;
          this.#undoPending = memberId;
          this.#write(
            memberId,
            () => this.client.undoTrust(accountId, memberId),
            () => {
              if (this.#undoPending === memberId)
                this.#undoPending = void 0;
            }
          );
          if (this.#page) this.update(this.#page);
        }
      } : {};
      const onToggle = (open2) => {
        this.#drawerOpen = open2;
      };
      const unknownText = data.kind === "triage" && target.profileUrl ? unknownProfileFactsText(data.result.automatic.evaluatedConditions) : void 0;
      if (data.kind === "triage")
        panel.append(
          ...memberBar(this.document, {
            result: data.result,
            trust: data.result.trust,
            ...unknownText && target.profileUrl ? { openProfile: { href: target.profileUrl, text: unknownText } } : {},
            actions: {
              onMark: (placement) => {
                if (this.#markPending === memberId || this.#trustPending === memberId || this.#undoPending === memberId)
                  return;
                this.#markPending = memberId;
                this.#errorFor = void 0;
                this.#notice = void 0;
                const page = target.page;
                this.#writeQueue = this.#writeQueue.then(
                  () => this.#mark(data.accountId, memberId, placement, page)
                );
                if (this.#page) this.update(this.#page);
              },
              onUseRule: () => this.#write(
                memberId,
                () => this.client.setOverride(data.accountId, memberId, null)
              ),
              onSharedEventOptOut: () => this.#write(
                memberId,
                () => this.client.optOutSharedEvent(data.accountId, memberId)
              ),
              ...trustActions
            },
            trustBusy: busy,
            undoBusy,
            markBusy,
            drawerOpen: this.#drawerOpen,
            onToggle
          })
        );
      else
        panel.append(
          ...memberBar(this.document, {
            ruleOff: message(RULE_OFF_TEXT[data.rule] ?? "panel.ruleOff.other"),
            ...data.trust.status === "ok" ? { trust: data.trust.trust } : {},
            actions: {
              ...trustActions,
              onOpenOptions: () => {
                void this.client.openOptions().catch(() => void 0);
              }
            },
            trustBusy: busy,
            undoBusy,
            drawerOpen: this.#drawerOpen,
            onToggle
          })
        );
      if (failed)
        panel.append(
          element(this.document, "p", "joyfox-error", t("common.saveFailed"))
        );
      if (notice)
        panel.append(element(this.document, "p", "joyfox-error", t(notice)));
      reopenSections(panel, open);
      placeInStrip(this.document, target.anchor, panel);
      restoreFocus(panel, focus, focusFallbacks(focus?.key));
    }
    /**
     * "Mark qualified" or "Mark as junk" (C4 to C7), step by step, stopping at
     * the first step that fails or is refused:
     *
     * 1. the user's own placement (`setOverride`);
     * 2. one trust outcome: Positive for Qualified, Negative for Junk;
     * 3. for Junk on a conversation page only, the Delete flow (D7, D10).
     *
     * A completed step is kept and never undone. The panel is drawn again
     * after step 2, so the new placement shows while the trash step runs.
     */
    async #mark(accountId, memberId, placement, page) {
      const finish = () => {
        if (this.#markPending === memberId) this.#markPending = void 0;
        this.invalidate();
      };
      try {
        await this.client.setOverride(accountId, memberId, placement);
      } catch {
        this.#errorFor = memberId;
        finish();
        return;
      }
      try {
        await this.client.logTrust(
          accountId,
          memberId,
          placement === "qualified" ? "positive" : "negative"
        );
      } catch {
        this.#notice = {
          memberId,
          text: message("mark.trustFailed", {
            placement: message(PLACEMENT_TEXT[placement])
          })
        };
        finish();
        return;
      }
      if (placement !== "quarantined" || page !== "conversation") {
        finish();
        return;
      }
      this.invalidate();
      const shown = await Promise.resolve(
        this.trash?.junk(memberId) ?? "unavailable"
      ).catch(() => "unavailable");
      if (shown === "unavailable")
        this.#notice = { memberId, text: message("mark.junk.noTrash") };
      finish();
    }
    /**
     * Run a write for `memberId`, then reload at once. The background also
     * bumps the triage revision, which other tabs hear through
     * `storage.onChanged`. `settled` runs once the write has ended, either
     * way, before the reload.
     *
     * Writes run one after another, in click order. Otherwise "Log" then a
     * quick "Undo" could reach the background in the other order, and undo
     * would remove the earlier outcome instead of the one just logged.
     */
    #write(memberId, action, settled) {
      this.#errorFor = void 0;
      this.#writeQueue = this.#writeQueue.then(
        () => action().then(() => {
          settled?.();
          this.invalidate();
        }).catch(() => {
          settled?.();
          this.#errorFor = memberId;
          this.#rendered = "";
          if (this.#page) this.update(this.#page);
        })
      );
    }
  };

  // src/content/member-notes.ts
  var MEMBER_NOTES = "member-notes";
  function messageNotesClient(sender) {
    return {
      getNotes: (memberId) => request(sender, "note.get", { memberId }),
      saveNote: (accountId, memberId, body, expectedBody) => request(sender, "note.save", {
        accountId,
        memberId,
        body,
        expectedBody
      }),
      addTag: async (accountId, memberId, label) => {
        const answer = await request(sender, "tag.add", {
          accountId,
          memberId,
          label
        });
        return answer.done && answer.existed ? "exists" : answer.done;
      },
      removeTag: async (accountId, memberId, label) => (await request(sender, "tag.remove", { accountId, memberId, label })).done
    };
  }
  function runtimeNotesClient() {
    return messageNotesClient(
      (message2) => browser.runtime.sendMessage(message2)
    );
  }
  var CONTROL = "data-joyfox-control";
  var NOTES_TEXT = {
    scope: "notes.scope",
    saved: "notes.saved",
    removed: "notes.removed",
    conflict: "notes.conflict",
    refused: "notes.refused",
    failed: "common.saveFailed",
    emptyTag: "notes.emptyTag",
    emptyNote: "notes.emptyNote",
    tagAdded: "notes.tagAdded",
    tagExists: "notes.tagExists",
    tagRemoved: "notes.tagRemoved",
    pasteCut: "notes.pasteCut"
  };
  var MemberNotes = class {
    constructor(document2, client) {
      this.document = document2;
      this.client = client;
    }
    #page;
    #key;
    #data;
    #inFlight;
    /** Bumped on every reload and leave, so a late answer is dropped. */
    #generation = 0;
    #rendered = "";
    #draft;
    #tagDraft = "";
    #open;
    #status;
    /**
     * Bumped whenever the shown member or the account changes. A write's
     * answer from before that must not touch the new state: the page and
     * member can be the same while the account is another.
     */
    #session = 0;
    /** The session of the save in flight, if any. */
    #savingSession;
    /** The account the shown note was read for. */
    #accountId;
    #writeQueue = Promise.resolve();
    update(page) {
      this.#page = page;
      const member = pageMember(this.document, page);
      if (!member || page === "profile" && isOwnProfile(this.document)) {
        this.teardown();
        return;
      }
      const target = {
        memberId: member.memberId,
        anchor: member.anchor,
        key: `${page}|${member.memberId}`
      };
      if (target.key !== this.#key) {
        this.#forget();
        this.teardown();
        this.#key = target.key;
      }
      const data = this.#data?.key === target.key ? this.#data.value : void 0;
      if (!data) {
        this.#load(target);
        return;
      }
      this.#render(target, data);
    }
    /** Read the note again, keeping any typed text. */
    invalidate() {
      this.#generation += 1;
      this.#data = void 0;
      this.#inFlight = void 0;
      if (this.#page) this.update(this.#page);
    }
    /**
     * The active account changed. The editor shows the previous account's
     * note, so it goes at once, and typed text is dropped: it must never be
     * saved into the newly active account.
     */
    accountChanged() {
      this.teardown();
      this.#forget();
      this.invalidate();
    }
    /**
     * Called when the page is no longer a conversation or profile. JoyClub can
     * hide the header for a moment while it re-renders, so typed text is kept
     * for the same member; another member or account drops it.
     */
    leave() {
      this.#page = void 0;
      this.#generation += 1;
      this.#inFlight = void 0;
      this.#data = void 0;
      this.#status = void 0;
      this.teardown();
    }
    /**
     * The language changed: draw the editor again. Typed text, the open state
     * and the status stay; the status is shown in the new language.
     */
    localeChanged() {
      this.#rendered = "";
      if (this.#page) this.update(this.#page);
    }
    teardown() {
      for (const node of Array.from(
        this.document.querySelectorAll(`[${UI_ATTRIBUTE}="${MEMBER_NOTES}"]`)
      ))
        node.remove();
      removeEmptyStrip(this.document);
      this.#rendered = "";
    }
    #forget() {
      this.#dropTyped();
      this.#key = void 0;
      this.#data = void 0;
      this.#accountId = void 0;
      this.#open = void 0;
      this.#status = void 0;
    }
    /** Typed text belongs to one member and account; answers to it lapse. */
    #dropTyped() {
      this.#session += 1;
      this.#draft = void 0;
      this.#tagDraft = "";
    }
    #element() {
      return this.document.querySelector(`[${UI_ATTRIBUTE}="${MEMBER_NOTES}"]`);
    }
    #load(target) {
      if (this.#inFlight === target.key) return;
      this.#inFlight = target.key;
      const generation = this.#generation;
      this.client.getNotes(target.memberId).then((value) => {
        if (generation !== this.#generation || this.#key !== target.key) return;
        this.#inFlight = void 0;
        const accountId = value.status === "ok" ? value.accountId : void 0;
        if (this.#accountId !== void 0 && accountId !== this.#accountId) {
          const typed = this.#draft !== void 0 || this.#tagDraft !== "";
          this.#dropTyped();
          if (typed) this.#status = { text: NOTES_TEXT.refused, error: true };
          else if (this.#status?.text !== NOTES_TEXT.refused)
            this.#status = void 0;
          this.#rendered = "";
        }
        this.#accountId = accountId;
        this.#data = { key: target.key, value };
        if (this.#page) this.update(this.#page);
      }).catch(() => {
        if (generation !== this.#generation || this.#inFlight !== target.key)
          return;
        this.#inFlight = void 0;
        this.teardown();
      });
    }
    #render(target, data) {
      if (data.status !== "ok") {
        this.teardown();
        return;
      }
      const existing = this.#element();
      const key2 = JSON.stringify([target.key, data]);
      if (existing && key2 === this.#rendered && isPlaced(existing, target.anchor))
        return;
      const focus = this.#focusState(existing);
      existing?.remove();
      const section = this.#build(target, data);
      placeInStrip(this.document, target.anchor, section);
      this.#rendered = key2;
      this.#restoreFocus(section, focus);
    }
    #build(target, data) {
      const document2 = this.document;
      const section = element(document2, "section", "joyfox-panel joyfox-notes");
      section.setAttribute(UI_ATTRIBUTE, MEMBER_NOTES);
      section.setAttribute("data-member", target.memberId);
      section.setAttribute("role", "group");
      section.setAttribute("aria-label", t("notes.region"));
      const details = element(document2, "details", "joyfox-notes__details");
      details.open = this.#open ?? false;
      details.addEventListener("toggle", () => {
        if (details.isConnected) this.#open = details.open;
      });
      const summary = element(
        document2,
        "summary",
        "joyfox-notes__summary",
        summaryText(data)
      );
      summary.setAttribute(CONTROL, "summary");
      details.append(
        summary,
        element(document2, "p", "joyfox-note", t(NOTES_TEXT.scope))
      );
      const noteLabel = element(
        document2,
        "label",
        "joyfox-notes__label",
        t("notes.privateNote")
      );
      noteLabel.htmlFor = "joyfox-note-text";
      const note = element(document2, "textarea", "joyfox-notes__text");
      note.id = "joyfox-note-text";
      note.rows = 3;
      note.maxLength = MAX_NOTE_LENGTH;
      note.setAttribute(CONTROL, "note");
      note.value = this.#draft?.text ?? data.note ?? "";
      const discard = button(
        document2,
        "joyfox-button",
        t("notes.discard"),
        () => {
          this.#draft = void 0;
          this.#setStatus(void 0);
          this.#rendered = "";
          if (this.#page) this.update(this.#page);
        }
      );
      discard.setAttribute(CONTROL, "discard-note");
      discard.disabled = this.#draft === void 0;
      note.addEventListener("input", () => {
        this.#draft = {
          text: note.value,
          base: this.#draft ? this.#draft.base : data.note
        };
        discard.disabled = false;
      });
      const save = button(
        document2,
        "joyfox-button",
        t("notes.save"),
        () => this.#saveNote(target, data, note.value)
      );
      save.setAttribute(CONTROL, "save-note");
      const noteActions = element(document2, "div", "joyfox-actions");
      noteActions.append(save, discard);
      const length = noteLength(
        document2,
        note,
        "joyfox-note-length",
        () => this.#setStatus({ text: NOTES_TEXT.pasteCut, error: true })
      );
      details.append(noteLabel, note, length, noteActions);
      details.append(
        element(document2, "h3", "joyfox-notes__heading", t("notes.tags"))
      );
      if (data.tags.length === 0)
        details.append(element(document2, "p", "joyfox-note", t("notes.noTags")));
      else {
        const list = element(document2, "ul", "joyfox-notes__tags");
        list.setAttribute("aria-label", t("notes.tags"));
        for (const label of data.tags) {
          const item = element(document2, "li", "joyfox-notes__tag");
          const remove = button(
            document2,
            "joyfox-button",
            t("notes.remove"),
            () => this.#removeTag(target, data, label)
          );
          remove.setAttribute("aria-label", t("notes.removeTag", { label }));
          remove.setAttribute(CONTROL, `remove-tag:${label}`);
          item.append(element(document2, "span", "", label), remove);
          list.append(item);
        }
        details.append(list);
      }
      const tagLabel2 = element(
        document2,
        "label",
        "joyfox-notes__label",
        t("notes.addTagLabel")
      );
      tagLabel2.htmlFor = "joyfox-tag-input";
      const tagInput = element(document2, "input", "joyfox-notes__tag-input");
      tagInput.type = "text";
      tagInput.id = "joyfox-tag-input";
      tagInput.maxLength = MAX_TAG_LENGTH;
      tagInput.setAttribute(CONTROL, "tag-input");
      tagInput.value = this.#tagDraft;
      tagInput.addEventListener("input", () => {
        this.#tagDraft = tagInput.value;
      });
      tagInput.addEventListener("keydown", (event) => {
        if (event.key !== "Enter" || event.isComposing) return;
        event.preventDefault();
        event.stopPropagation();
        this.#addTag(target, data, tagInput.value);
      });
      const add = button(
        document2,
        "joyfox-button",
        t("notes.addTag"),
        () => this.#addTag(target, data, tagInput.value)
      );
      add.setAttribute(CONTROL, "add-tag");
      const tagRow = element(document2, "div", "joyfox-actions");
      tagRow.append(tagInput, add);
      details.append(tagLabel2, tagRow);
      const status = element(document2, "p", "joyfox-notes__status");
      status.setAttribute("role", "status");
      status.setAttribute("aria-live", "polite");
      details.append(status);
      section.append(details);
      this.#showStatus(status);
      return section;
    }
    #saveNote(target, data, body) {
      const session = this.#session;
      if (this.#savingSession === session) return;
      const expected = this.#draft ? this.#draft.base : data.note;
      if (body.trim().length === 0 && expected === null) {
        this.#setStatus({ text: NOTES_TEXT.emptyNote, error: true });
        return;
      }
      this.#savingSession = session;
      this.#write(session, async () => {
        const answer = await this.client.saveNote(data.accountId, target.memberId, body, expected).finally(() => {
          if (this.#savingSession === session) this.#savingSession = void 0;
        });
        if (this.#session !== session) return;
        if (answer.status === "refused") {
          this.#dropTyped();
          this.#setStatus({ text: NOTES_TEXT.refused, error: true });
          return;
        }
        if (answer.status === "conflict") {
          this.#draft = { text: this.#draft?.text ?? body, base: answer.current };
          this.#setStatus({ text: NOTES_TEXT.conflict, error: true });
          return;
        }
        if (this.#draft && this.#draft.text !== body)
          this.#draft = { text: this.#draft.text, base: answer.current };
        else this.#draft = void 0;
        this.#setStatus({
          text: answer.current === null ? NOTES_TEXT.removed : NOTES_TEXT.saved,
          error: false
        });
      });
    }
    #addTag(target, data, label) {
      const typed = label;
      if (label.trim().length === 0) {
        this.#setStatus({ text: NOTES_TEXT.emptyTag, error: true });
        return;
      }
      const session = this.#session;
      this.#write(session, async () => {
        const done = await this.client.addTag(
          data.accountId,
          target.memberId,
          label
        );
        if (this.#session !== session) return;
        if (!done) {
          this.#dropTyped();
          this.#setStatus({ text: NOTES_TEXT.refused, error: true });
          return;
        }
        if (this.#tagDraft === typed) this.#tagDraft = "";
        this.#setStatus({
          text: done === "exists" ? NOTES_TEXT.tagExists : NOTES_TEXT.tagAdded,
          error: false
        });
      });
    }
    #removeTag(target, data, label) {
      const session = this.#session;
      this.#write(session, async () => {
        const done = await this.client.removeTag(
          data.accountId,
          target.memberId,
          label
        );
        if (this.#session !== session) return;
        if (!done) this.#dropTyped();
        this.#setStatus(
          done ? { text: NOTES_TEXT.tagRemoved, error: false } : { text: NOTES_TEXT.refused, error: true }
        );
      });
    }
    /**
     * Writes run one after another, in click order, then the note is read
     * again. A failure keeps typed text and says nothing was changed.
     */
    #write(session, action) {
      this.#writeQueue = this.#writeQueue.then(
        () => action().catch(() => {
          if (this.#session === session)
            this.#setStatus({ text: NOTES_TEXT.failed, error: true });
        }).then(() => {
          this.#rendered = "";
          this.invalidate();
        })
      );
    }
    /** Shown in place, so a status change does not redraw the editor. */
    #setStatus(status) {
      this.#status = status;
      const node = this.#element()?.querySelector(
        ".joyfox-notes__status"
      );
      if (node) this.#showStatus(node);
    }
    #showStatus(node) {
      node.textContent = this.#status ? t(this.#status.text) : "";
      node.classList.toggle("joyfox-error", this.#status?.error === true);
    }
    #focusState(existing) {
      const active = this.document.activeElement;
      if (!existing || !active || !existing.contains(active)) return void 0;
      const control = active.getAttribute(CONTROL);
      if (!control) return void 0;
      const field = active;
      return "selectionStart" in field ? { control, start: field.selectionStart, end: field.selectionEnd } : { control };
    }
    #restoreFocus(section, focus) {
      if (!focus) return;
      const find = (control) => Array.from(section.querySelectorAll(`[${CONTROL}]`)).find(
        (node) => node.getAttribute(CONTROL) === control
      );
      const usable2 = (node) => node && !node.disabled ? node : void 0;
      const fallback2 = focus.control.startsWith("remove-tag:") ? "tag-input" : focus.control === "discard-note" || focus.control === "save-note" ? "note" : void 0;
      const target = usable2(find(focus.control)) ?? (fallback2 ? usable2(find(fallback2)) : void 0);
      if (!target) return;
      if (target.closest("details:not([open])") && target.tagName !== "SUMMARY")
        return;
      target.focus({ preventScroll: true });
      if (focus.start !== void 0 && focus.start !== null && "setSelectionRange" in target)
        target.setSelectionRange(
          focus.start,
          focus.end ?? focus.start
        );
    }
  };
  var LENGTH_SHOWN_FROM = 0.9;
  function noteLength(document2, field, id, onCut) {
    const shown = element(document2, "span", "joyfox-note-length");
    shown.id = id;
    field.setAttribute("aria-describedby", id);
    const show = () => {
      const count = field.value.length;
      shown.textContent = count >= MAX_NOTE_LENGTH * LENGTH_SHOWN_FROM ? t("notes.length", { count, maximum: MAX_NOTE_LENGTH }) : "";
    };
    field.addEventListener("input", show);
    field.addEventListener("paste", (event) => {
      const pasted = (event.clipboardData?.getData("text/plain") ?? "").replace(
        /\r\n?/gu,
        "\n"
      );
      const start = field.selectionStart ?? field.value.length;
      const end = field.selectionEnd ?? start;
      const room = MAX_NOTE_LENGTH - (field.value.length - (end - start));
      if (pasted.length > room) onCut();
    });
    show();
    return shown;
  }
  function summaryText(data) {
    const count = data.tags.length;
    if (data.note !== null)
      return count > 0 ? t("notes.summary.noteAndTags", { count }) : t("notes.summary.note");
    return count > 0 ? t("notes.summary.tags", { count }) : t("notes.summary.none");
  }

  // src/content/card-note-editor.ts
  var CARD_EDITOR = "card-editor";
  function fallbacks(memo) {
    if (memo?.key.startsWith("remove:")) return ["tag", "close"];
    if (memo?.key === "discard" || memo?.key === "save") return ["note", "close"];
    return ["close"];
  }
  var CardNoteEditor = class {
    constructor(document2, client, noteButton = () => void 0) {
      this.document = document2;
      this.client = client;
      this.noteButton = noteButton;
    }
    #root;
    #heading;
    /** The part each draw replaces; the heading, notice and Close stay. */
    #body;
    #statusNode;
    #closeButton;
    #memberId;
    #name;
    #data;
    #status;
    #returnFocus;
    /** The note box takes focus once drawn, while focus is still on the panel. */
    #focusNote = false;
    /** Bumped on open and close, so a late answer is dropped. */
    #session = 0;
    #loadSequence = 0;
    /** Set while the shown notice is a failed read's. */
    #readFailed = false;
    #busy = false;
    /**
     * Typed text not saved yet, and the stored note it was typed over. A save
     * names that note, not one read later, so a newer note from another tab is
     * reported as a conflict instead of being overwritten unseen.
     */
    #noteDraft;
    #tagDraft = "";
    /** The member as the title names them: the nickname, else the number. */
    #member(memberId) {
      return this.#name ?? t(message("member.number", { id: memberId }));
    }
    get memberId() {
      return this.#memberId;
    }
    /** `name`: the nickname the card shows, for the editor's title. */
    open(memberId, returnFocus, name) {
      this.close();
      this.#memberId = memberId;
      this.#name = name;
      this.#returnFocus = returnFocus;
      const document2 = this.document;
      const root = element(document2, "div", "joyfox-panel joyfox-card-editor");
      root.setAttribute(UI_ATTRIBUTE, CARD_EDITOR);
      root.setAttribute("role", "dialog");
      root.tabIndex = -1;
      root.addEventListener("keydown", (event) => {
        if (event.key === "Escape") this.close();
      });
      const heading = element(document2, "strong", "joyfox-card-editor__heading");
      const body = element(document2, "div", "joyfox-card-editor__body");
      const status = element(document2, "p", "joyfox-card-editor__status");
      status.setAttribute("role", "status");
      status.setAttribute("aria-live", "polite");
      const close = button(document2, "joyfox-button", "", () => this.close());
      close.setAttribute(FOCUS_KEY, "close");
      root.append(heading, body, status, close);
      this.#root = root;
      this.#heading = heading;
      this.#body = body;
      this.#statusNode = status;
      this.#closeButton = close;
      this.#focusNote = true;
      document2.body.append(root);
      this.#draw();
      root.focus({ preventScroll: true });
      void this.#load();
    }
    close() {
      const memberId = this.#memberId;
      const root = this.#root;
      const active = this.document.activeElement;
      const hadFocus = !active || active === this.document.body || root?.contains(active);
      this.#session += 1;
      root?.remove();
      this.#root = void 0;
      this.#heading = void 0;
      this.#body = void 0;
      this.#statusNode = void 0;
      this.#closeButton = void 0;
      this.#memberId = void 0;
      this.#name = void 0;
      this.#data = void 0;
      this.#status = void 0;
      this.#busy = false;
      this.#noteDraft = void 0;
      this.#tagDraft = "";
      this.#readFailed = false;
      this.#focusNote = false;
      const focus = this.#returnFocus;
      this.#returnFocus = void 0;
      if (!root || !hadFocus) return;
      const target = focus?.isConnected ? focus : memberId ? this.noteButton(memberId) : void 0;
      target?.focus({ preventScroll: true });
    }
    /** Another tab or the account changed: read the member again. */
    invalidate() {
      if (this.#memberId) void this.#load();
    }
    localeChanged() {
      if (this.#root) this.#draw();
    }
    async #load() {
      const session = this.#session;
      const sequence = this.#loadSequence += 1;
      const current = () => session === this.#session && sequence === this.#loadSequence;
      const memberId = this.#memberId;
      if (!memberId) return;
      try {
        const answer = await this.client.getNotes(memberId);
        if (!current()) return;
        const account = answer.status === "ok" ? answer.accountId : void 0;
        if (this.#data && this.#data.accountId !== account) {
          this.#noteDraft = void 0;
          this.#tagDraft = "";
          this.#status = void 0;
        }
        if (answer.status !== "ok") {
          this.#data = void 0;
          this.#status = {
            text: message("signals.editor.noAccount"),
            error: true
          };
        } else {
          this.#data = answer;
          if (this.#readFailed) this.#status = void 0;
        }
        this.#readFailed = false;
      } catch {
        if (!current()) return;
        this.#readFailed = true;
        this.#status = {
          text: message("signals.editor.readFailed"),
          error: true
        };
      }
      this.#draw();
    }
    /** Runs one write, then reads the member again. */
    async #write(action) {
      const data = this.#data;
      if (!data || this.#busy) return;
      const session = this.#session;
      this.#busy = true;
      this.#draw();
      let status;
      try {
        status = await action(data);
      } catch {
        status = { text: message(NOTES_TEXT.failed), error: true };
      }
      if (session !== this.#session) return;
      this.#busy = false;
      this.#status = status;
      await this.#load();
    }
    /** Shown in place, so the live region stays the same node. */
    #showStatus() {
      const node = this.#statusNode;
      if (!node) return;
      const text2 = this.#status ? t(this.#status.text) : "";
      if (node.textContent !== text2) node.textContent = text2;
      node.classList.toggle("joyfox-error", this.#status?.error === true);
    }
    #draw() {
      const root = this.#root;
      const body = this.#body;
      const memberId = this.#memberId;
      if (!root || !body || !memberId) return;
      const document2 = this.document;
      const memo = rememberFocus(root);
      const label = t(
        message("signals.editor.label", { member: this.#member(memberId) })
      );
      root.setAttribute("aria-label", label);
      if (this.#heading && this.#heading.textContent !== label)
        this.#heading.textContent = label;
      const close = t("signals.editor.close");
      if (this.#closeButton && this.#closeButton.textContent !== close)
        this.#closeButton.textContent = close;
      body.replaceChildren();
      const data = this.#data;
      if (data) body.append(...this.#fields(data, memberId));
      else if (!this.#status)
        body.append(
          element(document2, "p", "joyfox-note", t("signals.editor.loading"))
        );
      this.#showStatus();
      restoreFocus(root, memo, fallbacks(memo));
      if (data && this.#focusNote) {
        this.#focusNote = false;
        if (document2.activeElement === root)
          root.querySelector(`[${FOCUS_KEY}="note"]`)?.focus({ preventScroll: true });
      }
    }
    #fields(data, memberId) {
      const document2 = this.document;
      const busy = this.#busy;
      const unavailable = (control) => {
        if (busy) control.setAttribute("aria-disabled", "true");
        return control;
      };
      const noteId = `joyfox-card-note-${memberId}`;
      const noteLabel = element(document2, "label", "", t("notes.privateNote"));
      noteLabel.htmlFor = noteId;
      const note = element(document2, "textarea", "joyfox-card-editor__note");
      note.id = noteId;
      note.maxLength = MAX_NOTE_LENGTH;
      note.rows = 3;
      note.readOnly = busy;
      note.setAttribute(FOCUS_KEY, "note");
      note.value = this.#noteDraft?.text ?? data.note ?? "";
      const discard = unavailable(
        button(document2, "joyfox-button", t("notes.discard"), () => {
          if (this.#busy) return;
          this.#noteDraft = void 0;
          this.#status = void 0;
          this.#draw();
        })
      );
      discard.setAttribute(FOCUS_KEY, "discard");
      discard.disabled = this.#noteDraft === void 0;
      note.addEventListener("input", () => {
        this.#noteDraft = {
          text: note.value,
          base: this.#noteDraft ? this.#noteDraft.base : data.note
        };
        discard.disabled = false;
      });
      const length = noteLength(
        document2,
        note,
        `joyfox-card-note-length-${memberId}`,
        () => {
          this.#status = { text: message(NOTES_TEXT.pasteCut), error: true };
          this.#showStatus();
        }
      );
      const save = unavailable(
        button(
          document2,
          "joyfox-button",
          t("notes.save"),
          () => void this.#write(async (current) => {
            const body = note.value;
            const expected = this.#noteDraft ? this.#noteDraft.base : current.note;
            if (!body.trim() && expected === null)
              return { text: message(NOTES_TEXT.emptyNote), error: true };
            const answer = await this.client.saveNote(
              current.accountId,
              memberId,
              body,
              expected
            );
            if (answer.status === "saved") {
              this.#noteDraft = void 0;
              return {
                text: message(
                  answer.current === null ? NOTES_TEXT.removed : NOTES_TEXT.saved
                ),
                error: false
              };
            }
            if (answer.status === "conflict")
              this.#noteDraft = {
                text: this.#noteDraft?.text ?? body,
                base: answer.current
              };
            return {
              text: message(
                answer.status === "conflict" ? NOTES_TEXT.conflict : NOTES_TEXT.refused
              ),
              error: true
            };
          })
        )
      );
      save.setAttribute(FOCUS_KEY, "save");
      const noteActions = element(document2, "div", "joyfox-actions");
      noteActions.append(save, discard);
      const tagsHeading = element(document2, "p", "", t("notes.tags"));
      const list = element(document2, "ul", "joyfox-card-editor__tags");
      for (const label of data.tags) {
        const item = element(document2, "li", "", label);
        const remove = unavailable(
          button(
            document2,
            "joyfox-button",
            t("notes.remove"),
            () => void this.#write(async (current) => {
              const done = await this.client.removeTag(
                current.accountId,
                memberId,
                label
              );
              return done ? { text: message(NOTES_TEXT.tagRemoved), error: false } : { text: message(NOTES_TEXT.refused), error: true };
            })
          )
        );
        remove.setAttribute(
          "aria-label",
          t(message("notes.removeTag", { label }))
        );
        remove.setAttribute(FOCUS_KEY, `remove:${label}`);
        item.append(" ", remove);
        list.append(item);
      }
      if (data.tags.length === 0)
        list.append(element(document2, "li", "", t("notes.noTags")));
      const tagId = `joyfox-card-tag-${memberId}`;
      const tagLabel2 = element(document2, "label", "", t("notes.addTagLabel"));
      tagLabel2.htmlFor = tagId;
      const tag = element(document2, "input", "joyfox-card-editor__tag");
      tag.id = tagId;
      tag.maxLength = MAX_TAG_LENGTH;
      tag.readOnly = busy;
      tag.setAttribute(FOCUS_KEY, "tag");
      tag.value = this.#tagDraft;
      tag.addEventListener("input", () => {
        this.#tagDraft = tag.value;
      });
      const addTag = () => void this.#write(async (current) => {
        const label = tag.value.trim();
        if (!label) return { text: message(NOTES_TEXT.emptyTag), error: true };
        const done = await this.client.addTag(
          current.accountId,
          memberId,
          label
        );
        if (!done) return { text: message(NOTES_TEXT.refused), error: true };
        this.#tagDraft = "";
        return {
          text: message(
            done === "exists" ? NOTES_TEXT.tagExists : NOTES_TEXT.tagAdded
          ),
          error: false
        };
      });
      tag.addEventListener("keydown", (event) => {
        if (event.key !== "Enter" || event.isComposing) return;
        event.preventDefault();
        event.stopPropagation();
        if (tag.readOnly) return;
        addTag();
      });
      const add = unavailable(
        button(document2, "joyfox-button", t("notes.addTag"), addTag)
      );
      add.setAttribute(FOCUS_KEY, "add");
      return [
        element(document2, "p", "joyfox-note", t(NOTES_TEXT.scope)),
        noteLabel,
        note,
        length,
        noteActions,
        tagsHeading,
        list,
        tagLabel2,
        tag,
        add
      ];
    }
  };

  // src/content/member-cards.ts
  function shownName(value) {
    const name = value?.replace(/\s+/gu, " ").trim();
    return name ? name : void 0;
  }
  var COMPAT_BADGE = "compat-badge";
  function linkMember(document2, link, source) {
    const id = memberIdFromProfileHref(
      link.getAttribute("href"),
      document2.URL,
      source
    );
    return id.status === "found" ? id.value : void 0;
  }
  function shieldCode(element2) {
    const raw = element2.getAttribute("verification-status");
    const value = raw === null ? Number.NaN : Number(raw);
    return Number.isInteger(value) && value >= 0 ? { status: "found", value, source: "search.resultCard" } : { status: "missing", source: "search.resultCard" };
  }
  function searchCards(document2) {
    const linkSelector = verifiedSelector("search", "resultLink");
    const cardSelector = verifiedSelector("search", "resultCard");
    if (!linkSelector) return [];
    const cards = [];
    for (const link of Array.from(document2.querySelectorAll(linkSelector))) {
      const memberId = linkMember(document2, link, "search.resultLink");
      if (!memberId) continue;
      const card = cardSelector ? link.querySelector(cardSelector) : null;
      const badgeHost = card ?? link;
      const nameSelector = verifiedSelector("search", "resultName");
      const named = nameSelector ? link.querySelector(nameSelector) : null;
      const name = shownName(named?.getAttribute("user-name"));
      cards.push({
        surface: "search",
        memberId,
        ...name ? { name } : {},
        observed: card ? observedFromShield(shieldCode(card)) : {},
        badgeHost,
        // A light-DOM child with this slot draws over the card's photo
        // (11-search.md, "Badge slots").
        placeBadge: (badge) => {
          badge.setAttribute("slot", "badge-top-right");
          badgeHost.append(badge);
        },
        // The JoyFox line goes over the photo, in the card's `media-overlay`
        // slot. Placed after the card, it overflowed JoyClub's grid row and the
        // next row covered it (owner's live check, 2026-09-27).
        signalsHost: badgeHost,
        placeSignals: (group) => placeInCardLine(
          badgeHost,
          group,
          card ? { slot: "media-overlay" } : {}
        )
      });
    }
    return cards;
  }
  function inboxCards(document2) {
    const cards = [];
    for (const row of extractInboxRows(document2, document2.URL)) {
      if (row.memberId.status !== "found") continue;
      const host = row.row;
      const name = row.senderName.status === "found" ? shownName(row.senderName.value) : void 0;
      cards.push({
        surface: "inbox",
        memberId: row.memberId.value,
        ...name ? { name } : {},
        observed: observedFromInboxRow(row),
        badgeHost: host,
        placeBadge: (badge) => placeInInboxLine(host, badge),
        signalsHost: host,
        placeSignals: (group) => placeInInboxLine(host, group)
      });
    }
    return cards;
  }
  function attendeeCards(document2) {
    const entrySelector = verifiedSelector("event", "attendeeEntry");
    const infoSelector = verifiedSelector("event", "attendeeInfo");
    const nameSelector = verifiedSelector("event", "attendeeNickname");
    if (!entrySelector) return [];
    const cards = [];
    for (const entry of Array.from(document2.querySelectorAll(entrySelector))) {
      const memberId = linkMember(document2, entry, "event.attendeeEntry");
      if (!memberId) continue;
      const host = (infoSelector ? entry.querySelector(infoSelector) : null) ?? entry;
      const name = nameSelector ? shownName(entry.querySelector(nameSelector)?.textContent) : void 0;
      cards.push({
        surface: "attendees",
        memberId,
        ...name ? { name } : {},
        // A guest entry shows a check icon, but no shield code (14-events.md).
        observed: {},
        badgeHost: host,
        placeBadge: (badge) => placeInCardLine(host, badge),
        signalsHost: host,
        placeSignals: (group) => placeInCardLine(host, group)
      });
    }
    return cards;
  }
  function memberCards(document2, type) {
    const surfaces = [];
    if (type === "search") surfaces.push(["search", searchCards(document2)]);
    if (inboxListShown(document2)) surfaces.push(["inbox", inboxCards(document2)]);
    if (type === "event") surfaces.push(["attendees", attendeeCards(document2)]);
    return surfaces;
  }
  function resultItems(document2) {
    const linkSelector = verifiedSelector("search", "resultLink");
    if (!linkSelector) return void 0;
    const links = Array.from(document2.querySelectorAll(linkSelector));
    let container = links[0]?.parentElement ?? null;
    while (container && !links.every((link) => container?.contains(link)))
      container = container.parentElement;
    if (!container) return void 0;
    const items = [];
    for (const link of links) {
      let item = link;
      while (item && item.parentElement !== container) item = item.parentElement;
      if (item && !items.includes(item)) items.push(item);
    }
    return { container, items };
  }

  // src/content/card-signals.ts
  function messageSignalsClient(sender) {
    return {
      lookup: (members) => request(sender, "signals.lookup", { members }),
      names: (accountId, names) => request(sender, "member.names", { accountId, names })
    };
  }
  function runtimeSignalsClient() {
    return messageSignalsClient(
      (message2) => browser.runtime.sendMessage(message2)
    );
  }
  var MAX_NAMES_PER_SEND = 200;
  var CARD_SIGNALS = "card-signals";
  var COMPLETENESS_SECTION = "completeness";
  var FILTER_BAR = "signals-filter";
  var HIDE_ATTRIBUTE = "data-joyfox-hide-incomplete";
  var INCOMPLETE_ATTRIBUTE = "data-joyfox-incomplete";
  var STATE_TEXT = {
    complete: "signals.state.complete",
    incomplete: "signals.state.incomplete",
    unknown: "signals.state.unknown"
  };
  function completenessText(value) {
    const parts = [
      value.photoCount === "unknown" ? t("signals.photosUnknown") : t(message("signals.photos", { count: value.photoCount })),
      value.profileWordCount === "unknown" ? t("signals.wordsUnknown") : t(message("signals.words", { count: value.profileWordCount })),
      t(
        value.verification === "unknown" ? "signals.verificationUnknown" : value.verification ? "signals.verified" : "signals.notVerified"
      )
    ];
    return `${t(STATE_TEXT[value.state])}: ${parts.join(", ")}`;
  }
  function trustText(signals) {
    return signals.trust === "unknown" ? t("trust.score.none") : t(message("trust.score.value", { score: signals.trust.score }));
  }
  var requestKey = (card) => `${card.memberId}|${factsKey(card.observed)}|${card.noShield === true}`;
  var cardRequest = (surface, card) => ({
    memberId: card.memberId,
    observed: card.observed,
    ...surface === "attendees" ? { noShield: true } : {}
  });
  var CardSignals = class {
    constructor(document2, client, notes) {
      this.document = document2;
      this.client = client;
      this.#editor = new CardNoteEditor(
        document2,
        notes,
        (memberId) => this.#noteButton(memberId)
      );
    }
    #type;
    #data = /* @__PURE__ */ new Map();
    #pending = /* @__PURE__ */ new Set();
    #reload = false;
    #failed = false;
    /** The cards shown when the lookup failed. */
    #failedFor = "";
    #session = 0;
    #version = 0;
    #hide = false;
    #accountId;
    #rendered = "";
    #editor;
    /** Where the editor was opened, so focus returns to a card there. */
    #editorSurface;
    /** `account|member|nickname` already sent from this tab. */
    #namesSent = /* @__PURE__ */ new Set();
    /** The member's note button now, on a card where the editor opened. */
    #noteButton(memberId) {
      const groups = Array.from(
        this.document.querySelectorAll(
          `[${UI_ATTRIBUTE}="${CARD_SIGNALS}"]`
        )
      ).filter((group2) => group2.getAttribute("data-member") === memberId);
      const group = groups.find(
        (node) => node.getAttribute("data-surface") === this.#editorSurface
      ) ?? groups[0];
      return group?.querySelector(".joyfox-signals__note") ?? void 0;
    }
    update(type) {
      this.#type = type;
      const wanted = this.#requests();
      const reload = this.#reload;
      this.#reload = false;
      const missing2 = wanted.filter(
        (item) => reload || !this.#data.has(requestKey(item)) && !this.#pending.has(requestKey(item))
      );
      const shownKey = JSON.stringify(wanted.map(requestKey).sort());
      if (this.#failed && shownKey !== this.#failedFor) this.#failed = false;
      if (missing2.length > 0 && !this.#failed) void this.#load(missing2, shownKey);
      this.#draw();
    }
    leave() {
      this.update(void 0);
    }
    /** Another account's notes and scores must never stay on screen. */
    accountChanged() {
      this.#session += 1;
      this.#data.clear();
      this.#pending.clear();
      this.#failed = false;
      this.#hide = false;
      this.#accountId = void 0;
      this.#editor.close();
      this.#clearAll();
      this.update(this.#type);
    }
    /** A note, tag, outcome or snapshot changed: read again, keep what shows. */
    invalidate() {
      this.#session += 1;
      this.#pending.clear();
      this.#failed = false;
      this.#reload = true;
      this.#editor.invalidate();
      this.update(this.#type);
    }
    localeChanged() {
      this.#version += 1;
      this.#rendered = "";
      this.#editor.localeChanged();
      this.#draw();
    }
    /** The members the page shows, with what each card shows of them. */
    #requests() {
      const seen = /* @__PURE__ */ new Map();
      const add = (item) => seen.set(requestKey(item), item);
      for (const [surface, cards] of memberCards(this.document, this.#type))
        for (const card of cards) add(cardRequest(surface, card));
      const profile = this.#profile();
      if (profile)
        add({ memberId: profile.memberId, observed: profile.observed });
      return [...seen.values()];
    }
    #profile() {
      if (this.#type !== "profile") return void 0;
      const member = pageMember(this.document, "profile");
      if (!member || member.page !== "profile") return void 0;
      return {
        memberId: member.memberId,
        anchor: member.anchor,
        observed: observedFromProfile(member.extraction)
      };
    }
    async #load(members, shownKey) {
      const session = this.#session;
      for (const item of members) this.#pending.add(requestKey(item));
      for (let start = 0; start < members.length; start += MAX_SIGNAL_MEMBERS) {
        const chunk = members.slice(start, start + MAX_SIGNAL_MEMBERS);
        let answer;
        try {
          answer = await this.client.lookup(chunk);
        } catch {
          if (session !== this.#session) return;
          this.#failed = true;
          this.#failedFor = shownKey;
          for (const item of chunk) this.#pending.delete(requestKey(item));
          continue;
        }
        if (session !== this.#session) return;
        if (answer.status === "no-account") {
          this.#accountId = null;
          for (const item of chunk) {
            this.#pending.delete(requestKey(item));
            this.#data.delete(requestKey(item));
          }
        } else {
          this.#accountId = answer.accountId;
          for (const item of chunk) {
            this.#pending.delete(requestKey(item));
            const signals = answer.signals[item.memberId];
            if (signals) this.#data.set(requestKey(item), signals);
          }
        }
        this.#draw();
      }
    }
    #draw() {
      const shown = memberCards(this.document, this.#type);
      const active = new Set(shown.map(([surface]) => surface));
      for (const surface of ["search", "inbox", "attendees"])
        if (!active.has(surface)) this.#clear(surface);
      for (const [surface, cards] of shown)
        for (const card of cards) this.#group(surface, card);
      if (this.#type === "search") this.#drawFilter(shown);
      else this.#removeFilter();
      if (this.#type === "profile") this.#drawProfile();
      else this.#removeSection();
      this.#keepNames(shown);
    }
    /**
     * Send the nicknames the cards show, each once per account and tab, so
     * JoyFox's own texts can name the member (owner decision, 2026-09-27).
     * Only for the account the cards' signals came from.
     */
    #keepNames(shown) {
      const accountId = this.#accountId;
      if (!accountId || !this.client.names) return;
      const names = /* @__PURE__ */ new Map();
      for (const [, cards] of shown)
        for (const card of cards) {
          const key2 = `${accountId}|${card.memberId}|${card.name}`;
          if (card.name && !this.#namesSent.has(key2)) {
            this.#namesSent.add(key2);
            names.set(card.memberId, {
              memberId: card.memberId,
              nickname: card.name
            });
          }
        }
      const list = [...names.values()];
      for (let start = 0; start < list.length; start += MAX_NAMES_PER_SEND) {
        const batch = list.slice(start, start + MAX_NAMES_PER_SEND);
        const forget = () => {
          for (const { memberId, nickname } of batch)
            this.#namesSent.delete(`${accountId}|${memberId}|${nickname}`);
        };
        void this.client.names(accountId, batch).then((answer) => {
          if (answer.status !== "ok") forget();
        }).catch(forget);
      }
    }
    #group(surface, card) {
      const existing = card.signalsHost.querySelector(
        `[${UI_ATTRIBUTE}="${CARD_SIGNALS}"]`
      );
      const signals = this.#data.get(requestKey(cardRequest(surface, card)));
      if (!signals || !this.#accountId) return existing?.remove();
      const version2 = JSON.stringify([
        card.memberId,
        card.name,
        signals,
        this.#version
      ]);
      if (existing?.getAttribute("data-joyfox-version") === version2) return;
      const document2 = this.document;
      const group = element(document2, "span", "joyfox-signals");
      group.setAttribute(UI_ATTRIBUTE, CARD_SIGNALS);
      group.setAttribute("data-surface", surface);
      group.setAttribute("data-member", card.memberId);
      group.setAttribute("data-joyfox-version", version2);
      const chip = (className, full, short) => {
        const node = element(document2, "span", `joyfox-badge ${className}`);
        if (short === full) {
          node.textContent = full;
          return node;
        }
        node.title = full;
        const shown = element(document2, "span", "", short);
        shown.setAttribute("aria-hidden", "true");
        node.append(
          shown,
          element(document2, "span", "joyfox-visually-hidden", full)
        );
        return node;
      };
      const { completeness: completeness2 } = signals;
      const state = chip(
        "joyfox-signals__completeness",
        completenessText(completeness2),
        t(
          completeness2.state === "unknown" ? "signals.state.unknownShort" : STATE_TEXT[completeness2.state]
        )
      );
      state.setAttribute("data-state", completeness2.state);
      group.append(
        state,
        chip(
          "joyfox-signals__trust",
          trustText(signals),
          signals.trust === "unknown" ? t("signals.trustNoneShort") : t(message("signals.trust", { score: signals.trust.score }))
        )
      );
      const noteText = t(
        signals.hasNote ? "signals.noteEdit" : "signals.noteAdd"
      );
      const note = button(
        document2,
        "joyfox-button joyfox-signals__note",
        "\u270E",
        () => {
          this.#editorSurface = surface;
          this.#editor.open(card.memberId, note, card.name);
        }
      );
      note.setAttribute(FOCUS_KEY, "note");
      note.title = noteText;
      note.setAttribute("aria-label", noteText);
      note.setAttribute("data-has-note", String(signals.hasNote));
      group.append(note);
      if (signals.tags.length > 0)
        group.append(
          chip(
            "joyfox-signals__tags",
            `${t("signals.tagsLabel")}: ${signals.tags.join(", ")}`,
            t(message("signals.tagCount", { count: signals.tags.length }))
          )
        );
      if (existing) {
        const focus = rememberFocus(existing);
        existing.replaceWith(group);
        restoreFocus(group, focus);
      } else card.placeSignals(group);
    }
    #clear(surface) {
      for (const node of Array.from(
        this.document.querySelectorAll(
          `[${UI_ATTRIBUTE}="${CARD_SIGNALS}"][data-surface="${surface}"]`
        )
      ))
        node.remove();
      if (surface === "search") this.#removeFilter();
      removeEmptyCardLines(this.document);
    }
    #clearAll() {
      for (const surface of ["search", "inbox", "attendees"])
        this.#clear(surface);
      this.#removeSection();
    }
    // --- Search filter ------------------------------------------------------
    #filterBar() {
      return this.document.querySelector(
        `[${UI_ATTRIBUTE}="${FILTER_BAR}"]`
      );
    }
    #drawFilter(shown) {
      const listSelector = verifiedSelector("search", "resultList");
      const list = listSelector ? this.document.querySelector(listSelector) : null;
      const results = resultItems(this.document);
      if (!list || !results) return this.#removeFilter();
      const cards = shown.find(([surface]) => surface === "search")?.[1] ?? [];
      let hidden = 0;
      for (const item of results.items) {
        const card = cards.find(
          (entry) => item === entry.signalsHost || item.contains(entry.signalsHost)
        );
        const state = card ? this.#data.get(requestKey(card))?.completeness.state : void 0;
        const incomplete = state === "incomplete";
        if (incomplete) hidden += 1;
        if (incomplete !== (item.getAttribute(INCOMPLETE_ATTRIBUTE) === "yes")) {
          if (incomplete) item.setAttribute(INCOMPLETE_ATTRIBUTE, "yes");
          else item.removeAttribute(INCOMPLETE_ATTRIBUTE);
        }
      }
      if (this.#hide) results.container.setAttribute(HIDE_ATTRIBUTE, "on");
      else results.container.removeAttribute(HIDE_ATTRIBUTE);
      const count = this.#hide ? message("signals.filter.count", {
        hidden,
        loaded: results.items.length
      }) : void 0;
      const key2 = JSON.stringify([this.#hide, count, this.#version]);
      const bar = this.#filterBar();
      if (bar?.getAttribute("data-joyfox-version") === key2) {
        if (!bar.isConnected) list.before(bar);
        return;
      }
      const next = element(
        this.document,
        "div",
        "joyfox-panel joyfox-signals-filter"
      );
      next.setAttribute(UI_ATTRIBUTE, FILTER_BAR);
      next.setAttribute("data-joyfox-version", key2);
      const toggle = element(this.document, "input", "");
      toggle.type = "checkbox";
      toggle.id = "joyfox-hide-incomplete";
      toggle.checked = this.#hide;
      toggle.addEventListener("change", () => {
        this.#hide = toggle.checked;
        this.#draw();
        this.document.getElementById("joyfox-hide-incomplete")?.focus();
      });
      const label = element(
        this.document,
        "label",
        "joyfox-signals-filter__label"
      );
      label.htmlFor = toggle.id;
      label.append(toggle, " ", t("signals.filter.label"));
      const note = element(
        this.document,
        "p",
        "joyfox-note",
        count ? t(count) : ""
      );
      note.setAttribute("role", "status");
      next.append(label, note);
      if (bar) bar.replaceWith(next);
      else list.before(next);
    }
    #removeFilter() {
      this.#filterBar()?.remove();
      for (const node of Array.from(
        this.document.querySelectorAll(`[${HIDE_ATTRIBUTE}]`)
      ))
        node.removeAttribute(HIDE_ATTRIBUTE);
      for (const node of Array.from(
        this.document.querySelectorAll(`[${INCOMPLETE_ATTRIBUTE}]`)
      ))
        node.removeAttribute(INCOMPLETE_ATTRIBUTE);
    }
    // --- Profile page -------------------------------------------------------
    #section() {
      return this.document.querySelector(
        `[${UI_ATTRIBUTE}="${COMPLETENESS_SECTION}"]`
      );
    }
    #removeSection() {
      this.#section()?.remove();
      removeEmptyStrip(this.document);
      this.#rendered = "";
    }
    #drawProfile() {
      const profile = this.#profile();
      const signals = profile ? this.#data.get(requestKey(profile)) : void 0;
      if (!profile || !signals || !this.#accountId) return this.#removeSection();
      const text2 = completenessText(signals.completeness);
      const key2 = JSON.stringify([profile.memberId, text2, this.#version]);
      const existing = this.#section();
      if (existing && key2 === this.#rendered && isPlaced(existing, profile.anchor))
        return;
      this.#rendered = key2;
      const section = element(
        this.document,
        "section",
        "joyfox-panel joyfox-completeness"
      );
      section.setAttribute(UI_ATTRIBUTE, COMPLETENESS_SECTION);
      section.setAttribute("role", "group");
      section.setAttribute("aria-label", t("signals.heading"));
      const badge = element(
        this.document,
        "span",
        "joyfox-badge joyfox-signals__completeness",
        text2
      );
      badge.setAttribute("data-state", signals.completeness.state);
      section.append(badge);
      existing?.remove();
      placeInStrip(this.document, profile.anchor, section);
    }
  };

  // src/compatibility/limits.ts
  var MAX_COMPATIBILITY_MEMBERS = 500;

  // src/content/compatibility.ts
  function messageCompatibilityClient(sender) {
    return {
      lookup: (memberIds) => request(sender, "compat.lookup", { memberIds })
    };
  }
  function runtimeCompatibilityClient() {
    return messageCompatibilityClient(
      (message2) => browser.runtime.sendMessage(message2)
    );
  }
  var SHARED_ATTRIBUTE = "data-joyfox-shared";
  var COMPAT_SECTION = "compatibility";
  var BADGE = COMPAT_BADGE;
  var SORT_BAR = "compat-sort";
  var RANK_ATTRIBUTE = "data-joyfox-rank";
  var CompatibilityOverlay = class {
    constructor(document2, client) {
      this.document = document2;
      this.client = client;
    }
    #type;
    #own;
    #counts = /* @__PURE__ */ new Map();
    #pending = /* @__PURE__ */ new Set();
    #ownLoading = false;
    /** Set by `invalidate`: the next update asks again for every member shown. */
    #reload = false;
    #error = false;
    #session = 0;
    /** Changed by a language switch, so every badge draws again. */
    #version = 0;
    #rendered = "";
    #sorted = false;
    /** Whether the user opened the shared list, for the member it was on. */
    #listOpen;
    update(type) {
      this.#type = type;
      const visible = [
        ...new Set(
          this.#cards().flatMap(
            ([, cards]) => cards.map((card) => card.memberId)
          )
        )
      ];
      const reload = this.#reload;
      this.#reload = false;
      if (reload) {
        for (const id of [...this.#counts.keys()])
          if (!visible.includes(id)) this.#counts.delete(id);
      }
      const wanted = reload ? visible : visible.filter((id) => !this.#counts.has(id) && !this.#pending.has(id));
      const ownNeeded = !this.#own && !this.#ownLoading && !this.#error;
      if (wanted.length > 0 || reload || ownNeeded) void this.#load(wanted);
      this.#draw();
    }
    /** The page shows none of the surfaces any more. */
    leave() {
      this.update(void 0);
    }
    /** Another account's preferences must never stay on screen: clear at once. */
    accountChanged() {
      this.#sorted = false;
      this.#reset(true);
    }
    /**
     * A snapshot, a setting or a deletion changed: read everything again. What
     * is shown stays until the new answer replaces it, so a save in another
     * tab does not make every badge blink.
     */
    invalidate() {
      this.#reset(false);
    }
    #reset(clear) {
      this.#session += 1;
      this.#pending.clear();
      this.#ownLoading = false;
      this.#error = false;
      this.#rendered = "";
      if (clear) {
        this.#own = void 0;
        this.#counts.clear();
        this.#clear(["search", "inbox", "attendees"]);
        this.#removeSection();
      } else this.#reload = true;
      this.update(this.#type);
    }
    localeChanged() {
      this.#version += 1;
      this.#rendered = "";
      this.#sortBar()?.remove();
      this.#draw();
    }
    async #load(ids) {
      const session = this.#session;
      for (const id of ids) this.#pending.add(id);
      if (!this.#own) this.#ownLoading = true;
      const chunks = [];
      for (let start = 0; start < ids.length; start += MAX_COMPATIBILITY_MEMBERS)
        chunks.push(ids.slice(start, start + MAX_COMPATIBILITY_MEMBERS));
      if (chunks.length === 0) chunks.push([]);
      for (const chunk of chunks) {
        let answer;
        try {
          answer = await this.client.lookup(chunk);
        } catch {
          if (session !== this.#session) return;
          this.#error = true;
          this.#ownLoading = false;
          for (const id of chunk) {
            this.#pending.delete(id);
            this.#counts.set(id, null);
          }
          this.#draw();
          continue;
        }
        if (session !== this.#session) return;
        this.#ownLoading = false;
        if (answer.status === "no-account") this.#own = answer;
        else {
          this.#own = {
            status: "ok",
            accountId: answer.accountId,
            own: answer.own,
            ownMemberId: answer.ownMemberId
          };
          for (const [id, count] of Object.entries(answer.shared))
            this.#counts.set(id, count);
        }
        for (const id of chunk) {
          this.#pending.delete(id);
          if (!this.#counts.has(id)) this.#counts.set(id, null);
        }
        this.#draw();
      }
    }
    /** The cards each active surface shows, with the members they name. */
    #cards() {
      return memberCards(this.document, this.#type);
    }
    /** The shared count JoyFox knows for a member, or `null`. */
    #count(memberId) {
      if (this.#own?.status !== "ok" || !this.#own.own) return null;
      return this.#counts.get(memberId) ?? null;
    }
    #draw() {
      const shown = this.#cards();
      const active = new Set(shown.map(([surface]) => surface));
      this.#clear(
        ["search", "inbox", "attendees"].filter(
          (surface) => !active.has(surface)
        )
      );
      for (const [surface, cards] of shown)
        for (const card of cards) this.#badge(surface, card);
      if (this.#type === "search") this.#drawSort(shown);
      else this.#unsort();
      if (this.#type === "profile") this.#drawProfile();
      else this.#removeSection();
    }
    #badge(surface, card) {
      const existing = card.badgeHost.querySelector(
        `[${UI_ATTRIBUTE}="${BADGE}"]`
      );
      const count = this.#count(card.memberId);
      if (count === null) return existing?.remove();
      const version2 = `${card.memberId}|${count}|${this.#version}`;
      if (existing?.getAttribute("data-joyfox-version") === version2) return;
      const badge = element(
        this.document,
        "span",
        "joyfox-badge joyfox-compat-badge",
        t(message("compat.badge", { count }))
      );
      badge.setAttribute(UI_ATTRIBUTE, BADGE);
      badge.setAttribute("data-surface", surface);
      badge.setAttribute("data-joyfox-version", version2);
      const label = t(message("compat.badgeLabel", { count }));
      badge.title = label;
      badge.setAttribute("aria-label", label);
      if (existing) existing.replaceWith(badge);
      else card.placeBadge(badge);
    }
    #clear(surfaces) {
      for (const surface of surfaces) {
        for (const node of Array.from(
          this.document.querySelectorAll(
            `[${UI_ATTRIBUTE}="${BADGE}"][data-surface="${surface}"]`
          )
        ))
          node.remove();
        if (surface === "search") this.#unsort();
        removeEmptyCardLines(this.document);
      }
    }
    // --- Profile page -------------------------------------------------------
    #section() {
      return this.document.querySelector(
        `[${UI_ATTRIBUTE}="${COMPAT_SECTION}"]`
      );
    }
    #removeSection() {
      this.#section()?.remove();
      removeEmptyStrip(this.document);
      for (const tag of Array.from(
        this.document.querySelectorAll(`[${SHARED_ATTRIBUTE}]`)
      ))
        tag.removeAttribute(SHARED_ATTRIBUTE);
      this.#rendered = "";
    }
    #drawProfile() {
      const member = pageMember(this.document, "profile");
      const own = this.#own;
      if (!member || !own && !this.#error) return this.#removeSection();
      const reading = readPreferences(this.document);
      let text2;
      let labels = [];
      let highlight = /* @__PURE__ */ new Set();
      if (this.#error && !own) text2 = message("compat.readFailed");
      else if (!own || own.status === "no-account")
        text2 = message("compat.noAccount");
      else if (isOwnProfile(this.document) || own.ownMemberId === member.memberId)
        text2 = reading.status === "found" ? message("compat.own", { count: reading.positive.length }) : message(
          reading.status === "missing" ? "compat.missing" : "compat.unreadable"
        );
      else if (!own.own) text2 = message("compat.ownUnknown");
      else if (reading.status === "missing") text2 = message("compat.missing");
      else if (reading.status === "unreadable")
        text2 = message("compat.unreadable");
      else {
        labels = sharedPreferences(own.own, reading.positive);
        highlight = new Set(labels);
        text2 = labels.length > 0 ? message("compat.shared", { count: labels.length }) : message("compat.none");
      }
      const marked = new Set(
        reading.status === "found" ? reading.entries.filter(
          (entry) => POSITIVE_LEVELS.has(entry.level) && highlight.has(entry.label)
        ).map((entry) => entry.tag) : []
      );
      for (const tag of Array.from(
        this.document.querySelectorAll(`[${SHARED_ATTRIBUTE}]`)
      ))
        if (!marked.has(tag)) tag.removeAttribute(SHARED_ATTRIBUTE);
      for (const tag of marked) tag.setAttribute(SHARED_ATTRIBUTE, "yes");
      const key2 = JSON.stringify([member.memberId, text2, labels, this.#version]);
      const existing = this.#section();
      if (existing && key2 === this.#rendered && isPlaced(existing, member.anchor))
        return;
      this.#rendered = key2;
      const section = element(
        this.document,
        "section",
        "joyfox-panel joyfox-compat"
      );
      section.setAttribute(UI_ATTRIBUTE, COMPAT_SECTION);
      section.setAttribute("data-member", member.memberId);
      section.setAttribute("role", "group");
      section.setAttribute("aria-label", t("compat.heading"));
      section.append(
        element(
          this.document,
          "strong",
          "joyfox-compat__heading",
          t("compat.heading")
        ),
        element(this.document, "p", "joyfox-compat__text", t(text2))
      );
      if (labels.length > 0) {
        const memberId = member.memberId;
        const details = element(
          this.document,
          "details",
          "joyfox-compat__details"
        );
        details.open = this.#listOpen?.memberId === memberId && this.#listOpen.open;
        details.addEventListener("toggle", () => {
          if (details.isConnected)
            this.#listOpen = { memberId, open: details.open };
        });
        const summary = element(
          this.document,
          "summary",
          "joyfox-compat__summary",
          t("compat.listToggle")
        );
        summary.setAttribute(FOCUS_KEY, "compat-list");
        const list = element(this.document, "ul", "joyfox-compat__list");
        for (const label of labels)
          list.append(element(this.document, "li", "", label));
        details.append(summary, list);
        section.append(details);
      }
      const focus = rememberFocus(existing);
      existing?.remove();
      placeInStrip(this.document, member.anchor, section);
      restoreFocus(section, focus);
    }
    // --- Search sort --------------------------------------------------------
    #sortBar() {
      return this.document.querySelector(
        `[${UI_ATTRIBUTE}="${SORT_BAR}"]`
      );
    }
    /** CSS `order` moves items only in a flex or grid container. */
    #canSort(container) {
      const display = this.document.defaultView?.getComputedStyle(container).display ?? "";
      return /^(inline-)?(flex|grid)$/u.test(display);
    }
    #drawSort(shown) {
      const listSelector = verifiedSelector("search", "resultList");
      const list = listSelector ? this.document.querySelector(listSelector) : null;
      if (!list) return this.#unsort();
      const own = this.#own;
      const ready = own?.status === "ok" && own.own !== null;
      const results = resultItems(this.document);
      const sortable = results ? this.#canSort(results.container) : false;
      let status;
      if (own?.status === "no-account") status = message("compat.noAccount");
      else if (own && !ready) status = message("compat.ownUnknown");
      else if (this.#sorted && !sortable)
        status = message("compat.sort.unavailable");
      else if (this.#sorted) status = message("compat.sort.on");
      let bar = this.#sortBar();
      const key2 = JSON.stringify([this.#sorted, ready, status, this.#version]);
      if (!bar || bar.getAttribute("data-joyfox-version") !== key2) {
        const next = element(
          this.document,
          "div",
          "joyfox-panel joyfox-compat-sort"
        );
        next.setAttribute(UI_ATTRIBUTE, SORT_BAR);
        next.setAttribute("data-joyfox-version", key2);
        const toggle = button(
          this.document,
          "joyfox-button joyfox-compat-sort__button",
          t("compat.sort.button"),
          () => {
            this.#sorted = !this.#sorted;
            this.#draw();
          }
        );
        toggle.setAttribute("aria-pressed", String(this.#sorted));
        toggle.setAttribute(FOCUS_KEY, "compat-sort");
        toggle.disabled = !ready;
        const note = element(
          this.document,
          "p",
          "joyfox-note",
          status ? t(status) : ""
        );
        note.setAttribute("role", "status");
        next.append(toggle, note);
        const focus = rememberFocus(bar);
        if (bar) bar.replaceWith(next);
        else list.before(next);
        restoreFocus(next, focus);
        bar = next;
      } else if (!bar.isConnected) list.before(bar);
      if (!this.#sorted || !ready || !results || !sortable)
        return this.#unorder();
      const counts = new Map(
        (shown.find(([surface]) => surface === "search")?.[1] ?? []).map(
          (card) => [card.badgeHost, this.#count(card.memberId)]
        )
      );
      const countOf = (item) => {
        for (const [host, count] of counts)
          if (item === host || item.contains(host)) return count;
        return null;
      };
      const ranked = results.items.map((item, index) => ({ item, index, count: countOf(item) })).sort((a, b) => (b.count ?? -1) - (a.count ?? -1) || a.index - b.index);
      ranked.forEach(({ item }, rank) => {
        if (!(item instanceof HTMLElement)) return;
        if (item.style.order !== String(rank)) item.style.order = String(rank);
        item.setAttribute(RANK_ATTRIBUTE, String(rank));
      });
    }
    #unorder() {
      for (const item of Array.from(
        this.document.querySelectorAll(`[${RANK_ATTRIBUTE}]`)
      )) {
        item.removeAttribute(RANK_ATTRIBUTE);
        if (item instanceof HTMLElement) item.style.removeProperty("order");
      }
    }
    #unsort() {
      this.#unorder();
      this.#sortBar()?.remove();
    }
  };

  // src/content/listing-panel.ts
  function messageListingClient(sender) {
    return {
      get: (kind, eventId) => request(sender, "listing.get", { kind, eventId }),
      list: () => request(sender, "listing.list", {}),
      save: (payload) => request(sender, "listing.save", payload),
      async openOptions() {
        await request(sender, "options.open", {});
      }
    };
  }
  function runtimeListingClient() {
    return messageListingClient(
      (message2) => browser.runtime.sendMessage(message2)
    );
  }
  var ATTENDANCE_TEXT = {
    unknown: "listing.attendance.unknown",
    interested: "listing.attendance.interested",
    attending: "listing.attendance.attending",
    "not-attending": "listing.attendance.not-attending",
    attended: "listing.attendance.attended"
  };
  var NOTE_FIELD = "joyfox-listing__note";
  var TAG_FIELD = "joyfox-listing__tag-input";
  function fallbacks2(memo) {
    return memo?.key.startsWith("remove:") ? ["tag", "summary"] : ["summary"];
  }
  function summaryText2(kind, listing) {
    const parts = [];
    if (listing && listing.attendance !== "unknown")
      parts.push(t(ATTENDANCE_TEXT[listing.attendance]));
    if (listing && listing.tags.length > 0)
      parts.push(t(message("signals.tagCount", { count: listing.tags.length })));
    if (listing?.note) parts.push(t("listing.summary.note"));
    const state = parts.length > 0 ? parts.join(", ") : t("listing.summary.none");
    return t(
      kind === "event" ? message("listing.summary.event", { state }) : message("listing.summary.venue", { state })
    );
  }
  function pathId(kind, pathname) {
    const definition = selectorRegistry[kind];
    if (definition.status !== "verified" || !definition.path) return void 0;
    return new RegExp(definition.path).exec(pathname)?.[1];
  }
  var text = (node) => node?.textContent?.replace(/\s+/gu, " ").trim() || void 0;
  var ListingPanel = class {
    constructor(document2, client, pathname = () => document2.location.pathname) {
      this.document = document2;
      this.client = client;
      this.pathname = pathname;
    }
    #root;
    /** The part each draw replaces; the notice below it stays. */
    #content;
    #statusNode;
    /** The user opened or closed the box on this page. */
    #open;
    #key;
    #kind;
    #id;
    #data;
    /** The note as typed, while it differs from the stored one. */
    #draft;
    #tagDraft = "";
    #status;
    /**
     * A save is on its way. The box's controls ignore changes meanwhile, so a
     * second change can never be dropped or overwritten by the first answer.
     */
    #busy = false;
    /** Bumped on teardown and on an account switch. */
    #session = 0;
    #loadSequence = 0;
    update(kind) {
      const id = pathId(kind, this.pathname());
      const anchor = this.#anchor(kind);
      if (!id || !anchor) return this.leave();
      const key2 = `${kind}:${id}`;
      if (key2 === this.#key && this.#root?.isConnected) return;
      if (key2 !== this.#key) {
        this.leave();
        this.#key = key2;
        this.#kind = kind;
        this.#id = id;
        const root = element(
          this.document,
          "section",
          "joyfox-panel joyfox-listing"
        );
        root.setAttribute(UI_ATTRIBUTE, "listing");
        const content = element(this.document, "div", "joyfox-listing__content");
        const status = element(this.document, "p", "joyfox-listing__status");
        status.setAttribute("role", "status");
        status.setAttribute("aria-live", "polite");
        root.append(content, status);
        this.#root = root;
        this.#content = content;
        this.#statusNode = status;
        this.#draw();
        void this.#load();
      }
      anchor.after(this.#root);
    }
    leave() {
      this.#session += 1;
      this.#root?.remove();
      this.#root = void 0;
      this.#content = void 0;
      this.#statusNode = void 0;
      this.#open = void 0;
      this.#key = void 0;
      this.#kind = void 0;
      this.#id = void 0;
      this.#data = void 0;
      this.#draft = void 0;
      this.#tagDraft = "";
      this.#status = void 0;
    }
    /** Text typed for the previous account is dropped, as for member notes. */
    accountChanged() {
      this.#session += 1;
      if (!this.#root) return;
      this.#data = void 0;
      this.#draft = void 0;
      this.#tagDraft = "";
      this.#status = void 0;
      this.#open = void 0;
      this.#draw();
      void this.#load();
    }
    /** A save in another tab, or data deleted: show what is stored now. */
    invalidate() {
      if (this.#root) void this.#load();
    }
    localeChanged() {
      if (this.#root) this.#draw();
    }
    /** Event: after JoyClub's info box, else the title. Venue: the name. */
    #anchor(kind) {
      const fields = kind === "event" ? ["infoBox", "title"] : ["name"];
      for (const field of fields) {
        const selector = verifiedSelector(kind, field);
        const found2 = selector ? this.document.querySelector(selector) : null;
        if (found2) return found2;
      }
      return null;
    }
    /** The listing facts the page shows now, read when the user saves. */
    #facts() {
      const kind = this.#kind;
      const read = (field) => {
        const selector = kind ? verifiedSelector(kind, field) : void 0;
        return selector ? this.document.querySelector(selector) : null;
      };
      const path = this.pathname();
      if (kind === "venue")
        return {
          ...text(read("name")) ? { title: text(read("name")) } : {},
          path
        };
      const start = parseEventStart(text(read("startText")) ?? "");
      const venue = read("venueLink");
      const venueId = /^\/club\/(\d{1,12})\./u.exec(
        venue?.getAttribute("href") ?? ""
      )?.[1];
      const title = text(read("title"));
      const venueName = text(venue);
      return {
        ...title ? { title } : {},
        ...start ? { startLocal: start } : {},
        path,
        ...venueId ? { venueId } : {},
        ...venueId && venueName ? { venueName } : {}
      };
    }
    async #load() {
      const kind = this.#kind;
      const id = this.#id;
      if (!kind || !id) return;
      const session = this.#session;
      const sequence = this.#loadSequence += 1;
      const current = () => session === this.#session && sequence === this.#loadSequence;
      let answer;
      try {
        answer = await this.client.get(kind, id);
      } catch {
        if (!current()) return;
        this.#status = { text: message("listing.readFailed"), error: true };
        this.#draw();
        return;
      }
      if (!current()) return;
      this.#data = answer;
      if (this.#status?.text.key === "listing.readFailed")
        this.#status = void 0;
      this.#draw();
    }
    #saved() {
      return this.#data?.status === "ok" ? this.#data : void 0;
    }
    #draw() {
      const root = this.#root;
      const content = this.#content;
      const kind = this.#kind;
      if (!root || !content || !kind) return;
      const document2 = this.document;
      const focus = rememberFocus(root);
      const heading = t(
        kind === "event" ? "listing.heading.event" : "listing.heading.venue"
      );
      root.setAttribute("aria-label", heading);
      content.replaceChildren();
      const data = this.#data;
      if (!data) {
        content.append(element(document2, "p", "joyfox-panel__heading", heading));
        if (!this.#status)
          content.append(
            element(document2, "p", "joyfox-note", t("listing.loading"))
          );
      } else content.append(this.#details(data, kind, heading));
      this.#showStatus();
      this.#markBusy();
      restoreFocus(root, focus, fallbacks2(focus));
    }
    #details(data, kind, heading) {
      const document2 = this.document;
      const stored = data.status === "ok" ? data.listing : null;
      const details = element(document2, "details", "joyfox-listing__details");
      details.open = this.#open ?? stored !== null;
      details.addEventListener("toggle", () => {
        if (details.isConnected) this.#open = details.open;
      });
      const summary = element(
        document2,
        "summary",
        "joyfox-listing__summary",
        data.status === "ok" ? summaryText2(kind, stored) : heading
      );
      summary.setAttribute(FOCUS_KEY, "summary");
      details.append(summary);
      if (data.status === "no-account") {
        const options = button(
          document2,
          "joyfox-button",
          t("common.openOptions"),
          () => void this.client.openOptions().catch(() => void 0)
        );
        options.setAttribute(FOCUS_KEY, "options");
        details.append(
          element(document2, "p", "joyfox-note", t("listing.noAccount")),
          options
        );
        return details;
      }
      if (kind === "event") details.append(this.#attendanceRow(data));
      details.append(this.#noteRow(data), this.#tagRow(data, kind));
      details.append(element(document2, "p", "joyfox-note", t("listing.privacy")));
      return details;
    }
    #attendanceRow(data) {
      const document2 = this.document;
      const row = element(document2, "div", "joyfox-listing__row");
      const label = element(document2, "label", "", t("listing.attendanceLabel"));
      const select = element(document2, "select", "joyfox-listing__attendance");
      select.id = "joyfox-listing-attendance";
      select.setAttribute(FOCUS_KEY, "attendance");
      label.htmlFor = select.id;
      const stored = data.listing?.attendance ?? "unknown";
      for (const value of ATTENDANCE_VALUES)
        select.append(
          new Option(t(ATTENDANCE_TEXT[value]), value, false, value === stored)
        );
      let chosen = stored;
      select.addEventListener("change", () => {
        if (this.#busy) {
          select.value = chosen;
          return;
        }
        chosen = select.value;
        void this.#save({ attendance: chosen });
      });
      row.append(label, select);
      return row;
    }
    #noteRow(data) {
      const document2 = this.document;
      const row = element(document2, "div", "joyfox-listing__row");
      const label = element(document2, "label", "", t("listing.noteLabel"));
      const note = element(document2, "textarea", NOTE_FIELD);
      note.id = "joyfox-listing-note";
      note.setAttribute(FOCUS_KEY, "note");
      label.htmlFor = note.id;
      note.maxLength = MAX_NOTE_LENGTH;
      note.rows = 3;
      note.value = this.#draft ?? data.listing?.note ?? "";
      note.addEventListener("input", () => {
        this.#draft = note.value;
      });
      note.addEventListener("keydown", (event) => event.stopPropagation());
      const length = noteLength(
        document2,
        note,
        "joyfox-listing-note-length",
        () => {
          this.#status = { text: message(NOTES_TEXT.pasteCut), error: true };
          this.#showStatus();
        }
      );
      const save = button(
        document2,
        "joyfox-button",
        t("listing.saveNote"),
        () => {
          void this.#save({ note: note.value }, true);
        }
      );
      save.setAttribute(FOCUS_KEY, "save-note");
      row.append(label, note, length, save);
      return row;
    }
    #tagRow(data, kind) {
      const document2 = this.document;
      const row = element(document2, "div", "joyfox-listing__row");
      row.append(
        element(document2, "p", "joyfox-listing__label", t("listing.tagsLabel"))
      );
      const tags = data.listing?.tags ?? [];
      if (tags.length > 0) {
        const list = element(document2, "ul", "joyfox-listing__tags");
        for (const tag of tags) {
          const item = element(document2, "li", "joyfox-listing__tag");
          const remove = button(document2, "joyfox-button", "\u2715", () => {
            void this.#save({ tags: tags.filter((other) => other !== tag) });
          });
          remove.setAttribute(FOCUS_KEY, `remove:${tag}`);
          const label = t(message("listing.removeTag", { tag }));
          remove.setAttribute("aria-label", label);
          remove.title = label;
          item.append(element(document2, "span", "", tag), remove);
          list.append(item);
        }
        row.append(list);
      }
      const input = element(document2, "input", TAG_FIELD);
      input.setAttribute(FOCUS_KEY, "tag");
      input.type = "text";
      input.maxLength = MAX_TAG_LENGTH;
      input.autocomplete = "off";
      input.value = this.#tagDraft;
      input.setAttribute("aria-label", t("listing.tagLabel"));
      input.placeholder = t("listing.tagLabel");
      const add = () => {
        if (this.#busy) return;
        const tag = input.value.trim();
        if (!tag) return this.#setStatus(message("listing.emptyTag"), true);
        if (cleanTags([...tags, tag]).length > MAX_EVENT_TAGS)
          return this.#setStatus(
            kind === "event" ? message("listing.tooManyTags.event", { maximum: MAX_EVENT_TAGS }) : message("listing.tooManyTags.venue", { maximum: MAX_EVENT_TAGS }),
            true
          );
        void this.#save({ tags: [...tags, tag] }, false, true);
      };
      input.addEventListener("input", () => {
        this.#tagDraft = input.value;
      });
      input.addEventListener("keydown", (event) => {
        event.stopPropagation();
        if (event.key === "Enter") {
          event.preventDefault();
          add();
        }
      });
      const addButton = button(
        document2,
        "joyfox-button",
        t("listing.addTag"),
        add
      );
      addButton.setAttribute(FOCUS_KEY, "add-tag");
      row.append(input, addButton);
      return row;
    }
    /**
     * While a save runs, the box's controls say they are unavailable and
     * ignore input, but keep focus, which `disabled` would drop to the page.
     */
    #markBusy() {
      for (const control of Array.from(
        this.#content?.querySelectorAll(
          "button, input, select, textarea"
        ) ?? []
      )) {
        if (this.#busy) control.setAttribute("aria-disabled", "true");
        else control.removeAttribute("aria-disabled");
        if (control.tagName === "INPUT" || control.tagName === "TEXTAREA")
          control.readOnly = this.#busy;
      }
    }
    /** Shown in place, so the live region stays the same node. */
    #showStatus() {
      const node = this.#statusNode;
      if (!node) return;
      const text2 = this.#status ? t(this.#status.text) : "";
      if (node.textContent !== text2) node.textContent = text2;
      node.classList.toggle("joyfox-error", this.#status?.error === true);
    }
    #setStatus(text2, error) {
      this.#status = { text: text2, error };
      this.#draw();
    }
    /**
     * Save one change on top of what is stored. The note typed but not saved
     * is kept aside unless this save is the note's own.
     */
    async #save(change, savesNote = false, savesTag = false) {
      const data = this.#saved();
      const kind = this.#kind;
      const id = this.#id;
      if (!data || !kind || !id || this.#busy) return;
      const stored = data.listing;
      const session = this.#session;
      let answer;
      this.#busy = true;
      this.#markBusy();
      try {
        answer = await this.client.save({
          accountId: data.accountId,
          kind,
          eventId: id,
          note: change.note ?? stored?.note ?? "",
          tags: change.tags ?? stored?.tags ?? [],
          attendance: change.attendance ?? stored?.attendance ?? "unknown",
          facts: this.#facts(),
          expectedUpdatedAt: stored?.updatedAt ?? null
        });
      } catch {
        if (session === this.#session)
          this.#setStatus(message("common.saveFailed"), true);
        return;
      } finally {
        this.#busy = false;
        this.#markBusy();
      }
      if (session !== this.#session) return;
      if (answer.status === "refused") {
        this.#setStatus(message("listing.refused"), true);
        void this.#load();
        return;
      }
      const listing = answer.status === "removed" ? null : answer.listing;
      this.#data = { ...data, listing };
      if (answer.status === "conflict") {
        this.#setStatus(message("listing.conflict"), true);
        return;
      }
      if (savesNote) this.#draft = void 0;
      if (savesTag) this.#tagDraft = "";
      const event = kind === "event";
      this.#setStatus(
        answer.status === "removed" ? message(event ? "listing.removed.event" : "listing.removed.venue") : stored ? message("listing.saved") : message(event ? "listing.tracked.event" : "listing.tracked.venue"),
        false
      );
    }
  };

  // src/content/event-list-filter.ts
  var FILTER_ATTRIBUTE = "data-joyfox-event-filter";
  var MATCH_ATTRIBUTE = "data-joyfox-event-match";
  var BADGE2 = "joyfox-event-badge";
  var FILTER_KEY = "joyfox.eventFilter";
  function matches(filter, listing) {
    if (filter.kind === "all") return true;
    if (!listing) return false;
    switch (filter.kind) {
      case "tracked":
        return true;
      case "note":
        return Boolean(listing.note);
      case "attendance":
        return listing.attendance === filter.value;
      case "tag": {
        const key2 = filter.tag.toLowerCase();
        return listing.tags.some((tag) => tag.toLowerCase() === key2);
      }
    }
  }
  var encode = (filter) => filter.kind === "attendance" ? `attendance:${filter.value}` : filter.kind === "tag" ? `tag:${filter.tag}` : filter.kind;
  function decode(value) {
    if (value === "tracked" || value === "note") return { kind: value };
    if (value === "attendance:interested" || value === "attendance:attending")
      return {
        kind: "attendance",
        value: value.slice("attendance:".length)
      };
    if (value.startsWith("tag:")) return { kind: "tag", tag: value.slice(4) };
    return { kind: "all" };
  }
  var EventListFilter = class {
    constructor(document2, client, store = () => document2.defaultView?.sessionStorage ?? void 0) {
      this.document = document2;
      this.client = client;
      this.store = store;
    }
    #bar;
    #list;
    #count;
    #data;
    #error;
    #filter = { kind: "all" };
    /** The tab's last choice, applied once the notes are read. */
    #kept;
    #session = 0;
    #loadSequence = 0;
    /** The kept choice; nothing when the browser blocks the storage. */
    #readKept() {
      try {
        const value = this.store()?.getItem(FILTER_KEY);
        const filter = value ? decode(value) : void 0;
        return filter && filter.kind !== "all" && filter.kind !== "tag" ? filter : void 0;
      } catch {
        return void 0;
      }
    }
    #keep(filter) {
      try {
        const store = this.store();
        if (filter.kind === "all" || filter.kind === "tag")
          store?.removeItem(FILTER_KEY);
        else store?.setItem(FILTER_KEY, encode(filter));
      } catch {
      }
    }
    update() {
      const selector = verifiedSelector("event-calendar", "list");
      const list = selector ? this.document.querySelector(selector) : null;
      if (!list) return this.leave();
      if (list !== this.#list) {
        this.#unmark();
        this.#list = list;
      }
      if (!this.#bar) {
        this.#bar = element(
          this.document,
          "div",
          "joyfox-panel joyfox-event-filter"
        );
        this.#bar.setAttribute(UI_ATTRIBUTE, "event-filter");
        this.#kept = this.#readKept();
        this.#draw();
        void this.#load();
      }
      if (!this.#bar.isConnected || this.#bar.nextElementSibling !== list)
        list.before(this.#bar);
      this.#apply();
    }
    leave() {
      this.#session += 1;
      this.#unmark();
      this.#bar?.remove();
      this.#bar = void 0;
      this.#list = void 0;
      this.#count = void 0;
      this.#data = void 0;
      this.#error = void 0;
      this.#filter = { kind: "all" };
      this.#kept = void 0;
    }
    /** Another account's notes must never stay on screen after a switch. */
    accountChanged() {
      this.#session += 1;
      if (!this.#bar) return;
      this.#data = void 0;
      this.#filter = { kind: "all" };
      this.#kept = void 0;
      this.#keep(this.#filter);
      this.#draw();
      this.#apply();
      void this.#load();
    }
    invalidate() {
      if (this.#bar) void this.#load();
    }
    localeChanged() {
      if (!this.#bar) return;
      this.#draw();
      this.#apply(true);
    }
    async #load() {
      const session = this.#session;
      const sequence = this.#loadSequence += 1;
      const current = () => session === this.#session && sequence === this.#loadSequence;
      let answer;
      try {
        answer = await this.client.list();
      } catch {
        if (!current()) return;
        this.#error = message("eventFilter.readFailed");
        this.#draw();
        return;
      }
      if (!current()) return;
      this.#data = answer;
      this.#error = void 0;
      if (this.#kept) {
        if (answer.accountId) this.#filter = this.#kept;
        this.#kept = void 0;
      }
      if (this.#filter.kind === "tag" && !this.#tags().includes(this.#filter.tag))
        this.#filter = { kind: "all" };
      this.#draw();
      this.#apply(true);
    }
    #events() {
      return new Map(
        (this.#data?.listings ?? []).filter((listing) => listing.kind === "event").map((listing) => [listing.eventId, listing])
      );
    }
    #tags() {
      const seen = /* @__PURE__ */ new Map();
      for (const listing of this.#data?.listings ?? [])
        if (listing.kind === "event") {
          for (const tag of listing.tags)
            if (!seen.has(tag.toLowerCase())) seen.set(tag.toLowerCase(), tag);
        }
      return [...seen.values()].sort((a, b) => a.localeCompare(b));
    }
    #draw() {
      const bar = this.#bar;
      if (!bar) return;
      const document2 = this.document;
      const focus = rememberFocus(bar);
      bar.replaceChildren();
      const label = element(
        document2,
        "label",
        "joyfox-event-filter__label",
        t("eventFilter.label")
      );
      const select = element(document2, "select", "joyfox-event-filter__select");
      select.id = "joyfox-event-filter";
      select.setAttribute(FOCUS_KEY, "event-filter");
      label.htmlFor = select.id;
      const option = (value, text2) => select.append(
        new Option(text2, value, false, value === encode(this.#filter))
      );
      option("all", t("eventFilter.all"));
      if (this.#data?.accountId) {
        option("tracked", t("eventFilter.tracked"));
        option("note", t("eventFilter.note"));
        option("attendance:attending", t("eventFilter.attending"));
        option("attendance:interested", t("eventFilter.interested"));
        for (const tag of this.#tags())
          option(`tag:${tag}`, t(message("eventFilter.tag", { tag })));
      }
      select.disabled = !this.#data?.accountId;
      select.addEventListener("change", () => {
        this.#filter = decode(select.value);
        this.#keep(this.#filter);
        this.#apply();
      });
      const count = element(document2, "span", "joyfox-event-filter__count");
      count.setAttribute("role", "status");
      count.setAttribute("aria-live", "polite");
      bar.append(label, select, count);
      if (this.#error)
        bar.append(element(document2, "p", "joyfox-error", t(this.#error)));
      else if (this.#data && !this.#data.accountId)
        bar.append(
          element(document2, "p", "joyfox-note", t("eventFilter.noAccount"))
        );
      this.#count = count;
      restoreFocus(bar, focus);
    }
    /**
     * Mark every loaded item and show or hide it; badge tracked events.
     * `redrawBadges` also rewrites badges already placed (new data or
     * language).
     */
    #apply(redrawBadges = false) {
      const list = this.#list;
      if (!list) return;
      const itemSelector = verifiedSelector("event-calendar", "item");
      const eventSelector = verifiedSelector("event-calendar", "eventItem");
      if (!itemSelector || !eventSelector) return;
      const events = this.#events();
      const filtering = this.#filter.kind !== "all";
      let shown = 0;
      let loaded = 0;
      for (const item of Array.from(list.querySelectorAll(itemSelector))) {
        const isEvent = item.matches(eventSelector);
        const id = isEvent ? item.getAttribute("data-element-id") ?? "" : "";
        const listing = isEvent ? events.get(id) : void 0;
        if (isEvent) loaded += 1;
        const match = isEvent && matches(this.#filter, listing);
        if (match && isEvent) shown += 1;
        item.setAttribute(MATCH_ATTRIBUTE, match ? "yes" : "no");
        this.#badge(item, listing, redrawBadges);
      }
      if (filtering) list.setAttribute(FILTER_ATTRIBUTE, "on");
      else list.removeAttribute(FILTER_ATTRIBUTE);
      const count = filtering ? t(message("eventFilter.count", { shown, loaded })) : "";
      if (this.#count && this.#count.textContent !== count)
        this.#count.textContent = count;
    }
    #badge(item, listing, redraw) {
      const existing = item.querySelector(`.${BADGE2}`);
      if (!listing) return existing?.remove();
      if (existing && !redraw && existing.getAttribute("data-joyfox-version") === listing.updatedAt)
        return;
      const parts = [t("eventFilter.badge")];
      if (listing.attendance !== "unknown")
        parts.push(t(ATTENDANCE_TEXT[listing.attendance]));
      if (listing.tags.length > 0) parts.push(listing.tags.join(", "));
      if (listing.note) parts.push(t("eventFilter.hasNote"));
      const badge = element(
        this.document,
        "span",
        `joyfox-badge ${BADGE2}`,
        parts.join(" \xB7 ")
      );
      badge.setAttribute(UI_ATTRIBUTE, "event-badge");
      badge.setAttribute("data-joyfox-version", listing.updatedAt);
      if (existing) return existing.replaceWith(badge);
      const headlineSelector = verifiedSelector("event-calendar", "headline");
      const headline = headlineSelector ? item.querySelector(headlineSelector) : null;
      (headline ?? item).append(badge);
    }
    #unmark() {
      const list = this.#list;
      if (!list) return;
      list.removeAttribute(FILTER_ATTRIBUTE);
      for (const item of Array.from(
        list.querySelectorAll(`[${MATCH_ATTRIBUTE}]`)
      ))
        item.removeAttribute(MATCH_ATTRIBUTE);
      for (const badge of Array.from(list.querySelectorAll(`.${BADGE2}`)))
        badge.remove();
    }
  };

  // src/extraction/messages.ts
  function bubbleText(content) {
    let text2 = "";
    const walk = (node) => {
      for (const child of Array.from(node.childNodes)) {
        if (child.nodeType === 3)
          text2 += (child.textContent ?? "").replace(/\s+/gu, " ");
        else if (child.nodeName === "BR") text2 += "\n";
        else walk(child);
      }
    };
    walk(content);
    return text2.split("\n").map((line) => line.trim()).join("\n").trim().slice(0, MAX_MESSAGE_TEXT_LENGTH);
  }
  function sentTime(item) {
    const bubbleSelector = verifiedSelector("conversation", "messageBubble");
    const timeSelector = verifiedSelector("conversation", "messageTime");
    if (!bubbleSelector || !timeSelector) return void 0;
    const bubble = item.querySelector(bubbleSelector);
    const shadow = bubble?.openOrClosedShadowRoot ?? bubble?.shadowRoot;
    const value = shadow?.querySelector(timeSelector)?.getAttribute("datetime");
    return value && isStrictIsoDate(value) ? value : void 0;
  }
  function readConversationMessages(root) {
    const itemSelector = verifiedSelector("conversation", "messageItem");
    const sentSelector = verifiedSelector("conversation", "sentBubble");
    const receivedSelector = verifiedSelector("conversation", "receivedBubble");
    const textSelector = verifiedSelector("conversation", "messageText");
    if (!itemSelector || !sentSelector || !receivedSelector || !textSelector)
      return [];
    const messages = [];
    for (const item of Array.from(root.querySelectorAll(itemSelector))) {
      const messageId = item.getAttribute("data-message-id") ?? "";
      if (!MESSAGE_ID_PATTERN.test(messageId)) continue;
      const sent = item.querySelector(sentSelector);
      const bubble = sent ?? item.querySelector(receivedSelector);
      const content = bubble?.querySelector(textSelector);
      if (!bubble || !content) continue;
      const text2 = bubbleText(content);
      if (!text2) continue;
      const sentAt = sentTime(item);
      messages.push({
        messageId,
        direction: sent ? "sent" : "received",
        text: text2,
        ...sentAt ? { sentAt } : {}
      });
    }
    return messages;
  }

  // src/content/message-cache.ts
  function messageCacheClient(sender) {
    return { cache: (payload) => request(sender, "messages.cache", payload) };
  }
  function runtimeMessageCacheClient() {
    return messageCacheClient(
      (message2) => browser.runtime.sendMessage(message2)
    );
  }
  var BATCH = 100;
  var version = (message2) => JSON.stringify([message2.text, message2.sentAt ?? ""]);
  var MessageCache = class {
    constructor(document2, client, activeAccount) {
      this.document = document2;
      this.client = client;
      this.activeAccount = activeAccount;
    }
    /** What was sent per message ID, so an unchanged message is not sent again. */
    #sent = /* @__PURE__ */ new Map();
    /** The conversation each message ID was first seen in. */
    #conversation = /* @__PURE__ */ new Map();
    #queue = Promise.resolve();
    /**
     * Set after a send that stored nothing; cleared by the next page, account
     * or switch change, so a refusing background is not asked on every page
     * mutation.
     */
    #failed = false;
    #lastUrl = "";
    /** A conversation page changed; `enabled` is the caching switch. */
    update(enabled) {
      if (!enabled) return;
      const url = this.document.URL;
      if (url !== this.#lastUrl) {
        this.#lastUrl = url;
        this.#failed = false;
      }
      if (this.#failed) return;
      const accountId = this.activeAccount();
      if (!accountId) return;
      const page = extractConversation(this.document, url);
      if (page.conversationId.status !== "found" || page.memberId.status !== "found")
        return;
      const conversationId = page.conversationId.value;
      const memberId = page.memberId.value;
      const fresh = [];
      for (const message2 of readConversationMessages(this.document)) {
        const owner = this.#conversation.get(message2.messageId);
        if (owner && owner !== conversationId) continue;
        this.#conversation.set(message2.messageId, conversationId);
        if (this.#sent.get(message2.messageId) === version(message2)) continue;
        this.#sent.set(message2.messageId, version(message2));
        fresh.push(message2);
      }
      for (let start = 0; start < fresh.length; start += BATCH) {
        const batch = fresh.slice(start, start + BATCH);
        this.#queue = this.#queue.then(
          () => this.client.cache({ accountId, conversationId, memberId, messages: batch }).then((answer) => {
            if (answer.status === "stored") return;
            this.#forget(batch);
            this.#failed = true;
          }).catch(() => {
            this.#forget(batch);
            this.#failed = true;
          })
        );
      }
    }
    /** The account or the switch changed: send what the page shows again. */
    reset() {
      this.#sent.clear();
      this.#failed = false;
    }
    #forget(batch) {
      for (const message2 of batch) this.#sent.delete(message2.messageId);
    }
  };

  // src/content/preference-retry.ts
  var PreferenceRetry = class {
    constructor(refresh, limit = 10, delayMs = 500) {
      this.refresh = refresh;
      this.limit = limit;
      this.delayMs = delayMs;
    }
    #url = "";
    #attempts = 0;
    #timer;
    /** Called after each pass with the page address and whether to retry. */
    check(url, unreadable) {
      if (url !== this.#url) {
        this.#url = url;
        this.#attempts = 0;
        this.stop();
      }
      if (!unreadable || this.#timer !== void 0) return;
      if (this.#attempts >= this.limit) return;
      this.#attempts += 1;
      this.#timer = globalThis.setTimeout(() => {
        this.#timer = void 0;
        this.refresh();
      }, this.delayMs);
    }
    stop() {
      globalThis.clearTimeout(this.#timer);
      this.#timer = void 0;
    }
  };

  // src/content/profile-type-filter.ts
  var TYPE_FILTER_ATTRIBUTE = "data-joyfox-type-filter";
  var TYPE_MATCH_ATTRIBUTE = "data-joyfox-type-match";
  var MARK = "joyfox-type-unknown";
  var TYPE_FILTER_KEY = "joyfox.profileTypeFilter";
  var CARD_TYPES = ["man", "woman", "couple", "unknown"];
  var TYPE_LABEL = {
    man: "typeFilter.man",
    woman: "typeFilter.woman",
    couple: "typeFilter.couple",
    unknown: "typeFilter.unknown"
  };
  function decodeTypes(value) {
    if (!value) return /* @__PURE__ */ new Set();
    let parsed;
    try {
      parsed = JSON.parse(value);
    } catch {
      return /* @__PURE__ */ new Set();
    }
    if (!Array.isArray(parsed)) return /* @__PURE__ */ new Set();
    return new Set(CARD_TYPES.filter((type) => parsed.includes(type)));
  }
  var ProfileTypeFilter = class {
    constructor(document2, store = () => document2.defaultView?.sessionStorage ?? void 0) {
      this.document = document2;
      this.store = store;
    }
    #bar;
    #grid;
    #count;
    #hint;
    #types = /* @__PURE__ */ new Set();
    #readKept() {
      try {
        return decodeTypes(this.store()?.getItem(TYPE_FILTER_KEY));
      } catch {
        return /* @__PURE__ */ new Set();
      }
    }
    #keep() {
      try {
        const store = this.store();
        if (this.#types.size === 0) store?.removeItem(TYPE_FILTER_KEY);
        else
          store?.setItem(
            TYPE_FILTER_KEY,
            JSON.stringify(CARD_TYPES.filter((type) => this.#types.has(type)))
          );
      } catch {
      }
    }
    update() {
      const rootSelector = selectorOf("root");
      const root = rootSelector ? this.document.querySelector(rootSelector) : null;
      if (!root) return this.leave();
      const gridSelector = verifiedSelector("my-joy-list", "grid");
      const grid = gridSelector && root.querySelector(gridSelector) || void 0;
      if (grid !== this.#grid) {
        this.#unmark();
        this.#grid = grid;
      }
      if (!this.#bar) {
        this.#bar = element(
          this.document,
          "div",
          "joyfox-panel joyfox-type-filter"
        );
        this.#bar.setAttribute(UI_ATTRIBUTE, "type-filter");
        this.#types = this.#readKept();
        this.#draw();
      }
      if (grid) {
        if (this.#bar.nextElementSibling !== grid) grid.before(this.#bar);
      } else if (root.firstElementChild !== this.#bar) root.prepend(this.#bar);
      this.#apply();
    }
    /** Leaves the tab's choice kept: the next list starts with it. */
    leave() {
      this.#unmark();
      this.#bar?.remove();
      this.#bar = void 0;
      this.#grid = void 0;
      this.#count = void 0;
      this.#hint = void 0;
      this.#types = /* @__PURE__ */ new Set();
    }
    localeChanged() {
      if (!this.#bar) return;
      this.#draw();
      this.#apply(true);
    }
    #draw() {
      const bar = this.#bar;
      if (!bar) return;
      const document2 = this.document;
      const focus = rememberFocus(bar);
      bar.replaceChildren();
      const group = element(document2, "fieldset", "joyfox-type-filter__group");
      group.append(
        element(
          document2,
          "legend",
          "joyfox-type-filter__legend",
          t("typeFilter.legend")
        )
      );
      for (const type of CARD_TYPES) {
        const label = element(document2, "label", "joyfox-type-filter__option");
        const box = element(document2, "input", "joyfox-type-filter__box");
        box.type = "checkbox";
        box.value = type;
        box.checked = this.#types.has(type);
        box.setAttribute(FOCUS_KEY, `type:${type}`);
        box.addEventListener("change", () => {
          if (box.checked) this.#types.add(type);
          else this.#types.delete(type);
          this.#keep();
          this.#apply();
        });
        label.append(box, document2.createTextNode(` ${t(TYPE_LABEL[type])}`));
        group.append(label);
      }
      const count = element(document2, "span", "joyfox-type-filter__count");
      count.setAttribute("role", "status");
      count.setAttribute("aria-live", "polite");
      const hint = element(document2, "span", "joyfox-type-filter__hint");
      bar.append(group, count, hint);
      this.#count = count;
      this.#hint = hint;
      restoreFocus(bar, focus);
    }
    /**
     * Mark every loaded card's slot and show or hide it. Every write happens
     * only on a change: a write is a page mutation, which would start the next
     * pass at once. `redrawMarks` rewrites marks already placed (language).
     */
    #apply(redrawMarks = false) {
      const grid = this.#grid;
      const filtering = this.#types.size > 0;
      let loaded = 0;
      let shown = 0;
      let unknownHidden = 0;
      const slotSelector = selectorOf("slot");
      const placeholder = selectorOf("placeholder");
      const cardSelector = selectorOf("card");
      if (grid && slotSelector && cardSelector)
        for (const slot of Array.from(grid.querySelectorAll(slotSelector))) {
          if (placeholder && slot.matches(placeholder)) continue;
          const card = Array.from(slot.children).find(
            (child) => child.matches(cardSelector)
          );
          if (!card) continue;
          loaded += 1;
          const type = cardProfileType(card);
          const match = !filtering || this.#types.has(type);
          if (match) shown += 1;
          else if (type === "unknown") unknownHidden += 1;
          setAttribute2(
            slot,
            TYPE_MATCH_ATTRIBUTE,
            filtering ? match ? "yes" : "no" : null
          );
          this.#mark(card, filtering && match && type === "unknown", redrawMarks);
        }
      if (grid)
        setAttribute2(grid, TYPE_FILTER_ATTRIBUTE, filtering ? "on" : null);
      const parts = filtering ? [t(message("typeFilter.count", { shown, loaded }))] : [];
      if (filtering && unknownHidden > 0)
        parts.push(
          t(message("typeFilter.unknownHidden", { count: unknownHidden }))
        );
      setText2(this.#count, parts.join(" \xB7 "));
      setText2(
        this.#hint,
        filtering && loaded > 0 ? t("typeFilter.scrollHint") : ""
      );
    }
    /** The "Type unknown" label, over the card's photo. */
    #mark(card, wanted, redraw) {
      const existing = Array.from(card.children).find(
        (child) => child.classList.contains(MARK)
      );
      if (!wanted) return existing?.remove();
      const text2 = t("typeFilter.unknownMark");
      if (existing) {
        if (redraw || existing.textContent !== text2) setText2(existing, text2);
        return;
      }
      const mark = element(this.document, "span", `joyfox-badge ${MARK}`, text2);
      mark.setAttribute(UI_ATTRIBUTE, "type-unknown");
      mark.setAttribute("slot", "badge-top-right");
      card.append(mark);
    }
    #unmark() {
      const grid = this.#grid;
      if (!grid) return;
      grid.removeAttribute(TYPE_FILTER_ATTRIBUTE);
      for (const slot of Array.from(
        grid.querySelectorAll(`[${TYPE_MATCH_ATTRIBUTE}]`)
      ))
        slot.removeAttribute(TYPE_MATCH_ATTRIBUTE);
      for (const mark of Array.from(grid.querySelectorAll(`.${MARK}`)))
        mark.remove();
    }
  };
  var selectorOf = (field) => field === "root" ? selectorRegistry["my-joy-list"].status === "verified" ? selectorRegistry["my-joy-list"].root : void 0 : verifiedSelector("my-joy-list", field);
  function setAttribute2(node, name, value) {
    if (node.getAttribute(name) === value) return;
    if (value === null) node.removeAttribute(name);
    else node.setAttribute(name, value);
  }
  function setText2(node, text2) {
    if (node && node.textContent !== text2) node.textContent = text2;
  }

  // src/content/shared-events.ts
  function messageSharedEventsClient(sender) {
    return {
      recordAttendees: (accountId, eventId, memberIds) => request(sender, "listing.attendees", { accountId, eventId, memberIds }),
      forMember: (memberId) => request(sender, "listing.forMember", { memberId })
    };
  }
  function runtimeSharedEventsClient() {
    return messageSharedEventsClient(
      (message2) => browser.runtime.sendMessage(message2)
    );
  }
  var MAX_TRIES = 3;
  var SHARED_EVENTS_SECTION = "shared-events";
  function pageEventId(document2) {
    const path = selectorRegistry.event.path;
    if (!path) return void 0;
    try {
      return new RegExp(path).exec(new URL(document2.URL).pathname)?.[1];
    } catch {
      return void 0;
    }
  }
  var SharedEvents = class {
    constructor(document2, client, activeAccount) {
      this.document = document2;
      this.client = client;
      this.activeAccount = activeAccount;
    }
    /** What was sent per event, so an unchanged list is not sent again. */
    #sent = /* @__PURE__ */ new Map();
    /** Set after a refusal or an untracked event, until a change. */
    #stopped = /* @__PURE__ */ new Set();
    /** Failed requests per event or member, so a transient error retries. */
    #failures = /* @__PURE__ */ new Map();
    #profileSession = 0;
    #profileMember;
    #profileData;
    #rendered = "";
    #version = 0;
    update(type) {
      if (type === "event") this.#captureGuests();
      if (type === "profile") this.#drawProfile();
      else this.#removeSection();
    }
    /** Event notes changed, or the account: read and send again. */
    invalidate() {
      this.#sent.clear();
      this.#stopped.clear();
      this.#failures.clear();
      this.#profileSession += 1;
      this.#profileData = void 0;
      this.#profileMember = void 0;
      this.#rendered = "";
    }
    localeChanged() {
      this.#version += 1;
      this.#rendered = "";
    }
    #captureGuests() {
      const eventId = pageEventId(this.document);
      const accountId = this.activeAccount();
      if (!eventId || !accountId) return;
      const key2 = `${accountId}|${eventId}`;
      if (this.#stopped.has(key2)) return;
      const shown = memberCards(this.document, "event").find(
        ([surface]) => surface === "attendees"
      )?.[1];
      const ids = [...new Set((shown ?? []).map((card) => card.memberId))].sort().slice(0, MAX_EVENT_ATTENDEES);
      if (ids.length === 0) return;
      const version2 = ids.join(",");
      if (this.#sent.get(key2) === version2) return;
      this.#sent.set(key2, version2);
      void this.client.recordAttendees(accountId, eventId, ids).then((answer) => {
        if (answer.status === "untracked" || answer.status === "refused")
          this.#stopped.add(key2);
      }).catch(() => {
        this.#sent.delete(key2);
        if (this.#failed(key2)) this.#stopped.add(key2);
      });
    }
    /** Counts a failure; true once the key has failed `MAX_TRIES` times. */
    #failed(key2) {
      const count = (this.#failures.get(key2) ?? 0) + 1;
      this.#failures.set(key2, count);
      return count >= MAX_TRIES;
    }
    #section() {
      return this.document.querySelector(
        `[${UI_ATTRIBUTE}="${SHARED_EVENTS_SECTION}"]`
      );
    }
    #removeSection() {
      this.#section()?.remove();
      removeEmptyStrip(this.document);
      this.#rendered = "";
    }
    #drawProfile() {
      const member = pageMember(this.document, "profile");
      if (!member) return this.#removeSection();
      if (this.#profileMember !== member.memberId) {
        this.#profileMember = member.memberId;
        this.#profileData = void 0;
        const session = this.#profileSession += 1;
        const memberId = member.memberId;
        void this.client.forMember(memberId).then((answer) => {
          if (session !== this.#profileSession) return;
          this.#profileData = {
            memberId,
            listings: answer.status === "ok" ? answer.listings : []
          };
          this.#drawProfile();
        }).catch(() => {
          if (session !== this.#profileSession) return;
          if (!this.#failed(`profile|${memberId}`))
            this.#profileMember = void 0;
        });
      }
      const data = this.#profileData;
      if (!data || data.memberId !== member.memberId || data.listings.length === 0)
        return this.#removeSection();
      const key2 = JSON.stringify([data, this.#version]);
      const existing = this.#section();
      if (existing && key2 === this.#rendered && isPlaced(existing, member.anchor))
        return;
      this.#rendered = key2;
      const section = element(
        this.document,
        "section",
        "joyfox-panel joyfox-shared-events"
      );
      section.setAttribute(UI_ATTRIBUTE, SHARED_EVENTS_SECTION);
      section.setAttribute("role", "group");
      section.setAttribute("aria-label", t("sharedEvents.heading"));
      section.append(
        element(this.document, "strong", "", t("sharedEvents.heading")),
        element(this.document, "p", "joyfox-note", t("sharedEvents.intro"))
      );
      const list = element(this.document, "ul", "joyfox-shared-events__list");
      for (const listing of data.listings) {
        const parts = [
          listing.title ?? t(message("events.untitled", { id: listing.eventId }))
        ];
        if (listing.startLocal) parts.push(formatWallTime(listing.startLocal));
        if (listing.attendance !== "unknown")
          parts.push(t(ATTENDANCE_TEXT[listing.attendance]));
        list.append(element(this.document, "li", "", parts.join(" \xB7 ")));
      }
      section.append(list);
      existing?.remove();
      placeInStrip(this.document, member.anchor, section);
    }
  };

  // src/content/navigation-coordinator.ts
  var WATCHED_ATTRIBUTES = [
    "href",
    "verification-status",
    "universal-gender",
    "aria-label",
    // A search card's nickname (JoyFox's own texts name the member with it).
    "user-name",
    // Visibility: JoyClub can hide and show the conversation list in place.
    "class",
    "style",
    "hidden"
  ];
  var NavigationCoordinator = class {
    constructor(detect) {
      this.detect = detect;
    }
    #listeners = /* @__PURE__ */ new Set();
    #observer;
    #timer;
    #urlTimer;
    #lastUrl = "";
    #started = false;
    #onPopState = () => this.#emit("history");
    subscribe(listener) {
      this.#listeners.add(listener);
      return () => this.#listeners.delete(listener);
    }
    start() {
      if (this.#started) return;
      this.#started = true;
      this.#lastUrl = location.href;
      this.#emit("initial");
      this.#observer = new MutationObserver(() => {
        globalThis.clearTimeout(this.#timer);
        this.#timer = globalThis.setTimeout(() => this.#emit("mutation"), 50);
      });
      this.#observer.observe(document.documentElement, {
        childList: true,
        subtree: true,
        // JoyClub can patch a triage input in place: a row's profile link, a
        // shield or gender code, or the photo count label. Only these
        // attributes are watched, never JoyFox's own `data-joyfox-*` ones, so
        // JoyFox's writes cannot wake the coordinator.
        attributes: true,
        attributeFilter: [...WATCHED_ATTRIBUTES],
        characterData: true
      });
      this.#urlTimer = globalThis.setInterval(() => {
        if (location.href !== this.#lastUrl) this.#emit("history");
      }, 250);
      globalThis.addEventListener("popstate", this.#onPopState);
    }
    /**
     * Ask every listener to read the page again, for a change no observer can
     * see (V1-2: labels drawn inside a shadow root).
     */
    refresh() {
      if (this.#started) this.#emit("mutation");
    }
    stop() {
      if (!this.#started) return;
      this.#observer?.disconnect();
      globalThis.clearTimeout(this.#timer);
      globalThis.clearInterval(this.#urlTimer);
      globalThis.removeEventListener("popstate", this.#onPopState);
      this.#started = false;
    }
    #emit(reason) {
      const url = location.href;
      this.#lastUrl = url;
      const event = { page: this.detect(), url, reason };
      for (const listener of [...this.#listeners])
        try {
          listener(event);
        } catch (error) {
          console.error("JoyFox: navigation listener failed", error);
        }
    }
  };

  // src/content/page-detector.ts
  var DETECTION_ORDER = [
    "conversation",
    "inbox",
    "profile",
    "search",
    "event",
    "event-calendar",
    "venue",
    "my-joy-list"
  ];
  function detectPage(url = location.href, root = document) {
    let parsed;
    try {
      parsed = new URL(url);
    } catch {
      return { status: "invalid", source: "location", reason: "Unparseable URL" };
    }
    if (!VERIFIED_HOSTS.includes(parsed.hostname))
      return { status: "missing", source: "host-unverified" };
    for (const page of DETECTION_ORDER) {
      const definition = selectorRegistry[page];
      if (definition.status !== "verified" || !definition.path) continue;
      if (!new RegExp(definition.path).test(parsed.pathname)) continue;
      if (definition.root && !root.querySelector(definition.root))
        return { status: "missing", source: `${page}:root-not-rendered` };
      return { status: "found", value: page, source: `${page}:path+root` };
    }
    return { status: "missing", source: "no-verified-page-matched" };
  }

  // src/actions/quick-action-setting.ts
  var QUICK_ACTION_KEY = "joyfox.quickIgnoreDelete";

  // src/actions/ignore-delete.ts
  var QUICK_IGNORE_DELETE = "quick-ignore-delete";
  var QUICK_DELETE = "quick-delete";
  var NEXT = {
    [QUICK_IGNORE_DELETE]: {
      Started: "DeleteRequested",
      DeleteRequested: "DeleteConfirmed",
      DeleteConfirmed: "IgnoreRequested",
      IgnoreRequested: "IgnoreConfirmed",
      IgnoreConfirmed: "Completed"
    },
    // Delete alone: `Started`, `DeleteRequested`, `DeleteConfirmed`,
    // `Completed`, or `Failed` from any state that is not terminal.
    [QUICK_DELETE]: {
      Started: "DeleteRequested",
      DeleteRequested: "DeleteConfirmed",
      DeleteConfirmed: "Completed"
    }
  };
  var ACTION_FAILURES = [
    "control-missing",
    "confirmation-missing",
    "not-verified",
    "unverifiable",
    "member-mismatch",
    "conversation-mismatch",
    "identity-unavailable",
    "account-changed",
    "turned-off",
    "superseded",
    "log-unavailable",
    "handoff-failed",
    "timeout",
    "step-error"
  ];
  var STEP_ORDER = ["delete", "ignore"];
  var ACTION_STEPS = {
    [QUICK_IGNORE_DELETE]: STEP_ORDER,
    [QUICK_DELETE]: ["delete"]
  };
  var STEP_STATES = {
    ignore: { requested: "IgnoreRequested", confirmed: "IgnoreConfirmed" },
    delete: { requested: "DeleteRequested", confirmed: "DeleteConfirmed" }
  };
  function checkTarget(expected, current, step) {
    if (current.page === "other" || current.memberId === void 0)
      return "identity-unavailable";
    if (current.memberId !== expected.memberId) return "member-mismatch";
    if (step === "delete" && current.page !== "conversation")
      return "identity-unavailable";
    if (step === "ignore" && current.page !== "profile")
      return "identity-unavailable";
    if (current.page === "conversation") {
      if (current.conversationId === void 0) return "identity-unavailable";
      if (current.conversationId !== expected.conversationId)
        return "conversation-mismatch";
    }
    return void 0;
  }
  var STEP_TIMEOUT_MS = 15e3;
  var STALE_AFTER_MS = 12e4;
  var STARTED_STALE_AFTER_MS = 2 * STEP_TIMEOUT_MS;
  function staleAfterMs(last) {
    return last === "Started" ? STARTED_STALE_AFTER_MS : STALE_AFTER_MS;
  }
  function outcome(steps, step) {
    const names = new Set(steps.map((item) => item.name));
    const states = STEP_STATES[step];
    if (names.has(states.confirmed)) return "done";
    if (names.has(states.requested)) return "unknown";
    return "not-done";
  }
  function failureText(failure, step, outcome2) {
    const name = message(`action.step.${step}`);
    const where = message(
      outcome2 === "not-done" ? "action.where.before" : "action.where.during",
      { step: name }
    );
    switch (failure) {
      case "control-missing":
      case "confirmation-missing":
      case "not-verified":
      case "timeout":
        return message(`action.failure.${failure}`, { step: name });
      case "unverifiable":
        return message("action.failure.unverifiable", { step: name, where });
      default:
        return message(`action.failure.${failure}`, { where });
    }
  }
  var stepText = (step, outcome2) => message(`action.stepText.${step}.${outcome2}`);
  var actionOf = (log) => log.action === QUICK_DELETE ? QUICK_DELETE : QUICK_IGNORE_DELETE;
  function reportOperation(log, now) {
    const action = actionOf(log);
    const steps = log.steps;
    const last = steps.at(-1);
    const lastState = last?.name;
    const ignore = outcome(steps, "ignore");
    const remove = outcome(steps, "delete");
    const failure = lastState === "Failed" && ACTION_FAILURES.includes(last?.errorCode) ? last?.errorCode : void 0;
    const lastAt = Date.parse(last?.at ?? log.updatedAt);
    const status = lastState === "Completed" ? "completed" : lastState === "Failed" ? "failed" : !Number.isFinite(lastAt) || now - lastAt > staleAfterMs(lastState) ? "interrupted" : "running";
    if (action === QUICK_DELETE)
      return deleteReport(status, remove, ignore, failure);
    const lines = [];
    if (status === "completed") {
      lines.push(message("action.report.finished"), stepText("delete", "done"));
      lines.push(stepText("ignore", "done"), message("action.report.undo"));
      return { status, ignore, delete: remove, lines };
    }
    if (status === "running") {
      lines.push(message("action.report.running"));
      return { status, ignore, delete: remove, lines };
    }
    lines.push(
      message(
        status === "failed" ? "action.report.stopped" : "action.report.interrupted"
      )
    );
    if (failure) {
      const step = remove === "done" ? "ignore" : "delete";
      lines.push(failureText(failure, step, step === "ignore" ? ignore : remove));
      if (failure === "unverifiable" && step === "delete")
        lines.push(message("action.next.showList"));
    }
    lines.push(stepText("delete", remove), stepText("ignore", ignore));
    const untouched = ignore === "not-done" && remove === "not-done";
    lines.push(
      message(
        untouched ? "action.report.nothingChanged" : "action.report.notUndone"
      )
    );
    if (untouched) {
      lines.push(message("action.self.delete"), message("action.self.ignore"));
    } else {
      if (remove !== "done") lines.push(message("action.next.delete"));
      if (ignore !== "done") lines.push(message("action.next.ignore"));
    }
    return {
      status,
      ignore,
      delete: remove,
      ...failure ? { failure } : {},
      lines
    };
  }
  function deleteReport(status, remove, ignore, failure) {
    const lines = [];
    if (status === "completed") {
      lines.push(
        message("action.deleteReport.finished"),
        stepText("delete", "done"),
        message("action.deleteReport.undo")
      );
      return { status, ignore, delete: remove, lines };
    }
    if (status === "running") {
      lines.push(message("action.deleteReport.running"));
      return { status, ignore, delete: remove, lines };
    }
    lines.push(
      message(
        status === "failed" ? "action.deleteReport.stopped" : "action.deleteReport.interrupted"
      )
    );
    if (failure) {
      lines.push(failureText(failure, "delete", remove));
      if (failure === "unverifiable") lines.push(message("action.next.showList"));
    }
    lines.push(stepText("delete", remove));
    const untouched = remove === "not-done";
    lines.push(
      message(
        untouched ? "action.report.nothingChanged" : "action.report.notUndone"
      ),
      message(untouched ? "action.self.delete" : "action.next.delete")
    );
    return {
      status,
      ignore,
      delete: remove,
      ...failure ? { failure } : {},
      lines
    };
  }

  // src/actions/executor.ts
  var STEP_PAGE = {
    delete: "conversation",
    ignore: "profile"
  };
  var StepTimeout = class extends Error {
  };
  function withTimeout(promise, ms) {
    let timer;
    return Promise.race([
      promise,
      new Promise((_, reject) => {
        timer = setTimeout(() => reject(new StepTimeout()), ms);
      })
    ]).finally(() => clearTimeout(timer));
  }
  var failureOf = (error) => error instanceof StepTimeout ? "timeout" : "step-error";
  var runQuickIgnoreDelete = (options) => runQuickAction(QUICK_IGNORE_DELETE, options);
  var runQuickDelete = (options) => runQuickAction(QUICK_DELETE, options);
  async function runQuickAction(action, options) {
    const { target, driver, recorder } = options;
    const timeout = options.timeoutMs ?? STEP_TIMEOUT_MS;
    const now = options.now ?? (() => (/* @__PURE__ */ new Date()).toISOString());
    const resume = options.resume;
    const steps = resume ? [...resume.steps] : [{ name: "Started", ok: true, at: now() }];
    const note = (state, failure) => {
      steps.push({
        name: state,
        ok: state !== "Failed",
        at: now(),
        ...failure ? { errorCode: failure } : {}
      });
      try {
        options.onState?.(state);
      } catch {
      }
    };
    const report = () => reportOperation({ action, steps, updatedAt: now() }, Date.parse(now()));
    let operationId;
    if (resume) operationId = resume.operationId;
    else {
      let begun;
      try {
        const deadline = Date.parse(now()) + timeout;
        begun = await withTimeout(
          action === QUICK_IGNORE_DELETE ? recorder.begin(target, deadline) : recorder.begin(target, deadline, action),
          timeout
        );
      } catch {
        note("Failed", "log-unavailable");
        return { status: "finished", report: report() };
      }
      if (begun.status === "busy")
        return { status: "busy", report: begun.report };
      if (begun.status === "refused") {
        note("Failed", "account-changed");
        return { status: "finished", report: report() };
      }
      if (begun.status === "expired") {
        note("Failed", "log-unavailable");
        return { status: "finished", report: report() };
      }
      operationId = begun.operationId;
    }
    const store = async (state) => {
      try {
        const answer = await withTimeout(
          recorder.record(operationId, state),
          timeout
        );
        if (answer === "recorded") return void 0;
        if (answer === "refused") return "account-changed";
        return answer === "superseded" ? "superseded" : "log-unavailable";
      } catch {
        return "log-unavailable";
      }
    };
    const stop = async (failure) => {
      note("Failed", failure);
      await withTimeout(
        recorder.record(operationId, "Failed", failure),
        timeout
      ).catch(() => void 0);
      return { status: "finished", operationId, report: report() };
    };
    const guard = (step) => {
      try {
        return options.stopReason?.() ?? checkTarget(target, driver.currentTarget(), step);
      } catch {
        return "step-error";
      }
    };
    const ready = (step) => {
      const failure = guard(step);
      if (failure) return failure;
      try {
        if (!driver.hasControl(step)) return "control-missing";
        if (driver.canVerify && !driver.canVerify(step)) return "unverifiable";
        return void 0;
      } catch {
        return "step-error";
      }
    };
    const attempt = async (action2) => {
      try {
        await withTimeout(action2(), timeout);
        return void 0;
      } catch (error) {
        return failureOf(error);
      }
    };
    const runStep = async (step) => {
      const { requested, confirmed } = STEP_STATES[step];
      const before = ready(step);
      if (before) return before;
      const unstored = await store(requested);
      if (unstored) return unstored;
      note(requested);
      const changed = ready(step);
      if (changed) return changed;
      const clicked = await attempt(() => driver.request(step));
      if (clicked) return clicked;
      let confirmation = "missing";
      const waited = await attempt(async () => {
        confirmation = await driver.awaitConfirmation(step);
      });
      if (waited) return waited;
      if (confirmation === "missing") return "confirmation-missing";
      if (confirmation === "shown") {
        const moved = guard(step);
        if (moved) return moved;
        const confirmedClick = await attempt(() => driver.confirm(step));
        if (confirmedClick) return confirmedClick;
      }
      let verified = false;
      const checked = await attempt(async () => {
        verified = await driver.verify(step);
      });
      if (checked) return checked;
      if (!verified) return "not-verified";
      note(confirmed);
      return store(confirmed);
    };
    const all = ACTION_STEPS[action];
    const order = resume ? all.slice(all.indexOf(resume.from)) : all;
    for (const [index, step] of order.entries()) {
      if (index > 0 && options.handOff) {
        let page;
        try {
          page = driver.currentTarget().page;
        } catch {
          return stop("step-error");
        }
        if (page !== STEP_PAGE[step]) {
          const stopped = options.stopReason?.();
          if (stopped) return stop(stopped);
          const handed = await attempt(() => options.handOff(operationId, step));
          if (handed)
            return stop(handed === "timeout" ? "timeout" : "handoff-failed");
          const late = options.stopReason?.();
          if (late) return stop(late);
          return { status: "handed-off", operationId, report: report() };
        }
      }
      let failure;
      try {
        failure = await runStep(step);
      } catch {
        failure = "step-error";
      }
      if (failure) return stop(failure);
    }
    note("Completed");
    await store("Completed");
    return { status: "finished", operationId, report: report() };
  }

  // src/selectors/quick-action.ts
  var QUICK_ACTION_SELECTORS = {
    /**
     * The conversation's three-dot menu (owner evidence, 2026-09-24, eighth
     * report): it shares this header with the conversation header.
     */
    conversationScope: "header.cm-clubmail-header",
    conversationMenu: "j-context-menu.cm-conversation__context-menu",
    conversationMenuButton: 'j-control-button[data-e2e="button-conversation-kebap"]',
    profileMenu: 'j-context-menu[data-e2e="profile-context-menu"]',
    /** A direct child of the profile menu (label "Profiloptionen"). */
    menuActivator: 'j-control-button[slot="activator"]',
    ignoreItem: 'j-context-menu-item[title="Profil ignorieren"]',
    /** Shown in the menu once the member is ignored: the lasting signal. */
    ignoredItem: 'j-context-menu-item[title="Profil nicht mehr ignorieren"]',
    /** Slotted into the dialog's `j-modal` host, in the light DOM. */
    ignoreDialogContent: ".profile-ignore-modal__content",
    dialogHost: "j-modal",
    ignoreConfirm: 'j-button[aria-label="Ignorieren"]'
  };
  var DELETE_ITEM_TEXT = "In den Papierkorb schieben";

  // src/content/quick-action-driver.ts
  var DEFAULT_TIMING = { waitMs: 1e4, pollMs: 100 };
  function press(control) {
    const inner = control.shadowRoot?.querySelector("button");
    (inner ?? control).click();
  }
  var JoyClubQuickActionDriver = class {
    constructor(document2, timing = DEFAULT_TIMING) {
      this.document = document2;
      this.timing = timing;
    }
    /** The member and row count when Delete was clicked; counted after. */
    #deleted;
    currentTarget() {
      const conversation = pageMember(this.document, "conversation");
      if (conversation?.page === "conversation") {
        const id = conversation.extraction.conversationId;
        return {
          page: "conversation",
          memberId: conversation.memberId,
          ...id.status === "found" ? { conversationId: id.value } : {}
        };
      }
      const profile = pageMember(this.document, "profile");
      if (profile) return { page: "profile", memberId: profile.memberId };
      return { page: "other" };
    }
    hasControl(step) {
      if (step === "delete") {
        const menu2 = this.#conversationMenu();
        if (!menu2) return false;
        const shown = menu2.querySelectorAll("j-context-menu-item").length > 0;
        return !shown || this.#deleteItem(menu2) !== void 0;
      }
      const menu = this.#menu();
      if (!menu?.querySelector(`:scope > ${QUICK_ACTION_SELECTORS.menuActivator}`)) return false;
      return menu.querySelector(QUICK_ACTION_SELECTORS.ignoredItem) === null;
    }
    canVerify(step) {
      if (step === "ignore") return true;
      const member = this.currentTarget().memberId;
      return member !== void 0 && (this.#rows(member) ?? 0) > 0;
    }
    async request(step) {
      const before = this.currentTarget();
      const same = () => {
        const now = this.currentTarget();
        return now.page === before.page && now.memberId === before.memberId && now.conversationId === before.conversationId;
      };
      if (step === "delete") {
        const menu2 = this.#conversationMenu();
        const memberId = before.memberId;
        const rows = memberId ? this.#rows(memberId) : void 0;
        if (!menu2 || !memberId || !rows) throw new Error("Delete not ready");
        const item2 = this.#deleteItem(menu2) ?? await this.#openMenu(menu2, () => this.#deleteItem(menu2) ?? null);
        if (!item2) throw new Error("Delete item not found");
        if (!same() || this.#conversationMenu() !== menu2)
          throw new Error("The page changed before the click");
        const baseline = this.#rows(memberId);
        if (!baseline) throw new Error("The list no longer shows the row");
        this.#deleted = { memberId, rows: baseline };
        press(item2);
        return;
      }
      const menu = this.#menu();
      if (!menu) throw new Error("Profile menu gone");
      const item = menu.querySelector(QUICK_ACTION_SELECTORS.ignoreItem) ?? await this.#openMenu(menu, () => menu.querySelector(QUICK_ACTION_SELECTORS.ignoreItem));
      if (!item) throw new Error("Ignore item not found");
      if (!same() || this.#menu() !== menu)
        throw new Error("The page changed before the click");
      press(item);
    }
    async awaitConfirmation(step) {
      if (step === "delete") return "none";
      const content = await this.#waitFor(
        () => this.document.querySelector(QUICK_ACTION_SELECTORS.ignoreDialogContent)
      );
      return content ? "shown" : "missing";
    }
    async confirm(step) {
      if (step === "delete") return;
      const button2 = this.document.querySelector(QUICK_ACTION_SELECTORS.ignoreDialogContent)?.closest(QUICK_ACTION_SELECTORS.dialogHost)?.querySelector(QUICK_ACTION_SELECTORS.ignoreConfirm);
      if (!button2) throw new Error("Ignore confirmation button not found");
      press(button2);
    }
    async verify(step) {
      if (step === "delete") {
        const deleted = this.#deleted;
        if (!deleted) return false;
        let seen = 0;
        const gone = () => {
          const rows = this.#rows(deleted.memberId);
          seen = rows !== void 0 && rows < deleted.rows ? seen + 1 : 0;
          return seen >= 2 || null;
        };
        return await this.#waitFor(gone) === true;
      }
      const menu = this.#menu();
      if (!menu) return false;
      const found2 = () => menu.querySelector(QUICK_ACTION_SELECTORS.ignoredItem);
      const first = Math.round(this.timing.waitMs * 0.3);
      if (await this.#waitFor(found2, first)) return true;
      const rest = this.timing.waitMs - first;
      return await this.#openMenu(menu, found2, true, rest) !== null;
    }
    /**
     * The conversation's three-dot menu: exactly one, with its button, in the
     * JoyClub header that holds the conversation header. Never a guess.
     */
    #conversationMenu() {
      const header = pageMember(this.document, "conversation")?.anchor;
      const scope = header?.closest(QUICK_ACTION_SELECTORS.conversationScope);
      if (!scope) return void 0;
      const menus = Array.from(scope.querySelectorAll(QUICK_ACTION_SELECTORS.conversationMenu)).filter(
        (menu) => menu.querySelector(`:scope > ${QUICK_ACTION_SELECTORS.conversationMenuButton}`) !== null
      );
      return menus.length === 1 ? menus[0] : void 0;
    }
    /** The menu's Delete item, by its visible text; exactly one, or none. */
    #deleteItem(menu) {
      const items = Array.from(
        menu.querySelectorAll("j-context-menu-item")
      ).filter(
        (item) => (item.shadowRoot?.textContent ?? "").replace(/\s+/g, " ").trim() === DELETE_ITEM_TEXT
      );
      return items.length === 1 ? items[0] : void 0;
    }
    /**
     * How many rows in the conversation list are `member`'s, or `undefined`
     * when the list is not on screen or shows no rows at all: then nothing can
     * be concluded from it.
     */
    #rows(member) {
      if (inboxListState(this.document) !== "shown") return void 0;
      const rows = extractInboxRows(this.document, this.document.URL);
      if (rows.length === 0) return void 0;
      return rows.filter((row) => {
        const identity = resolveMemberIdentity({
          page: "inbox",
          field: "memberId",
          extraction: row.memberId
        });
        return identity.status === "resolved" && identity.memberId === member;
      }).length;
    }
    /**
     * The profile menu the page shows. JoyClub's profile holds it three times,
     * two copies hidden by screen width (owner's live check, 2026-09-27); a
     * click on a hidden copy opens nothing. While several copies exist and
     * none shows yet (the page is still drawing), there is none: the run
     * waits for it rather than click a hidden one. A single copy is used as
     * it is, as before.
     */
    #menu() {
      const menus = Array.from(this.document.querySelectorAll(QUICK_ACTION_SELECTORS.profileMenu));
      const shown = menus.find((menu) => menu.getClientRects().length > 0);
      if (shown) return shown;
      return menus.length === 1 ? menus[0] : null;
    }
    /**
     * Open the menu if it is closed and wait for `find`. A menu JoyFox opened
     * is closed again when nothing was found, or when `closeAfter` is set (a
     * read only); otherwise the caller clicks an item, which closes it.
     */
    async #openMenu(menu, find, closeAfter = false, waitMs = this.timing.waitMs) {
      const activator = menu.querySelector(`:scope > ${QUICK_ACTION_SELECTORS.menuActivator}`);
      if (!activator) return null;
      const wasOpen = menu.getAttribute("open") === "true";
      if (!wasOpen) press(activator);
      const result = await this.#waitFor(find, waitMs);
      if (!wasOpen && (result === null || closeAfter) && menu.getAttribute("open") === "true")
        press(activator);
      return result;
    }
    async #waitFor(find, waitMs = this.timing.waitMs) {
      const deadline = Date.now() + waitMs;
      for (; ; ) {
        const value = find();
        if (value !== null && value !== void 0 && value !== false)
          return value;
        if (Date.now() >= deadline) return null;
        await new Promise((resolve) => setTimeout(resolve, this.timing.pollMs));
      }
    }
  };

  // src/content/quick-action.ts
  var QUICK_ACTION = "quick-action";
  function messageQuickActionClient(sender) {
    return {
      latest: (memberId) => request(sender, "action.ignoreDelete.latest", { memberId }),
      handOff: async (accountId, operationId, next, profilePath) => {
        const answer = await request(sender, "action.ignoreDelete.handOff", {
          accountId,
          operationId,
          next,
          profilePath
        });
        if (answer.status !== "stored")
          throw new Error("The hand-off was refused");
      },
      pending: () => request(sender, "action.ignoreDelete.pending", {}),
      dropStale: () => request(sender, "action.ignoreDelete.dropStale", {}),
      withdraw: (accountId, operationId) => request(sender, "action.ignoreDelete.withdraw", {
        accountId,
        operationId
      }),
      recorder: (accountId) => ({
        begin: (target, deadline, action) => request(sender, "action.ignoreDelete.start", {
          accountId,
          ...target,
          ...deadline !== void 0 ? { deadline } : {},
          ...action !== void 0 ? { action } : {}
        }),
        record: async (operationId, state, failure) => (await request(sender, "action.ignoreDelete.record", {
          accountId,
          operationId,
          state,
          ...failure ? { failure } : {}
        })).status
      })
    };
  }
  function runtimeQuickActionClient() {
    return messageQuickActionClient(
      (message2) => browser.runtime.sendMessage(message2)
    );
  }
  function liveQuickActionDriver() {
    return new JoyClubQuickActionDriver(document);
  }
  var PROGRESS_TEXT = {
    Started: message("quick.progress.Started"),
    DeleteRequested: message("quick.progress.DeleteRequested"),
    DeleteConfirmed: message("quick.progress.DeleteConfirmed"),
    IgnoreRequested: message("quick.progress.IgnoreRequested")
  };
  var DELETE_PROGRESS_TEXT = {
    Started: message("quick.delete.progress.Started"),
    DeleteRequested: message("quick.progress.DeleteRequested")
  };
  var RESUME_WAIT_MS = 1e4;
  var HANDOFF_WAIT_MS = STEP_TIMEOUT_MS;
  var RETURN_WAIT_MS = 2e3;
  var CLUBMAIL_PATH = "/clubmail/";
  var QUICK_ACTION_TEXT = {
    button: message("quick.button"),
    scope: message("quick.scope"),
    deleteButton: message("quick.delete.button"),
    deleteScope: message("quick.delete.scope"),
    needsList: message("quick.needsList"),
    handedOff: message("quick.progress.DeleteConfirmed"),
    noProfile: message("quick.noProfile"),
    resumed: message("quick.resumed"),
    waitingMenu: message("quick.waitingMenu"),
    previous: message("quick.previous"),
    previousOther: message("quick.previousOther"),
    otherResult: message("quick.otherResult"),
    otherRunning: message("quick.otherRunning"),
    busy: message("quick.busy"),
    unexpected: message("quick.unexpected"),
    deleteUnexpected: message("quick.delete.unexpected"),
    junkDone: message("quick.junk.done"),
    junkBusy: message("quick.junk.busy"),
    junkNotTrashed: message("quick.junk.notTrashed")
  };
  var PREVIOUS_TEXT = {
    [QUICK_IGNORE_DELETE]: {
      previous: QUICK_ACTION_TEXT.previous,
      previousOther: QUICK_ACTION_TEXT.previousOther,
      otherResult: QUICK_ACTION_TEXT.otherResult
    },
    [QUICK_DELETE]: {
      previous: message("quick.delete.previous"),
      previousOther: message("quick.delete.previousOther"),
      otherResult: message("quick.delete.otherResult")
    }
  };
  var sectionIds = 0;
  var QuickIgnoreDelete = class {
    constructor(document2, client, driver, navigate = (url) => document2.defaultView?.location.assign(url), clock = () => Date.now(), handOffWaitMs = HANDOFF_WAIT_MS, returnWaitMs = RETURN_WAIT_MS) {
      this.document = document2;
      this.client = client;
      this.driver = driver;
      this.navigate = navigate;
      this.clock = clock;
      this.handOffWaitMs = handOffWaitMs;
      this.returnWaitMs = returnWaitMs;
    }
    #shown;
    #latest;
    #inFlight;
    /** The ActionLog read in flight; `done` settles when it ends, either way. */
    #loading;
    #generation = 0;
    #drawn;
    #running;
    #result;
    /** Whether "Ignore and Delete" is on (its experimental flag). */
    #ignoreDeleteOn = true;
    /** Set when the run must stop before its next click. */
    #stop;
    #busy = false;
    #staleTimer;
    /** The answer the stale timer was set for; a redraw keeps that timer. */
    #staleFor;
    /** The hand-off this profile page resumes, once read (one-shot). */
    #resume;
    #discarded = false;
    /** Set once this page has asked to drop a hand-off meant for another. */
    #pageSeen = false;
    /** Failed reads of the hand-off marker on this page; retried a few times. */
    #pendingFailures = 0;
    #profileDrawn;
    #profileAnchor;
    /** Set while a finished run waits to return to the ClubMail list. */
    #returnTimer;
    /** The same, for a finished Delete on the conversation page. */
    #deleteReturnTimer;
    /**
     * On a profile page: continue a run this tab handed off from a
     * conversation (Path B, ADR 0011). The marker is read once per page; the
     * run starts once JoyClub's profile menu is there, or after
     * `RESUME_WAIT_MS`, when it stops with a clear reason if it is not.
     */
    updateProfile() {
      if (this.#shown) this.leave();
      const member = pageMember(this.document, "profile");
      if (!member) {
        this.#removeProfileSection();
        return;
      }
      if (!this.#resume) {
        if (!this.driver()) return;
        const resume2 = {
          answer: { status: "none" },
          since: this.clock(),
          started: false
        };
        this.#resume = resume2;
        this.client.pending().then((answer2) => {
          resume2.answer = answer2;
          if (this.#resume === resume2) this.updateProfile();
        }).catch(() => {
          if (this.#resume !== resume2 || this.#pendingFailures >= 3) return;
          this.#pendingFailures += 1;
          this.#resume = void 0;
          setTimeout(() => this.updateProfile(), 500);
        });
        return;
      }
      const resume = this.#resume;
      const answer = resume.answer;
      if (answer.status === "stopped" && !resume.started) {
        resume.started = true;
        this.#result = {
          key: "stopped",
          action: QUICK_IGNORE_DELETE,
          lines: answer.lines
        };
      }
      if (answer.status !== "ok") {
        this.#renderProfile(member.anchor);
        return;
      }
      const driver = this.driver();
      if (!resume.started && driver && !this.#running) {
        const waited = this.clock() - resume.since;
        if (answer.memberId !== member.memberId) {
          resume.started = true;
        } else if (safely(() => driver.hasControl("ignore")) || waited > RESUME_WAIT_MS) {
          resume.started = true;
          this.#resumeRun(answer, driver);
        } else if (!resume.timer) {
          resume.timer = setTimeout(
            () => this.updateProfile(),
            RESUME_WAIT_MS - waited + 50
          );
        }
      }
      this.#renderProfile(member.anchor);
    }
    #resumeRun(answer, driver) {
      const key2 = `${answer.memberId}|${answer.conversationId}`;
      this.#running = {
        key: key2,
        action: QUICK_IGNORE_DELETE,
        progress: PROGRESS_TEXT.Started
      };
      this.#stop = void 0;
      this.#result = void 0;
      void runQuickIgnoreDelete({
        target: {
          memberId: answer.memberId,
          conversationId: answer.conversationId
        },
        driver,
        recorder: this.client.recorder(answer.accountId),
        stopReason: () => this.#stop,
        resume: {
          operationId: answer.operationId,
          from: answer.next,
          steps: answer.steps
        },
        onState: (state) => {
          const text2 = PROGRESS_TEXT[state];
          if (!text2 || !this.#running) return;
          this.#running = { ...this.#running, progress: text2 };
          this.updateProfile();
        }
      }).then((result) => {
        this.#result = {
          key: key2,
          action: QUICK_IGNORE_DELETE,
          lines: result.report.lines
        };
        if (result.report.status === "completed" && !this.#stop)
          this.#returnToClubMail(answer.memberId);
      }).catch(() => {
        this.#result = {
          key: key2,
          action: QUICK_IGNORE_DELETE,
          lines: [QUICK_ACTION_TEXT.unexpected]
        };
      }).finally(() => {
        this.#running = void 0;
        if (this.#stop === "turned-off") this.#result = void 0;
        if (!this.#shown) this.updateProfile();
      });
    }
    /**
     * After `returnWaitMs`, go to the ClubMail list, but only while the page
     * still shows the run's member's profile and the flag is on: a user who
     * moved on in the meantime is not taken back.
     */
    #returnToClubMail(memberId) {
      clearTimeout(this.#returnTimer);
      this.#returnTimer = setTimeout(() => {
        this.#returnTimer = void 0;
        if (pageMember(this.document, "profile")?.memberId !== memberId) return;
        this.navigate(new URL(CLUBMAIL_PATH, this.document.URL).href);
      }, this.returnWaitMs);
    }
    /** A return still waiting is dropped: the flag is off or the account changed. */
    #cancelReturn() {
      clearTimeout(this.#returnTimer);
      this.#returnTimer = void 0;
    }
    /**
     * After a completed Delete, the conversation stays open on JoyClub
     * (`10-ignore.md`). After `returnWaitMs`, go to the ClubMail list (D5),
     * but only while the page still shows that conversation: a user who
     * moved on in the meantime is not taken back.
     */
    #returnFromConversation(target) {
      clearTimeout(this.#deleteReturnTimer);
      this.#deleteReturnTimer = setTimeout(() => {
        this.#deleteReturnTimer = void 0;
        const member = pageMember(this.document, "conversation");
        const conversation = member?.page === "conversation" ? member.extraction.conversationId : void 0;
        if (member?.memberId !== target.memberId || conversation?.status !== "found" || conversation.value !== target.conversationId)
          return;
        this.navigate(new URL(CLUBMAIL_PATH, this.document.URL).href);
      }, this.returnWaitMs);
    }
    /**
     * The language changed: the button, its note and the notice are drawn
     * again. A run in progress is not touched.
     */
    localeChanged() {
      if (this.#drawn) {
        const focused = this.#focusedAction(this.#drawn);
        this.teardown();
        if (this.#shown) this.update();
        if (focused) this.#focusButton(focused);
      }
      if (this.#profileDrawn) {
        this.#removeProfileSection();
        this.#renderProfile(this.#profileAnchor);
      }
    }
    /**
     * The profile page shows only a resumed run's progress and result, and
     * while the run waits for JoyClub's profile menu, that it waits.
     */
    #renderProfile(anchor) {
      this.#profileAnchor = anchor;
      const resume = this.#resume;
      const waiting = resume?.answer.status === "ok" && !resume.started && !this.#running;
      const lines = this.#running ? [QUICK_ACTION_TEXT.resumed, this.#running.progress] : this.#result ? [QUICK_ACTION_TEXT.resumed, ...this.#result.lines] : waiting ? [QUICK_ACTION_TEXT.resumed, QUICK_ACTION_TEXT.waitingMenu] : [];
      if (!anchor || lines.length === 0) {
        this.#removeProfileSection();
        return;
      }
      let drawn = this.#profileDrawn;
      if (!drawn || !drawn.section.isConnected || !isPlaced(drawn.section, anchor)) {
        this.#removeProfileSection();
        const section = element(this.document, "section", "joyfox-panel");
        section.setAttribute(UI_ATTRIBUTE, QUICK_ACTION);
        section.setAttribute("role", "group");
        section.setAttribute("aria-label", t("quick.region"));
        const status = element(
          this.document,
          "div",
          "joyfox-quick-action__status"
        );
        status.setAttribute("role", "status");
        status.setAttribute("aria-live", "polite");
        section.append(status);
        placeInStrip(this.document, anchor, section);
        drawn = { section, status, lines: "" };
        this.#profileDrawn = drawn;
      }
      const text2 = JSON.stringify(lines);
      if (drawn.lines === text2) return;
      drawn.lines = text2;
      const list = element(this.document, "ul", "joyfox-explain__list");
      for (const line of lines)
        list.append(element(this.document, "li", "", t(line)));
      drawn.status.replaceChildren(list);
    }
    #removeProfileSection() {
      if (!this.#profileDrawn) return;
      this.#profileDrawn.section.remove();
      removeEmptyStrip(this.document);
      this.#profileDrawn = void 0;
    }
    update() {
      const member = this.driver() ? pageMember(this.document, "conversation") : void 0;
      const conversation = member?.page === "conversation" ? member.extraction.conversationId : void 0;
      if (!member || conversation?.status !== "found") {
        this.teardown();
        return;
      }
      const target = {
        memberId: member.memberId,
        conversationId: conversation.value
      };
      const key2 = `${target.memberId}|${target.conversationId}`;
      if (this.#shown?.key !== key2) this.teardown();
      this.#shown = { key: key2, target, anchor: member.anchor };
      const latest = this.#latest?.key === key2 ? this.#latest.answer : void 0;
      if (!latest) {
        this.#load(key2, target.memberId);
        return;
      }
      this.#render(this.#shown, latest);
    }
    /** Read the ActionLog again: another tab's run moved, or data changed. */
    invalidate() {
      this.#generation += 1;
      this.#latest = void 0;
      this.#inFlight = void 0;
      if (this.#shown) this.update();
    }
    /** The active account changed: a run stops before its next click. */
    accountChanged() {
      if (this.#running) this.#stop = "account-changed";
      else this.#result = void 0;
      this.#cancelReturn();
      clearTimeout(this.#deleteReturnTimer);
      this.#deleteReturnTimer = void 0;
      this.teardown();
      this.invalidate();
    }
    /**
     * Called when the page is no longer a conversation. A running operation
     * is not cancelled here: it checks the page's identity before every
     * click, so a route to another page stops it there.
     */
    leave() {
      this.#generation += 1;
      this.#inFlight = void 0;
      this.#latest = void 0;
      this.#shown = void 0;
      this.#profileDrawn = void 0;
      this.teardown();
    }
    /**
     * Called on every page event while the flag is on; acts once per page
     * load. A hand-off waits in this tab only for the profile it names, and
     * the move there always loads a new page. So a page that loads anywhere
     * else in the tab shows the move did not happen, and the background
     * drops the marker (ADR 0011). The background compares the address the
     * browser reports, so a profile still loading keeps its own marker.
     */
    pageSeen() {
      if (this.#pageSeen || !this.driver()) return;
      this.#pageSeen = true;
      this.client.dropStale().catch(() => void 0);
    }
    /** The experimental flag is on: "Ignore and Delete" shows again. */
    turnOn() {
      this.#ignoreDeleteOn = true;
    }
    /**
     * The experimental flag is off (D2): "Ignore and Delete" goes, and a run
     * of it stops before its next click. Delete stays: it does not need the
     * flag. Called on every page event while the flag is off; the caller
     * then updates or leaves the page as usual.
     */
    turnOff() {
      this.#ignoreDeleteOn = false;
      if (this.#running?.action === QUICK_IGNORE_DELETE)
        this.#stop = "turned-off";
      if (this.#result?.action === QUICK_IGNORE_DELETE) this.#result = void 0;
      this.#cancelReturn();
      this.#discardHandOff();
      this.#removeProfileSection();
    }
    /**
     * With the flag off, a hand-off waiting for this tab must never run later,
     * when the flag is turned on again: read it once (which removes it) and
     * close its run as turned off. Once per page load, as `turnOff` runs on
     * every page event while the flag is off.
     */
    #discardHandOff() {
      if (this.#discarded || !pageMember(this.document, "profile")) return;
      this.#discarded = true;
      const read = this.#resume;
      if (read && !read.started) {
        read.started = true;
        clearTimeout(read.timer);
        const answer = read.answer;
        if (answer.status === "ok")
          void this.client.recorder(answer.accountId).record(answer.operationId, "Failed", "turned-off").catch(() => void 0);
      }
      this.client.pending().then(async (answer) => {
        if (answer.status !== "ok") return;
        await this.client.recorder(answer.accountId).record(answer.operationId, "Failed", "turned-off");
      }).catch(() => void 0);
    }
    teardown() {
      this.#clearStaleTimer();
      for (const node of Array.from(
        this.document.querySelectorAll(`[${UI_ATTRIBUTE}="${QUICK_ACTION}"]`)
      ))
        node.remove();
      removeEmptyStrip(this.document);
      this.#drawn = void 0;
    }
    #load(key2, memberId) {
      if (this.#inFlight === key2) return;
      this.#inFlight = key2;
      const generation = this.#generation;
      const done = this.client.latest(memberId).then((answer) => {
        if (generation !== this.#generation) return;
        this.#inFlight = void 0;
        this.#latest = { key: key2, answer };
        this.update();
      }).catch(() => {
        if (generation !== this.#generation || this.#inFlight !== key2) return;
        this.#inFlight = void 0;
        this.teardown();
      });
      this.#loading = { key: key2, done };
    }
    /**
     * Wait until the ActionLog answer for the shown conversation is in, so a
     * "Mark as junk" clicked while the page is still loading runs its trash
     * step instead of skipping it. A read replaced by a newer one (another
     * tab's run moved) is waited for too. Gives up after one step timeout, or
     * once the page shows another conversation.
     */
    async #ready(key2) {
      const deadline = this.clock() + STEP_TIMEOUT_MS;
      for (let attempt = 0; attempt < 3; attempt += 1) {
        if (this.#shown?.key !== key2 || this.#latest?.key === key2) return;
        const loading = this.#loading;
        if (loading?.key !== key2) return;
        const left = deadline - this.clock();
        if (left <= 0) return;
        let timer;
        await Promise.race([
          loading.done,
          new Promise((resolve) => {
            timer = setTimeout(resolve, left);
          })
        ]);
        clearTimeout(timer);
      }
    }
    #clearStaleTimer() {
      clearTimeout(this.#staleTimer);
      this.#staleTimer = void 0;
      this.#staleFor = void 0;
    }
    #lines(shown, previous, previousHere = true) {
      const running = this.#running;
      if (running)
        return running.key === shown.key ? [...running.lead ?? [], running.progress] : [QUICK_ACTION_TEXT.otherRunning];
      const result = this.#result;
      if (result)
        return result.key === shown.key ? result.lines : [PREVIOUS_TEXT[result.action].otherResult, ...result.lines];
      if (!previous) return [];
      const labels = PREVIOUS_TEXT[previous.action];
      return [
        previousHere ? labels.previous : labels.previousOther,
        ...previous.report.lines
      ];
    }
    #render(shown, latest) {
      if (latest.status === "no-account") {
        this.teardown();
        return;
      }
      const previous = latest.status === "ok" && latest.report.status !== "completed" ? { action: latest.action, report: latest.report } : void 0;
      const otherTab = previous?.report.status === "running" && !this.#running;
      this.#busy = this.#running !== void 0 || otherTab;
      let drawn = this.#drawn;
      if (!drawn || drawn.key !== shown.key || drawn.withIgnore !== this.#ignoreDeleteOn || !drawn.section.isConnected || !isPlaced(drawn.section, shown.anchor)) {
        const focused = drawn ? this.#focusedAction(drawn) : void 0;
        this.teardown();
        drawn = this.#build(shown, latest.accountId);
        placeInStrip(this.document, shown.anchor, drawn.section);
        this.#drawn = drawn;
        if (focused) this.#focusButton(focused);
      }
      const deleted = latest.status === "ok" && latest.conversationId === shown.target.conversationId && latest.report.delete === "done";
      const unverifiable = !canVerifyDelete(this.driver());
      const needsList = !this.#busy && !deleted && unverifiable;
      const unavailable = this.#busy || unverifiable;
      for (const item of drawn.buttons) {
        item.button.setAttribute("aria-disabled", String(unavailable));
        const describedBy = needsList ? `${drawn.hint.id} ${item.scope.id}` : item.scope.id;
        if (item.button.getAttribute("aria-describedby") !== describedBy)
          item.button.setAttribute("aria-describedby", describedBy);
      }
      if (drawn.hint.hidden === needsList) drawn.hint.hidden = !needsList;
      const lines = this.#lines(
        shown,
        previous,
        latest.status === "ok" && latest.conversationId === shown.target.conversationId
      );
      const text2 = JSON.stringify(lines);
      if (drawn.lines !== text2) {
        drawn.lines = text2;
        if (lines.length === 0) drawn.status.replaceChildren();
        else {
          const list = element(this.document, "ul", "joyfox-explain__list");
          for (const line of lines)
            list.append(element(this.document, "li", "", t(line)));
          drawn.status.replaceChildren(list);
        }
      }
      if (!otherTab || latest.status !== "ok") this.#clearStaleTimer();
      else if (this.#staleFor !== latest) {
        this.#clearStaleTimer();
        const moved = Date.parse(latest.updatedAt);
        const limit = latest.staleAfterMs;
        const left = Number.isFinite(moved) ? limit - (Date.now() - moved) : limit;
        this.#staleFor = latest;
        this.#staleTimer = setTimeout(
          () => this.invalidate(),
          Math.max(left, 0) + 1e3
        );
      }
    }
    /** The action of the button that has keyboard focus, if any. */
    #focusedAction(drawn) {
      return drawn.buttons.find(
        (item) => item.button === this.document.activeElement
      )?.action;
    }
    /** Focus the same button after a redraw, or Delete when it is gone. */
    #focusButton(action) {
      const buttons = this.#drawn?.buttons ?? [];
      (buttons.find((item) => item.action === action) ?? buttons[0])?.button.focus({ preventScroll: true });
    }
    #build(shown, accountId) {
      const document2 = this.document;
      const section = element(document2, "section", "joyfox-panel");
      section.setAttribute(UI_ATTRIBUTE, QUICK_ACTION);
      section.setAttribute("data-member", shown.target.memberId);
      section.setAttribute("role", "group");
      section.setAttribute("aria-label", t("quick.region"));
      const id = sectionIds += 1;
      const row = element(document2, "div", "joyfox-actions");
      const scopes = [];
      const buttons = [];
      const add = (action, label, description, onClick) => {
        const run = button(document2, "joyfox-button", t(label), () => {
          if (!this.#busy) onClick();
        });
        run.dataset.action = action;
        const scope = element(
          document2,
          "p",
          "joyfox-visually-hidden",
          t(description)
        );
        scope.id = `joyfox-quick-scope-${id}-${action}`;
        run.setAttribute("aria-describedby", scope.id);
        row.append(run);
        scopes.push(scope);
        buttons.push({ action, button: run, scope });
      };
      add(
        QUICK_DELETE,
        QUICK_ACTION_TEXT.deleteButton,
        QUICK_ACTION_TEXT.deleteScope,
        () => void this.#runDelete(shown, accountId)
      );
      if (this.#ignoreDeleteOn)
        add(
          QUICK_IGNORE_DELETE,
          QUICK_ACTION_TEXT.button,
          QUICK_ACTION_TEXT.scope,
          () => this.#run(shown, accountId)
        );
      const hint = element(
        document2,
        "p",
        "joyfox-note joyfox-quick-action__hint",
        t(QUICK_ACTION_TEXT.needsList)
      );
      hint.id = `joyfox-quick-hint-${id}`;
      hint.hidden = true;
      const status = element(document2, "div", "joyfox-quick-action__status");
      status.setAttribute("role", "status");
      status.setAttribute("aria-live", "polite");
      section.append(row, hint, ...scopes, status);
      return {
        key: shown.key,
        withIgnore: this.#ignoreDeleteOn,
        section,
        buttons,
        hint,
        status,
        lines: ""
      };
    }
    /**
     * The trash step of "Mark as junk" (C5): the Delete flow for `memberId`'s
     * conversation, shown on this page. The placement and the Negative
     * outcome are already stored, so every notice starts with that line, and
     * a trash step that cannot run says the conversation was not moved and
     * names the manual step (C7). `unavailable`: this page shows no Delete
     * for that member, so nothing was started or shown.
     */
    async junk(memberId) {
      const pending = this.#shown;
      if (pending?.target.memberId === memberId) await this.#ready(pending.key);
      const shown = this.#shown;
      const latest = this.#latest;
      if (!shown || shown.target.memberId !== memberId || this.#drawn?.key !== shown.key || latest?.key !== shown.key || latest.answer.status === "no-account")
        return "unavailable";
      const lead = [QUICK_ACTION_TEXT.junkDone];
      const refused = (...lines) => {
        this.#result = {
          key: shown.key,
          action: QUICK_DELETE,
          lines: [
            ...lead,
            ...lines,
            QUICK_ACTION_TEXT.junkNotTrashed,
            message("action.self.delete")
          ]
        };
        this.update();
        return "shown";
      };
      if (this.#busy) return refused(QUICK_ACTION_TEXT.junkBusy);
      if (!canVerifyDelete(this.driver()))
        return refused(QUICK_ACTION_TEXT.needsList);
      await this.#runDelete(shown, latest.answer.accountId, lead);
      return "shown";
    }
    /**
     * Delete alone (A1 to A8): one click moves the conversation to JoyClub's
     * trash, with the checks of Quick Ignore and Delete's Delete step. A
     * completed run returns to the ClubMail list after `returnWaitMs`; a
     * failed one stays, and its notice names the next manual step. `lead`
     * comes first in every notice of the run.
     */
    #runDelete(shown, accountId, lead = []) {
      const driver = this.driver();
      if (this.#running || !driver) return Promise.resolve();
      this.#stop = void 0;
      const busyLines = lead.length ? [
        QUICK_ACTION_TEXT.junkBusy,
        QUICK_ACTION_TEXT.junkNotTrashed,
        message("action.self.delete")
      ] : [QUICK_ACTION_TEXT.busy];
      this.#running = {
        key: shown.key,
        action: QUICK_DELETE,
        progress: DELETE_PROGRESS_TEXT.Started,
        lead
      };
      this.#result = void 0;
      this.update();
      return runQuickDelete({
        target: shown.target,
        driver,
        recorder: this.client.recorder(accountId),
        // Delete does not need the experimental flag (D2), so turning it off
        // never stops this run.
        stopReason: () => this.#stop === "turned-off" ? void 0 : this.#stop,
        onState: (state) => {
          const text2 = DELETE_PROGRESS_TEXT[state];
          if (!text2 || this.#running?.action !== QUICK_DELETE) return;
          this.#running = { ...this.#running, progress: text2 };
          if (this.#shown) this.update();
        }
      }).then((result) => {
        this.#result = {
          key: shown.key,
          action: QUICK_DELETE,
          lines: [
            ...lead,
            ...result.status === "busy" ? busyLines : result.report.lines
          ]
        };
        if (result.report.status === "completed" && !this.#stop)
          this.#returnFromConversation(shown.target);
      }).catch(() => {
        this.#result = {
          key: shown.key,
          action: QUICK_DELETE,
          lines: [...lead, QUICK_ACTION_TEXT.deleteUnexpected]
        };
      }).finally(() => {
        this.#running = void 0;
        if (this.#shown) this.invalidate();
      });
    }
    #run(shown, accountId) {
      const driver = this.driver();
      if (this.#running || !driver) return;
      this.#stop = void 0;
      const profile = profileUrl(shown.anchor, shown.target.memberId);
      if (!profile) {
        this.#result = {
          key: shown.key,
          action: QUICK_IGNORE_DELETE,
          lines: [QUICK_ACTION_TEXT.noProfile]
        };
        this.update();
        return;
      }
      this.#running = {
        key: shown.key,
        action: QUICK_IGNORE_DELETE,
        progress: PROGRESS_TEXT.Started
      };
      this.#result = void 0;
      this.update();
      void runQuickIgnoreDelete({
        target: shown.target,
        driver,
        recorder: this.client.recorder(accountId),
        stopReason: () => this.#stop,
        // Ignore is on the profile page: store the marker; the page moves
        // only once the run returns "handed-off".
        handOff: (operationId, next) => this.client.handOff(
          accountId,
          operationId,
          next,
          new URL(profile).pathname
        ),
        onState: (state) => {
          const text2 = PROGRESS_TEXT[state];
          if (!text2 || this.#running?.action !== QUICK_IGNORE_DELETE) return;
          this.#running = { ...this.#running, progress: text2 };
          if (this.#shown) this.update();
        }
      }).then((result) => {
        if (result.status === "handed-off") {
          this.navigate(profile);
          this.#awaitDeparture(shown.key, accountId, result.operationId);
        }
        this.#result = {
          key: shown.key,
          action: QUICK_IGNORE_DELETE,
          lines: result.status === "busy" ? [QUICK_ACTION_TEXT.busy] : result.status === "handed-off" ? [QUICK_ACTION_TEXT.handedOff] : result.report.lines
        };
      }).catch(() => {
        this.#result = {
          key: shown.key,
          action: QUICK_IGNORE_DELETE,
          lines: [QUICK_ACTION_TEXT.unexpected]
        };
      }).finally(() => {
        this.#running = void 0;
        if (this.#stop === "turned-off") this.#result = void 0;
        if (this.#shown) this.invalidate();
      });
    }
    /**
     * The hand-off loads a new page, so this page goes. If it is still here
     * after `handOffWaitMs`, the navigation was cancelled or never finished:
     * the marker is withdrawn, so a later visit to the profile in this tab
     * never continues the run, and the notice shows what the run did.
     */
    #awaitDeparture(key2, accountId, operationId) {
      const view = this.document.defaultView;
      if (!operationId || !view) return;
      const timer = setTimeout(() => {
        view.removeEventListener("pagehide", left);
        this.client.withdraw(accountId, operationId).then((answer) => {
          if (answer.status === "withdrawn")
            this.#result = {
              key: key2,
              action: QUICK_IGNORE_DELETE,
              lines: answer.lines
            };
        }).catch(() => void 0).finally(() => this.invalidate());
      }, this.handOffWaitMs);
      const left = () => clearTimeout(timer);
      view.addEventListener("pagehide", left, { once: true });
    }
  };
  function safely(check) {
    try {
      return check();
    } catch {
      return false;
    }
  }
  function canVerifyDelete(driver) {
    try {
      return driver?.canVerify?.("delete") ?? true;
    } catch {
      return true;
    }
  }
  function profileUrl(header, memberId) {
    const href = header.getAttribute("href");
    const pattern = selectorRegistry.profile.path;
    if (!href || !pattern) return void 0;
    let url;
    try {
      url = new URL(href, header.ownerDocument.URL);
    } catch {
      return void 0;
    }
    if (url.origin !== new URL(header.ownerDocument.URL).origin) return void 0;
    const match = new RegExp(pattern).exec(url.pathname);
    return match?.[1] === memberId ? url.href : void 0;
  }

  // src/search/saved-search.ts
  var MAX_SAVED_SEARCH_NAME_LENGTH = 80;
  var MAX_SAVED_SEARCHES = 50;
  var MAX_SAVED_SEARCH_URL_LENGTH = 2e3;
  var NO_MATCH = { status: "no-match" };
  function decode2(segment) {
    try {
      return decodeURIComponent(segment);
    } catch {
      return segment;
    }
  }
  function readSearchAddress(url) {
    const definition = selectorRegistry.search;
    if (definition.status !== "verified" || !definition.path || url.length > MAX_SAVED_SEARCH_URL_LENGTH)
      return NO_MATCH;
    let parsed;
    try {
      parsed = new URL(url);
    } catch {
      return NO_MATCH;
    }
    if (parsed.protocol !== "https:" || parsed.username !== "" || parsed.password !== "" || parsed.port !== "" || !VERIFIED_HOSTS.includes(parsed.hostname) || !new RegExp(definition.path).test(parsed.pathname))
      return NO_MATCH;
    return {
      status: "ok",
      url: parsed.href,
      filters: {
        path: parsed.pathname.split("/").slice(2).filter((segment) => segment.length > 0).map(decode2),
        query: queryPairs(parsed.searchParams)
      }
    };
  }
  function queryPairs(params) {
    const pairs = [];
    params.forEach((value, name) => pairs.push([name, value]));
    return pairs;
  }
  function isFilters(value) {
    if (typeof value !== "object" || value === null) return false;
    const { path, query } = value;
    return Array.isArray(path) && path.every((segment) => typeof segment === "string") && Array.isArray(query) && query.every(
      (pair) => Array.isArray(pair) && pair.length === 2 && typeof pair[0] === "string" && typeof pair[1] === "string"
    );
  }
  function sameFilters(a, b) {
    return JSON.stringify(a) === JSON.stringify(b);
  }
  function replayAddress(saved) {
    const address = readSearchAddress(saved.url);
    if (address.status !== "ok" || !isFilters(saved.filters)) return void 0;
    return sameFilters(address.filters, saved.filters) ? address.url : void 0;
  }
  var normalizeSearchName = (name) => name.trim().replace(/\s+/gu, " ");

  // src/content/saved-searches.ts
  function messageSavedSearchClient(sender) {
    return {
      list: () => request(sender, "search.list", {}),
      save: (accountId, name, url) => request(sender, "search.save", { accountId, name, url }),
      remove: (accountId, id) => request(sender, "search.delete", { accountId, id }),
      async openOptions() {
        await request(sender, "options.open", {});
      }
    };
  }
  function runtimeSavedSearchClient() {
    return messageSavedSearchClient(
      (message2) => browser.runtime.sendMessage(message2)
    );
  }
  var NAME_INPUT = "joyfox-saved-searches__name";
  var RUN_SEARCH_MARKER = "#joyfox-run-search";
  var DEFAULT_RUN_TIMING = { waitMs: 8e3, pollMs: 250 };
  var RUN_REQUEST_KEY = "joyfox.runSavedSearch";
  var RUN_REQUEST_TTL_MS = 6e4;
  function withoutFragment(url) {
    const parsed = new URL(url);
    parsed.hash = "";
    return parsed.href;
  }
  function press2(control) {
    const inner = control.shadowRoot?.querySelector("button");
    (inner ?? control).click();
  }
  var SavedSearchBar = class {
    constructor(document2, client, navigate = (url) => document2.location.assign(url), currentUrl = () => document2.location.href, options = {}) {
      this.document = document2;
      this.client = client;
      this.navigate = navigate;
      this.currentUrl = currentUrl;
      this.options = options;
    }
    #root;
    #heading;
    /** The part each draw replaces; the heading and the notice stay. */
    #body;
    #statusNode;
    /** The page address the list was drawn for, which marks the current one. */
    #drawnFor;
    #data;
    /**
     * Bumped on teardown and on an account switch, so a late answer for the
     * page or account shown before is dropped.
     */
    #session = 0;
    /** Bumped on every load, so only the newest list is drawn. */
    #loadSequence = 0;
    #status;
    /** The name box is open, and what was typed in it. */
    #naming = false;
    #draft = "";
    /** The saved search whose ✕ was clicked once; a second click deletes. */
    #armed;
    /**
     * A save or delete is on its way. A second Enter, double click or ✕
     * meanwhile is ignored, so one action never stores or deletes twice.
     */
    #busy = false;
    /** The address was checked for `RUN_SEARCH_MARKER` on this page. */
    #markerChecked = false;
    /** JoyFox is opening the filter panel and clicking "Anwenden". */
    #running = false;
    /** The saved search run on this page, for the notice while and after. */
    #run;
    get #timing() {
      return this.options.timing ?? DEFAULT_RUN_TIMING;
    }
    #now() {
      return this.options.now?.() ?? Date.now();
    }
    /** The tab's session storage, or nothing where the browser blocks it. */
    #store() {
      try {
        return this.options.store ? this.options.store() : this.document.defaultView?.sessionStorage ?? void 0;
      } catch {
        return void 0;
      }
    }
    /** Records the click; false when the tab cannot store it. */
    #requestRun(address) {
      try {
        const store = this.#store();
        if (!store) return false;
        store.setItem(
          RUN_REQUEST_KEY,
          JSON.stringify({ address, expires: this.#now() + RUN_REQUEST_TTL_MS })
        );
        return true;
      } catch {
        return false;
      }
    }
    /** Reads and removes the tab's run request: whether it is for `address`. */
    #takeRunRequest(address) {
      try {
        const store = this.#store();
        const raw = store?.getItem(RUN_REQUEST_KEY);
        store?.removeItem(RUN_REQUEST_KEY);
        if (!raw) return false;
        const request2 = JSON.parse(raw);
        return request2.address === address && typeof request2.expires === "number" && request2.expires >= this.#now();
      } catch {
        return false;
      }
    }
    /** Place the bar above the result list, again after JoyClub redraws it. */
    update() {
      const selector = verifiedSelector("search", "resultList");
      const list = selector ? this.document.querySelector(selector) : null;
      if (!list) return this.leave();
      this.#checkMarker();
      if (this.#root?.isConnected) {
        if (this.#drawnFor !== this.#address()) this.#draw();
        return;
      }
      if (!this.#root) {
        const document2 = this.document;
        const root = element(document2, "section", "joyfox-saved-searches");
        root.setAttribute(UI_ATTRIBUTE, "saved-searches");
        const heading = element(document2, "p", "joyfox-saved-searches__heading");
        const body = element(document2, "div", "joyfox-saved-searches__body");
        const status = element(document2, "p", "joyfox-saved-searches__status");
        status.setAttribute("role", "status");
        status.setAttribute("aria-live", "polite");
        root.append(heading, body, status);
        this.#root = root;
        this.#heading = heading;
        this.#body = body;
        this.#statusNode = status;
        this.#draw();
        void this.#load();
      }
      list.before(this.#root);
    }
    leave() {
      this.#session += 1;
      this.#root?.remove();
      this.#root = void 0;
      this.#heading = void 0;
      this.#body = void 0;
      this.#statusNode = void 0;
      this.#drawnFor = void 0;
      this.#run = void 0;
      this.#data = void 0;
      this.#status = void 0;
      this.#naming = false;
      this.#draft = "";
      this.#armed = void 0;
    }
    /** Another account's searches must never stay on screen after a switch. */
    accountChanged() {
      this.#session += 1;
      if (!this.#root) return;
      this.#data = void 0;
      this.#status = void 0;
      this.#naming = false;
      this.#draft = "";
      this.#armed = void 0;
      this.#draw();
      void this.#load();
    }
    /** A search saved or deleted in another tab, or data deleted. */
    invalidate() {
      if (this.#root) void this.#load();
    }
    localeChanged() {
      if (this.#root) this.#draw();
    }
    /** The page's address without its fragment. */
    #address() {
      return withoutFragment(this.currentUrl());
    }
    /** Whether a saved search opens `address`. */
    #opens(search, address) {
      const url = replayAddress(search);
      return url !== void 0 && withoutFragment(url) === address;
    }
    /** Run the saved search this page was opened for, once per page. */
    #checkMarker() {
      if (this.#markerChecked) return;
      this.#markerChecked = true;
      const url = new URL(this.currentUrl());
      if (url.hash !== RUN_SEARCH_MARKER) return;
      const history = this.document.defaultView?.history;
      history?.replaceState(history.state, "", url.pathname + url.search);
      const address = withoutFragment(url.href);
      if (this.#takeRunRequest(address)) void this.#runSearch(address);
    }
    /**
     * Open JoyClub's filter panel and click "Anwenden" once, so the results
     * follow the filters in the address.
     */
    async #runSearch(address) {
      if (this.#running) return;
      this.#running = true;
      const session = this.#session;
      const current = () => session === this.#session && withoutFragment(this.currentUrl()) === address;
      this.#run = { address, done: false };
      this.#status = void 0;
      this.#draw();
      try {
        for (const field of ["filterButton", "applyButton"]) {
          const control = await this.#waitFor(field, current);
          if (!current()) {
            if (session === this.#session) {
              this.#run = void 0;
              this.#draw();
            }
            return;
          }
          if (!control)
            return this.#setStatus(message("searches.runFailed"), true);
          press2(control);
        }
        this.#run = { address, done: true };
        this.#draw();
      } finally {
        this.#running = false;
      }
    }
    /** The verified search control, polled until it appears or time is up. */
    async #waitFor(field, current) {
      const selector = verifiedSelector("search", field);
      if (!selector) return void 0;
      const { waitMs, pollMs } = this.#timing;
      for (let waited = 0; ; waited += pollMs) {
        if (!current()) return void 0;
        const control = this.document.querySelector(selector);
        if (control) return control;
        if (waited >= waitMs) return void 0;
        await new Promise((resolve) => setTimeout(resolve, pollMs));
      }
    }
    async #load() {
      const session = this.#session;
      const sequence = this.#loadSequence += 1;
      const current = () => session === this.#session && sequence === this.#loadSequence;
      let answer;
      try {
        answer = await this.client.list();
      } catch {
        if (!current()) return;
        this.#status = { text: message("searches.readFailed"), error: true };
        this.#draw();
        return;
      }
      if (!current()) return;
      this.#data = answer;
      if (this.#status?.text.key === "searches.readFailed")
        this.#status = void 0;
      if (!answer.searches.some((search) => search.id === this.#armed))
        this.#armed = void 0;
      this.#draw();
    }
    /** The notice of the saved search run on this page, by its name. */
    #runStatus() {
      const run = this.#run;
      if (!run || run.address !== this.#address()) return void 0;
      const name = this.#data?.searches.find(
        (search) => this.#opens(search, run.address)
      )?.name;
      const text2 = run.done ? name ? message("searches.shown", { name }) : message("searches.shownUnnamed") : name ? message("searches.running", { name }) : message("searches.runningUnnamed");
      return { text: text2, error: false };
    }
    #draw() {
      const root = this.#root;
      const body = this.#body;
      if (!root || !body) return;
      const document2 = this.document;
      const focus = rememberFocus(root);
      const heading = t("searches.heading");
      root.setAttribute("aria-label", heading);
      if (this.#heading && this.#heading.textContent !== heading)
        this.#heading.textContent = heading;
      this.#drawnFor = this.#address();
      body.replaceChildren();
      const data = this.#data;
      if (!data) {
        if (!this.#status)
          body.append(
            element(document2, "p", "joyfox-note", t("searches.loading"))
          );
      } else if (!data.accountId) {
        const options = button(
          document2,
          "joyfox-button",
          t("common.openOptions"),
          () => void this.client.openOptions().catch(() => void 0)
        );
        options.setAttribute(FOCUS_KEY, "options");
        body.append(
          element(document2, "p", "joyfox-note", t("searches.noAccount")),
          options
        );
      } else body.append(this.#list(data.searches), this.#saveRow());
      const shown = this.#status ?? this.#runStatus();
      if (this.#statusNode) {
        const text2 = shown ? t(shown.text) : "";
        if (this.#statusNode.textContent !== text2)
          this.#statusNode.textContent = text2;
        this.#statusNode.classList.toggle("joyfox-error", shown?.error === true);
      }
      restoreFocus(
        root,
        focus,
        /^(open|delete):/u.test(focus?.key ?? "") ? ["save", "name", "options"] : ["name", "save", "options"]
      );
    }
    #list(searches) {
      const document2 = this.document;
      if (searches.length === 0)
        return element(document2, "p", "joyfox-note", t("searches.empty"));
      const list = element(document2, "ul", "joyfox-saved-searches__list");
      const address = this.#address();
      for (const search of searches) {
        const item = element(document2, "li", "joyfox-saved-searches__item");
        const open = button(
          document2,
          "joyfox-button joyfox-saved-searches__open",
          search.name,
          () => this.#open(search)
        );
        open.setAttribute(FOCUS_KEY, `open:${search.id}`);
        if (this.#opens(search, address))
          open.setAttribute("aria-current", "true");
        const remove = button(
          document2,
          "joyfox-button joyfox-saved-searches__delete",
          "\u2715",
          () => void this.#remove(search)
        );
        const label = t(message("searches.deleteLabel", { name: search.name }));
        remove.setAttribute("aria-label", label);
        remove.setAttribute(FOCUS_KEY, `delete:${search.id}`);
        remove.title = label;
        if (this.#armed === search.id)
          remove.setAttribute("aria-pressed", "true");
        item.append(open, remove);
        list.append(item);
      }
      return list;
    }
    #saveRow() {
      const document2 = this.document;
      const row = element(document2, "div", "joyfox-saved-searches__save");
      if (!this.#naming) {
        const save = button(document2, "joyfox-button", t("searches.save"), () => {
          this.#naming = true;
          this.#status = void 0;
          this.#run = void 0;
          this.#draw();
          this.#root?.querySelector(`.${NAME_INPUT}`)?.focus();
        });
        save.setAttribute(FOCUS_KEY, "save");
        row.append(save);
        return row;
      }
      const input = element(document2, "input", NAME_INPUT);
      input.setAttribute(FOCUS_KEY, "name");
      input.type = "text";
      input.maxLength = MAX_SAVED_SEARCH_NAME_LENGTH;
      input.autocomplete = "off";
      input.value = this.#draft;
      input.setAttribute("aria-label", t("searches.nameLabel"));
      input.placeholder = t("searches.nameLabel");
      input.addEventListener("input", () => {
        this.#draft = input.value;
      });
      input.addEventListener("keydown", (event) => {
        event.stopPropagation();
        if (event.key === "Enter") {
          event.preventDefault();
          void this.#save();
        } else if (event.key === "Escape") {
          event.preventDefault();
          this.#cancel();
        }
      });
      const confirm = button(
        document2,
        "joyfox-button",
        t("searches.confirmSave"),
        () => {
          void this.#save();
        }
      );
      confirm.setAttribute(FOCUS_KEY, "confirm");
      const cancel = button(
        document2,
        "joyfox-button",
        t("searches.cancel"),
        () => this.#cancel()
      );
      cancel.setAttribute(FOCUS_KEY, "cancel");
      row.append(input, confirm, cancel);
      return row;
    }
    #cancel() {
      this.#naming = false;
      this.#draft = "";
      this.#draw();
    }
    #setStatus(text2, error) {
      this.#status = { text: text2, error };
      this.#run = void 0;
      this.#draw();
    }
    #open(search) {
      this.#armed = void 0;
      const url = replayAddress(search);
      if (!url)
        return this.#setStatus(
          message("searches.noMatch", { name: search.name }),
          true
        );
      const address = withoutFragment(url);
      if (!this.#requestRun(address)) return this.navigate(address);
      if (address === withoutFragment(this.currentUrl())) {
        const view = this.document.defaultView;
        const target = new URL(address);
        view?.history.replaceState(
          view.history.state,
          "",
          target.pathname + target.search + RUN_SEARCH_MARKER
        );
        return (this.options.reload ?? (() => view?.location.reload()))();
      }
      this.navigate(address + RUN_SEARCH_MARKER);
    }
    async #save() {
      if (this.#busy) return;
      const accountId = this.#data?.accountId;
      if (!accountId) return;
      const name = normalizeSearchName(this.#draft);
      if (name.length === 0)
        return this.#setStatus(message("searches.noName"), true);
      if (name.length > MAX_SAVED_SEARCH_NAME_LENGTH)
        return this.#setStatus(
          message("searches.nameTooLong", {
            maximum: MAX_SAVED_SEARCH_NAME_LENGTH
          }),
          true
        );
      const address = readSearchAddress(this.currentUrl());
      if (address.status !== "ok")
        return this.#setStatus(message("searches.notSearchAddress"), true);
      const session = this.#session;
      let answer;
      this.#busy = true;
      try {
        answer = await this.client.save(accountId, name, address.url);
      } catch {
        if (session === this.#session)
          this.#setStatus(message("common.saveFailed"), true);
        return;
      } finally {
        this.#busy = false;
      }
      if (session !== this.#session) return;
      if (answer.status === "saved") {
        this.#naming = false;
        this.#draft = "";
        this.#run = void 0;
        this.#status = {
          text: message("searches.saved", { name }),
          error: false
        };
        void this.#load();
        return;
      }
      this.#setStatus(
        answer.status === "full" ? message("searches.full", { maximum: MAX_SAVED_SEARCHES }) : answer.status === "no-match" ? message("searches.notSearchAddress") : message("searches.refused"),
        true
      );
    }
    async #remove(search) {
      if (this.#busy) return;
      const accountId = this.#data?.accountId;
      if (!accountId) return;
      if (this.#armed !== search.id) {
        this.#armed = search.id;
        return this.#setStatus(
          message("searches.confirmDelete", { name: search.name }),
          false
        );
      }
      this.#armed = void 0;
      const session = this.#session;
      let answer;
      this.#busy = true;
      try {
        answer = await this.client.remove(accountId, search.id);
      } catch {
        if (session === this.#session)
          this.#setStatus(message("common.saveFailed"), true);
        return;
      } finally {
        this.#busy = false;
      }
      if (session !== this.#session) return;
      if (answer.status === "deleted") {
        this.#run = void 0;
        this.#status = {
          text: message("searches.deleted", { name: search.name }),
          error: false
        };
        void this.#load();
        return;
      }
      this.#setStatus(message("searches.refused"), true);
    }
  };

  // src/templates/insertion.ts
  function insertAtCursor(field, text2) {
    if (!field.isConnected || field.disabled || field.readOnly)
      return { status: "refused", reason: "not-editable" };
    const current = field.value;
    const start = Math.min(
      field.selectionStart ?? current.length,
      current.length
    );
    const end = Math.max(
      start,
      Math.min(field.selectionEnd ?? start, current.length)
    );
    const expected = current.slice(0, start) + text2 + current.slice(end);
    if (field.maxLength >= 0 && expected.length > field.maxLength) {
      field.focus();
      return {
        status: "refused",
        reason: "too-long",
        limit: field.maxLength,
        over: expected.length - field.maxLength
      };
    }
    field.focus();
    field.setRangeText(text2, start, end, "end");
    const view = field.ownerDocument.defaultView;
    const InputEventType = view?.InputEvent ?? InputEvent;
    const EventType = view?.Event ?? Event;
    field.dispatchEvent(
      new InputEventType("input", {
        bubbles: true,
        inputType: "insertText",
        data: text2
      })
    );
    field.dispatchEvent(new EventType("change", { bubbles: true }));
    return field.value === expected ? { status: "inserted" } : { status: "altered" };
  }

  // src/content/template-picker.ts
  var TEMPLATE_PICKER_KEY = "joyfox.templatePicker";
  function messageTemplateClient(sender) {
    return {
      listTemplates: () => request(sender, "template.list", {}),
      async openOptions() {
        await request(sender, "options.open", {});
      }
    };
  }
  function runtimeTemplateClient() {
    return messageTemplateClient(
      (message2) => browser.runtime.sendMessage(message2)
    );
  }
  function resultText(result) {
    if (result.status === "inserted") return message("picker.result.inserted");
    if (result.status === "altered") return message("picker.result.altered");
    return result.reason === "too-long" ? message("picker.result.too-long", {
      over: result.over,
      limit: result.limit
    }) : message("picker.result.not-editable");
  }
  var folderName = (template) => template.folder || t("templates.folder.general");
  var TemplatePicker = class {
    constructor(document2, client) {
      this.document = document2;
      this.client = client;
    }
    #root;
    #composer;
    #list;
    #toggle;
    #status;
    /** The notice shown, kept so a language change can redraw it. */
    #statusText;
    /** Bumped on every open and teardown, so a late answer is dropped. */
    #generation = 0;
    /** Mount beside the composer, or move with it when JoyClub replaces it. */
    update() {
      const selector = verifiedSelector("conversation", "composer");
      const found2 = selector ? this.document.querySelector(selector) : null;
      const composer = found2 instanceof (this.document.defaultView?.HTMLTextAreaElement ?? HTMLTextAreaElement) ? found2 : void 0;
      if (!composer) return this.leave();
      if (composer === this.#composer && this.#root?.isConnected) return;
      this.leave();
      this.#composer = composer;
      this.#mount(composer);
    }
    leave() {
      this.#generation += 1;
      this.#root?.remove();
      this.#root = void 0;
      this.#composer = void 0;
      this.#list = void 0;
      this.#toggle = void 0;
      this.#status = void 0;
    }
    /** Another account's templates must never stay on screen after a switch. */
    accountChanged() {
      this.#close();
    }
    /**
     * The language changed: relabel the button and the notice. An open list
     * is read again, so its folder names follow too.
     */
    localeChanged() {
      if (!this.#root) return;
      if (this.#toggle) this.#toggle.textContent = t("picker.toggle");
      this.#setStatus(this.#statusText);
      if (this.#list) void this.#open();
    }
    #mount(composer) {
      const document2 = this.document;
      const root = element(document2, "div", "joyfox-template-picker");
      root.setAttribute(UI_ATTRIBUTE, "template-picker");
      const toggle = button(
        document2,
        "joyfox-template-picker__toggle",
        t("picker.toggle"),
        () => this.#list ? this.#close() : void this.#open()
      );
      toggle.setAttribute("aria-expanded", "false");
      const status = element(document2, "p", "joyfox-template-picker__status");
      status.setAttribute("role", "status");
      status.setAttribute("aria-live", "polite");
      root.append(toggle, status);
      (composer.form ?? composer).after(root);
      this.#root = root;
      this.#toggle = toggle;
      this.#status = status;
    }
    #close() {
      this.#generation += 1;
      this.#list?.remove();
      this.#list = void 0;
      this.#toggle?.setAttribute("aria-expanded", "false");
    }
    async #open() {
      this.#close();
      const generation = this.#generation;
      this.#setStatus(message("picker.loading"));
      let answer;
      try {
        answer = await this.client.listTemplates();
      } catch {
        if (generation === this.#generation)
          this.#setStatus(message("picker.readFailed"));
        return;
      }
      if (generation !== this.#generation || !this.#root) return;
      this.#setStatus(void 0);
      const list = element(this.document, "div", "joyfox-template-picker__list");
      list.id = "joyfox-template-picker-list";
      this.#toggle?.setAttribute("aria-controls", list.id);
      if (!answer.accountId || answer.templates.length === 0) {
        list.append(
          element(
            this.document,
            "p",
            "joyfox-template-picker__empty",
            t(answer.accountId ? "picker.empty" : "picker.noAccount")
          ),
          button(
            this.document,
            "joyfox-template-picker__options",
            t("common.openOptions"),
            () => void this.client.openOptions().catch(() => void 0)
          )
        );
      } else {
        for (const [folder, templates] of groupByFolder(answer.templates)) {
          const group = element(
            this.document,
            "div",
            "joyfox-template-picker__group"
          );
          group.setAttribute("role", "group");
          group.setAttribute("aria-label", folder);
          group.append(
            element(this.document, "p", "joyfox-template-picker__folder", folder)
          );
          for (const template of templates)
            group.append(
              button(
                this.document,
                "joyfox-template-picker__item",
                template.name,
                () => this.#insert(template)
              )
            );
          list.append(group);
        }
      }
      this.#root.append(list);
      this.#list = list;
      this.#toggle?.setAttribute("aria-expanded", "true");
    }
    #insert(template) {
      const composer = this.#composer;
      this.#close();
      if (!composer) return;
      this.#setStatus(resultText(insertAtCursor(composer, template.body)));
      if (this.document.activeElement !== composer)
        this.#toggle?.focus({ preventScroll: true });
    }
    #setStatus(text2) {
      this.#statusText = text2;
      if (this.#status) this.#status.textContent = text2 ? t(text2) : "";
    }
  };
  function groupByFolder(templates) {
    const groups = /* @__PURE__ */ new Map();
    for (const template of templates) {
      const folder = folderName(template);
      const group = groups.get(folder) ?? [];
      group.push(template);
      groups.set(folder, group);
    }
    for (const group of groups.values())
      group.sort(
        (a, b) => a.name.localeCompare(b.name) || a.id.localeCompare(b.id)
      );
    return Array.from(groups).sort(([a], [b]) => a.localeCompare(b));
  }

  // src/content/triage-client.ts
  function messageTriageClient(sender) {
    return {
      evaluate: (members) => request(sender, "triage.evaluate", { members }),
      async setOverride(accountId, memberId, placement) {
        const answer = await request(sender, "triage.setOverride", {
          accountId,
          memberId,
          placement
        });
        if (!answer.done) throw new Error("The placement was not saved");
      },
      getTrust: (memberId, observed) => request(sender, "trust.get", { memberId, observed }),
      async logTrust(accountId, memberId, kind) {
        const answer = await request(sender, "trust.log", {
          accountId,
          memberId,
          kind
        });
        if (!answer.done) throw new Error("The outcome was not logged");
      },
      async undoTrust(accountId, memberId) {
        await request(sender, "trust.undo", { accountId, memberId });
      },
      async captureSnapshot(accountId, memberId, observed, extras = {}) {
        await request(sender, "snapshot.capture", {
          accountId,
          memberId,
          observed,
          ...extras
        });
      },
      async optOutSharedEvent(accountId, memberId) {
        await request(sender, "triage.sharedEventOptOut", {
          accountId,
          memberId
        });
      },
      async openOptions() {
        await request(sender, "options.open", {});
      }
    };
  }
  function runtimeTriageClient() {
    return messageTriageClient(
      (message2) => browser.runtime.sendMessage(message2)
    );
  }

  // src/content/index.ts
  if (hasVerifiedSelectors() && VERIFIED_HOSTS.includes(location.hostname)) {
    const coordinator = new NavigationCoordinator(detectPage);
    const storageEvents = globalThis.browser?.storage?.onChanged;
    const diagnostics = new DiagnosticsFlag(
      () => runtimeSettingsArea.get([DIAGNOSTICS_KEY]),
      storageEvents
    );
    const templatePicker = new DiagnosticsFlag(
      () => runtimeSettingsArea.get([TEMPLATE_PICKER_KEY]),
      storageEvents,
      TEMPLATE_PICKER_KEY,
      true
    );
    const quickAction = new DiagnosticsFlag(
      () => runtimeSettingsArea.get([QUICK_ACTION_KEY]),
      storageEvents,
      QUICK_ACTION_KEY,
      true
    );
    const stripCollapsed = new DiagnosticsFlag(
      () => runtimeSettingsArea.get([STRIP_COLLAPSED_KEY]),
      storageEvents,
      STRIP_COLLAPSED_KEY
    );
    const messageCaching = new DiagnosticsFlag(
      () => runtimeSettingsArea.get([MESSAGE_CACHING_KEY]),
      storageEvents,
      MESSAGE_CACHING_KEY,
      true
    );
    let activeAccountId;
    let accountHeard = false;
    const accountIdOf = (value) => typeof value === "string" && value.length > 0 ? value : void 0;
    const accountRead = runtimeSettingsArea.get([ACTIVE_ACCOUNT_SETTING_KEY]).then((settings) => {
      if (!accountHeard)
        activeAccountId = accountIdOf(settings[ACTIVE_ACCOUNT_SETTING_KEY]);
    }).catch(() => void 0);
    const messageCache = new MessageCache(
      document,
      runtimeMessageCacheClient(),
      () => activeAccountId
    );
    const sharedEvents = new SharedEvents(
      document,
      runtimeSharedEventsClient(),
      () => activeAccountId
    );
    const updateMessageCache = () => {
      if (lastType === "conversation")
        messageCache.update(messageCaching.enabled);
    };
    const client = runtimeTriageClient();
    const quick = new QuickIgnoreDelete(
      document,
      runtimeQuickActionClient(),
      liveQuickActionDriver
    );
    const inbox = new InboxTriage(document, client);
    const panel = new MemberPanel(document, client, quick);
    const notes = new MemberNotes(document, runtimeNotesClient());
    const picker = new TemplatePicker(document, runtimeTemplateClient());
    const searches = new SavedSearchBar(document, runtimeSavedSearchClient());
    const listingClient = runtimeListingClient();
    const listing = new ListingPanel(document, listingClient);
    const eventFilter = new EventListFilter(document, listingClient);
    const typeFilter = new ProfileTypeFilter(document);
    const cardSignals = new CardSignals(
      document,
      runtimeSignalsClient(),
      runtimeNotesClient()
    );
    const compatibility = new CompatibilityOverlay(
      document,
      runtimeCompatibilityClient()
    );
    onLocaleChange(() => {
      inbox.localeChanged();
      panel.localeChanged();
      notes.localeChanged();
      picker.localeChanged();
      quick.localeChanged();
      searches.localeChanged();
      listing.localeChanged();
      eventFilter.localeChanged();
      typeFilter.localeChanged();
      compatibility.localeChanged();
      cardSignals.localeChanged();
      sharedEvents.localeChanged();
      sharedEvents.update(lastType);
    });
    const preferenceRetry = new PreferenceRetry(() => coordinator.refresh());
    let lastType;
    const updatePicker = () => {
      if (lastType === "conversation" && templatePicker.enabled) picker.update();
      else picker.leave();
    };
    const updateQuickAction = () => {
      if (quickAction.enabled) {
        quick.turnOn();
        quick.pageSeen();
      } else quick.turnOff();
      if (lastType === "conversation") quick.update();
      else if (lastType === "profile" && quickAction.enabled)
        quick.updateProfile();
      else quick.leave();
    };
    let lastSummary = "";
    coordinator.subscribe(({ page }) => {
      const type = page.status === "found" ? page.value : void 0;
      if (inboxListShown(document)) inbox.update();
      else inbox.leave();
      if (type === "conversation" || type === "profile") {
        panel.update(type);
        notes.update(type);
      } else {
        panel.leave();
        notes.leave();
      }
      if (type === "search") searches.update();
      else searches.leave();
      if (type === "event" || type === "venue") listing.update(type);
      else listing.leave();
      if (type === "event-calendar") eventFilter.update();
      else eventFilter.leave();
      if (type === "my-joy-list") typeFilter.update();
      else typeFilter.leave();
      compatibility.update(type);
      cardSignals.update(type);
      sharedEvents.update(type);
      preferenceRetry.check(
        document.URL,
        type === "profile" && readPreferences(document).status === "unreadable"
      );
      lastType = type;
      updateMessageCache();
      updatePicker();
      updateQuickAction();
    });
    let lastPageLine = "";
    coordinator.subscribe(({ page }) => {
      if (!diagnostics.enabled) return;
      const pageLine = `page=${page.status === "found" ? page.value : `${page.status}:${page.source ?? ""}`} inboxList=${inboxListState(document)}`;
      if (pageLine !== lastPageLine) {
        lastPageLine = pageLine;
        logDiagnostic(pageLine);
      }
      if (!inboxListShown(document)) return;
      const summary = summarizeInbox(extractInboxRows(document, location.href));
      if (summary === lastSummary) return;
      lastSummary = summary;
      logDiagnostic(summary);
    });
    let localeChanged = false;
    storageEvents?.addListener((changes, area) => {
      if (area !== "local") return;
      if (LOCALE_KEY in changes) {
        localeChanged = true;
        setLocale(localeFromSetting(changes[LOCALE_KEY]?.newValue));
      }
      if (TEMPLATE_PICKER_KEY in changes) updatePicker();
      if (QUICK_ACTION_KEY in changes) updateQuickAction();
      if (STRIP_COLLAPSED_KEY in changes)
        setStripCollapsed(document, stripCollapsed.enabled);
      if (MESSAGE_CACHING_KEY in changes) {
        messageCache.reset();
        updateMessageCache();
      }
      if (ACTION_REVISION_KEY in changes) quick.invalidate();
      if (ACTIVE_ACCOUNT_SETTING_KEY in changes) {
        inbox.accountChanged();
        panel.accountChanged();
        notes.accountChanged();
        picker.accountChanged();
        quick.accountChanged();
        searches.accountChanged();
        listing.accountChanged();
        eventFilter.accountChanged();
        compatibility.accountChanged();
        cardSignals.accountChanged();
        accountHeard = true;
        activeAccountId = accountIdOf(
          changes[ACTIVE_ACCOUNT_SETTING_KEY]?.newValue
        );
        messageCache.reset();
        updateMessageCache();
        sharedEvents.invalidate();
        sharedEvents.update(lastType);
      } else if (TRIAGE_REVISION_KEY in changes) {
        inbox.invalidate();
        panel.invalidate();
        notes.invalidate();
        quick.invalidate();
        searches.invalidate();
        listing.invalidate();
        eventFilter.invalidate();
        compatibility.invalidate();
        cardSignals.invalidate();
        sharedEvents.invalidate();
        sharedEvents.update(lastType);
      } else if (NOTES_REVISION_KEY in changes) {
        notes.invalidate();
        cardSignals.invalidate();
      }
      if (SAVED_SEARCH_REVISION_KEY in changes) searches.invalidate();
      if (EVENT_REVISION_KEY in changes) {
        listing.invalidate();
        eventFilter.invalidate();
        sharedEvents.invalidate();
        sharedEvents.update(lastType);
        if (!(TRIAGE_REVISION_KEY in changes)) {
          inbox.invalidate();
          panel.invalidate();
        }
      }
    });
    const language = readLocale(runtimeSettingsArea).then((locale2) => {
      if (!localeChanged) setLocale(locale2);
    });
    void Promise.all([
      diagnostics.ready,
      templatePicker.ready,
      quickAction.ready,
      stripCollapsed.ready.then(
        () => setStripCollapsed(document, stripCollapsed.enabled, (value) => {
          void runtimeSettingsArea.set({ [STRIP_COLLAPSED_KEY]: value }).catch(() => void 0);
        })
      ),
      messageCaching.ready,
      accountRead,
      language
    ]).then(() => coordinator.start());
  }
})();
